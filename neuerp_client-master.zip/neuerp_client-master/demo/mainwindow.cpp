#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Network/Body/request.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    auto &client = MainClient::get_instance();
    // bind signal and function, advise bind signal when you use this gui, if not use, better to disconnect
    connect(&client, SIGNAL(notify_close()), this, SLOT(close_connection()));
    connect(&client, SIGNAL(notify_error(QString)), this, SLOT(error_message(QString)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_send_clicked()
{
    Request req;
    req.set_module("hello");
    req.set_func("hello");
    req.put("name", "chenhanlin");
    auto &client = MainClient::get_instance();
    client.send(req);
    // advise bind this signal when button pressed
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_resp(Response)));
}

void MainWindow::error_message(QString error)
{
    this->ui->label->setText(error);
}

void MainWindow::recv_resp(Response resp)
{
    this->ui->label->setText(resp.get_string("answer"));
    auto &client = MainClient::get_instance();
    // advise disconnect this signal when receive response
//    client.disconnect(SIGNAL(notify_resp(Response)));
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_resp(Response)));
}

void MainWindow::close_connection()
{
    this->ui->label->setText("close connection");
}
