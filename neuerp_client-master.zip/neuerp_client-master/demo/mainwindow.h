#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <Network/Client/mainclient.h>
#include "Network/Body/response.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    // button action
    void on_send_clicked();
    // when receive error
    void error_message(QString);
    // when receive response
    void recv_resp(Response);
    // when connection close
    void close_connection();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
