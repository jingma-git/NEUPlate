var myTitleTextStyle = {
    // // fontSize: 18,
    // fontWeight: 'bolder',
    // color: '#fff' ,
    // 'font-family':"Microsoft YaHei"
}
var myAxisLabelTextStyle = {
    // color:'#e8e8e8'
}

var mlog = function (text) {
    // var logh6 = document.getElementById("mlog");
    // logh6.innerText = logh6.innerText + "\n " + text;
}

var saleroom_year = function (ec) {
    //折线图，带缩放
    var option = {
        title: {
            text: '年度销售额走势',
            textStyle: myTitleTextStyle
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['销售额']
        },
        toolbox: {
            show: true,
            feature: {
                // mark: { show: true },
                // dataView: { show: true, readOnly: false },
                magicType: { show: true, type: ['line', 'bar'] },
                restore: { show: true },
                saveAsImage: { show: true }
            }
        },
        dataZoom: {
            show: true,
            start: 0,
            end: 100
        },
        calculable: true,
        xAxis: [
            {
                type: 'category',
                boundaryGap: false,
                data: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月']
            }
        ],
        yAxis: [
            {
                type: 'value',
                axisLabel: {
                    formatter: '{value} 元',
                }
            }
        ],
        series: [
            {
                name: '销售额',
                type: 'line',
                data: stat.getTotal_saleroom_year_saleroom(),
                markPoint: {
                    data: [
                        { type: 'max', name: '最大值' },
                        { type: 'min', name: '最小值' }
                    ]
                },
                markLine: {
                    data: [
                        { type: 'average', name: '平均值' }
                    ]
                }
            }
        ]
    };

    ec.init(document.getElementById("saleroom_year"), 'my_dark').setOption(option);
}

var saleroom_month = function (ec) {
    //折线图，带缩放
    var option = {
        title: {
            text: '30天销售额走势',
            textStyle: myTitleTextStyle
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['销售额']
        },
        toolbox: {
            show: true,
            feature: {
                // mark: { show: true },
                // dataView: { show: true, readOnly: false },
                magicType: { show: true, type: ['line', 'bar'] },
                restore: { show: true },
                saveAsImage: { show: true }
            }
        },
        dataZoom: {
            show: true,
            start: 0,
            end: 100
        },
        calculable: true,
        xAxis: [
            {
                type: 'category',
                boundaryGap: false,
                data: stat.getTotal_saleroom_month_date()
            }
        ],
        yAxis: [
            {
                type: 'value',
                axisLabel: {
                    formatter: '{value} 元'
                }
            }
        ],
        series: [
            {
                name: '销售额',
                type: 'line',
                data: stat.getTotal_saleroom_month_saleroom(),
                markPoint: {
                    data: [
                        { type: 'max', name: '最大值' },
                        { type: 'min', name: '最小值' }
                    ]
                },
                markLine: {
                    data: [
                        { type: 'average', name: '平均值' }
                    ]
                }
            }
        ]
    };
    ec.init(document.getElementById("saleroom_month"), 'my_dark').setOption(option);

}


var top10_products_week = function (ec) {
    //标准条形图
    var option = {
        title: {
            text: '周销量前10商品',
            textStyle: myTitleTextStyle
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['销量']
        },
        toolbox: {
            show: true,
            feature: {
                mark: { show: true },
                dataView: { show: true, readOnly: false },
                magicType: { show: true, type: ['line', 'bar'] },
                restore: { show: true },
                saveAsImage: { show: true }
            }
        },
        calculable: true,
        xAxis: [
            {
                type: 'value',
                boundaryGap: [0, 0.01]
            }
        ],
        yAxis: [
            {
                type: 'category',
                data: stat.getTop_product_week_name()
            }
        ],
        series: [
            {
                name: '销量',
                type: 'bar',
                data: stat.getTop_product_week_volume()
            }
        ]
    };
    ec.init(document.getElementById("top10_products_week"), 'my_dark').setOption(option);

}

var top10_products_month = function (ec) {
    //标准条形图
    var option = {
        title: {
            text: '月销量前10商品',
            textStyle: myTitleTextStyle
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['销量']
        },
        toolbox: {
            show: true,
            feature: {
                mark: { show: true },
                dataView: { show: true, readOnly: false },
                magicType: { show: true, type: ['line', 'bar'] },
                restore: { show: true },
                saveAsImage: { show: true }
            }
        },
        calculable: true,
        xAxis: [
            {
                type: 'value',
                boundaryGap: [0, 0.01]
            }
        ],
        yAxis: [
            {
                type: 'category',
                data: stat.getTop_product_month_name()
            }
        ],
        series: [
            {
                name: '销量',
                type: 'bar',
                data: stat.getTop_product_month_volume()
            }
        ]
    };
    ec.init(document.getElementById("top10_products_month"), 'my_dark').setOption(option);
}

var top10_products_month_trend = function (ec) {
    //折线图，带缩放
    var my_series = [];

    var top_product = stat.getTop_product_month_name();
    if (top_product.length > 5) {
        top_product = top_product.slice(0, 5);
    }
    mlog("top-product1:" + top_product[0]);
    mlog("top_product size" + top_product.length.toString());
    for (var index = 0; index < top_product.length; index++) {
        mlog("name:" + top_product[index]);
        mlog("volume" + stat.get_top_product_month_trend_volume_by_index(index).join("-"))
        var a_serie = {
            name: top_product[index],
            type: 'line',
            data: stat.get_top_product_month_trend_volume_by_index(index)
            // markPoint: {
            //     data: [
            //         { type: 'max', name: '最大值' },
            //         { type: 'min', name: '最小值' }
            //     ]
            // },
            // markLine: {
            //     data: [
            //         { type: 'average', name: '平均值' }
            //     ]
            // }
        }
        my_series.push(a_serie);
    }

    var option = {
        title: {
            text: '销售额走势',
            subtext: '本月销量前5商品',
            textStyle: myTitleTextStyle
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: top_product
        },
        toolbox: {
            show: true,
            feature: {
                // mark: { show: true },
                // dataView: { show: true, readOnly: false },
                magicType: { show: true, type: ['line', 'bar'] },
                restore: { show: true },
                saveAsImage: { show: true }
            }
        },
        dataZoom: {
            show: true,
            start: 0,
            end: 100
        },
        calculable: true,
        xAxis: [
            {
                type: 'category',
                boundaryGap: false,
                data: stat.getTop_product_month_trend_date(0)
            }
        ],
        yAxis: [
            {
                type: 'value',
                axisLabel: {
                    formatter: '{value} 件'
                }
            }
        ],
        series: my_series
    };
    ec.init(document.getElementById("top10_products_month_trend"), 'my_dark').setOption(option);
}


var top10_salers_week = function (ec) {
    //标准条形图
    var option = {
        title: {
            text: '周top10销售员',
            subtext: '按销售额计算',
            textStyle: myTitleTextStyle
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['销售额']
        },
        toolbox: {
            show: true,
            feature: {
                mark: { show: true },
                dataView: { show: true, readOnly: false },
                magicType: { show: true, type: ['line', 'bar'] },
                restore: { show: true },
                saveAsImage: { show: true }
            }
        },
        calculable: true,
        xAxis: [
            {
                type: 'value',
                boundaryGap: [0, 0.01]
            }
        ],
        yAxis: [
            {
                type: 'category',
                data: stat.getTop_salesman_week_name()
            }
        ],
        series: [
            {
                name: '销售额',
                type: 'bar',
                data: stat.getTop_salesman_week_saleroom()
            }
        ]
    };
    ec.init(document.getElementById("top10_salers_week"), 'my_dark').setOption(option);
}

var top10_salers_month = function (ec) {
    //标准条形图
    var option = {
        title: {
            text: '月top10销售员',
            textStyle: myTitleTextStyle,
            subtext: ''
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['销售额']
        },
        toolbox: {
            show: true,
            feature: {
                mark: { show: true },
                dataView: { show: true, readOnly: false },
                magicType: { show: true, type: ['line', 'bar'] },
                restore: { show: true },
                saveAsImage: { show: true }
            }
        },
        calculable: true,
        xAxis: [
            {
                type: 'value',
                boundaryGap: [0, 0.01]
            }
        ],
        yAxis: [
            {
                type: 'category',
                data: stat.getTop_salesman_month_name()
            }
        ],
        series: [
            {
                name: '销售额',
                type: 'bar',
                data: stat.getTop_salesman_month_saleroom()
            }
        ]
    };
    ec.init(document.getElementById("top10_salers_month"), 'my_dark').setOption(option);
}

var top10_salers_month_trend = function (ec) {
    //折线图，带缩放
    var my_series = [];
    var top_salesman = stat.getTop_salesman_month_name();
    if (top_salesman.length > 5) {
        top_salesman = top_salesman.slice(0, 5);
    }
    mlog("top_salesman size" + top_salesman.length.toString());
    for (var index = 0; index < top_salesman.length; index++) {
        mlog("name:" + top_salesman[index]);
        mlog("volume" + stat.get_top_salesman_month_trend_saleroom_by_index(index).join("-"))

        var a_serie = {
            name: top_salesman[index],
            type: 'line',
            data: stat.get_top_salesman_month_trend_saleroom_by_index(index)
        }
        my_series.push(a_serie);
    }

    var option = {
        title: {
            text: '销售额走势',
            subtext: 'top5销售员的销售额走势',
            textStyle: myTitleTextStyle
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: top_salesman
        },
        toolbox: {
            show: true,
            feature: {
                // mark: { show: true },
                // dataView: { show: true, readOnly: false },
                magicType: { show: true, type: ['line', 'bar'] },
                restore: { show: true },
                saveAsImage: { show: true }
            }
        },
        dataZoom: {
            show: true,
            start: 0,
            end: 100
        },
        calculable: true,
        xAxis: [
            {
                type: 'category',
                boundaryGap: false,
                data: stat.getTop_salesman_month_trend_date()
            }
        ],
        yAxis: [
            {
                type: 'value',
                axisLabel: {
                    formatter: '{value} 元'
                }
            }
        ],
        series: my_series
    };
    ec.init(document.getElementById("top10_salers_month_trend"), 'my_dark').setOption(option);
}