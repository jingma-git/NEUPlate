#include "UI/personalCenter/login.h"
#include "UI/neuerp.h"
#include "UI/appinit.h"
#include "demo/mainwindow.h"
#include "Network/Client/mainclient.h"
#include <QApplication>
#include <QTextCodec>
#include <QFile>
#include <UI/msgbox.h>
#include <UI/CutDialog/cut_photo_dialog.h>

int main(int argc, char *argv[])
{


    QApplication a(argc, argv);

#if (QT_VERSION <= QT_VERSION_CHECK(5,0,0))
#if _MSC_VER
    QTextCodec *codec = QTextCodec::codecForName("gbk");
#else
    QTextCodec *codec = QTextCodec::codecForName("utf-8");
#endif
    QTextCodec::setCodecForLocale(codec);
    QTextCodec::setCodecForCStrings(codec);
    QTextCodec::setCodecForTr(codec);
#else
    QTextCodec *codec = QTextCodec::codecForName("utf-8");
    QTextCodec::setCodecForLocale(codec);
#endif

    //加载样式表
    QFile file(":/qss/psblack.css");
    if (file.open(QFile::ReadOnly)) {
        QString qss = QLatin1String(file.readAll());
        QString paletteColor = qss.mid(20, 7);
        qApp->setPalette(QPalette(QColor(paletteColor)));
        qApp->setStyleSheet(qss);
        file.close();
    }

    a.setFont(QFont("Microsoft Yahei", 9));
    AppInit::Instance()->start();

    MainClient::get_instance().connect_to_server("127.0.0.1", 1234);
    Login l;
    NEUERP w;
    if(l.exec() == QDialog::Accepted){
        w.init_permission();
        w.show();
    }else{
        return 0;
    }

    return a.exec();
}