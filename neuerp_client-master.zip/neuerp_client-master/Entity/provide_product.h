#ifndef PROVIDE_PRODUCT_H
#define PROVIDE_PRODUCT_H

/**
* @projectName   provide_product.h
* @brief         This class store the supplier provide product's information
* @author        luxijia
* @date          2018-7-3
* @modify_author
* @modify_date
*/
#include <QString>

class ProvideProduct
{
public:
    const QString &getSp_name() const;
    const QString &getPp_id() const;
    const QString &getPp_name() const;
    double getPp_price() const;
    const QString &getSp_id() const;
    const QString &getPp_desc() const;
    void setSp_id(const QString &sp_id);
    void setSp_name(const QString &sp_name);
    void setPp_id(const QString &pp_id);
    void setPp_name(const QString &pp_name);
    void setPp_price(double pp_price);
    void setPp_desc(const QString &pp_desc);
private:
    QString sp_id;
    QString sp_name;
    QString pp_id;
    QString pp_name;
    QString pp_desc;
    double pp_price;
};

#endif // PROVIDE_PRODUCT_H
