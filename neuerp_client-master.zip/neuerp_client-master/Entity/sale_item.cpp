#include "sale_item.h"

const QString &SaleItem::getProduct_id() const
{
    return product_id;
}

void SaleItem::setProduct_id(const QString &product_id)
{
    SaleItem::product_id = product_id;
}

double SaleItem::getSale_price() const
{
    return sale_price;
}

void SaleItem::setSale_price(double sale_price)
{
    SaleItem::sale_price = sale_price;
}

int SaleItem::getSale_amount() const
{
    return sale_amount;
}

void SaleItem::setSale_amount(int sale_amount)
{
    SaleItem::sale_amount = sale_amount;
}

const QString &SaleItem::getProduct_name() const
{
    return product_name;
}

void SaleItem::setProduct_name(const QString &product_name)
{
    SaleItem::product_name = product_name;
}

