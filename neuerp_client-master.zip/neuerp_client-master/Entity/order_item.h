#ifndef ORDER_ITEM_H
#define ORDER_ITEM_H

#include <QJsonObject>
#include <QDebug>

class OrderItem
{
public:
    OrderItem();
    OrderItem(const OrderItem& other);
    OrderItem operator=(const OrderItem& other);
    bool operator==(const OrderItem& other);
    OrderItem(QJsonObject order_json);
    QJsonObject toJSON();
    QString toString();


    QString order_id;
    QString product_id;
    QString product_name;
    QString sp_id;
    QString sp_name;
    int amt;
    double pp_price;
};

#endif // ORDER_ITEM_H
