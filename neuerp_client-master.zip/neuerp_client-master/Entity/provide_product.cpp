#include "provide_product.h"

const QString &ProvideProduct::getSp_name() const
{
    return sp_name;
}

const QString &ProvideProduct::getPp_id() const
{
    return pp_id;
}

const QString &ProvideProduct::getPp_name() const
{
    return pp_name;
}

double ProvideProduct::getPp_price() const
{
    return pp_price;
}

const QString &ProvideProduct::getSp_id() const
{
    return sp_id;
}

const QString &ProvideProduct::getPp_desc() const
{
    return pp_desc;
}

void ProvideProduct::setSp_id(const QString &sp_id)
{
    ProvideProduct::sp_id = sp_id;
}

void ProvideProduct::setSp_name(const QString &sp_name)
{
    ProvideProduct::sp_name = sp_name;
}

void ProvideProduct::setPp_id(const QString &pp_id)
{
    ProvideProduct::pp_id = pp_id;
}

void ProvideProduct::setPp_name(const QString &pp_name)
{
    ProvideProduct::pp_name = pp_name;
}

void ProvideProduct::setPp_price(double pp_price)
{
    ProvideProduct::pp_price = pp_price;
}

void ProvideProduct::setPp_desc(const QString &pp_desc)
{
    ProvideProduct::pp_desc = pp_desc;
}
