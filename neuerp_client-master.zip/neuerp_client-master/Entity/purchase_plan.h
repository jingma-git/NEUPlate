#ifndef PURCHASE_PLAN_H
#define PURCHASE_PLAN_H

#include <QString>
#include <QJsonObject>
#include <QDateTime>

class Purchase_Plan
{
private:
    QString plan_id;
    QString name;
    QString date;
    int state;

public:
    static const int COMPLETED = 0;
    static const int EDITABLE = 1;

    Purchase_Plan(const QString &plan_id, const QString &name, const QString &date, int state);
    Purchase_Plan();
    Purchase_Plan(QJsonObject plan_json);
    QString toString();
    QJsonObject toJSON();
    void fromJSON(QJsonObject plan_json);

    const QString &get_plan_id() const;
    void set_plan_id(const QString &plan_id);

    const QString &get_name() const;
    void set_name(const QString &name);

    const QString &get_date() const;
    void set_date(const QString &date);

    int get_state() const;
    void set_state(int state);
};

#endif // PURCHASE_PLAN_H
