#include "user.h"

QString User::get_e_id() const
{
    return m_e_id;
}

QString User::get_name() const
{
    return m_name;
}

void User::set_name(const QString &name)
{
    m_name = name;
}

QString User::get_dept() const
{
    return m_dept;
}

void User::set_dept(const QString &dept)
{
    m_dept = dept;
}

employee_state User::get_e_state() const
{
    return m_e_state;
}

void User::set_e_state(const employee_state &e_state)
{
    m_e_state = e_state;
}

int User::get_u_state() const
{
    return m_u_status;
}

void User::set_u_state(const int u_status)
{
    m_u_status = u_status;
}

QString User::get_user_status_str(int state)
{
    if(User::USER_CLOSED & state){
        return QString("关闭");
    }else if(User::USER_FROZN & state){
        return QString("冻结");
    }else if(User::USER_NEW & state){
        return QString("新用户");
    }else if(User::USER_NORMAL & state){
        return QString("正常");
    }else{
        return QString("未知");
    }
}
