#ifndef Entity_PURCHASE_ORDER_H
#define Entity_PURCHASE_ORDER_H
#include <vector>
#include <QString>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QDebug>

#include "order_item.h"
class PurchaseOrder {
public:
    const static int WAIT_TO_PAY=0; //待支付
    const static int ON_DELIVER=1; //待收货
    const static int CONFIRMED=2; //确认收货

    QString order_id;
    QString sp_id;
    int state;
    QString date;
    std::vector<OrderItem> orderItems;

    PurchaseOrder();
    PurchaseOrder(const PurchaseOrder& other);
    PurchaseOrder& operator=(const PurchaseOrder& other);
    bool operator==(const PurchaseOrder& other);
    PurchaseOrder(QJsonObject order_json);
    QJsonObject toJSON();
    QString toString();
    double total_price();
};


#endif // Entity_PURCHASE_ORDER_H
