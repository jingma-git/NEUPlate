#include "supplier.h"

const QString &Supplier::getSp_id() const
{
    return sp_id;
}

const QString &Supplier::getSp_name() const
{
    return sp_name;
}

//const QString &Supplier::getSp_country() const
//{
//    return sp_country;
//}

//const QString &Supplier::getSp_province() const
//{
//    return sp_province;
//}

//const QString &Supplier::getSp_city() const
//{
//    return sp_city;
//}

const QString &Supplier::getSp_region() const
{
    return sp_region;
}

const QString &Supplier::getSp_phone() const
{
    return sp_phone;
}

const QString &Supplier::getContact() const
{
    return contact;
}

int Supplier::getSp_state() const
{
    return sp_state;
}

void Supplier::setSp_id(const QString &sp_id)
{
    Supplier::sp_id = sp_id;
}

void Supplier::setSp_name(const QString &sp_name)
{
    Supplier::sp_name = sp_name;
}

//void Supplier::setSp_country(const QString &sp_country)
//{
//    Supplier::sp_country = sp_country;
//}

//void Supplier::setSp_province(const QString &sp_province)
//{
//    Supplier::sp_province = sp_province;
//}

//void Supplier::setSp_city(const QString &sp_city)
//{
//    Supplier::sp_city = sp_city;
//}

void Supplier::setSp_region(const QString &sp_region)
{
    Supplier::sp_region = sp_region;
}

void Supplier::setSp_phone(const QString &sp_phone)
{
    Supplier::sp_phone = sp_phone;
}

void Supplier::setContact(const QString &contact)
{
    Supplier::contact = contact;
}

void Supplier::setSp_state(int sp_state)
{
    Supplier::sp_state = sp_state;
}
