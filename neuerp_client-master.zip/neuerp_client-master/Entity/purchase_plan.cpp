#include "purchase_plan.h"

Purchase_Plan::Purchase_Plan(){

}

Purchase_Plan::Purchase_Plan(const QString &plan_id, const QString &name,
                             const QString &date, int state):
    plan_id(plan_id),name(name),date(date),state(state){}

Purchase_Plan::Purchase_Plan(QJsonObject plan_json){
    fromJSON(plan_json);
}
void Purchase_Plan::fromJSON(QJsonObject plan_json){
    plan_id=plan_json.value("plan_id").toString();
    name=plan_json.value("name").toString();
    date=plan_json.value("date").toString();
    state=plan_json.value("state").toInt();
}

QString Purchase_Plan::toString(){
    return plan_id + " "+ name +" "+date+" "+QString::number(state);
}

QJsonObject Purchase_Plan::toJSON(){
    QJsonObject plan_json;
    plan_json.insert("plan_id", plan_id);
    plan_json.insert("name",name);
    plan_json.insert("date",date);
    plan_json.insert("state",state);
    return plan_json;
}

const QString &Purchase_Plan::get_plan_id() const{
    return plan_id;
}
void Purchase_Plan::set_plan_id(const QString &plan_id){
    this->plan_id = plan_id;
}

const QString &Purchase_Plan::get_name() const{
    return name;
}
void Purchase_Plan::set_name(const QString &name){
    this->name = name;
}

const QString &Purchase_Plan::get_date() const{
    return date;
}
void Purchase_Plan::set_date(const QString &date){
    this->date = date;
}

int Purchase_Plan::get_state() const{
    return state;
}
void Purchase_Plan::set_state(int state){
    this->state = state;
}
