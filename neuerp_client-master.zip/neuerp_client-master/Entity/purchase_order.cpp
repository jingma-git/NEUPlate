#include <Entity/purchase_order.h>
PurchaseOrder::PurchaseOrder(){

}

PurchaseOrder::PurchaseOrder(const PurchaseOrder& other){
    qDebug()<<"PurchaseOrder::PurchaseOrder(const PurchaseOrder& other)";
    if(this!=&other){
     this->order_id = other.order_id;
     this->sp_id = other.sp_id;
     this->state = other.state;qDebug()<<"this->state = other.state;"<<QString::number(this->state);
     this->date = other.date;
     int size = other.orderItems.size();
     this->orderItems.clear();
     for(int i=0; i<size; i++){
         this->orderItems.push_back(other.orderItems[i]);
     }
     //qDebug()<<"this->orderItems.size();"<<QString::number(this->orderItems.size())<<"other.orderItems.size()"<<QString::number(size);
    }
}

PurchaseOrder& PurchaseOrder::operator=(const PurchaseOrder& other){
    qDebug()<<"PurchaseOrder::operator=)";
    if(this!=&other){ qDebug()<<"if(this!=&other){";
        this->order_id = other.order_id;
        this->sp_id = other.sp_id;
        this->state = other.state;
        this->date = other.date;
        int size = other.orderItems.size();
        this->orderItems.clear();
        for(int i=0; i<size; i++){
            this->orderItems.push_back(other.orderItems[i]);
        }
    }
    return *this;
}

bool PurchaseOrder::operator==(const PurchaseOrder& other){
    int size = other.orderItems.size();
    int this_size = this->orderItems.size();
    if(this_size!=size) return false;
    for(int i=0; i<size; i++){
        if(!(this->orderItems[i]==other.orderItems[i])){
            return false;
        }
    }

    return this->order_id==other.order_id && this->sp_id==other.sp_id
            && this->state==other.state && this->date==other.date;
}

PurchaseOrder::PurchaseOrder(QJsonObject order_json){
    order_id = order_json.value("order_id").toString();
    sp_id = order_json.value("sp_id").toString();
    state = order_json.value("state").toInt();
    date = order_json.value("date").toString();
    QJsonArray orderItemArray = order_json.value("order_items").toArray();
    foreach(const QJsonValue& value, orderItemArray){
        OrderItem orderItem(value.toObject());
        orderItems.push_back(orderItem);
    }
}

QJsonObject PurchaseOrder::toJSON(){
    QJsonObject order_json;
    order_json.insert("order_id", order_id);
    order_json.insert("sp_id",sp_id);
    order_json.insert("state",state);
    order_json.insert("date",date);
    QJsonArray orderItemArray;
    for(OrderItem orderItem:orderItems){
        orderItemArray.append(orderItem.toJSON());
    }
    order_json.insert("order_items", orderItemArray);
    return order_json;
}
QString PurchaseOrder::toString(){
    return "order_id "+order_id + "\n" +
            "sp_id "+sp_id + "\n"+
            "state "+state + "\n" +
            "date "+date +"\n**********"+orderItems[0].toString()+"\n\n\n";
}

double PurchaseOrder::total_price(){
    //qDebug()<<"PurchaseOrder::total_price()";
    double total = 0;
    for(OrderItem orderItem:orderItems){
        total+= orderItem.pp_price * orderItem.amt;
    }
    return total;
}
