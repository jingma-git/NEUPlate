#include "employee.h"


Employee::Employee(const QString &name, const QString &dept, const QString &position, Gender gender,
                   const QDate &birthday, const QString &birth_place, const QString &nation, bool married, const QString &political_status,
                   Education edu, const QString id, const QString &address, const QString &phone, const QString &email,
                   const QPixmap &photo, const QString &e_c_name, const QString &e_c_phone, const QString &e_c_address,
                   employee_state state)
    :m_str_name(name), m_str_department(dept), m_str_position(position), m_gender(gender), m_t_birthday(birthday),
      m_str_birth_place(birth_place), m_str_nation(nation), m_b_married(married), m_str_political_status(political_status),
      m_education(edu), m_str_id(id), m_str_address(address), m_str_telephone(phone), m_str_email(email), m_photo(photo),
      m_str_emergency_contact_name(e_c_name), m_str_emergency_contact_phone(e_c_phone), m_str_emergency_contact_address(e_c_address),
      m_state(state)
{

}

QString Employee::get_name() const
{
    return m_str_name;
}

void Employee::set_name(const QString &str_name)
{
    m_str_name = str_name;
}

QString Employee::get_department() const
{
    return m_str_department;
}

void Employee::set_department(const QString &str_department)
{
    m_str_department = str_department;
}

QString Employee::get_position() const
{
    return m_str_position;
}

void Employee::set_position(const QString &str_position)
{
    m_str_position = str_position;
}

Gender Employee::get_gender() const
{
    return m_gender;
}

void Employee::set_gender(const Gender &gender)
{
    m_gender = gender;
}

QDate Employee::get_birthday() const
{
    return m_t_birthday;
}

void Employee::set_birthday(const QDate &t_birthday)
{
    m_t_birthday = t_birthday;
}

QString Employee::get_birth_place() const
{
    return m_str_birth_place;
}

void Employee::set_birth_place(const QString &str_birth_place)
{
    m_str_birth_place = str_birth_place;
}

QString Employee::get_nation() const
{
    return m_str_nation;
}

void Employee::set_nation(const QString &str_nation)
{
    m_str_nation = str_nation;
}

bool Employee::is_married() const
{
    return m_b_married;
}

void Employee::set_married(bool b_married)
{
    m_b_married = b_married;
}

QString Employee::get_political_status() const
{
    return m_str_political_status;
}

void Employee::set_political_status(const QString &str_political_status)
{
    m_str_political_status = str_political_status;
}

Education Employee::get_education() const
{
    return m_education;
}

void Employee::set_education(const Education &education)
{
    m_education = education;
}

QString Employee::get_id() const
{
    return m_str_id;
}

void Employee::set_id(const QString &str_id)
{
    m_str_id = str_id;
}

QString Employee::get_address() const
{
    return m_str_address;
}

void Employee::set_address(const QString &str_address)
{
    m_str_address = str_address;
}

QString Employee::get_telephone() const
{
    return m_str_telephone;
}

void Employee::set_telephone(const QString &str_telephone)
{
    m_str_telephone = str_telephone;
}

QString Employee::get_email() const
{
    return m_str_email;
}

void Employee::set_email(const QString &str_email)
{
    m_str_email = str_email;
}

QString Employee::get_emergency_contact_name() const
{
    return m_str_emergency_contact_name;
}

void Employee::set_emergency_contact_name(const QString &str_emergency_contact_name)
{
    m_str_emergency_contact_name = str_emergency_contact_name;
}

QString Employee::get_emergency_contact_phone() const
{
    return m_str_emergency_contact_phone;
}

void Employee::set_emergency_contact_phone(const QString &str_emergency_contact_phone)
{
    m_str_emergency_contact_phone = str_emergency_contact_phone;
}

QString Employee::get_emergency_contact_address() const
{
    return m_str_emergency_contact_address;
}

void Employee::set_emergency_contact_address(const QString &str_emergency_contact_address)
{
    m_str_emergency_contact_address = str_emergency_contact_address;
}

employee_state Employee::get_state() const
{
    return m_state;
}

void Employee::set_state(const employee_state &state)
{
    m_state = state;
}

QString Employee::get_str_state() const
{
    switch (m_state) {
    case employee_state::normal:
        return QString("正常");
    case employee_state::resignation:
        return QString("离职");
    }
    return QString();
}

QString Employee::get_str_state(employee_state state)
{
    switch (state) {
    case employee_state::normal:
        return QString("正常");
    case employee_state::resignation:
        return QString("离职");
    }
    return QString();
}

/**
* @functionName  to_json
* @Description   put object data into json
* @author        chenhanlin
* @date          2018-07-05
* @parameter     void
* @return        QjsonObject
*/
QJsonObject Employee::to_json() const
{
    QJsonObject json;
    json.insert("name", m_str_name);
    json.insert("department", m_str_department);
    json.insert("position", m_str_position);
    json.insert("gender", int(m_gender));
    json.insert("birthday", m_t_birthday.toString());
    json.insert("birth_place", m_str_birth_place);
    json.insert("nation", m_str_nation);
    json.insert("married", m_b_married);
    json.insert("political_status", m_str_political_status);
    json.insert("education", int(m_education));
    json.insert("id", m_str_id);
    json.insert("address", m_str_address);
    json.insert("telephone", m_str_telephone);
    json.insert("email", m_str_email);
//    json.insert("photo_path", m_str_photo_path);
    json.insert("emergency_contact_name", m_str_emergency_contact_name);
    json.insert("emergency_contact_phone", m_str_emergency_contact_phone);
    json.insert("emergency_contact_address", m_str_emergency_contact_address);
    json.insert("state", int(m_state));
    return json;
}

QPixmap Employee::get_photo() const
{
    return m_photo;
}

void Employee::set_photo(const QPixmap &photo)
{
    m_photo = photo;

}
