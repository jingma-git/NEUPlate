#ifndef SALE_ITEM_H
#define SALE_ITEM_H

/**
* @projectName   neuerp
* @brief         This class store the sale list item information.
* @author        luxijia
* @date          2018-7-5
* @modify_author
* @modify_date
*/
#include <QString>

class SaleItem
{
public:
    const QString &getProduct_id() const;
    void setProduct_id(const QString &product_id);
    double getSale_price() const;
    void setSale_price(double sale_price);
    int getSale_amount() const;
    void setSale_amount(int sale_amount);
    const QString &getProduct_name() const;
    void setProduct_name(const QString &product_name);
private:
    QString product_id;
    QString product_name;
    double sale_price;
    int sale_amount;
};

#endif // SALE_ITEM_H
