#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <QString>
#include <QJsonObject>
#include <QDate>
#include <QPixmap>


enum class Gender {male = 0, female};
enum class Education {secret = 0, primary_school, junior_high_school, high_school, bachelor, master, doctor};
enum class employee_state {normal = 0, resignation};

class Employee
{
public:
    Employee(const QString &name, const QString &dept, const QString &position,
             Gender get_gender, const QDate &birthday, const QString &birth_place, const QString &nation,
             bool married, const QString &political_status, Education edu, const QString id,
             const QString &address, const QString &phone, const QString &email, const QPixmap &photo,
             const QString &e_c_name, const QString &e_c_phone, const QString &e_c_address, employee_state get_state);

    QString get_name() const;
    void set_name(const QString &get_name);

    QString get_department() const;
    void set_department(const QString &get_department);

    QString get_position() const;
    void set_position(const QString &get_position);

    Gender get_gender() const;
    void set_gender(const Gender &get_gender);

    QDate get_birthday() const;
    void set_birthday(const QDate &get_birthday);

    QString get_birth_place() const;
    void set_birth_place(const QString &get_birth_place);

    QString get_nation() const;
    void set_nation(const QString &get_nation);

    bool is_married() const;
    void set_married(bool is_married);

    QString get_political_status() const;
    void set_political_status(const QString &get_political_status);

    Education get_education() const;
    void set_education(const Education &get_education);

    QString get_id() const;
    void set_id(const QString &get_id);

    QString get_address() const;
    void set_address(const QString &get_address);

    QString get_telephone() const;
    void set_telephone(const QString &get_telephone);

    QString get_email() const;
    void set_email(const QString &get_email);

    QString get_emergency_contact_name() const;
    void set_emergency_contact_name(const QString &get_emergency_contact_name);

    QString get_emergency_contact_phone() const;
    void set_emergency_contact_phone(const QString &get_emergency_contact_phone);

    QString get_emergency_contact_address() const;
    void set_emergency_contact_address(const QString &get_emergency_contact_address);

    employee_state get_state() const;
    void set_state(const employee_state &get_state);
    QString get_str_state() const;
    static QString get_str_state(employee_state state);

    QJsonObject to_json() const;

    QPixmap get_photo() const;
    void set_photo(const QPixmap &photo);

private:

    QString m_str_name;
    QString m_str_department;
    QString m_str_position;
    Gender m_gender;
    QDate m_t_birthday;
    QString m_str_birth_place;
    QString m_str_nation;
    bool m_b_married;
    QString m_str_political_status;
    Education m_education;
    QString m_str_id;
    QString m_str_address;
    QString m_str_telephone;
    QString m_str_email;
    QPixmap m_photo;
    QString m_str_emergency_contact_name;
    QString m_str_emergency_contact_phone;
    QString m_str_emergency_contact_address;
    employee_state m_state;
};

#endif // EMPLOYEE_H
