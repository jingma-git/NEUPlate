﻿/**
* @projectName   neuerp_server
* @brief         class user, contain the information of employee's account and access to database
* @author        chenhanlin
* @date          2018-07-02
*/
#ifndef USER_H
#define USER_H

#include <QString>
#include <vector>
#include <map>
#include "Entity/employee.h"

class User
{
public:
    static const int USER_NORMAL = 1;
    static const int USER_FROZN = 2;
    static const int USER_CLOSED = 4;
    static const int USER_NEW = 8;
public:

    QString get_e_id() const;

    QString get_name() const;
    void set_name(const QString &get_name);

    QString get_dept() const;
    void set_dept(const QString &get_dept);

    employee_state get_e_state() const;
    void set_e_state(const employee_state &get_e_state);

    int get_u_state() const;
    void set_u_state(const int get_u_state);

    static QString get_user_status_str(int state);

private:
    QString m_e_id;
    QString m_name;
    QString m_dept;
    employee_state m_e_state;
    int m_u_status;
};

#endif // USER_H
