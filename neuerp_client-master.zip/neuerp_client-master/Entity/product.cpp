//
// Created by xiaha on 2018/7/3.
//

#include "product.h"
#include <QJsonObject> 

const QString &Product::getP_id() const {
    return p_id;
}

void Product::setP_id(const QString &p_id) {
    Product::p_id = p_id;
}

const QString &Product::getBar_code() const {
    return bar_code;
}

void Product::setBar_code(const QString &bar_code) {
    Product::bar_code = bar_code;
}

const QString &Product::getName() const {
    return name;
}

void Product::setName(const QString &name) {
    Product::name = name;
}

double Product::getPrice() const {
    return price;
}

void Product::setPrice(double price) {
    Product::price = price;
}

const QString &Product::getDescription() const {
    return description;
}

void Product::setDescription(const QString &description) {
    Product::description = description;
}

const QString &Product::get_photo() const {
    return photo;
}

void Product::set_photo(const QString &img_url) {
    Product::photo = img_url;
}

int Product::getState() const {
    return state;
}

void Product::setState(int state) {
    Product::state = state;
}

Product::Product(const QString &p_id, const QString &bar_code, const QString &name, double price,
                 const QString &description, const QString &img_url, int state,int amount) : p_id(p_id), bar_code(bar_code),
                                                                                  name(name), price(price),
                                                                                  description(description),
                                                                                  photo(img_url), state(state),stock_amount(amount) {}

Product::Product()
{

}

QJsonObject Product::toJSON()
{
    QJsonObject product_json;
    product_json.insert("p_id",getP_id());
    product_json.insert("name",getName());
    product_json.insert("price",getPrice());
    product_json.insert("bar_code",getBar_code());
    product_json.insert("description",getDescription());
    product_json.insert("photo",get_photo());
    product_json.insert("state",getState());
    product_json.insert("stock_amount",getStock_amount());
    return product_json;

}


Product::Product(const QJsonObject &product_json){
    p_id=product_json.value("p_id").toString();
    name=product_json.value("name").toString();
    price=product_json.value("price").toDouble();
    state=product_json.value("state").toInt();
    stock_amount=product_json.value("stock_amount").toInt();
    bar_code=product_json.value("bar_code").toString();
    description=product_json.value("description").toString();
    photo=product_json.value("photo").toString();
}

const int &Product::getStock_amount() const
{
    return stock_amount;

}

void Product::setStock_amount(const int amount)
{
    this->stock_amount=amount;
}

Product::~Product() {

}
