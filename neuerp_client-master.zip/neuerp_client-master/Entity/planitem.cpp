#include "planitem.h"

PlanItem::PlanItem()
{
}

PlanItem::PlanItem(const PlanItem& other){
       if(this!=&other){
        this->plan_id = other.plan_id;
        this->product_id = other.product_id;
        this->product_name = other.product_name;
        this->sp_id = other.sp_id;
        this->sp_name = other.sp_name;
        this->amt = other.amt;
        this->pp_price = other.pp_price;
       }
}

PlanItem PlanItem::operator=(const PlanItem& other){
    if(this!=&other){
        this->plan_id = other.plan_id;
        this->product_id = other.product_id;
        this->product_name = other.product_name;
        this->sp_id = other.sp_id;
        this->sp_name = other.sp_name;
        this->amt = other.amt;
        this->pp_price = other.pp_price;
    }
    return *this;
}

PlanItem::PlanItem(QJsonObject planItem_json){
    plan_id = planItem_json.value("plan_id").toString();
    product_id = planItem_json.value("product_id").toString();
    product_name = planItem_json.value("product_name").toString();
    sp_id = planItem_json.value("sp_id").toString();
    sp_name = planItem_json.value("sp_name").toString();
    amt = planItem_json.value("amt").toInt();
    pp_price = planItem_json.value("pp_price").toDouble();
}

QJsonObject PlanItem::toJSON(){
    QJsonObject plan_json;
    plan_json.insert("plan_id", plan_id);
    plan_json.insert("product_id",product_id);
    plan_json.insert("product_name",product_name);
    plan_json.insert("sp_id",sp_id);
    plan_json.insert("sp_name",sp_name);
    plan_json.insert("amt",amt);
    plan_json.insert("pp_price", pp_price);
    return plan_json;
}


