#include "order_item.h"

OrderItem::OrderItem()
{
}

OrderItem::OrderItem(const OrderItem& other){

       if(this!=&other){
        this->order_id = other.order_id;
        this->product_id = other.product_id;
        this->product_name = other.product_name;
        this->sp_id = other.sp_id;
        this->sp_name = other.sp_name;
        this->amt = other.amt;
        this->pp_price = other.pp_price;
       }
}

OrderItem OrderItem::operator=(const OrderItem& other){
   if(this!=&other){
    this->order_id = other.order_id;
    this->product_id = other.product_id;
    this->product_name = other.product_name;
    this->sp_id = other.sp_id;
    this->sp_name = other.sp_name;
    this->amt = other.amt;
    this->pp_price = other.pp_price;
   }
    return *this;
}

bool OrderItem::operator==(const OrderItem& other){
    return this->order_id==other.order_id && this->product_id==other.product_id
            && this->product_name==other.product_name && this->sp_id==other.sp_id
            && this->sp_name==other.sp_name && this->amt==other.amt && this->pp_price==other.pp_price;
}

OrderItem::OrderItem(QJsonObject orderItem_json){
    order_id = orderItem_json.value("order_id").toString();
    product_id = orderItem_json.value("product_id").toString();
    product_name = orderItem_json.value("product_name").toString();
    sp_id = orderItem_json.value("sp_id").toString();
    sp_name = orderItem_json.value("sp_name").toString();
    amt = orderItem_json.value("amt").toInt();
    pp_price = orderItem_json.value("pp_price").toDouble();
}

QJsonObject OrderItem::toJSON(){
    QJsonObject order_json;
    order_json.insert("order_id", order_id);
    order_json.insert("product_id",product_id);
    order_json.insert("product_name",product_name);
    order_json.insert("sp_id",sp_id);
    order_json.insert("sp_name",sp_name);
    order_json.insert("amt",amt);
    order_json.insert("pp_price", pp_price);
    return order_json;
}

QString OrderItem::toString(){
    return "order_id " + order_id + "\n" +
            "product_id " + product_id + "\n" +
            "product_name " + product_name + "\n" +
            "sp_id " + sp_id + "\n" +
            "sp_name " + sp_name + "\n"+
            "amt " + QString::number(amt) + "\n"+
            "pp_price " + QString::number(pp_price, 'g', 2)+"\n\n";
}

