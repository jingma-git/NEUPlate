#ifndef PLANITEM_H
#define PLANITEM_H
#include <QString>
#include <QJsonObject>
class PlanItem
{
public:
    PlanItem();
    PlanItem(const PlanItem& other);
    PlanItem operator=(const PlanItem& other);
    PlanItem(QJsonObject plan_json);
    QJsonObject toJSON();


    QString plan_id;
    QString product_id;
    QString product_name;
    QString sp_id;
    QString sp_name;
    int amt;
    double pp_price;
};

#endif // PLANITEM_H
