#include "response.h"
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QByteArray>

Response::Response()
{

}

Response::Response(const QJsonObject &json)
    :Body(json["params"].toObject()),
      m_i_status_code(json["code"].toInt()),
      m_str_desc(json["desc"].toString()),
      m_module(json["module"].toString()),
      m_func(json["func"].toString())
{

}

Response::Response(int status_code, const QString &desc)
    :m_i_status_code(status_code),
      m_str_desc(desc)
{

}

int Response::get_status_code() const
{
    return m_i_status_code;
}

void Response::set_status_code(int i_status_code)
{
    m_i_status_code = i_status_code;
}

QString Response::get_desc() const
{
    return m_str_desc;
}

void Response::set_desc(const QString &str_desc)
{
    m_str_desc = str_desc;
}

#ifdef SERVER
QString Response::transfer_to_json()
{
    QJsonObject json;
    json.insert(QString("code"), m_i_status_code);
    json.insert(QString("desc"), m_str_desc);
    json.insert(QString("params"), m_json_params);
    json.insert(QString("module"), m_module);
    json.insert(QString("func"), m_func);
    QJsonDocument json_doc(json);
    QByteArray json_data(json_doc.toJson(QJsonDocument::Compact));
    return QString(json_data);
}

QString Response::get_module() const
{
    return m_module;
}

void Response::set_module(const QString &module)
{
    m_module = module;
}

QString Response::get_func() const
{
    return m_func;
}

void Response::set_func(const QString &func)
{
    m_func = func;
}
#endif
