/**
* @projectName   network_client
* @brief         network layer in client, send data and receive data
* @author        chenhanlin
* @date          2018-07-03
*/

#ifndef MAINCLIENT_H
#define MAINCLIENT_H

#include <QObject>
#include <QTcpSocket>
#include <queue>
#include "Network/Body/request.h"
#include "Network/Body/response.h"

class MainClient : public QObject
{
    Q_OBJECT
public:
    static MainClient &get_instance();
    void connect_to_server(const QString &host, int port);
    void send(const Request &req);

private:
    QTcpSocket m_socket;
    QString m_cache;
    std::queue<QString> m_req_queue;

    explicit MainClient(QObject *parent = nullptr);
    ~MainClient();
    MainClient(const MainClient &mainclient);
    MainClient& operator =(const MainClient &mainclient);
signals:
    void notify_error(QString);
    void notify_close();
    void notify_resp(Response);

public slots:
    void connection_close();
    void message_arrive();
    void error_occours();
};

#endif // MAINCLIENT_H
