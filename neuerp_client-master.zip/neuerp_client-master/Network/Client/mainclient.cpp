#include "mainclient.h"
#include <QDebug>
#include <QJsonObject>
#include <QJsonDocument>
#include <QByteArray>
#include <QHostAddress>
#include <QStringList>

/**
* @functionName  get_instance
* @Description   get the singleton MainClient class
* @author        chenhanlin
* @date          2018-07-03
* @parameter     void
* @return        void
*/
MainClient &MainClient::get_instance()
{
    static MainClient client;
    return client;
}

/**
* @functionName  connect_to_server
* @Description   connect socket with server
* @author        chenhanlin
* @date          2018-07-03
* @parameter     std::string host, int port
* @return        void
*/
void MainClient::connect_to_server(const QString &host, int port)
{
    m_socket.connectToHost(host, port);
}

/**
* @functionName  send
* @Description   send data in request to server
* @author        chenhanlin
* @date          2018-07-03
* @parameter     Request &req
* @return        void
*/
void MainClient::send(const Request &req)
{
    if(!m_socket.isWritable()) emit notify_error(tr("socket is not writable"));
    QString send_data(req.transfer_to_json() + "\r\n\r\n");
    if(req.get_func() != "add_employee")
    qDebug() << send_data;
    qDebug() << send_data;
    m_socket.write(send_data.toUtf8());
}

MainClient::MainClient(QObject *parent) : QObject(parent)
{
    connect(&m_socket, SIGNAL(readyRead()), this, SLOT(message_arrive()));
    connect(&m_socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(error_occours()));
    connect(&m_socket, SIGNAL(disconnected()), this, SLOT(connection_close()));
}

MainClient::~MainClient()
{

}

MainClient::MainClient(const MainClient &mainclient)
{

}

MainClient &MainClient::operator =(const MainClient &mainclient)
{

}

/**
* @functionName  connection_close
* @Description   excute in socket close connection
* @author        chenhanlin
* @date          2018-07-03
* @parameter     void
* @return        void
*/
void MainClient::connection_close()
{
    qDebug() << "close connection with " << m_socket.peerAddress().toString() << " :" << m_socket.peerPort();
    m_socket.close();
    emit notify_close();
}

/**
* @functionName  message_arrive
* @Description   receive data from sever and put them into response
* @author        chenhanlin
* @date          2018-07-03
* @parameter     void
* @return        void
*/
void MainClient::message_arrive()
{
    m_cache += m_socket.readAll();
    // split request
    QStringList reqs = m_cache.split("\r\n\r\n");
    // if not receive totally, save into cache
    if(!m_cache.endsWith("\r\n\r\n")){
        m_cache = reqs[reqs.size() - 1];
        for (int i=0; i < reqs.size()-1; i++)
            m_req_queue.push(reqs[i]);
    }else{
        m_cache.clear();
        for (int i=0; i < reqs.size(); i++)
            m_req_queue.push(reqs[i]);
    }
    while (!m_req_queue.empty()) {
        QString message(m_req_queue.front());
        m_req_queue.pop();
        if(message.isEmpty()) continue;
        qDebug() << message;
        QJsonDocument json_doc(QJsonDocument::fromJson(message.toUtf8()));
        QJsonObject json(json_doc.object());
        emit notify_resp(Response(json));
    }
}

/**
* @functionName  error_occurs
* @Description   send error message to gui class
* @author        chenhanlin
* @date          2018-07-03
* @parameter     void
* @return        void
*/
void MainClient::error_occours()
{
    QString error(m_socket.errorString());
    qDebug() << error;
    emit notify_error(error);
}
