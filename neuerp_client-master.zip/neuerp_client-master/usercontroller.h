#ifndef USERCONTROLLER_H
#define USERCONTROLLER_H

#include <QString>
#include <map>

class UserController
{
public:
    static UserController& get_instance();
    QString get_e_id() const;
    void set_e_id(const QString &value);

    int get_access_code() const;
    void set_access_code(int value);

    void add_permission(const QString &permission, int code, const QString &desc);
    bool check_access_code(const QString &permission, int access_code);
    bool check_access_code(const QString &permission);

    std::vector<QString> get_permission_desc();
    int get_access_code(const QString &permission) const;
    QString get_permission(const QString &desc);

private:
    UserController();
    ~UserController();
    UserController(const UserController &controller);
    UserController &operator =(const UserController &controller);
    QString e_id;
    int access_code;
    std::map<QString, int> permission;
    std::map<QString, QString> permission_desc;
};

#endif // USERCONTROLLER_H
