#include "add_employee_dialog.h"
#include "ui_add_employee_dialog.h"
#include "UI/iconhelper.h"
#include <QFileDialog>
#include <QFile>
#include <QDate>
#include <QByteArray>
#include <QPixmap>
#include "UI/msgbox.h"
#include "status_code.h"
#include <QRegExp>
#include <QRegExpValidator>

const int AddEmployeeDialog::photo_size = 150;

AddEmployeeDialog::AddEmployeeDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddEmployeeDialog),
    client(MainClient::get_instance())
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    cut = new CutPhotoDialog;
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
    init_lineedit();
    connect(cut, SIGNAL(notify_data(QByteArray)), this, SLOT(receive_photo_data(QByteArray)));
    connect(cut, SIGNAL(notify_pixmap(QPixmap)), this, SLOT(receive_pixmap(QPixmap)));
}

AddEmployeeDialog::~AddEmployeeDialog()
{
    delete ui;
    delete wait;
    delete cut;
}

void AddEmployeeDialog::modify_employee(const QString &e_id)
{
    this->e_id = e_id;
    Request req;
    req.set_module("employee");
    req.set_func("query_employee");
    req.put("keyword", e_id);
    req.put("page", 0);
    req.put("item", 1);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(query_resp(Response)));
    client.send(req);
    wait->start();
}

void AddEmployeeDialog::on_btnMenu_Close_clicked()
{
    reset();
    close();
    this->reject();
}

void AddEmployeeDialog::on_btn_submit_clicked()
{
    submit_employee();
}

/**
* @functionName  on_btn_upload_clicked
* @Description   upoload button trigger
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void AddEmployeeDialog::on_btn_upload_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this, tr("选择图片"), "./", tr("图片文件(*.png *.jpg)"));
    if(filename.isEmpty())return;
    wait->start();
    cut->load_photo(filename);
    wait->stop();
    cut->setModal(true);
    cut->show();
}

void AddEmployeeDialog::on_btn_cancel_clicked()
{
    reset();
    close();
    this->reject();
}

/**
* @functionName  add_resp
* @Description   handle the response from add_employee
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void AddEmployeeDialog::add_resp(Response resp)
{
    if("employee" != resp.get_module() || "add_employee" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(add_resp(Response)));
    wait->stop();

    if(SUCCESS != resp.get_status_code()){
        MsgBox::warming(this, tr("添加员工"), tr("系统错误，请稍后再试"));
        return;
    }
    this->reset();
    this->close();
    this->accept();
}

void AddEmployeeDialog::modify_resp(Response resp)
{
    if("employee" != resp.get_module() || "modify_all" != resp.get_func()) return;

    if(SUCCESS != resp.get_status_code()){
        MsgBox::warming(this, tr("编辑员工信息"), tr("系统错误，请稍后再试"));
        return;
    }
    this->reset();
    this->close();
    this->accept();
}

/**
* @functionName  query_resp
* @Description   handle the response from query_employee
* @author        chenhanlin
* @date          2018-07-10
* @parameter     Response resp
* @return        void
*/
void AddEmployeeDialog::query_resp(Response resp)
{
    if("employee" != resp.get_module() || "query_employee" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(query_resp(Response)));
    wait->stop();

    if(SUCCESS != resp.get_status_code()){
        MsgBox::warming(this, tr("编辑员工信息"), tr("系统错误，请稍后再试"));
        return;
    }

    QJsonObject employee(resp.get_json(e_id));

    ui->name->setText(employee["name"].toString());
    ui->dept->setCurrentIndex(ui->dept->findText(employee["department"].toString()));
    ui->position->setText(employee["position"].toString());
    ui->sex->setCurrentIndex(employee["gender"].toInt());
    ui->birthday->setDate(QDate::fromString(employee["birthday"].toString()));
    ui->birth_place->setText(employee["birth_place"].toString());
    ui->nation->setText(employee["nation"].toString());
    ui->married->setCurrentIndex(int(employee["married"].toBool()));
    ui->political_status->setText(employee["political_status"].toString());
    ui->edu->setCurrentIndex(employee["education"].toInt());
    ui->id->setText(employee["id"].toString());
    ui->address->setText(employee["address"].toString());
    ui->phone->setText(employee["telephone"].toString());
    ui->email->setText(employee["email"].toString());
    QPixmap photo;
    photo.loadFromData(QByteArray::fromBase64(employee["photo"].toString().toUtf8()));
    ui->photo->setPixmap(photo);
    ui->e_c_name->setText(employee["emergency_contact_name"].toString());
    ui->e_c_phone->setText(employee["emergency_contact_phone"].toString());
    ui->e_c_address->setText(employee["emergency_contact_address"].toString());

    this->setModal(true);
    this->show();
}

/**
* @functionName  recevice_photo_data
* @Description       recevice photo data from cutdialog
* @author              chenhanlin
* @date                  2018-07-13
* @parameter         void
* @return               void
*/
void AddEmployeeDialog::receive_photo_data(QByteArray data)
{
    // to base64
    photo_data = data.toBase64();
}

/**
* @functionName  receive_pixmap
* @Description   receive QPixmap object from cutdialog
* @author        chenhanlin
* @date          2018-07-13
* @parameter     void
* @return        void
*/
void AddEmployeeDialog::receive_pixmap(QPixmap photo)
{
    ui->photo->setPixmap(photo);
}

/**
* @functionName  cancel_submit
* @Description   do question before close window and clear some input
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void AddEmployeeDialog::reset()
{
    ui->name->clear();
    ui->id->clear();
    ui->sex->setCurrentIndex(0);
    ui->dept->setCurrentIndex(0);
    ui->position->clear();
    ui->email->clear();
    ui->address->clear();
    ui->edu->setCurrentIndex(0);
    ui->married->setCurrentIndex(0);
    ui->birth_place->clear();
    ui->phone->clear();
    ui->political_status->clear();
    ui->nation->clear();
    ui->e_c_name->clear();
    ui->e_c_phone->clear();
    ui->e_c_address->clear();
    this->e_id.clear();
    this->photo_data.clear();
    ui->photo->setPixmap(QPixmap(":/image/user.png"));
}

/**
* @functionName  submit_employee
* @Description   get data from gui and send add_employee request to server
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void AddEmployeeDialog::submit_employee()
{
    QString name(ui->name->text());
    QString id(ui->id->text());
    int sex = ui->sex->currentIndex();
    QDate birthday(ui->birthday->date());
    QString dept(ui->dept->currentIndex()==0 ? "" : ui->dept->currentText());
    QString position(ui->position->text());
    QString email(ui->email->text());
    QString address(ui->address->text());
    int edu = ui->edu->currentIndex();
    int married = bool(ui->married->currentIndex());
    QString birth_place(ui->birth_place->text());
    QString phone(ui->phone->text());
    QString political_status(ui->political_status->text());
    QString nation(ui->nation->text());
    QString e_c_name(ui->e_c_name->text());
    QString e_c_phone(ui->e_c_phone->text());
    QString e_c_address(ui->e_c_address->text());

    if(photo_data.isEmpty() || name.isEmpty() || id.isEmpty() || dept.isEmpty() || position.isEmpty() || email.isEmpty() || phone.isEmpty()){
        MsgBox::information(this, tr("添加员工"), tr("请填写完整信息"));
        return;
    }
    QRegExp id_check("(^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$)|(^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}$)");
    QRegExp email_check("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$");
    QRegExp phone_check("^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$");
    if(!id_check.exactMatch(id)){
        MsgBox::information(this, tr(""), tr("请输入正确的身份证号"));
        return;
    }
    if(!email_check.exactMatch(email)){
        MsgBox::information(this, tr(""), tr("请输入正确的电子邮件"));
        return;
    }
    if(!phone_check.exactMatch(phone) || (!e_c_phone.isEmpty() && !phone_check.exactMatch(e_c_phone))){
        MsgBox::information(this, tr(""), tr("请输入正确的电话号码"));
        return;
    }


    Request req;
    req.set_module("employee");
    if(e_id.isEmpty()){
        req.set_func("add_employee");
        connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(add_resp(Response)));
    }else{
        req.set_func("modify_all");
        // add modify need informaiton
        req.put("e_id", e_id);
        connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(modify_resp(Response)));
    }

    req.put("name", name);
    req.put("department", dept);
    req.put("position", position);
    req.put("gender", sex);
    req.put("year", birthday.year());
    req.put("month", birthday.month());
    req.put("day", birthday.day());
    req.put("birth_place", birth_place);
    req.put("nation", nation);
    req.put("married", married);
    req.put("political_status", political_status);
    req.put("education", edu);
    req.put("id", id);
    req.put("address", address);
    req.put("telephone", phone);
    req.put("email", email);
    req.put("photo", QString(photo_data));
    req.put("e_c_name", e_c_name);
    req.put("e_c_phone", e_c_phone);
    req.put("e_c_address", e_c_address);

    client.send(req);
    wait->start();
}

/**
* @functionName  init_lineedit
* @Description       add contraint at line edit
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         void
* @return               void
*/
void AddEmployeeDialog::init_lineedit()
{
    QRegExp id("(^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$)|(^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}$)");
    QRegExpValidator *pid = new QRegExpValidator(id, this);
    ui->id->setValidator(pid);
    QRegExp email("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$");
    QRegExpValidator *pemail = new QRegExpValidator(email, this);
    ui->email->setValidator(pemail);
    QRegExp phone("^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$");
    QRegExpValidator *pphone = new QRegExpValidator(phone, this);
    ui->phone->setValidator(pphone);
    ui->e_c_phone->setValidator(pphone);
}
