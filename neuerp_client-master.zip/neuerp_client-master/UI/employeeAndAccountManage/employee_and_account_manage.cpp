#include "employee_and_account_manage.h"
#include "ui_employee_and_account_manage.h"
#include <QJsonArray>
#include <QJsonObject>
#include <QPoint>
#include <QAction>
#include <QStandardItem>
#include <QHeaderView>
#include <QContextMenuEvent>
#include <QDebug>
#include <QTableWidgetItem>
#include <cmath>

#include "Network/Body/request.h"
#include "status_code.h"
#include "UI/msgbox.h"
#include "Entity/user.h"
#include "usercontroller.h"

const int EmployeeAndAccountManage::page_item = 10;

EmployeeAndAccountManage::EmployeeAndAccountManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::EmployeeAndAccountManage),
    add_modify_page(nullptr),
    modify_permission_page(nullptr),
    wait(nullptr),
    client(MainClient::get_instance()),
    change_work(false)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    init_button();
    init_table();
    connect(ui->ledit_input, SIGNAL(returnPressed()), ui->btn_search, SLOT(click()));
}

EmployeeAndAccountManage::~EmployeeAndAccountManage()
{
    delete ui;
    delete add_modify_page;
}

/**
* @functionName  init_page
* @Description   when click the button, this page show, shuld init and show some information;
* @author        chenhanlin
* @date          2018-07-11
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::init_page()
{
    wait->start();
    ui->ledit_input->clear();
    ui->e_state->setCurrentIndex(0);
    ui->u_state->setCurrentIndex(0);
    ui->dept->setCurrentIndex(0);
    ui->sex->setCurrentIndex(0);
    change_work = false;
    ui->page->clear();
    ui->page->addItem(tr("第1页"));
    query_page(0);
    change_work = true;
}

/**
* @functionName  init_table
* @Description   set tablewidget
* @author        chenhanlin
* @date          2018-07-09
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::init_table()
{
    // basicly set
    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    auto &user = UserController::get_instance();
    // constructor menu
    t_menu = new QMenu(ui->tableWidget);
    QAction *delete_e = t_menu->addAction(tr("删除员工"));
    QAction *leave_e = t_menu->addAction(tr("员工离职"));
    QAction *enter_e = t_menu->addAction(tr("员工入职"));

    connect(delete_e, SIGNAL(triggered(bool)), this, SLOT(delete_select_employee()));
    connect(leave_e, SIGNAL(triggered(bool)), this, SLOT(leave_select_employee()));
    connect(enter_e, SIGNAL(triggered(bool)), this, SLOT(hire_select_employee()));

    if(user.check_access_code("dept_HR_manager")){
        QAction *frozen_u = t_menu->addAction(tr("账户冻结"));
        QAction *unfrozen_u = t_menu->addAction(tr("账户解冻"));
        connect(frozen_u, SIGNAL(triggered(bool)), this, SLOT(frozen_select_employee()));
        connect(unfrozen_u, SIGNAL(triggered(bool)), this, SLOT(unfrozen_select_employee()));
        ui->tableWidget->insertColumn(7);
        /*
        auto *h_item = ui->tableWidget->horizontalHeaderItem(7);
        if(nullptr != h_item)
            h_item->setText("");
            */
        ui->tableWidget->setHorizontalHeaderItem(7, new QTableWidgetItem(tr("")));
    }

    for(int i=0; i < page_item; i++){
        ui->tableWidget->insertRow(i);
    }
}

/**
* @functionName  init_tool_button
* @Description   init the set state and page change toolbutton
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::init_button()
{
    // init user_state button
    QMenu *menu = new QMenu(this);
    QAction *frozen = menu->addAction(tr("冻结账户"));
    QAction *unfrozen = menu->addAction(tr("解冻账户"));
    ui->tbn_user_state->setPopupMode(QToolButton::InstantPopup);
    this->ui->tbn_user_state->setMenu(menu);

    connect(frozen, SIGNAL(triggered(bool)), this, SLOT(frozen_employee()));
    connect(unfrozen, SIGNAL(triggered(bool)), this, SLOT(unfrozen_employee()));

    // init employee_state button
    QMenu *e_menu = new QMenu(this);
    QAction *enter = e_menu->addAction(tr("员工入职"));
    QAction *leave = e_menu->addAction(tr("员工离职"));
    ui->tbn_e_state->setPopupMode(QToolButton::InstantPopup);
    ui->tbn_e_state->setMenu(e_menu);
    ui->tbn_next->setArrowType(Qt::RightArrow);
    ui->tbn_previous->setArrowType(Qt::LeftArrow);

    connect(enter, SIGNAL(triggered(bool)), this, SLOT(hire_employee()));
    connect(leave, SIGNAL(triggered(bool)), this, SLOT(leave_employee()));

    connect(ui->btn_delete, SIGNAL(clicked(bool)), this, SLOT(delete_employee()));
    connect(ui->btn_search, SIGNAL(clicked(bool)), this, SLOT(search_page()));
    auto &user = UserController::get_instance();
    if(!user.check_access_code("dept_HR_manager")){
        ui->tbn_user_state->hide();
        ui->btn_delete->hide();
    }
}

/**
* @functionName  query_page
* @Description   query the ith page by some condition
* @author        chenhanlin
* @date          2018-07-11
* @parameter     int page
* @return        void
*/
void EmployeeAndAccountManage::query_page(int page)
{
    QString keyword(ui->ledit_input->text());
    int e_state = ui->e_state->currentIndex() - 1;
    e_state = e_state <0 ? 0 : e_state;
    int u_state = ui->u_state->currentIndex() - 1;
    if(u_state == 0){
        u_state = 1;
    }else if(u_state == 1){
        u_state = 2;
    }else if(u_state == 2){
        u_state = 4;
    }else if(u_state == 3){
        u_state = 8;
    }else{
        u_state = 0;
    }
    QString dept(ui->dept->currentIndex()==0 ? "" : ui->dept->currentText());
    int gender = ui->sex->currentIndex() - 1;
    gender = gender < 0 ? 0 : gender;

    Request req;
    req.set_module("employee");
    req.set_func("condition_query");
    req.put("keyword", keyword);
    req.put("dept", dept);
    req.put("e_state", int(e_state));
    req.put("u_state", int(u_state));
    req.put("gender", int(gender));
    req.put("has_e_state", bool(e_state));
    req.put("has_u_state", bool(u_state));
    req.put("has_gender", bool(gender));
    req.put("page", page);
    req.put("item", page_item);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(query_employee_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  on_tableWidget_customContextMenuRequest
* @Description   trigger the right click menu
* @author        chenhanlin
* @date          2018-07-10
* @parameter     QPoint pos
* @return        void
*/
void EmployeeAndAccountManage::on_tableWidget_customContextMenuRequested(const QPoint &pos)
{
    QList<QTableWidgetItem*> items = ui->tableWidget->selectedItems();
    if(items.count() > 0){
        t_menu->exec(QCursor::pos());
    }
}

/**
* @functionName  select_delete_employee
* @Description   send remove_employee request to delete employees, the employee is get by select by mutilple line
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::delete_select_employee()
{
    int flag = MsgBox::question(this, tr("删除员工"), tr("删除操作不可逆转，请确认是否删除员工？"));
    if(MsgBox::NO == flag) return;
    QList<QTableWidgetItem*> items = ui->tableWidget->selectedItems();
    QJsonArray e_id;
    for(const auto &item : items){
        if(item->column() == 0){
            e_id.push_back(item->text());
        }
    }
    Request req;
    req.set_module("employee");
    req.set_func("remove_employee");
    req.put("e_id", e_id);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(delete_employee_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  delete_employee
* @Description   delete checked employee
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::delete_employee()
{
    int flag = MsgBox::question(this, tr("删除员工"), tr("删除操作不可逆转，请确认是否删除员工？"));
    if(MsgBox::NO == flag) return;
    QJsonArray e_id;
    for(const auto &id : select_e_id){
        e_id.push_back(id);
    }
    Request req;
    req.set_module("employee");
    req.set_func("remove_employee");
    req.put("e_id", e_id);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(delete_employee_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  frozen_select_employee
* @Description   freeze selected multi-line user
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::frozen_select_employee()
{
    int flag = MsgBox::question(this, tr("员工管理"), tr("是否冻结选中账户？"));
    if(MsgBox::NO == flag) return;
    QJsonArray e_ids;
    auto items = ui->tableWidget->selectedItems();
    for(const auto &item : items){
        if(item->column() == 0){
            e_ids.push_back(item->text());
        }
    }
    Request req;
    req.set_module("user");
    req.set_func("add_state");
    req.put("e_ids", e_ids);
    req.put("state", User::USER_FROZN);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(user_set_state_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  frozen_employee
* @Description   freeze checked user
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::frozen_employee()
{
    int flag = MsgBox::question(this, tr("员工管理"), tr("是否冻结选中账户？"));
    if(MsgBox::NO == flag) return;
    QJsonArray e_ids;
    for(const auto &e_id : select_e_id){
            e_ids.push_back(e_id);
    }
    Request req;
    req.set_module("user");
    req.set_func("add_state");
    req.put("e_ids", e_ids);
    req.put("state", User::USER_FROZN);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(user_set_state_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  unfrozen_employee
* @Description   unfreeze checked user
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::unfrozen_employee()
{
    int flag = MsgBox::question(this, tr("员工管理"), tr("是否解冻选中账户？"));
    if(MsgBox::NO == flag) return;
    QJsonArray e_ids;
    for(const auto &e_id : select_e_id){
            e_ids.push_back(e_id);
    }
    Request req;
    req.set_module("user");
    req.set_func("remove_state");
    req.put("e_ids", e_ids);
    req.put("state", User::USER_FROZN);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(user_set_state_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  unfrozen_select_employee
* @Description   unfreeze selected multi-line user
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::unfrozen_select_employee()
{
    int flag = MsgBox::question(this, tr("员工管理"), tr("是否解冻选中账户？"));
    if(MsgBox::NO == flag) return;
    QJsonArray e_ids;
    auto items = ui->tableWidget->selectedItems();
    for(const auto &item : items){
        if(item->column() == 0){
            e_ids.push_back(item->text());
        }
    }
    Request req;
    req.set_module("user");
    req.set_func("remove_state");
    req.put("e_ids", e_ids);
    req.put("state", User::USER_FROZN);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(user_set_state_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  leave_select_employee
* @Description   set selected multi-line employee's state to leave
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::leave_select_employee()
{
    int flag = MsgBox::question(this, tr("员工管理"), tr("是否为选中员工办理离职？"));
    if(MsgBox::NO == flag) return;
    QJsonObject e_ids;
    auto items = ui->tableWidget->selectedItems();
    for(const auto &item : items){
        if(item->column() == 0){
            e_ids.insert(item->text(), int(employee_state::resignation));
        }
    }
    Request req;
    req.set_module("employee");
    req.set_func("change_state");
    req.put("e_ids", e_ids);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(employee_change_state_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  leave_select_employee
* @Description   set checked employee's state to leave
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::leave_employee()
{
    int flag = MsgBox::question(this, tr("员工管理"), tr("是否为选中员工办理离职？"));
    if(MsgBox::NO == flag) return;
    QJsonObject e_ids;
    for(const auto &item : select_e_id){
        e_ids.insert(item, int(employee_state::resignation));
    }
    Request req;
    req.set_module("employee");
    req.set_func("change_state");
    req.put("e_ids", e_ids);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(employee_change_state_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  hire_select_employee
* @Description   set checked employee's state to normal
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::hire_employee()
{
    int flag = MsgBox::question(this, tr("员工管理"), tr("是否为选中员工办理入职？"));
    if(MsgBox::NO == flag) return;
    QJsonObject e_ids;
    for(const auto &item : select_e_id){
        e_ids.insert(item, int(employee_state::normal));
    }
    Request req;
    req.set_module("employee");
    req.set_func("change_state");
    req.put("e_ids", e_ids);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(employee_change_state_resp(Response)));
    client.send(req);

    wait->start();
}

/**
* @functionName  hire_select_employee
* @Description   set selected multi-line employee's state to normal
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::hire_select_employee()
{
    int flag = MsgBox::question(this, tr("员工管理"), tr("是否为选中员工办理入职？"));
    if(MsgBox::NO == flag) return;
    QJsonObject e_ids;
    auto items = ui->tableWidget->selectedItems();
    for(const auto &item : items){
        if(item->column() == 0){
            e_ids.insert(item->text(), int(employee_state::normal));
        }
    }
    Request req;
    req.set_module("employee");
    req.set_func("change_state");
    req.put("e_ids", e_ids);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(employee_change_state_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  search_page
* @Description       query employee by condition
* @author              chenhanlin
* @date                  2018-07-11
* @parameter         void
* @return               void
*/
void EmployeeAndAccountManage::search_page()
{
    change_work = false;
    ui->page->clear();
    ui->page->addItem(tr("第1页"));
    this->query_page(0);
    change_work = true;
}

/**
* @functionName  delete_employee_resp
* @Description   handle the response from remove_employee
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::delete_employee_resp(Response resp)
{
    if("employee" != resp.get_module() || "remove_employee" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(delete_employee_resp(Response)));
    wait->stop();
    if(SUCCESS != resp.get_status_code()){
        MsgBox::warming(this, tr("员工管理"), tr("系统错误，请稍后再试"));
        disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(delete_employee_resp(Response)));
        return;
    }

    select_e_id.clear();
    // refresh page
    change_work = false;
    ui->page->clear();
    ui->page->addItem(tr("第1页"));
    query_page(0);
    change_work = true;

}

/**
* @functionName  set_state_resp
* @Description   handle the response from set_state
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::user_set_state_resp(Response resp)
{
    if("user" != resp.get_module() || ("add_state" != resp.get_func() && "remove_state" != resp.get_func())) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(user_set_state_resp(Response)));
    wait->stop();
    if(SUCCESS != resp.get_status_code()){
        MsgBox::warming(this, tr("员工管理"), tr("系统错误，请稍后再试"));
        disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(delete_employee_resp(Response)));
        return;
    }

    select_e_id.clear();
    // refresh page
    query_page(ui->page->currentIndex());
}

/**
* @functionName  employee_change_state_resp
* @Description   handle the response from change_state
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::employee_change_state_resp(Response resp)
{
    if("employee" != resp.get_module() || "change_state" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(employee_change_state_resp(Response)));
    wait->stop();
    if(SUCCESS != resp.get_status_code()){
        MsgBox::warming(this, tr("员工管理"), tr("系统错误，请稍后再试"));
        return;
    }

    select_e_id.clear();
    // refresh page
    query_page(ui->page->currentIndex());
}

void EmployeeAndAccountManage::query_employee_resp(Response resp)
{
    if("employee" != resp.get_module() || "condition_query" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(query_employee_resp(Response)));
    wait->stop();
    if(EMPTY_QUERY == resp.get_status_code()){
        ui->tableWidget->clearContents();
        return;
    }
    if(SUCCESS != resp.get_status_code()){
        MsgBox::warming(this, tr("员工管理"), tr("系统错误，请稍后再试"));
        return;
    }

    QJsonArray users(resp.get_array("users"));

    int total = resp.get_int("total");
    int page_num = std::ceil(double(total)/page_item);

    auto &myuser = UserController::get_instance();
    ui->tableWidget->clearContents();
    int count = 0;
    // build data
    for(const auto i : users){
        int col = 0;
        QJsonObject user(i.toObject());
        QTableWidgetItem *e_id = new QTableWidgetItem(user.value("e_id").toString());
        e_id->setCheckState(Qt::Unchecked);
        ui->tableWidget->setItem(count, col, e_id);
        col++;
        QTableWidgetItem *name = new QTableWidgetItem(user.value("name").toString());
        ui->tableWidget->setItem(count, col, name);
        col++;
        QTableWidgetItem *dept = new QTableWidgetItem(user.value("dept").toString());
        ui->tableWidget->setItem(count, col, dept);
        col++;
        auto *position = new QTableWidgetItem(user.value("position").toString());
        ui->tableWidget->setItem(count, col, position);
        col++;
        auto *e_state = new QTableWidgetItem(Employee::get_str_state(employee_state(user.value("e_state").toInt())));
        ui->tableWidget->setItem(count, col, e_state);
        col++;
        auto *u_state = new QTableWidgetItem(User::get_user_status_str(user.value("u_state").toInt()));
        ui->tableWidget->setItem(count, col, u_state);
        col++;
        auto *modify_employee = new QPushButton;
        modify_employee->setText(tr("编辑"));
        modify_employee->setObjectName(e_id->text());
        modify_employee->setProperty("btn_color", "green");
        connect(modify_employee, SIGNAL(clicked(bool)), this, SLOT(modify_employee_button_clicked()));
        ui->tableWidget->setCellWidget(count, col, modify_employee);
        if(myuser.check_access_code("dept_HR_manager")){
            col++;
            auto *modify_permission = new QPushButton;
            modify_permission->setText(tr("修改权限"));
            modify_permission->setObjectName(e_id->text());
            modify_permission->setProperty("btn_color", "green");
            connect(modify_permission, SIGNAL(clicked(bool)), this, SLOT(modify_permission_button_clicked()));
            ui->tableWidget->setCellWidget(count, col, modify_permission);
        }
        count++;
    }

    // build page
    this->change_work = false;
    if(ui->page->count() < page_num){
        for(int i=ui->page->count(); i<page_num; i++){
            ui->page->addItem(QString("第%1页").arg(i+1));
            qDebug() << ui->page->count();
        }
    }
    ui->tbn_next->setEnabled(true);
    ui->tbn_previous->setEnabled(true);
    if(ui->page->currentIndex()+1 == ui->page->count()){
        ui->tbn_next->setEnabled(false);
    }
    if(0 == ui->page->currentIndex()){
        ui->tbn_previous->setEnabled(false);
    }
    this->change_work = true;
}

/**
* @functionName  on_btn_add_clicked
* @Description   show add employee dialog
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeAndAccountManage::on_btn_add_clicked()
{
    if(nullptr == add_modify_page)
        add_modify_page = new AddEmployeeDialog;
    this->add_modify_page->setModal(true);
    if(QDialog::Accepted == this->add_modify_page->exec())
        query_page(ui->page->currentIndex());
}

void EmployeeAndAccountManage::on_tableWidget_cellChanged(int row, int column)
{
    if(0 == column){
        auto item = ui->tableWidget->item(row, column);
        if(item->checkState() == Qt::Checked){
            select_e_id.push_back(item->text());
        }else{
            auto iter = select_e_id.begin();
            for(;iter!=select_e_id.end(); iter++){
                if(*iter == item->text()) break;
            }
            if(iter!=select_e_id.end()) select_e_id.erase(iter);
        }
    }
}

void EmployeeAndAccountManage::modify_employee_button_clicked()
{
    auto *button = (QPushButton*)sender();
    QString e_id(button->objectName());
    if(nullptr == add_modify_page)
        add_modify_page = new AddEmployeeDialog;
    add_modify_page->modify_employee(e_id);
    if(QDialog::Accepted == add_modify_page->exec()){
        query_page(ui->page->currentIndex());
    }
}

void EmployeeAndAccountManage::modify_permission_button_clicked()
{
    if(nullptr == modify_permission_page)
        modify_permission_page = new ModifyPermissionDialog;
    QString e_id(sender()->objectName());
    for(int i=0; i<page_item; i++){
        auto *item = ui->tableWidget->item(i, 0);
        if(nullptr != item && item->text() == e_id){
            auto *name = ui->tableWidget->item(i, 1);
            auto *dept = ui->tableWidget->item(i, 2);
            auto *position = ui->tableWidget->item(i, 3);
            modify_permission_page->modify(e_id, name->text(), dept->text(), position->text());
        }
    }
    if(QDialog::Accepted == modify_permission_page->exec())
        query_page(ui->page->currentIndex());
}

void EmployeeAndAccountManage::on_page_currentIndexChanged(int index)
{
    if(change_work){
        change_work = false;
        query_page(index);
        change_work = true;
    }
}

void EmployeeAndAccountManage::on_tbn_next_clicked()
{
    this->ui->page->setCurrentIndex(ui->page->currentIndex() + 1);
    if(ui->page->currentIndex()+1 == ui->page->count()){
        ui->tbn_next->setEnabled(false);
    }else{
        ui->tbn_next->setEnabled(true);
    }
    ui->tbn_previous->setEnabled(true);
}

void EmployeeAndAccountManage::on_tbn_previous_clicked()
{
    this->ui->page->setCurrentIndex(ui->page->currentIndex() - 1);
    if(0 == ui->page->currentIndex()){
        ui->tbn_previous->setEnabled(false);
    }else{
        ui->tbn_previous->setEnabled(true);
    }
    ui->tbn_next->setEnabled(true);
}
