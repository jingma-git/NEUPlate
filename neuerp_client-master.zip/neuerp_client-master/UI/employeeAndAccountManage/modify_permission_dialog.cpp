#include "modify_permission_dialog.h"
#include "ui_modify_permission_dialog.h"
#include "UI/iconhelper.h"
#include "Network/Body/request.h"
#include "status_code.h"
#include "UI/msgbox.h"
#include "usercontroller.h"

ModifyPermissionDialog::ModifyPermissionDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ModifyPermissionDialog),
    client(MainClient::get_instance())
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
    init_list();
    ui->btn_submit->setProperty("btn_color", "green");
    ui->btn_cancel->setProperty("btn_color", "red");
}

ModifyPermissionDialog::~ModifyPermissionDialog()
{
    delete ui;
}

/**
* @functionName  modify
* @Description       to init this page and show the page
* @author              chenhanlin
* @date                  2018-07-11
* @parameter         QString e_id, QString name, QString dept, QString position
* @return               void
*/
void ModifyPermissionDialog::modify(const QString &e_id, const QString &name, const QString &dept, const QString &position)
{
    ui->e_id->setText(e_id);
    ui->name->setText(name);
    ui->dept->setText(dept);
    ui->position->setText(position);

    query_permission();
}

void ModifyPermissionDialog::on_btnMenu_Close_clicked()
{
    close();
    reject();
}

/**
* @functionName  query_permission_resp
* @Description       handle the response from query_permission
* @author              chenhanlin
* @date                  2018-07-11
* @parameter         Response resp
* @return               void
*/
void ModifyPermissionDialog::query_permission_resp(Response resp)
{
    if("user" != resp.get_module() || "query_permission" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(query_permission_resp(Response)));

    if(SUCCESS != resp.get_status_code()){
        MsgBox::warming(this, tr("权限编辑"), tr("系统错误，请稍后再试"));
        return;
    }

    auto &controller = UserController::get_instance();
    int access_code = resp.get_int("code");
    for(const auto &item : map_index){
        if(controller.check_access_code(item.first, access_code)){
            ui->listWidget->item(item.second)->setCheckState(Qt::Checked);
        }else{
            ui->listWidget->item(item.second)->setCheckState(Qt::Unchecked);
        }
    }
    wait->stop();
}

/**
* @functionName  modify_permission_resp
* @Description       handle the response from change_code
* @author              chenhanlin
* @date                  2018-07-11
* @parameter         Response resp
* @return               void
*/
void ModifyPermissionDialog::modify_permission_resp(Response resp)
{
    if("user" != resp.get_module() || "change_code" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(modify_permission_resp(Response)));
    wait->stop();

    if(ILLEGAL_ACCESS == resp.get_status_code()){
        MsgBox::warming(this, tr("权限编辑"), tr("无权修改此员工权限"));
        close();
        reject();
        return;
    }
    if(SUCCESS != resp.get_status_code()){
        MsgBox::warming(this, tr("权限编辑"), tr("系统错误，请稍后再试"));
        return;
    }

    close();
    accept();
}

/**
* @functionName  query_permission
* @Description       query user's permission and init QListWidget
* @author              chenhanlin
* @date                  2018-07-11
* @parameter         void
* @return               void
*/
void ModifyPermissionDialog::query_permission()
{
    QString e_id(ui->e_id->text());
    Request req;
    req.set_module("user");
    req.set_func("query_permission");
    req.put("e_id", e_id);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(query_permission_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  modify_permission
* @Description       send change_code request to server to modify user's permission
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         void
* @return               void
*/
void ModifyPermissionDialog::modify_permission()
{
    int code = 1;
    auto &controller = UserController::get_instance();
    for(int i=0; i<ui->listWidget->count(); i++){
        const auto *item = ui->listWidget->item(i);
        if(Qt::Checked == item->checkState()){
            code |= controller.get_access_code(controller.get_permission(item->text()));
        }
    }
    Request req;
    req.set_module("user");
    req.set_func("change_code");
    req.put("e_id", ui->e_id->text());
    req.put("access_code", code);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(modify_permission_resp(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  init_list
* @Description       init the QListWidget
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         void
* @return               void
*/
void ModifyPermissionDialog::init_list()
{
    auto &controller = UserController::get_instance();
    int row = 0;
    for(const auto &key : controller.get_permission_desc()){
        ui->listWidget->addItem(key);
        QString permission(controller.get_permission(key));
        this->map_index.insert(std::map<QString, int>::value_type(permission, row));
        row++;
    }
}

void ModifyPermissionDialog::on_btn_cancel_clicked()
{
    close();
    reject();
}

void ModifyPermissionDialog::on_btn_submit_clicked()
{
    modify_permission();
}
