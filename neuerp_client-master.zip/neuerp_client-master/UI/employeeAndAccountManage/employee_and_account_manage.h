#ifndef EMPOLEE_AND_ACCOUNT_MANAGE_H
#define EMPOLEE_AND_ACCOUNT_MANAGE_H

#include <QWidget>
#include <QMenu>
#include <vector>
#include "Network/Body/response.h"
#include "Network/Client/mainclient.h"
#include "UI/employeeAndAccountManage/add_employee_dialog.h"
#include "UI/employeeAndAccountManage/modify_permission_dialog.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class EmployeeAndAccountManage;
}

class EmployeeAndAccountManage : public QWidget
{
    Q_OBJECT

public:
    explicit EmployeeAndAccountManage(QWidget *parent = 0);
    ~EmployeeAndAccountManage();
    void init_page();

private slots:
    void on_tableWidget_customContextMenuRequested(const QPoint &pos);

    void delete_select_employee();
    void delete_employee();
    void frozen_select_employee();
    void frozen_employee();
    void unfrozen_employee();
    void unfrozen_select_employee();
    void leave_select_employee();
    void leave_employee();
    void hire_employee();
    void hire_select_employee();
    void search_page();

    void delete_employee_resp(Response);
    void user_set_state_resp(Response);
    void employee_change_state_resp(Response);
    void query_employee_resp(Response);

    void on_btn_add_clicked();

    void on_tableWidget_cellChanged(int row, int column);

    void modify_employee_button_clicked();
    void modify_permission_button_clicked();

    void on_page_currentIndexChanged(int index);

    void on_tbn_next_clicked();

    void on_tbn_previous_clicked();

private:
    Ui::EmployeeAndAccountManage *ui;
    QMenu *t_menu;
    AddEmployeeDialog *add_modify_page;
    ModifyPermissionDialog *modify_permission_page;
    WaitingSpinnerWidget *wait;
    MainClient &client;
    std::vector<QString> select_e_id;
    static const int page_item;
    bool change_work;

    void init_table();
    void init_button();

    void query_page(int page);
};

#endif // EMPOLEE_AND_ACCOUNT_MANAGE_H
