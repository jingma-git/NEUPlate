#ifndef ADD_EMPLOYEE_DIALOG_H
#define ADD_EMPLOYEE_DIALOG_H

#include <QDialog>
#include "Network/Body/response.h"
#include "Network/Client/mainclient.h"
#include "UI/waitingspinnerwidget.h"
#include "UI/CutDialog/cut_photo_dialog.h"

namespace Ui {
class AddEmployeeDialog;
}

class AddEmployeeDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddEmployeeDialog(QWidget *parent = 0);
    ~AddEmployeeDialog();
    void modify_employee(const QString &e_id);

private slots:
    void on_btnMenu_Close_clicked();

    void on_btn_submit_clicked();

    void on_btn_upload_clicked();

    void on_btn_cancel_clicked();

    void add_resp(Response);
    void modify_resp(Response);
    void query_resp(Response);

    void receive_photo_data(QByteArray data);
    void receive_pixmap(QPixmap photo);

private:
    Ui::AddEmployeeDialog *ui;
    MainClient &client;
    static const int photo_size;
    QByteArray photo_data;
    bool isModify;
    QString e_id;
    WaitingSpinnerWidget *wait;
    CutPhotoDialog *cut;

    void reset();
    void submit_employee();
    void init_lineedit();
};

#endif // ADD_EMPLOYEE_DIALOG_H
