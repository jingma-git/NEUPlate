#ifndef MODIFY_PERMISSION_DIALOG_H
#define MODIFY_PERMISSION_DIALOG_H

#include <QDialog>
#include "Network/Body/response.h"
#include "Network/Client/mainclient.h"
#include "UI/waitingspinnerwidget.h"
#include <map>

namespace Ui {
class ModifyPermissionDialog;
}

class ModifyPermissionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ModifyPermissionDialog(QWidget *parent = 0);
    ~ModifyPermissionDialog();
    void modify(const QString &e_id, const QString &name, const QString &dept, const QString &position);

private slots:
    void on_btnMenu_Close_clicked();

    void query_permission_resp(Response);
    void modify_permission_resp(Response);

    void on_btn_cancel_clicked();

    void on_btn_submit_clicked();

private:
    Ui::ModifyPermissionDialog *ui;
    MainClient &client;
    std::map<QString, int> map_index; // the value is the permission of QListWidget's index, and key is permission
    WaitingSpinnerWidget *wait;

    void query_permission();
    void modify_permission();
    void init_list();
};

#endif // MODIFY_PERMISSION_DIALOG_H
