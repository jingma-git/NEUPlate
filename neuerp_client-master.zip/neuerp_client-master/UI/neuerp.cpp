﻿#include "neuerp.h"
#include "ui_neuerp.h"
#include "iconhelper.h"
#include "usercontroller.h"


NEUERP::NEUERP(QWidget *parent) : QWidget(parent),
                                  ui(new Ui::NEUERP),
                                  main_page(new MainPage),
                                employee_and_account_manage(nullptr),
                                personal_center(nullptr),
                                product_and_stock_manage(nullptr),
                                purchase_manage(nullptr),
                                sale_manage(nullptr),
                                supplier_manage(nullptr)
{
    ui->setupUi(this);


    this->initForm();
}

NEUERP::~NEUERP()
{
    delete ui;
    delete employee_and_account_manage;
    delete personal_center;
    delete product_and_stock_manage;
    delete purchase_manage;
    delete sale_manage;
    delete supplier_manage;
}

void NEUERP::init_permission()
{
    if(nullptr == purchase_manage)
        purchase_manage = new PurchaseManage();
    if(nullptr == product_and_stock_manage)
        product_and_stock_manage =new  ProductAndStockManage();
    if(nullptr == sale_manage)
        sale_manage =new SaleManage();
    if(nullptr == supplier_manage)
        supplier_manage =new SupplierManage();
    if(nullptr == employee_and_account_manage)
        employee_and_account_manage=new EmployeeAndAccountManage();
    if(nullptr == personal_center)
        personal_center =new PersonalCenter();
    this->init_stacked_widget();
    auto &user = UserController::get_instance();
    if(!user.check_access_code("dept_HR_employee") && !user.check_access_code("dept_HR_manager"))
        ui->btnEmployeenAndAccount->hide();
    if(!user.check_access_code("dept_purchase_employee") && !user.check_access_code("dept_purchase_manager"))
        ui->btnPurchase->hide();
    if(!user.check_access_code("dept_sale_employee") && !user.check_access_code("dept_sale_manager"))
        ui->btnSale->hide();
    if(!user.check_access_code("dept_stock_employee") && !user.check_access_code("dept_stock_manager"))
        ui->btnProductAndStock->hide();
    if(!user.check_access_code("dept_supplier_employee") && !user.check_access_code("dept_supplier_manager"))
        ui->btnSupplier->hide();
}

//初始化页面
void NEUERP::initForm()
{
    this->setProperty("form", true);
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint | Qt::WindowSystemMenuHint | Qt::WindowMinMaxButtonsHint);

//    IconHelper::Instance()->setIcon(ui->labIco, QChar(0xf073), 30);
    IconHelper::Instance()->setIcon(ui->btnMenu_Min, QChar(0xf068));
    IconHelper::Instance()->setIcon(ui->btnMenu_Max, QChar(0xf067));
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));

    //ui->widgetMenu->setVisible(false);
    ui->widgetTitle->setProperty("form", "title");
    ui->widgetTop->setProperty("nav", "top");
//    ui->labTitle->setText("智能物流管理平台");
    ui->labTitle->setFont(QFont("Microsoft Yahei", 20));
    this->setWindowTitle(ui->labTitle->text());

//    ui->stackedWidget->setStyleSheet("QLabel{font:60pt;}");

    QSize icoSize(32, 32);
    int icoWidth = 85;

    //设置顶部导航按钮
    //todo 要根据权限来设置，有的要设置为不显示
    QList<QToolButton *> tbtns = ui->widgetTop->findChildren<QToolButton *>();
    foreach (QToolButton *btn, tbtns)
    {
        btn->setIconSize(icoSize);
        btn->setMinimumWidth(icoWidth);
        btn->setCheckable(true);
        connect(btn, SIGNAL(clicked()), this, SLOT(buttonClick()));
    }

    //初始化的时候，点击主界面按钮来实现显示主界面
    ui->stackedWidget->insertWidget(0, main_page);
    ui->btnMain->click();


    //widgetLeftMain and widgetLeftConfig是首页和设置页的左边栏
    //    ui->widgetLeftMain->setProperty("flag", "left");
    //    ui->widgetLeftConfig->setProperty("flag", "left");

    //page1,2是有左边栏的
    //    ui->page1->setStyleSheet(QString("QWidget[flag=\"left\"] QAbstractButton{min-height:%1px;max-height:%1px;}").arg(60));
    //    ui->page2->setStyleSheet(QString("QWidget[flag=\"left\"] QAbstractButton{min-height:%1px;max-height:%1px;}").arg(20));

}

void NEUERP::init_stacked_widget()
{
    // 0 is page main
    ui->stackedWidget->insertWidget(1,purchase_manage);
    ui->stackedWidget->insertWidget(2,product_and_stock_manage);
    ui->stackedWidget->insertWidget(3,sale_manage);
    ui->stackedWidget->insertWidget(4,supplier_manage);
    ui->stackedWidget->insertWidget(5,employee_and_account_manage);
    ui->stackedWidget->insertWidget(6,personal_center);
}

//设置stackedWidget切换的点击事件，根据点击的按钮来确定跳转到哪一个widget。并且要设置按钮对应的状态
void NEUERP::buttonClick()
{
    QToolButton *b = (QToolButton *)sender();
    QList<QToolButton *> tbtns = ui->widgetTop->findChildren<QToolButton *>();
    foreach (QToolButton *btn, tbtns)
    {
        if (btn == b)
        {
            btn->setChecked(true);
        }
        else
        {
            btn->setChecked(false);
        }
    }
    //todo 根据不同的页面来设置

    if (b == ui->btnMain)
    {
        ui->stackedWidget->setCurrentIndex(0);
    }
    else if (b == ui->btnPurchase)
    {
        ui->stackedWidget->setCurrentIndex(1);
    }
    else if (b == ui->btnProductAndStock)
    {
        ui->stackedWidget->setCurrentIndex(2);
        product_and_stock_manage->first_init();
    }
    else if (b == ui->btnSale)
    {
        ui->stackedWidget->setCurrentIndex(3);
        sale_manage->init_sale();
        sale_manage->init_statistics();
    }
    else if (b == ui->btnSupplier)
    {
        ui->stackedWidget->setCurrentIndex(4);
        supplier_manage->init_supplier_manage();
    }
    else if (b == ui->btnEmployeenAndAccount)
    {
        employee_and_account_manage->init_page();
        ui->stackedWidget->setCurrentIndex(5);
    }
    else if (b == ui->btnPersonalCenter)
    {
        this->personal_center->init_menu();
        ui->stackedWidget->setCurrentIndex(6);
    }
}

void NEUERP::on_btnMenu_Min_clicked()
{
    showMinimized();
}

void NEUERP::on_btnMenu_Max_clicked()
{
    static bool max = false;
    static QRect location = this->geometry();

    if (max)
    {
        this->setGeometry(location);
    }
    else
    {
        location = this->geometry();
        this->setGeometry(qApp->desktop()->availableGeometry());
    }

    this->setProperty("canMove", max);
    max = !max;
}

void NEUERP::on_btnMenu_Close_clicked()
{
    close();
}
void NEUERP::error_arrive(QString)
{
    MsgBox::error(this, tr("网络错误"), tr("无法连接至网络，请重试"));
    exit(0);
}
void NEUERP::close_connection()
{
    MsgBox::error(this, tr("网络错误"), tr("与服务器断开连接"));
    exit(0);
}
