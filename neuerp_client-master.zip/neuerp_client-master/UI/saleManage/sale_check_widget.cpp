#include "sale_check_widget.h"

SaleCheckWidget::SaleCheckWidget(QWebView *parent) :
    QWebView(parent)
{
    waiting=new WaitingSpinnerWidget(this);
    stat=new SaleStatistics(this);
    inited=false;
}




SaleCheckWidget::~SaleCheckWidget()
{
    delete waiting;
    delete stat;
}

void SaleCheckWidget::init()
{
    if(inited){
       return;
    }
    inited=false;
    this->getData();
}


void SaleCheckWidget::getData()
{
    Request req;
    req.set_func("statistics");

    req.set_module("statistics");
    auto &client=MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_data(Response)));

}

void SaleCheckWidget::recv_data(Response resp)
{
    if(resp.get_module()!="statistics"||resp.get_func()!="statistics"){
        return;
    }

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_data(Response)));
    waiting->stop();
    if(resp.get_status_code()==SUCCESS){
        stat->setTop_salesman_month_name(JsonArray2QStringList(resp.get_array("top_salesman_week_name")));
        qDebug()<<"aaaaaaaaaaaaaa";
        qDebug()<<stat->getTop_salesman_month_name();
        stat->setTop_salesman_month_saleroom(JsonArray2QStringList(resp.get_array("top_salesman_month_saleroom")));
        stat->setTop_salesman_month_name(JsonArray2QStringList(resp.get_array("top_salesman_month_name")));
        stat->setTop_salesman_week_name(JsonArray2QStringList(resp.get_array("top_salesman_week_name")));
        stat->setTop_salesman_week_saleroom(JsonArray2QStringList(resp.get_array("top_salesman_week_saleroom")));

        stat->setTop_salesman_month_trend_date(JsonArray2QStringList(resp.get_array("top_salesman_month_trend_date")));
        stat->setTop_salesman_month_trend_saleroom(JsonArray2QList(resp.get_array("top_salesman_month_trend_saleroom")));


        stat->setTop_product_week_name(JsonArray2QStringList(resp.get_array("top_product_week_name")));
        stat->setTop_product_week_volume(JsonArray2QStringList(resp.get_array("top_product_week_volume")));
        stat->setTop_product_month_name(JsonArray2QStringList(resp.get_array("top_product_month_name")));
        stat->setTop_product_month_volume(JsonArray2QStringList(resp.get_array("top_product_month_volume")));

        stat->setTop_product_month_trend_date(JsonArray2QStringList(resp.get_array("top_product_month_trend_date")));
        stat->setTop_product_month_trend_volume(JsonArray2QList(resp.get_array("top_product_month_trend_volume")));

        stat->setTotal_saleroom_month_date(JsonArray2QStringList(resp.get_array("total_saleroom_month_date")));
        stat->setTotal_saleroom_month_saleroom(JsonArray2QStringList(resp.get_array("total_saleroom_month_saleroom")));
        stat->setTotal_saleroom_year_date(JsonArray2QStringList(resp.get_array("total_saleroom_year_date")));
        stat->setTotal_saleroom_year_saleroom(JsonArray2QStringList(resp.get_array("total_saleroom_year_saleroom")));

        qDebug()<<"year"<<stat->getTotal_saleroom_year_saleroom();
        qDebug()<<"month"<<stat->getTotal_saleroom_month_saleroom();


        QObject::connect(page()->mainFrame(), SIGNAL(javaScriptWindowObjectCleared()),
                         this, SLOT(addJsonObj()));
        load(QUrl::fromLocalFile(qApp->applicationDirPath()+"/index.html"));

    }else{
        MsgBox::error(0,"销售盘点","获取盘点信息失败");
        return;
    }

}

QStringList SaleCheckWidget::JsonArray2QStringList(const QJsonArray &array)
{
    QStringList sl;
    foreach(const QJsonValue &str,array){
        sl.append(str.toString());
    }
    return sl;
}

QList<QStringList> SaleCheckWidget::JsonArray2QList(const QJsonArray &array)
{
    QList<QStringList> ql;
    foreach(const QJsonValue & a_qsl,array){
        QStringList qsl;
        foreach (const QJsonValue &str, a_qsl.toArray()) {
            qsl.append(str.toString());
        }
        ql.append(qsl);
    }
    return ql;
}




void SaleCheckWidget::addJsonObj()
{
    page()->mainFrame()->addToJavaScriptWindowObject(QString("stat"),stat);
}
