#ifndef SALE_MANAGE_H
#define SALE_MANAGE_H

#include <QWidget>
#include <QToolButton>
#include "UI/iconhelper.h"
#include "sale_widget.h"
#include "sale_check_widget.h"

namespace Ui {
class SaleManage;
}

class SaleManage : public QWidget
{
    Q_OBJECT

public:
    void init_sale();
    explicit SaleManage(QWidget *parent = 0);
    ~SaleManage();
    void init_statistics();

private slots:
    void menu_click();

private:
    QList<int> pixChars;
    QList<QToolButton *> btns;
    SaleWidget *sale_widget;
    SaleCheckWidget *sale_check_widget;
    Ui::SaleManage *ui;

    void init_left_menu();
    void init_stacked_widget();

};

#endif // SALE_MANAGE_H
