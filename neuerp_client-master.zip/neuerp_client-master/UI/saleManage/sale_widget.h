#ifndef SALE_WIDGET_H
#define SALE_WIDGET_H

#include <QWidget>
#include <QJsonArray>
#include <QJsonObject>
#include <QMenu>
#include <QTime>
#include <QDateTime>
#include "add_sale_dialog.h"
#include "show_sale_item_dialog.h"
#include "Network/Body/response.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Entity/sale_list.h"
#include "Entity/sale_item.h"
#include "status_code.h"
#include "UI/msgbox.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class SaleWidget;
}

class SaleWidget : public QWidget
{
    Q_OBJECT

public:
    explicit SaleWidget(QWidget *parent = 0);
    ~SaleWidget();
    void init_sale_list();

signals:
    void send_sale_to_show_dialog(const SaleList&);
    void add_new_sale();

private slots:

    void change_page(int new_index);
    void last_page();
    void next_page();
    void right_menu_action(const QPoint&);
    void show_sale_item_info();
    void recv_add_sale_success();

    void recv_search_sale_list(Response);
    void recv_delete_sale_list(Response);
    void recv_repeal_sale_list(Response);

    void on_btn_search_clicked();
    void on_btn_repeal_sale_clicked();
    void on_btn_delete_sale_clicked();
    void on_dedit_end_userDateChanged(const QDate &date);
    void on_dedit_start_userDateChanged(const QDate &date);
    void on_btn_add_sale_clicked();

private:
    Ui::SaleWidget *ui;
    AddSaleDialog *add_sale_list;
    ShowSaleItemDialog *show_sale_item;
    std::vector<SaleList> sale_lists;
    QMenu *right_menu;
    QAction *show_sale;
    QAction *repeal_sale;
    QAction *delete_sale;
    WaitingSpinnerWidget *waiting;
    int page;
    int item;
    int current_page;
    bool inited;

    void refresh_page();
    void search_sale_list();
    void show_sale_list();
    void create_menu();
};

#endif // SALE_WIDGET_H
