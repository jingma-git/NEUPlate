/**
* @projectName   NEUERP_client
* @brief         销售盘点
* @author        haoyun
* @date          2018-07-16
* @modify_author haoyun
* @modify_date   2018-07-16
*/

#ifndef SALE_CHECK_WIDGET_H
#define SALE_CHECK_WIDGET_H

#include <QWebView>
#include <UI/msgbox.h>
#include <QJsonArray>
#include <QJSonDocument>
#include "Network/Body/response.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "status_code.h"
#include "UI/iconhelper.h"
#include "UI/waitingspinnerwidget.h"

#include <QWebFrame>
#include <QWebElementCollection>
#include <QNetworkDiskCache>

#include "sale_statistics.h"


class SaleCheckWidget : public QWebView
{
    Q_OBJECT

public:
    explicit SaleCheckWidget(QWebView *parent = 0);
    ~SaleCheckWidget();
    void init();
private:
    WaitingSpinnerWidget *waiting;
    SaleStatistics *stat;
    bool inited;


private slots:
    void getData();
    void addJsonObj();
    void recv_data(Response resp);
    QStringList JsonArray2QStringList(const QJsonArray &array);
    QList<QStringList> JsonArray2QList(const QJsonArray &array);
};

#endif // SALE_CHECK_WIDGET_H
