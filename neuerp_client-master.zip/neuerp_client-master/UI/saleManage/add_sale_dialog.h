#ifndef ADD_SALE_DIALOG_H
#define ADD_SALE_DIALOG_H

#include <QDialog>
#include <QJsonArray>
#include <QJsonObject>
#include <QMenu>
#include <QCompleter>
#include <QModelIndexList>
#include <QRegExpValidator>
#include "add_sale_dialog.h"
#include "show_sale_item_dialog.h"
#include "Network/Body/response.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Entity/sale_list.h"
#include "Entity/sale_item.h"
#include "Entity/product.h"
#include "UI/msgbox.h"
#include "UI/waitingspinnerwidget.h"
#include "usercontroller.h"

namespace Ui {
class AddSaleDialog;
}

class AddSaleDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddSaleDialog(QWidget *parent = 0);
    ~AddSaleDialog();

signals:
    void add_success();

private slots:
    void create_sale();

    void recv_add_sale(Response);
    void recv_product(Response);

    void on_btn_add_clicked();
    void on_btnMenu_Close_clicked();
    void on_btn_delete_clicked();
    void on_btn_save_clicked();
    void finish_edit();

private:
    Ui::AddSaleDialog *ui;
    QDoubleValidator *price_validator;
    QIntValidator *amount_validator;
    QCompleter *completer;
    WaitingSpinnerWidget *waiting;
    std::vector<Product> stock_products;
    std::vector<Product> add_products;

    QModelIndexList deleteRepeatList(QModelIndexList index_list);
    void search_product();
};

#endif // ADD_SALE_DIALOG_H






