#include "sale_widget.h"
#include "ui_sale_widget.h"
#include "usercontroller.h"

/**
* @functionName  SaleWidget
* @Description   the constructor that initial sale list widget
*                interface.
* @author        luxijia
* @date          2018-7-12
*/
SaleWidget::SaleWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SaleWidget)
{
    ui->setupUi(this);
    item = 10;
    inited=false;
    waiting = new WaitingSpinnerWidget(this);
    add_sale_list = new AddSaleDialog();
    show_sale_item = new ShowSaleItemDialog();

    //fixed table rows number
    ui->tableWidget->setRowCount(item);
    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    //set time
    ui->dedit_end->setDate(QDate::currentDate());
    ui->dedit_start->setDate(QDate::currentDate().addDays(-7));

    //set tool button
    ui->tbtn_left->setArrowType(Qt::LeftArrow);
    ui->tbtn_right->setArrowType(Qt::RightArrow);

    //set right mouse button menu
    create_menu();

    //connect search line deit return presss signal with search button clicked signal
    connect(ui->ledit_serach, SIGNAL(returnPressed()), ui->btn_search, SIGNAL(clicked()));

    //connect left and right tool button whth last page and next page function
    connect(ui->tbtn_left, SIGNAL(clicked()), this, SLOT(last_page()));
    connect(ui->tbtn_right, SIGNAL(clicked()), this, SLOT(next_page()));

    //connect change_supplier to class ChangeSupplierInforDialog get_supplier
    connect(this, SIGNAL(send_sale_to_show_dialog(SaleList)), show_sale_item, SLOT(get_sale_list(SaleList)));
    connect(add_sale_list, SIGNAL(add_success()), this, SLOT(recv_add_sale_success()));
    connect(this, SIGNAL(add_new_sale()), add_sale_list, SLOT(create_sale()));

    // set style
    ui->ledit_serach->setProperty("type", "input");
    ui->btn_add_sale->setProperty("btn_color", "green");
    ui->btn_delete_sale->setProperty("btn_color", "red");
    ui->btn_repeal_sale->setProperty("btn_color", "red");
    ui->btn_search->setProperty("btn_color", "green");
    ui->tbtn_left->setProperty("btn_color", "green");
    ui->tbtn_right->setProperty("btn_color", "green");

    // set permission
    auto &user = UserController::get_instance();
    if(!user.check_access_code("dept_supplier_manager")){
        ui->btn_delete_sale->hide();
    }

}

/**
* @functionName  ~SaleWidget
* @Description   the constructor that release sale widget resource.
*                interface.
* @author        luxijia
* @date          2018-7-12
*/
SaleWidget::~SaleWidget()
{
    delete ui;
    delete add_sale_list;
    delete show_sale_item;
    delete show_sale;
    delete repeal_sale;
    delete delete_sale;
    delete waiting;
}

/**
* @functionName  create_menu
* @Description   crete table widget right mouse menu
* @author        luxijia
* @date          2018-7-12
*/
void SaleWidget::create_menu()
{
    right_menu = new QMenu(this->ui->tableWidget);

    show_sale = new QAction(this);
    repeal_sale = new QAction(this);

    show_sale->setText(QString("查看详情"));
    repeal_sale->setText(QString("撤销"));

    right_menu->addAction(show_sale);
    right_menu->addAction(repeal_sale);

    auto &user = UserController::get_instance();
    if(user.check_access_code("dept_supplier_manager")){
        delete_sale = new QAction(this);
        delete_sale->setText(QString("删除"));
        right_menu->addAction(delete_sale);
        connect(delete_sale, SIGNAL(triggered()), this, SLOT(on_btn_delete_sale_clicked()));
    }

    //connect action
    connect(show_sale, SIGNAL(triggered()), this, SLOT(show_sale_item_info()));
    connect(repeal_sale, SIGNAL(triggered()), this , SLOT(on_btn_repeal_sale_clicked()));
    connect(this->ui->tableWidget, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(right_menu_action(const QPoint&)));

}

/**
* @functionName  right_menu_action
* @Description   show right menu item
* @author        luxijia
* @date          2018-7-12
* @parameter     QPoint dialog postion
*/
void SaleWidget::right_menu_action(const QPoint &pos)
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();
    int rows = count / this->ui->tableWidget->columnCount();
    int row = -1;
    int repeal_count = 0, finish_count = 0;

    if (rows > 0)
    {
        show_sale->setEnabled(true);
        repeal_sale->setEnabled(true);
        delete_sale->setEnabled(true);

        if (rows > 1)
            show_sale->setDisabled(true);

        for (int i = 0; i < count; i++)
        {
            if (row != this->ui->tableWidget->row(items.at(i)))
            {
                row = this->ui->tableWidget->row(items.at(i));
                if (0 == sale_lists[row].getSale_state())
                    repeal_count++;

                if (1 == sale_lists[row].getSale_state())
                    finish_count++;
            }
        }

        if (0 != repeal_count)
            repeal_sale->setDisabled(true);

        if (0 == finish_count)
            repeal_sale->setDisabled(true);

        right_menu->exec(QCursor::pos());
    }
}

/**
* @functionName  refresh_page
* @Description   refresh combobox context and set current page.
* @author        luxijia
* @date          2018-7-12
*/
void SaleWidget::refresh_page()
{
    disconnect(this->ui->comboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(change_page(int)));
    this->ui->tbtn_left->setEnabled(!(current_page == 1));
    this->ui->tbtn_right->setEnabled(!(current_page == page));
    this->ui->comboBox->clear();

    for (int i = 0; i < page; i++)
        this->ui->comboBox->insertItem(i, QString("第%1页").arg(i+1));

    this->ui->comboBox->setCurrentIndex(current_page - 1);
    connect(this->ui->comboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(change_page(int)));
}

/**
* @functionName  change_page
* @Description   change current page number and search supplier
* @author        luxijia
* @date          2018-7-10
* @parameter     new_index combobox next state index
*/
void SaleWidget::change_page(int new_index)
{
    current_page = new_index + 1;
    search_sale_list();
}

/**
* @functionName  init_sale_list
* @Description   set all search sale list condition to default
*                and search;
* @author        luxijia
* @date          2018-7-15
*/
void SaleWidget::init_sale_list()
{
    if (inited)
       return;

    inited=true;
    current_page = 1;
    this->ui->ledit_serach->clear();
    this->ui->cbox_finish->clicked(false);
    this->ui->cbox_repeal->clicked(false);
    this->ui->dedit_start->setDate(QDate::currentDate().addDays(-7));
    this->ui->dedit_end->setDate(QDate::currentDate());
    search_sale_list();
}

/**
* @functionName  last_page
* @Description   a slot funtion that return last page.
* @author        luxijia
* @date          2018-7-12
*/
void SaleWidget::last_page()
{
    //since combobox index begin in 0, and actually page begin in 1,
    //index need sub 1 and then sub 1
    int index = current_page - 2;

    if (index < 0)
        index = 0;

    change_page(index);
}

/**
* @functionName  next_page
* @Description   a slot funtion that return last page.
* @author        luxijia
* @date          2018-7-12
*/
void SaleWidget::next_page()
{
    //since combobox index begin in 0, and actually page begin in 1,
    //index need and 1 and then sub 1
    int index = current_page;

    if (index > page)
        index = page;

    change_page(current_page);
}

/**
* @functionName  on_btn_search_clicked
* @Description   a slot function that send search sale list request
*                after click search botton.
* @author        luxijia
* @date          2018-7-10
*/
void SaleWidget::on_btn_search_clicked()
{
    current_page = 1;
    search_sale_list();
}

/**
* @functionName  search_sale_list
* @Description   send search sale list request to server.
* @author        luxijia
* @date          2018-7-12
*/
void SaleWidget::search_sale_list()
{
    Request req;
    req.set_module("sale");
    req.set_func("search_list");

    int state;

    if (true == this->ui->cbox_repeal->isChecked())
        state = 1;

    if (true == this->ui->cbox_finish->isChecked())
        state = 0;

    if ((this->ui->cbox_repeal->isChecked() == true && this->ui->cbox_finish->isChecked() == true)
            || (this->ui->cbox_repeal->isChecked() == false && this->ui->cbox_finish->isChecked() == false))
        state = -1;

    req.put("state", state);
    req.put("keyword", this->ui->ledit_serach->text());
    req.put("page_number", current_page);
    req.put("page_item", item);
    req.put("start_time", this->ui->dedit_start->date().toString("yyyy-MM-dd"));
    req.put("end_time", this->ui->dedit_end->date().toString("yyyy-MM-dd"));

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_search_sale_list(Response)));
}

/**
* @functionName  recv_search_sale_list
* @Description   a slot function that receive search sale list request's respone,
*                show whether search success, and close conncection.
* @author        luxijia
* @date          2018-7-12
* @parameter     resp network response
*/
void SaleWidget::recv_search_sale_list(Response resp)
{
    if ("sale" != resp.get_module() || "search_list" != resp.get_func())
        return;


    //close connection
    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_search_sale_list(Response)));

    if (EMPTY_QUERY == resp.get_status_code())
    {
        this->ui->tableWidget->clearContents();
        return;
    }
    else if (QUERY_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "查询失败!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "发送参数出错!");
        return;
    }

    sale_lists.clear();
    page = ceil((double)resp.get_int("all_result_num") / item);
    QJsonArray sale_list_array = resp.get_array("sale_list");

    if (!sale_list_array.isEmpty())
    {
        int size = sale_list_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = sale_list_array.at(i);

            if (value.isObject())
            {
                QJsonObject sale_list_object = value.toObject();
                SaleList sale_list;
                sale_list.setSale_id(sale_list_object.value("id").toString());
                sale_list.setSale_date(sale_list_object.value("date").toString());
                sale_list.setClient_name(sale_list_object.value("client_name").toString());
                sale_list.setClient_address(sale_list_object.value("client_address").toString());
                sale_list.setClient_phone(sale_list_object.value("client_phone").toString());
                sale_list.setSale_state(sale_list_object.value("sale_state").toInt());
                sale_list.setSalesman(sale_list_object.value("salesman").toString());
                sale_list.setHandler_id(sale_list_object.value("handler_id").toString());
                sale_list.setHandler_name(sale_list_object.value("handler_name").toString());
                sale_list.setRemark(sale_list_object.value("remark").toString());
                sale_lists.push_back(sale_list);
            }
        }
    }

    refresh_page();
    show_sale_list();
}

/**
* @functionName  show_sale_list
* @Description   show sale list information in table widget.
* @author        luxijia
* @date          2018-7-12
*/
void SaleWidget::show_sale_list()
{
    int size = sale_lists.size();
    this->ui->tableWidget->clearContents();

    for (int i = 0; i < size; i++)
    {
        this->ui->tableWidget->setItem(i, 0, new QTableWidgetItem(sale_lists[i].getSale_id()));
        this->ui->tableWidget->setItem(i, 1, new QTableWidgetItem(sale_lists[i].getSale_date()));
        this->ui->tableWidget->setItem(i, 2, new QTableWidgetItem(sale_lists[i].getClient_name()));
        this->ui->tableWidget->setItem(i, 3, new QTableWidgetItem(sale_lists[i].getClient_address()));
        this->ui->tableWidget->setItem(i, 4, new QTableWidgetItem(sale_lists[i].getClient_phone()));
        this->ui->tableWidget->setItem(i, 5, new QTableWidgetItem(sale_lists[i].getRemark()));

        if (1 == sale_lists[i].getSale_state())
            this->ui->tableWidget->setItem(i, 6, new QTableWidgetItem("已完成"));
        else
            this->ui->tableWidget->setItem(i, 6, new QTableWidgetItem("撤销"));

        this->ui->tableWidget->setItem(i, 7, new QTableWidgetItem(sale_lists[i].getSalesman()));
        this->ui->tableWidget->setItem(i, 8, new QTableWidgetItem(sale_lists[i].getHandler_name()));
    }
}
/**
* @functionName  on_btn_remove_supplier_clicked
* @Description   a slot function that repeal selected supplier
*                and send request.
* @author        luxijia
* @date          2018-7-12
*/
void SaleWidget::on_btn_repeal_sale_clicked()
{

    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();

    if (0 == count)
        return;

    Request req;
    req.set_module("sale");
    req.set_func("cancel");

    //get repeal supplier id
    QJsonArray sale_id;

    int row = -1;

    for (int i = 0; i < count; i++)
    {
        if (row != this->ui->tableWidget->row(items.at(i)))
        {
            row = this->ui->tableWidget->row(items.at(i));
            sale_id.append(sale_lists[row].getSale_id());

            if (0 == sale_lists[row].getSale_state())
            {
                MsgBox::warming(this, "警告", "试图移除已撤销销售单");
                return;
            }
        }
    }

    req.put("sale_id", sale_id);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_repeal_sale_list(Response)));
}

/**
* @functionName  recv_repeal_sale_list
* @Description   a slot function that receive repeal sale list request's respone,
*                show whether repeal success, and close conncection.
* @author        luxijia
* @date          2018-7-12
* @parameter     resp network response
*/
void SaleWidget::recv_repeal_sale_list(Response resp)
{
    if ("sale" != resp.get_module() || "cancel" != resp.get_func())
        return;

    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_repeal_sale_list(Response)));

    if (CHANGE_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "撤销销售单失败!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "发送参数出错!");
        return;
    }

    search_sale_list();
}

/**
* @functionName  on_btn_delete_supplier_clicked
* @Description   a slot function that delete selected supplier
*                and send request.
* @author        luxijia
* @date          2018-7-9
*/
void SaleWidget::on_btn_delete_sale_clicked()
{

    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();

    if (0 == count)
        return;

    int flag = MsgBox::question(this, "注意", "是否确认删除供应商品,此操作无法撤销!");

    if (flag == MsgBox::NO)
        return;

    Request req;
    req.set_module("sale");
    req.set_func("delete_sale");

    //get remove supplier id
    QJsonArray sale_id;

    int row = -1;

    for (int i = 0; i < count; i++)
    {
        if (row != this->ui->tableWidget->row(items.at(i)))
        {
            row = this->ui->tableWidget->row(items.at(i));
            sale_id.append(sale_lists[row].getSale_id());
        }
    }

    req.put("sale_id", sale_id);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_delete_sale_list(Response)));
}

/**
* @functionName  recv_delete_sale_list
* @Description   a slot function that receive delete sale list request's respone,
*                show whether delete success, and close conncection.
* @author        luxijia
* @date          2018-7-12
* @parameter     resp network response
*/
void SaleWidget::recv_delete_sale_list(Response resp)
{
    if ("sale" != resp.get_module() || "delete_sale" != resp.get_func())
        return;

    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_delete_sale_list(Response)));

    if (DELETE_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "删除销售单失败!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "发送参数出错!");
        return;
    }

    search_sale_list();
}

/**
* @functionName  show_sale_item_info
* @Description   a slot function that send signal with argument supplier to show sale list
*                detail information dialog after show sale action.
* @author        luxijia
* @date          2018-7-12
*/
void SaleWidget::show_sale_item_info()
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int row = this->ui->tableWidget->row(items.at(0));

    emit send_sale_to_show_dialog(sale_lists[row]);
}

/**
* @functionName  on_dedit_end_userDateChanged
* @Description   when user change end date deit then end date edit time
*                can't less the start.
* @author        luxijia
* @date          2018-7-13
* @parameter     date end edit change date
*/
void SaleWidget::on_dedit_end_userDateChanged(const QDate &date)
{
    if (date < this->ui->dedit_start->date())
        this->ui->dedit_end->setDate(this->ui->dedit_start->date());
}

/**
* @functionName  on_dedit_start_userDateChanged
* @Description   when user change start date deit then start date edit time
*                can't more the start.
* @author        luxijia
* @date          2018-7-13
* @parameter     date start edit change date
*/
void SaleWidget::on_dedit_start_userDateChanged(const QDate &date)
{
    if (date > this->ui->dedit_end->date())
        this->ui->dedit_start->setDate(this->ui->dedit_end->date());
}

/**
* @functionName  on_btn_add_sale_clicked
* @Description   a slot function that open add sale list dialog.
* @author        luxijia
* @date          2018-7-13
* @parameter     date start edit change date
*/
void SaleWidget::on_btn_add_sale_clicked()
{
    emit add_new_sale();
}

/**
* @functionName  recv_add_sale_success
* @Description   a slot function that recv add sale list success signal.
* @author        luxijia
* @date          2018-7-13
* @parameter     date start edit change date
*/
void SaleWidget::recv_add_sale_success()
{
    this->ui->ledit_serach->clear();
    this->ui->cbox_finish->clicked(true);
    this->ui->cbox_repeal->clicked(false);
    current_page = 1;
    search_sale_list();
}
