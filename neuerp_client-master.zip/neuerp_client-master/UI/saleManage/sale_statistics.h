#ifndef SALE_STATISTICS_H
#define SALE_STATISTICS_H

#include <QObject>
#include <QStringList>
#include <QList>

class SaleStatistics : public QObject
{
    Q_OBJECT
public:
    explicit SaleStatistics(QObject *parent = nullptr);


private:
    QStringList top_salesman_week_name;
    QStringList top_salesman_week_saleroom;
    QStringList top_salesman_month_name;
    QStringList top_salesman_month_saleroom;

    QList<QStringList>   top_salesman_month_trend_saleroom;
    QStringList top_salesman_month_trend_date;

    QStringList top_product_week_name;
    QStringList top_product_week_volume;
    QStringList top_product_month_name;
    QStringList top_product_month_volume;

    QList<QStringList>   top_product_month_trend_volume;
    QStringList top_product_month_trend_date;

    QStringList total_saleroom_year_saleroom;
    QStringList total_saleroom_year_date;

    QStringList total_saleroom_month_date;
    QStringList total_saleroom_month_saleroom;






signals:

public slots:
    const QStringList haha();
    QStringList get_top_salesman_month_trend_saleroom_by_index(int i);

    QStringList get_top_product_month_trend_volume_by_index(int i);




    const QStringList getTop_salesman_week_name() const;

    void setTop_salesman_week_name(const QStringList &top_salesman_week_name);

    const QStringList getTop_salesman_week_saleroom() const;

    void setTop_salesman_week_saleroom(const QStringList &top_salesman_week_saleroom);

    const QStringList getTop_salesman_month_name() const;

    void setTop_salesman_month_name(const QStringList &top_salesman_month_name);

    const QStringList getTop_salesman_month_saleroom() const;

    void setTop_salesman_month_saleroom(const QStringList &top_salesman_month_saleroom);

    const QList<QStringList>   getTop_salesman_month_trend_saleroom() const;

    void setTop_salesman_month_trend_saleroom(const QList<QStringList>   &top_salesman_month_trend_saleroom);

    const QStringList   getTop_salesman_month_trend_date() const;

    void setTop_salesman_month_trend_date(const QStringList   &top_salesman_month_trend_date);

    const QStringList getTop_product_week_name() const;

    void setTop_product_week_name(const QStringList &top_product_week_name);

    const QStringList getTop_product_week_volume() const;

    void setTop_product_week_volume(const QStringList &top_product_week_volume);

    const QStringList getTop_product_month_name() const;

    void setTop_product_month_name(const QStringList &top_product_month_name);

    const QStringList getTop_product_month_volume() const;

    void setTop_product_month_volume(const QStringList &top_product_month_volume);

    const QList<QStringList>   getTop_product_month_trend_volume() const;

    void setTop_product_month_trend_volume(const QList<QStringList>   &top_product_month_trend_volume);

    const QStringList   getTop_product_month_trend_date() const;

    void setTop_product_month_trend_date(const QStringList   &top_product_month_trend_date);

    const QStringList getTotal_saleroom_year_saleroom() const;

    void setTotal_saleroom_year_saleroom(const QStringList &total_saleroom_year_saleroom);

    const QStringList getTotal_saleroom_year_date() const;

    void setTotal_saleroom_year_date(const QStringList &total_saleroom_year_date);

    const QStringList getTotal_saleroom_month_date() const;

    void setTotal_saleroom_month_date(const QStringList &total_saleroom_month_date);

    const QStringList getTotal_saleroom_month_saleroom() const;

    void setTotal_saleroom_month_saleroom(const QStringList &total_saleroom_month_saleroom);

};

#endif // SALE_STATISTICS_H
