#ifndef SHOW_SALE_ITEM_DIALOG_H
#define SHOW_SALE_ITEM_DIALOG_H

#include <QDialog>
#include <QJsonArray>
#include <QJsonObject>
#include <QMenu>
#include "add_sale_dialog.h"
#include "show_sale_item_dialog.h"
#include "Network/Body/response.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Entity/sale_list.h"
#include "Entity/sale_item.h"
#include "UI/msgbox.h"
#include "UI/iconhelper.h"
#include "status_code.h"
#include "UI/waitingspinnerwidget.h"


namespace Ui {
class ShowSaleItemDialog;
}

class ShowSaleItemDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ShowSaleItemDialog(QWidget *parent = 0);
    ~ShowSaleItemDialog();

private slots:
    void get_sale_list(const SaleList&);

    void recv_sale_item(Response);

    void on_btnMenu_Close_clicked();

private:
    Ui::ShowSaleItemDialog *ui;
    SaleList sale_list;
    WaitingSpinnerWidget *waiting;
    void search_sale_item();
    void show_sale_item();
};

#endif // SHOW_SALE_ITEM_DIALOG_H
