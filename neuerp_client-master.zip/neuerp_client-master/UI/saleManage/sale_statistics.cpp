#include "sale_statistics.h"

SaleStatistics::SaleStatistics(QObject *parent) : QObject(parent)
{

}

const QStringList SaleStatistics::haha()
{
    QStringList h;
    h.append("haha");
    h.append("lala");
    return h;
}

QStringList SaleStatistics::get_top_salesman_month_trend_saleroom_by_index(int i)
{
    return top_salesman_month_trend_saleroom.at(i);
}



QStringList SaleStatistics::get_top_product_month_trend_volume_by_index(int i)
{
    return top_product_month_trend_volume.at(i);
}




const QStringList SaleStatistics::getTop_salesman_week_name() const {
    return top_salesman_week_name;
}

void SaleStatistics::setTop_salesman_week_name(const QStringList &top_salesman_week_name) {
    SaleStatistics::top_salesman_week_name = top_salesman_week_name;
}

const QStringList SaleStatistics::getTop_salesman_week_saleroom() const {
    return top_salesman_week_saleroom;
}

void SaleStatistics::setTop_salesman_week_saleroom(const QStringList &top_salesman_week_saleroom) {
    SaleStatistics::top_salesman_week_saleroom = top_salesman_week_saleroom;
}

const QStringList SaleStatistics::getTop_salesman_month_name() const {
    return top_salesman_month_name;
}

void SaleStatistics::setTop_salesman_month_name(const QStringList &top_salesman_month_name) {
    SaleStatistics::top_salesman_month_name = top_salesman_month_name;
}

const QStringList SaleStatistics::getTop_salesman_month_saleroom() const {
    return top_salesman_month_saleroom;
}

void SaleStatistics::setTop_salesman_month_saleroom(const QStringList &top_salesman_month_saleroom) {
    SaleStatistics::top_salesman_month_saleroom = top_salesman_month_saleroom;
}

const QList<QStringList>   SaleStatistics::getTop_salesman_month_trend_saleroom() const {
    return top_salesman_month_trend_saleroom;
}

void SaleStatistics::setTop_salesman_month_trend_saleroom(const QList<QStringList>   &top_salesman_month_trend_saleroom) {
    SaleStatistics::top_salesman_month_trend_saleroom = top_salesman_month_trend_saleroom;
}

const QStringList   SaleStatistics::getTop_salesman_month_trend_date() const {
    return top_salesman_month_trend_date;
}

void SaleStatistics::setTop_salesman_month_trend_date(const QStringList &top_salesman_month_trend_date) {
    SaleStatistics::top_salesman_month_trend_date = top_salesman_month_trend_date;
}

const QStringList SaleStatistics::getTop_product_week_name() const {
    return top_product_week_name;
}

void SaleStatistics::setTop_product_week_name(const QStringList &top_product_week_name) {
    SaleStatistics::top_product_week_name = top_product_week_name;
}

const QStringList SaleStatistics::getTop_product_week_volume() const {
    return top_product_week_volume;
}

void SaleStatistics::setTop_product_week_volume(const QStringList &top_product_week_volume) {
    SaleStatistics::top_product_week_volume = top_product_week_volume;
}

const QStringList SaleStatistics::getTop_product_month_name() const {
    return top_product_month_name;
}

void SaleStatistics::setTop_product_month_name(const QStringList &top_product_month_name) {
    SaleStatistics::top_product_month_name = top_product_month_name;
}

const QStringList SaleStatistics::getTop_product_month_volume() const {
    return top_product_month_volume;
}

void SaleStatistics::setTop_product_month_volume(const QStringList &top_product_month_volume) {
    SaleStatistics::top_product_month_volume = top_product_month_volume;
}

const QList<QStringList>   SaleStatistics::getTop_product_month_trend_volume() const {
    return top_product_month_trend_volume;
}

void SaleStatistics::setTop_product_month_trend_volume(const QList<QStringList>   &top_product_month_trend_volume) {
    SaleStatistics::top_product_month_trend_volume = top_product_month_trend_volume;
}

const QStringList SaleStatistics::getTop_product_month_trend_date() const {
    return top_product_month_trend_date;
}

void SaleStatistics::setTop_product_month_trend_date(const QStringList   &top_product_month_trend_date) {
    SaleStatistics::top_product_month_trend_date = top_product_month_trend_date;
}

const QStringList SaleStatistics::getTotal_saleroom_year_saleroom() const {
    return total_saleroom_year_saleroom;
}

void SaleStatistics::setTotal_saleroom_year_saleroom(const QStringList &total_saleroom_year_saleroom) {
    SaleStatistics::total_saleroom_year_saleroom = total_saleroom_year_saleroom;
}

const QStringList SaleStatistics::getTotal_saleroom_year_date() const {
    return total_saleroom_year_date;
}

void SaleStatistics::setTotal_saleroom_year_date(const QStringList &total_saleroom_year_date) {
    SaleStatistics::total_saleroom_year_date = total_saleroom_year_date;
}

const QStringList SaleStatistics::getTotal_saleroom_month_date() const {
    return total_saleroom_month_date;
}

void SaleStatistics::setTotal_saleroom_month_date(const QStringList &total_saleroom_month_date) {
    SaleStatistics::total_saleroom_month_date = total_saleroom_month_date;
}

const QStringList SaleStatistics::getTotal_saleroom_month_saleroom() const {
    return total_saleroom_month_saleroom;
}

void SaleStatistics::setTotal_saleroom_month_saleroom(const QStringList &total_saleroom_month_saleroom) {
    SaleStatistics::total_saleroom_month_saleroom = total_saleroom_month_saleroom;
}
