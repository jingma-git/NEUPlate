#include "add_sale_dialog.h"
#include "ui_add_sale_dialog.h"

/**
* @functionName  AddSaleDialog
* @Description   the constructor taht initial class AddSaleDialog.
* @author        luxijia
* @date          2018-7-14
*/
AddSaleDialog::AddSaleDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddSaleDialog)
{
    ui->setupUi(this);
    this->setModal(true);

    waiting = new WaitingSpinnerWidget(this);

    //set completer
    completer = new QCompleter();
//    search_product();

    //set price line edit only input number
    price_validator = new QDoubleValidator();
    price_validator->setBottom(0.0);
    ui->ledit_proudct_price->setValidator(price_validator);

    amount_validator = new QIntValidator();
    amount_validator->setBottom(0);
    ui->ledit_product_amount->setValidator(amount_validator);

    //set tab order
    QWidget::setTabOrder(ui->ledit_client_name, ui->ledit_client_address);
    QWidget::setTabOrder(ui->ledit_client_address, ui->ledit_telephone);
    QWidget::setTabOrder(ui->ledit_telephone, ui->ledit_salesman);
    QWidget::setTabOrder(ui->ledit_salesman, ui->ledit_product_name);
    QWidget::setTabOrder(ui->ledit_product_name, ui->ledit_product_amount);
    QWidget::setTabOrder(ui->ledit_product_amount, ui->ledit_proudct_price);

    //set no border
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    //set table widget style
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);

    //connect
    connect(ui->btn_cancel, SIGNAL(clicked()), ui->btnMenu_Close, SIGNAL(clicked()));

    connect(ui->ledit_product_name, SIGNAL(editingFinished()), this, SLOT(finish_edit()));

    // set style
    ui->btn_add->setProperty("btn_color", "green");
    ui->btn_cancel->setProperty("btn_color", "red");
    ui->btn_delete->setProperty("btn_color", "red");
    ui->btn_save->setProperty("btn_color", "green");
    ui->ledit_client_address->setProperty("type", "input");
    ui->ledit_client_name->setProperty("type", "input");
    ui->ledit_product_name->setProperty("type", "input");
    ui->ledit_product_amount->setProperty("type", "input");
    ui->ledit_proudct_price->setProperty("type", "input");
    ui->ledit_salesman->setProperty("type", "input");
    ui->ledit_telephone->setProperty("type", "input");
    ui->ledit_remark->setProperty("type", "input");
}

/**
* @functionName  AddSaleDialog
* @Description   the constructor taht release class AddSaleDialog resource.
* @author        luxijia
* @date          2018-7-14
*/
AddSaleDialog::~AddSaleDialog()
{
    delete ui;
    delete price_validator;
    delete amount_validator;
    delete completer;
    delete waiting;
}

void AddSaleDialog::create_sale()
{
    search_product();
    this->show();
}

/**
* @functionName  on_btnMenu_Close_clicked
* @Description   a slot funtion that close add sale list information dialog
*                that judge supplier information whether change after clicked menu button.
*                if change then show message wheher give save.
* @author        luxijia
* @date          2018-7-12
*/
void AddSaleDialog::on_btnMenu_Close_clicked()
{
    int flag = -1;

    if (!this->ui->ledit_client_name->text().isEmpty() || !this->ui->ledit_client_address->text().isEmpty() ||
            !this->ui->ledit_telephone->text().isEmpty() || !this->ui->ledit_salesman->text().isEmpty() ||
            !this->ui->ledit_product_amount->text().isEmpty() || !this->ui->ledit_proudct_price->text().isEmpty() ||
            !this->ui->ledit_product_name->text().isEmpty() || !this->ui->ledit_remark->text().isEmpty())
    {
        flag = MsgBox::question(this, "关闭", "销售单未保存是否关闭");

        if (flag == MsgBox::NO)
            return;

        flag = -1;
    }

    int row_count = this->ui->tableWidget->rowCount();
    int column_count = this->ui->tableWidget->columnCount();
    int has_item = 0;

    for (int i = 0; i < row_count; i++)
    {
        for (int j = 0; j < column_count; j++)
        {
            if (this->ui->tableWidget->item(i, j) != NULL)
            {
                has_item = 1;
                break;
            }
        }
    }

    if (has_item == 1)
    {
        flag = MsgBox::question(this, "退出", "是否确认退出？");

        if (flag == MsgBox::NO)
            return;
    }

    for (int i = row_count - 1; i > -1; i--)
        this->ui->tableWidget->removeRow(i);

    this->ui->ledit_client_name->clear();
    this->ui->ledit_client_address->clear();
    this->ui->ledit_telephone->clear();
    this->ui->ledit_salesman->clear();
    this->ui->ledit_product_name->clear();
    this->ui->ledit_product_amount->clear();
    this->ui->ledit_proudct_price->clear();
    this->ui->ledit_remark->clear();
    this->ui->label_product_tip->clear();
    this->ui->label_higher_stock->clear();
    add_products.clear();

    this->close();
}

/**
* @functionName  finish_edit
* @Description   finsh edit product name then change stock_number.
* @author        luxijia
* @date          2018-7-12
*/
void AddSaleDialog::finish_edit()
{
    int size = stock_products.size();

    if (this->ui->label_product_name->text().isEmpty())
    {
        this->ui->label_product_tip->clear();
        this->ui->label_higher_stock->clear();
        return;
    }

    int i = 0;

    for (i = 0; i < size; i++)
    {
        if (stock_products[i].getName() == this->ui->ledit_product_name->text())
        {
            break;
        }
    }

    if (i == size)
    {
        this->ui->label_product_tip->setText("无此商品");
        return;
    }

    this->ui->label_product_tip->clear();
    this->ui->label_higher_stock->setText("最大库存:" + QString("%1").arg(stock_products[i].getStock_amount()));
    this->ui->ledit_proudct_price->setText(QString("%1").arg(stock_products[i].getPrice()));
    amount_validator->setTop(stock_products[i].getStock_amount());
}

/**
* @functionName  AddSaleDialog
* @Description   send search product funtion.
* @author        luxijia
* @date          2018-7-12
*/
void AddSaleDialog::search_product()
{
    Request req;
    req.set_module("product");
    req.set_func("get_products");
    req.put("keyword", "");
    req.put("lowest_price", 0);
    req.put("highest_price", 10000);
    req.put("order_by_price", -1);
    req.put("lowest_stock", 1);
    req.put("highest_stock", 10000);
    req.put("order_by_stock", -1);
    req.put("page", 1);
    req.put("page_size", 99999999);
    req.put("state", 1);

    auto &client = MainClient::get_instance();
    client.send(req);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_product(Response)));
}

/**
* @functionName  recv_product
* @Description   a slot funtion that receive get products request's response.
* @author        luxijia
* @date          2018-7-12
*/
void AddSaleDialog::recv_product(Response resp)
{
    if ("product" != resp.get_module() || "get_products" != resp.get_func())
        return;

    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_product(Response)));

    if(ILLEGAL_ACCESS == resp.get_status_code()) return;
    if (SQL_EXEC_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "商品列表", "查询商品列表出错");
    }

    QJsonArray product_array = resp.get_array("products");
    QStringList string_list;

    stock_products.clear();

    if (!product_array.isEmpty())
    {
        int size = product_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = product_array.at(i);

            if (value.isObject())
            {
                QJsonObject product_object = value.toObject();
                Product product;
                product.setP_id(product_object.value("p_id").toString());
                product.setName(product_object.value("name").toString());
                product.setPrice(product_object.value("price").toDouble());
                product.setBar_code(product_object.value("bar_code").toString());
                product.setStock_amount(product_object.value("stock_amount").toInt());
                string_list.append(product_object.value("name").toString());
                stock_products.push_back(product);
            }
        }
    }
    completer->setModel(new QStringListModel(string_list, this));
    completer->setFilterMode(Qt::MatchStartsWith);
    completer->setCompletionMode(QCompleter::PopupCompletion);
    completer->setCaseSensitivity(Qt::CaseInsensitive);
    completer->setMaxVisibleItems(7);
    this->ui->ledit_product_name->setCompleter(completer);
}

/**
* @functionName  on_btn_add_clicked
* @Description   a slot funtion that add product information to table widget
*                that judge product information whether is empty.
* @author        luxijia
* @date          2018-7-12
*/
void AddSaleDialog::on_btn_add_clicked()
{
    if (this->ui->ledit_product_name->text().isEmpty() || this->ui->ledit_product_amount->text().isEmpty() ||
            this->ui->ledit_proudct_price->text().isEmpty())
    {
        MsgBox::warming(this, "添加", "添加商品信息未填写完全");
    }

    int size = stock_products.size();
    int i = 0;

    for (i = 0; i < size; i++)
    {
        if (stock_products[i].getName() == this->ui->ledit_product_name->text())
            break;
    }

    if (i == size)
    {
        MsgBox::warming(this, "添加", "没有该商品!");
        return;
    }

    int add_size = add_products.size();
    int is_in = 0;
    int j = 0;

    for (j = 0; j < add_size; j++)
    {
        if (add_products[j].getP_id() == stock_products[i].getP_id())
        {
            is_in = 1;
            break;
        }
    }

    if (0 == is_in)
    {
        int row = this->ui->tableWidget->rowCount();
        this->ui->tableWidget->insertRow(row);

        this->ui->tableWidget->setItem(row, 0, new QTableWidgetItem(this->ui->ledit_product_name->text()));
        this->ui->tableWidget->setItem(row, 1, new QTableWidgetItem(this->ui->ledit_proudct_price->text()));
        this->ui->tableWidget->setItem(row, 2, new QTableWidgetItem(this->ui->ledit_product_amount->text()));
    }
    else
    {
        add_products[j].setStock_amount(add_products[j].getStock_amount() +
                                        this->ui->ledit_product_amount->text().toInt());
        add_products[j].setPrice(this->ui->ledit_proudct_price->text().toDouble());
        this->ui->tableWidget->setItem(j, 1, new QTableWidgetItem(QString("%1").arg(add_products[j].getPrice())));
        this->ui->tableWidget->setItem(j, 2, new QTableWidgetItem(QString("%1").arg(add_products[j].getStock_amount())));
    }

    Product product;
    stock_products[i].setStock_amount(stock_products[i].getStock_amount()
                                      - this->ui->ledit_product_amount->text().toInt());
    product.setP_id(stock_products[i].getP_id());
    product.setName(stock_products[i].getName());
    product.setBar_code(stock_products[i].getBar_code());
    product.setPrice(this->ui->ledit_proudct_price->text().toDouble());
    product.setStock_amount(this->ui->ledit_product_amount->text().toInt());
    add_products.push_back(product);

    this->ui->ledit_product_name->clear();
    this->ui->ledit_product_amount->clear();
    this->ui->ledit_proudct_price->clear();
    this->ui->label_product_tip->clear();
    this->ui->label_higher_stock->clear();
}

/**
* @functionName  on_btn_delete_clicked
* @Description   a slot funtion that delete product information in table widget.
* @author        luxijia
* @date          2018-7-12
*/
void AddSaleDialog::on_btn_delete_clicked()
{
    QModelIndexList selected = this->ui->tableWidget->selectionModel()->selectedIndexes();
    int size = stock_products.size();

    while (!selected.isEmpty())
    {
        QModelIndexList index_list = deleteRepeatList(selected);
        QModelIndex index = index_list.first();
        int row = index.row();

        for (int i = 0; i < size; i++)
        {
            if (stock_products[i].getP_id() == add_products[row].getP_id())
                stock_products[i].setStock_amount(stock_products[i].getStock_amount() +
                                                  add_products[row].getStock_amount());
        }

        add_products.erase(add_products.begin() + row);

        this->ui->tableWidget->removeRow(row);
        selected = this->ui->tableWidget->selectionModel()->selectedIndexes();
    }
}

/**
* @functionName  deleteRepeatList
* @Description   copy old table widget select model index list
*                to a new model index list to resort table line
*                and avoid repeat delete.
* @author        luxijia
* @date          2018-7-12
* @parameter     index_list old model index list
* @return        new_index_list new model index list that no repeat line.
*/
QModelIndexList AddSaleDialog::deleteRepeatList(QModelIndexList index_list)
{
    QModelIndex index, new_index;
    QModelIndexList new_index_list;

    foreach (index, index_list)
    {
        if (new_index.row() != index.row())
        {
            new_index = index;
            new_index_list.append(new_index);
        }
    }

    return new_index_list;
}

/**
* @functionName  on_btn_save_clicked
* @Description   a slot funtion that collect all information and seng add sale list
*                to server.
* @author        luxijia
* @date          2018-7-12
*/
void AddSaleDialog::on_btn_save_clicked()
{
    if (this->ui->ledit_client_name->text().isEmpty() || this->ui->ledit_client_address->text().isEmpty() ||
            this->ui->ledit_telephone->text().isEmpty() || this->ui->ledit_salesman->text().isEmpty())
    {
        MsgBox::warming(this, "创建", "客户信息未填写完全");
        return;
    }

    if (!this->ui->ledit_product_amount->text().isEmpty() || !this->ui->ledit_proudct_price->text().isEmpty())
    {
        int flag = MsgBox::question(this, "创建", "有商品未添加到销售单，是否放弃添加!");

        if (flag == MsgBox::YES)
        {
            this->ui->ledit_product_name->clear();
            this->ui->ledit_product_amount->clear();
            this->ui->ledit_proudct_price->clear();
        }
    }

    int row_count = this->ui->tableWidget->rowCount();
    int column_count = this->ui->tableWidget->columnCount();

    for (int i = 0; i < row_count; i++)
    {
        for (int j = 0; j < column_count; j++)
        {
            if (this->ui->tableWidget->item(i, j) == NULL)
            {
                MsgBox::warming(this, "创建", "销售商品信息未填写完毕!");
            }
        }
    }

    Request req;
    QJsonArray item_array;
    auto &user = UserController::get_instance();

    req.set_module("sale");
    req.set_func("add");
    req.put("date", QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));
    req.put("client_name", this->ui->ledit_client_name->text());
    req.put("client_address", this->ui->ledit_client_address->text());
    req.put("client_phone", this->ui->ledit_telephone->text());
    req.put("salesman", this->ui->ledit_salesman->text());
    req.put("handler_id", user.get_e_id());
    req.put("remark", this->ui->ledit_remark->text());

    for (int i = 0; i < row_count; i++)
    {
        QJsonObject sale_item;
        for (int j = 0; j < column_count; j++)
        {
            switch (j) {
            case 0:
                sale_item.insert("id", add_products[i].getP_id());
                break;
            case 1:
                sale_item.insert("price", this->ui->tableWidget->item(i, j)->text().toDouble());
                break;
            case 2:
                sale_item.insert("amount", this->ui->tableWidget->item(i, j)->text().toInt());
                break;
            default:
                break;
            }
        }
        item_array.append(sale_item);
    }
    req.put("sale_array", item_array);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_add_sale(Response)));
}

void AddSaleDialog::recv_add_sale(Response resp)
{
    if ("sale" != resp.get_module() || "add" != resp.get_func())
        return;

    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_add_sale(Response)));

    if (ADD_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "创建", "创建销售订单失败!");
        return;
    }
    else if (SUCCESS == resp.get_status_code())
    {
        MsgBox::information(this, "创建", "创建成功");

        int row_count = this->ui->tableWidget->rowCount();

        for (int i = row_count - 1; i > -1; i--)
            this->ui->tableWidget->removeRow(i);

        this->ui->ledit_client_name->clear();
        this->ui->ledit_client_address->clear();
        this->ui->ledit_telephone->clear();
        this->ui->ledit_salesman->clear();
        this->ui->ledit_product_name->clear();
        this->ui->ledit_product_amount->clear();
        this->ui->ledit_proudct_price->clear();
        this->ui->ledit_remark->clear();

        this->close();
        search_product();
        add_products.clear();
        emit add_success();
    }
}


