#include "show_sale_item_dialog.h"
#include "ui_show_sale_item_dialog.h"

/**
* @functionName  ShowSaleItemDialog
* @Description   the constructor that initial sale list item dialog
*                interface.
* @author        luxijia
* @date          2018-7-12
*/
ShowSaleItemDialog::ShowSaleItemDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ShowSaleItemDialog)
{
    ui->setupUi(this);
    this->setModal(true);

    waiting = new WaitingSpinnerWidget(this);
    //set table widget style
    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);

    //set no border
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    //connect cancel button clicked signal with close menu button clicked signal
//    connect(ui->btn_ensure, SIGNAL(clicked()), ui->btnMenu_Close, SIGNAL(clicked()));

    ui->ledit_client_address->setProperty("type", "input");
    ui->ledit_client_name->setProperty("type", "input");
    ui->ledit_handler_name->setProperty("type", "input");
    ui->ledit_remark->setProperty("type", "input");
    ui->ledit_salesman->setProperty("type", "input");
    ui->ledit_sale_id->setProperty("type", "input");
    ui->ledit_telephone->setProperty("type", "input");
}

/**
* @functionName  ~ShowSaleItemDialog
* @Description   the deconstructor that release class ShowSaleItemDialog
*                interface.
* @author        luxijia
* @date          2018-7-12
*/
ShowSaleItemDialog::~ShowSaleItemDialog()
{
    delete ui;
    delete waiting;
}

/**
* @functionName  get_supplier
* @Description   a slot function get supplier information from supplier widget.
* @author        luxijia
* @date          2018-7-10
* @parameter     send_supplier supplier onject that store supplier information
*/
void ShowSaleItemDialog::get_sale_list(const SaleList &send_sale_list)
{
    sale_list = send_sale_list;

    this->ui->ledit_sale_id->setText(sale_list.getSale_id());
    this->ui->ledit_client_name->setText(sale_list.getClient_name());
    this->ui->ledit_client_address->setText(sale_list.getClient_address());
    this->ui->ledit_telephone->setText(sale_list.getClient_phone());
    this->ui->ledit_salesman->setText(sale_list.getSalesman());
    this->ui->ledit_handler_name->setText(sale_list.getHandler_name());
    this->ui->ledit_remark->setText(sale_list.getRemark());
    this->ui->dtedit_sale_date->setDateTime(QDateTime::fromString(sale_list.getSale_date(), "yyyy-MM-dd hh:mm:ss"));
    qDebug() << sale_list.getSale_date();

    if (0 == sale_list.getSale_state())
        this->ui->rbtn_repeal->click();
    else
        this->ui->rbtn_finish->click();

    this->ui->ledit_sale_id->setDisabled(true);
    this->ui->ledit_client_name->setDisabled(true);
    this->ui->ledit_client_address->setDisabled(true);
    this->ui->ledit_telephone->setDisabled(true);
    this->ui->ledit_salesman->setDisabled(true);
    this->ui->ledit_handler_name->setDisabled(true);
    this->ui->ledit_remark->setDisabled(true);
    this->ui->dtedit_sale_date->setDisabled(true);
    this->ui->rbtn_repeal->setDisabled(true);
    this->ui->rbtn_finish->setDisabled(true);

    search_sale_item();
    this->show();
}

/**
* @functionName  search_provide_product
* @Description   send search provide product request to server.
* @author        luxijia
* @date          2018-7-10
*/
void ShowSaleItemDialog::search_sale_item()
{
    Request req;
    req.set_module("sale");
    req.set_func("search_item");

    req.put("sale_id", sale_list.getSale_id());

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_sale_item(Response)));
}

/**
* @functionName  recv_sale_item
* @Description   a slot function that receive search sale list item request's respone,
*                show whether search success, and close conncection.
* @author        luxijia
* @date          2018-7-10
* @parameter     resp network response
*/
void ShowSaleItemDialog::recv_sale_item(Response resp)
{
    if ("sale" != resp.get_module() || "search_item" != resp.get_func())
        return;

    //close connection
    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_sale_item(Response)));

    if (EMPTY_QUERY == resp.get_status_code())
        return;
    else if (QUERY_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "查询失败!");
        this->close();
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "查询参数出错!");
        this->close();
        return;
    }

    QJsonArray sale_item_array = resp.get_array("sale_item");

    if (!sale_item_array.isEmpty())
    {
        int size = sale_item_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = sale_item_array.at(i);

            if (value.isObject())
            {
                QJsonObject sale_item_object = value.toObject();

                int row = this->ui->tableWidget->rowCount();
                this->ui->tableWidget->insertRow(row);

                this->ui->tableWidget->setItem(row, 0, new QTableWidgetItem(sale_item_object.value("name").toString()));
                this->ui->tableWidget->setItem(row, 1, new QTableWidgetItem(QString("%1").arg(sale_item_object.value("sale_price").toDouble())));
                this->ui->tableWidget->setItem(row, 2, new QTableWidgetItem(QString("%1").arg(sale_item_object.value("sale_amount").toInt())));
            }
        }
    }
}

/**
* @functionName  on_btnMenu_Close_clicked
* @Description   a slot function that close show item dialog.
* @author        luxijia
* @date          2018-7-10
* @parameter     resp network response
*/
void ShowSaleItemDialog::on_btnMenu_Close_clicked()
{
    int row_count = this->ui->tableWidget->rowCount();

    for (int i = row_count - 1; i > -1; i--)
        this->ui->tableWidget->removeRow(i);

    this->close();
}
