#include "sale_manage.h"
#include "ui_sale_manage.h"

/**
* @functionName  SaleManage
* @Description   the constructor that initial sale manage widget
*                interface.
* @author        luxijia
* @date          2018-7-11
*/
SaleManage::SaleManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SaleManage)
{
    ui->setupUi(this);

    sale_widget = new SaleWidget();
    sale_check_widget = new SaleCheckWidget();

    this->init_left_menu();
    this->init_stacked_widget();
}

/**
* @functionName  SaleManage
* @Description   the deconstructor that release class SaleManage resource.
*                interface.
* @author        luxijia
* @date          2018-7-11
*/
SaleManage::~SaleManage()
{
    delete ui;
    delete sale_widget;
    delete sale_check_widget;
}

/**
* @functionName  init_left_menu
* @Description   initial left menu int interface.
* @author        luxijia
* @date          2018-7-11
*/
void SaleManage::init_left_menu()
{
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf0ca << 0xf201;
    btns << ui->btn_sale << ui->btn_check;

    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btn_sale->click();
}

/**
* @functionName  init_stacked_widget
* @Description   initial statcked order int interface.
* @author        luxijia
* @date          2018-7-11
*/
void SaleManage::init_stacked_widget()
{
    ui->stackedWidget->insertWidget(0, sale_widget);
    ui->stackedWidget->insertWidget(1, sale_check_widget);
}

void SaleManage::init_statistics()
{
//    sale_check_widget->init();
}

/**
* @functionName  menu_click
* @Description   enter menu button to change menu.
* @author        luxijia
* @date          2018-7-11
*/
void SaleManage::menu_click()
{
    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);

    if(b == ui->btn_sale){
        ui->stackedWidget->setCurrentIndex(0);
//        sale_widget->init_sale_list();
    }else if(b == ui->btn_check){
        sale_check_widget->init();
        ui->stackedWidget->setCurrentIndex(1);
    }
}

/**
* @functionName  init_sale
* @Description   init sale interface after click sale manage button.
* @author        luxijia
* @date          2018-7-11
*/
void SaleManage::init_sale()
{
    sale_widget->init_sale_list();
}
