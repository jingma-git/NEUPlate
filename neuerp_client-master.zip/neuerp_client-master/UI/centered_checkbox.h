#ifndef CENTERED_CHECKBOX_H
#define CENTERED_CHECKBOX_H

#include <QWidget>
#include <QHBoxLayout>
#include <QCheckBox>

class CenteredCheckBox : public QWidget
{
    Q_OBJECT
public:
    explicit CenteredCheckBox(QWidget *parent = 0);
    bool isChecked();

signals:

public slots:
private:
    QCheckBox *checkBox;
    QHBoxLayout *layout;

};

#endif // CENTERED_CHECKBOX_H
