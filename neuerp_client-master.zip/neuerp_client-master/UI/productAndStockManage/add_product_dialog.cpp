#include "add_product_dialog.h"
#include "ui_add_product_dialog.h"
#include <QPixmap>
#include <QByteArray>


//图片没有处理。

AddProductDialog::AddProductDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddProductDialog)
{
    ui->setupUi(this);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    waiting=new WaitingSpinnerWidget(this);
    cut_photo = new CutPhotoDialog;
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    ui->btnSave->setProperty("btn_color","green");
    ui->btnUpload->setProperty("btn_color","green");
    ui->btnCancel->setProperty("btn_color","red");
    ui->leditName->setProperty("type","input");
    ui->leditBarCode->setProperty("type","input");
    ui->leditPrice->setProperty("type","input");
    ui->teditDescription->setProperty("type","input");

    stock_checked(false);
    ui->teditDescription->setTabChangesFocus(true);
    //回车提交
    connect(ui->leditPrice,SIGNAL(returnPressed()),ui->btnSave,SIGNAL(clicked()));


    connect(ui->btnSave,SIGNAL(clicked()),this,SLOT(submit()));
    connect(ui->btnCancel,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->radioOnSale,SIGNAL(clicked(bool)),this,SLOT(stock_checked(bool)));
    connect(cut_photo, SIGNAL(notify_data(QByteArray)), this, SLOT(receive_photo_data(QByteArray)));

    QWidget::setTabOrder(ui->leditName,ui->leditBarCode);
    QWidget::setTabOrder(ui->leditBarCode,ui->teditDescription);
    QWidget::setTabOrder(ui->teditDescription,ui->leditPrice);
    QWidget::setTabOrder(ui->leditPrice,ui->radioOnSale);
    QWidget::setTabOrder(ui->radioOnSale,ui->spinBoxStock);
    QWidget::setTabOrder(ui->spinBoxStock,ui->btnSave);
    QWidget::setTabOrder(ui->btnSave,ui->btnCancel);


    QDoubleValidator *price_validator=new QDoubleValidator();
    price_validator->setBottom(0.0);
    ui->leditPrice->setValidator(price_validator);

}




void AddProductDialog::stock_checked(bool checked){
    if(ui->spinBoxStock->value()==0){
        //如果是0库存，那想上（下）架就上（下）架
        ui->labelStock->setVisible(checked);
        ui->spinBoxStock->setVisible(checked);
    }else if(ui->spinBoxStock->value()>0){
        if(!checked){
            MsgBox::information(0,"商品信息","只有库存为0时才能下架");
            ui->radioOnSale->setChecked(true);
        }else{
            ui->labelStock->setVisible(checked);
            ui->spinBoxStock->setVisible(checked);
        }

    }

}

AddProductDialog::~AddProductDialog()
{
    delete ui;
    delete waiting;
}

void AddProductDialog::edit_product(Product &product)
{
    this->product=product;
    this->isedit=true;
    ui->leditBarCode->insert(product.getBar_code());
    ui->leditName->insert(product.getName());
    ui->leditPrice->insert(QString::number(product.getPrice(),'f',2));

    ui->teditDescription->insertPlainText(product.getDescription());

    ui->radioOnSale->setChecked((product.getState()==1));
    stock_checked(true);
    ui->spinBoxStock->setValue(product.getStock_amount());

    QPixmap photo;
    photo.loadFromData(QByteArray::fromBase64(product.get_photo().toUtf8()));
    ui->labelImage->setPixmap(photo);
}


void AddProductDialog::submit(){
    Request req;

    product.setName(ui->leditName->text());
    product.setDescription(ui->teditDescription->toPlainText());
    product.setPrice(ui->leditPrice->text().toDouble());
    product.setState((ui->radioOnSale->isChecked()?1:0));
    product.setBar_code(ui->leditBarCode->text());
    qDebug()<<"bar_code"<<product.getBar_code();
    product.setStock_amount(ui->spinBoxStock->value());
//    product.set_photo(this->photo_data_base64);
    // product.setImg_url()

    if(product.getName().isEmpty() || product.getDescription().isEmpty() || !product.getPrice() || product.getBar_code().isEmpty() || product.get_photo().isEmpty()){
        MsgBox::warming(nullptr, tr(""), tr("请输入完整信息"));
        return;
    }

    if(isedit){
        req.set_func("update_product");
    }else{
        req.set_func("add_product");
    }

    req.set_module("product");
    req.set_params(product.toJSON());


    MainClient &client=MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_info(Response)));
}

void AddProductDialog::recv_info(Response resp){
    if(resp.get_module()!="product"){
        return;
    }
    int status_code=resp.get_status_code();
    waiting->stop();
    if(resp.get_func()=="add_product"){
        if(status_code==SUCCESS){
            MsgBox::success(this,"添加商品","添加成功");
            emit refresh_table();
            close();
            qDebug()<<"success";
        }else if(status_code==BAR_CODE_ERROR){
            MsgBox::warming(this,"添加商品","条形码冲突,请检查");
            qDebug()<<"bar_code_error";
        }else{
            MsgBox::warming(this,"添加商品","添加失败");
            qDebug()<<"failed";
        }
    }else if(resp.get_func()=="update_product"){
        if(status_code==SUCCESS){
            MsgBox::success(this,"修改商品信息","修改成功");
            emit refresh_table();
            close();
            qDebug()<<"success";
        }else if(status_code==BAR_CODE_ERROR){
            MsgBox::warming(this,"修改商品信息","条形码冲突,请检查");
            qDebug()<<"bar_code_error";
        }else{
            MsgBox::warming(this,"修改商品信息","修改失败");
            qDebug()<<"failed";
        }
    }else{
        return;
    }

    MainClient &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_info(Response)));

}

void AddProductDialog::on_btnMenu_Close_clicked()
{
    close();
}


void AddProductDialog::on_btnUpload_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this, tr("选择图片"), "./", tr("图片文件(*.png *.jpg)"));
    if(filename.isEmpty())return;
    waiting->start();
    cut_photo->load_photo(filename);
    waiting->stop();
    cut_photo->setModal(true);
    cut_photo->show();
}

void AddProductDialog::receive_photo_data(QByteArray data)
{
    product.set_photo(data.toBase64());
    QPixmap photo;
    photo.loadFromData(data);
    ui->labelImage->setPixmap(photo);
}


