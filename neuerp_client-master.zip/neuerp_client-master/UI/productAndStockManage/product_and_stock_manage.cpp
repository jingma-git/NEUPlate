#include "product_and_stock_manage.h"
#include "ui_product_and_stock_manage.h"
#include "UI/iconhelper.h"
#include "usercontroller.h"


ProductAndStockManage::ProductAndStockManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ProductAndStockManage)
{
    ui->setupUi(this);
    ui->tableWidget->setRowCount(10);
    connect(ui->btnQuery,SIGNAL(clicked()),this,SLOT(query_clicked()));
    connect(ui->checkBoxNotSale,SIGNAL(stateChanged(int)),this,SLOT(check_box_clicked(int)));
    connect(ui->checkBoxOnSale,SIGNAL(stateChanged(int)),this,SLOT(check_box_clicked(int)));
//    connect(ui->checkBoxPriceDesc,SIGNAL(stateChanged(int)),this,SLOT(check_box_clicked(int)));
//    connect(ui->checkBoxStockDesc,SIGNAL(stateChanged(int)),this,SLOT(check_box_clicked(int)));
    connect(ui->comboBoxSort,SIGNAL(currentIndexChanged(int)),this,SLOT(change_sort(int)));
    connect(ui->ledit_keyword,SIGNAL(returnPressed()),ui->btnQuery,SIGNAL(clicked()));
    connect(ui->btnLastPage,SIGNAL(clicked()),this,SLOT(last_page()));
    connect(ui->btnNextPage,SIGNAL(clicked()),this,SLOT(next_page()));
    connect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));

    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    ui->btnAddProduct->setProperty("btn_color", "green");
    ui->btnQuery->setProperty("btn_color", "green");
    ui->btnNextPage->setProperty("btn_color", "green");
    ui->btnLastPage->setProperty("btn_color", "green");
    ui->ledit_keyword->setProperty("type", "input");

    waiting=new WaitingSpinnerWidget(this);
    init_menu();

}
ProductAndStockManage::~ProductAndStockManage()
{
    delete ui;
    delete add_product_dialog;
    delete right_menu;
    delete waiting;
}

void ProductAndStockManage::change_sort(int i)
{
    qDebug()<<"sort"<<i;
    query_clicked();
}


// about menu
void ProductAndStockManage::init_menu(){
    right_menu =new QMenu(ui->tableWidget);
    
    edit_product = new QAction(this);
    onsale_product= new QAction(this);
    notsale_product= new QAction(this);
    
    edit_product->setText("修改信息");
    onsale_product->setText("上架");
    notsale_product->setText("下架");
    

    right_menu->addAction(edit_product);
    right_menu->addAction(onsale_product);
    right_menu->addAction(notsale_product);

    connect(edit_product,SIGNAL(triggered()),this,SLOT(edit_product_clicked()));
    connect(onsale_product,SIGNAL(triggered()),this,SLOT(onsale_clicked()));
    connect(notsale_product,SIGNAL(triggered()),this,SLOT(notsale_clicked()));

    auto &user = UserController::get_instance();
    if(user.check_access_code("dept_stock_manager")){
        delete_product = new QAction(this);
        delete_product->setText("删除商品");
        right_menu->addAction(delete_product);
        connect(delete_product,SIGNAL(triggered()),this,SLOT(delete_clicked()));
    }

    connect(this->ui->tableWidget, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(right_menu_action(const QPoint&)));
    

}

//设置右键菜单显示的内容，根据所选的内容。
void ProductAndStockManage::right_menu_action(const QPoint& pos){

     QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();
    int column_count=ui->tableWidget->columnCount();
    int rows = count /column_count ;
    qDebug()<<"rows:"<<rows<<"count"<<count<<"cloumn"<<column_count;
    int row = -1;
    if(rows>0){
        // change_state->setEnabled(true);
        delete_product->setDisabled(true);
        edit_product->setDisabled(true);

        if(rows==1){
            
            edit_product->setEnabled(true);
            row=ui->tableWidget->row(items.at(0));
            qDebug()<<"row:"<<row;
            qDebug()<<"id"<<products.at(row).getP_id();
            if(products.at(row).getState()==1){
                onsale_product->setDisabled(true);
                notsale_product->setEnabled(true);
            }else{
                onsale_product->setEnabled(true);
                notsale_product->setDisabled(true);
            }
            if(products.at(row).getStock_amount()==0){
                delete_product->setEnabled(true);
            }
        }else if(rows>1){
            onsale_product->setEnabled(true);
            notsale_product->setEnabled(true);
            int stock=0;
            for(int i=0;i<count;i+=column_count){
                row=ui->tableWidget->row(items.at(i));
                stock+=products.at(row).getStock_amount();
            }
            if(stock>0){
                notsale_product->setDisabled(true);
            }
        }
        right_menu->exec(QCursor::pos());
    }
}
//about menu end


//about change state begin
void ProductAndStockManage::notsale_clicked()
{
    qDebug()<<"not sale clicked";
    int state=0;
    change_state(state);
}

void ProductAndStockManage::onsale_clicked()
{
    qDebug()<<"onsale clicked";
    int state=1;
    change_state(state);


}

void ProductAndStockManage::change_state(int state){

    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count =items.count();
    int column_count=ui->tableWidget->columnCount();
    int stock=0;
    QJsonArray change_state_json;
    if(count<column_count){
        return;
    }


    for(int i=0;i<count;i+=column_count){
            //获取商品id们
            int row=ui->tableWidget->row(items.at(i));
            change_state_json.append(products.at(row).getP_id());
            stock+=products.at(row).getStock_amount();
    }
    if(stock!=0&&state==0){
        MsgBox::warming(0,"修改状态","只有库存为0时才能设置为下架");
        return;
    }

    //构造请求体
    //发送
    Request req;
    req.set_func("change_product_state");

    req.set_module("product");
    req.put("p_ids",change_state_json);
    req.put("state",state);
    auto &client=MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_change_state(Response)));

}

void ProductAndStockManage::recv_change_state(Response resp){

    if(resp.get_module()!="product"||resp.get_func()!="change_product_state"){
        return;
    }
    waiting->stop();
    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_change_state(Response)));
    qDebug()<<"state code"<<resp.get_status_code();

    if(SUCCESS==resp.get_status_code()){
        //成功
        MsgBox::success(0,"修改商品状态","修改成功");

        //刷新页面:可以考虑，翻页到本页
        change_page(current_page-1);

    }else{
//        失败
        MsgBox::error(0,"修改商品状态","修改失败");
    }



}

//about change state end




//about delete product
void ProductAndStockManage::delete_clicked()
{
    int flag = MsgBox::question(this, "注意", "是否确认删除商品,此操作无法撤销!");

    if (flag == MsgBox::NO)
        return;

    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int row=ui->tableWidget->row(items.at(0));
    QString p_id=products.at(row).getP_id();

    qDebug()<<"delete p_id:"<<p_id;
    Request req;
    req.set_module("product");
    req.set_func("delete_product");
    req.put("p_id",p_id);

    auto &client = MainClient::get_instance();
    client.send(req);

    waiting->start();
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_delete_product(Response)));
}

void ProductAndStockManage::recv_delete_product(Response resp)
{
    if(resp.get_module()!="product"||resp.get_func()!="delete_product"){
        return;
    }
    auto &client = MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_delete_product(Response)));

    int code=resp.get_status_code();
    waiting->stop();
    if(code==SUCCESS){
        //成功
        MsgBox::success(0,"删除商品","成功删除");
        //刷新页面
        change_page(current_page-1);
    }else{
        //失败
        MsgBox::information(0,"删除商品","删除失败");
    }

}
//delete end

void ProductAndStockManage::first_init()
{
    if(inited){
        return;
    }
    inited=true;
    query_clicked();
}

void ProductAndStockManage::refresh_table_after_edit()
{
    change_page(current_page-1);
}

void ProductAndStockManage::check_box_clicked(int i)
{
    query_clicked();
}



void ProductAndStockManage::query_clicked()
{
    on_sale=ui->checkBoxOnSale->isChecked();
    not_sale=ui->checkBoxNotSale->isChecked();
    if(on_sale&&not_sale){
        state=-1;
    }else if(on_sale){
        state=1;
    }else if(not_sale){
        state=0;
    }else{
        products.clear();
        ui->tableWidget->clearContents();
        current_page=1;
        max_page=1;
        refresh_page_bar();
        return;
    }
    lowest_price=ui->spinBoxLowPrice->value();
    highest_price=ui->spinBoxHighPrice->value();
//    price_desc=ui->checkBoxPriceDesc->isChecked();

    lowest_stock=ui->spinBoxLowStock->value();
    highest_stock=ui->spinBoxHighStock->value();
//    stock_desc=ui->checkBoxStockDesc->isChecked();
    int order=ui->comboBoxSort->currentIndex();
    switch (order) {
    case 0:
        //库存从低到高
        order_by_stock=0;
        order_by_price=-1;
        break;
    case 1:
        //库存从高到低
        order_by_stock=1;
        order_by_price=-1;
        break;
    case 2:
        //价格从低到高
        order_by_stock=-1;
        order_by_price=0;
        break;
    case 3:
        //价格从高到低
        order_by_stock=-1;
        order_by_price=1;
        break;
    }

    keyword=ui->ledit_keyword->text();

    current_page=1;
    query_products();

}

void ProductAndStockManage::query_products()
{
    Request req;
    req.set_module("product");
    req.set_func("get_products");
    req.put("keyword",keyword);
    req.put("lowest_price",lowest_price);
    req.put("highest_price",highest_price);
    req.put("order_by_price",order_by_price);
    req.put("lowest_stock",lowest_stock);
    req.put("highest_stock",highest_stock);
    req.put("order_by_stock",order_by_stock);
    req.put("page",current_page);
    req.put("page_size",page_size);
    req.put("state",state);

    auto &client=MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_products(Response)));
}

void ProductAndStockManage::recv_products(Response resp)
{   qDebug()<<"Recv products";
    if(resp.get_module()!="product"||resp.get_func()!="get_products"){
        return;
    }
    waiting->stop();
    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_products(Response)));
    if(resp.get_status_code()==SUCCESS){
        products.clear();
        //这里的循环会间歇性异常
        qDebug()<<"get array";
        QJsonArray products_json=resp.get_array("products");
        foreach(const QJsonValue &product_json ,products_json){
            qDebug()<<product_json;
            Product p=Product(product_json.toObject());
            qDebug()<<"get product";
            products.push_back(p);
            qDebug()<<"push back";
        }
        qDebug()<<"push end";
        max_page=resp.get_int("all_page");
        qDebug()<<"all_page"<<max_page;
        refresh_page_bar();
        refresh_table();
    }else {
        MsgBox::error(0,"搜索商品","查询失败，请稍后重试");
    }

}


void ProductAndStockManage::refresh_table()
{
        unsigned int product_len=products.size();
    QTableWidget &table= *(ui->tableWidget);
    table.clearContents();
    for(unsigned int i=0;i<product_len;i++){
        Product &p=products.at(i);

        table.setItem(i,0,new QTableWidgetItem(p.getP_id()));
        table.setItem(i,1,new QTableWidgetItem(p.getBar_code()));
        table.setItem(i,2,new QTableWidgetItem(p.getName()));
        table.setItem(i,3,new QTableWidgetItem(p.getDescription()));
        table.setItem(i,4,new QTableWidgetItem(QString::number(p.getPrice(),'f',2)));
        table.setItem(i,5,new QTableWidgetItem(QString::number(p.getStock_amount())));
        QString state_string;
        if(p.getState()==1){
            state_string="在售";
        }else{
            state_string="下架";
        }
        table.setItem(i,6,new QTableWidgetItem(state_string));

    }
}

void ProductAndStockManage::refresh_page_bar(){
     disconnect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));
     ui->btnLastPage->setEnabled(!(current_page==1));
     ui->btnNextPage->setEnabled(!(current_page==max_page));
     ui->comboBoxPage->clear();

     for(int i=0;i<max_page;i++){
         ui->comboBoxPage->insertItem(i,QString("第%1页").arg(i+1));
     }
     ui->comboBoxPage->setCurrentIndex(current_page-1);
     connect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));

}


// about page
void ProductAndStockManage::next_page()
{
    change_page(current_page-1+1);
}

void ProductAndStockManage::last_page()
{
    change_page(current_page-1-1);
}

//传入参数是页数-1；
void ProductAndStockManage::change_page(int new_index){
    int new_page=new_index + 1;
    current_page=new_page;
    query_products();
}



//add product
void ProductAndStockManage::on_btnAddProduct_clicked()
{

    delete add_product_dialog;
    add_product_dialog=nullptr;
    add_product_dialog=new AddProductDialog;
    connect(add_product_dialog,SIGNAL(refresh_table()),this,SLOT(refresh_table_after_edit()));
    add_product_dialog->setModal(true);
    add_product_dialog->show();
}

//edit product
void ProductAndStockManage::edit_product_clicked()
{
    qDebug()<<"edit_product_clicked";
    //获取是哪个商品
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();
    if(count>ui->tableWidget->columnCount()){
        return;
    }

    int row=ui->tableWidget->row(items.at(0));
    qDebug()<<"edit_product_clicked-row"<<row;
    //传到对应界面里面
    delete add_product_dialog;
    add_product_dialog=nullptr;

    add_product_dialog=new AddProductDialog;
    add_product_dialog->edit_product(products.at(row));
    add_product_dialog->setModal(true);
    connect(add_product_dialog,SIGNAL(refresh_table()),this,SLOT(refresh_table_after_edit()));
    add_product_dialog->show();


}


