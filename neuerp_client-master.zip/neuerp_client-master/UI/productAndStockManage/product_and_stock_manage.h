#ifndef STACKMANAGE_H
#define STACKMANAGE_H

#include <QWidget>
#include <QToolButton>
#include "Entity/product.h"
#include <vector>

#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Network/Body/response.h"
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QJsonArray>
#include <QMenu>
#include <QAction>
#include "add_product_dialog.h"
#include "UI/waitingspinnerwidget.h"
namespace Ui {
class ProductAndStockManage;
}

class ProductAndStockManage : public QWidget
{
    Q_OBJECT

public:
    explicit ProductAndStockManage(QWidget *parent = 0);
    ~ProductAndStockManage();
    void first_init();

private:
    Ui::ProductAndStockManage *ui;
    WaitingSpinnerWidget *waiting;
    AddProductDialog *add_product_dialog=nullptr;
    QMenu *right_menu;
    QAction *edit_product=nullptr;
    QAction *delete_product;
    QAction *onsale_product;
    QAction *notsale_product;

  


    int lowest_stock=0;
    int highest_stock=10000000;
    double lowest_price=0;
    double highest_price=10000000;
    QString keyword;
    int order_by_price=-1;
    int order_by_stock=0;
    bool on_sale;
    bool not_sale;
    int current_page=1;
    int max_page=1;
    int page_size=10;
    int state=-1;
    bool inited=false;
    std::vector<Product> products;
    

public slots:
    void refresh_table_after_edit();
    
    
private slots:
    void check_box_clicked(int i);
    void query_clicked();
    void query_products();
    void recv_products(Response resp);
    void refresh_table();
    void change_page(int new_index);
    void refresh_page_bar();
    void next_page();
    void last_page();
    void on_btnAddProduct_clicked();
    void init_menu();
    void right_menu_action(const QPoint& pos);
    void edit_product_clicked();
    void onsale_clicked();
    void notsale_clicked();
    void delete_clicked();
    void recv_delete_product(Response resp);
    void change_state(int state);
    void recv_change_state(Response resp);
    void change_sort(int i);

};

#endif // STACKMANAGE_H
