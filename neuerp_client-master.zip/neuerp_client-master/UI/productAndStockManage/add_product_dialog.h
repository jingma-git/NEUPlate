#ifndef ADD_PRODUCT_DIALOG_H
#define ADD_PRODUCT_DIALOG_H

#include <QDialog>
#include "Entity/product.h"
#include "Network/Body/request.h"
#include "Network/Body/response.h"
#include "Network/Client/mainclient.h"

#include "status_code.h"
#include "UI/msgbox.h"
#include <QJsonObject>
#include "UI/iconhelper.h"
#include "UI/msgbox.h"

#include <QIntValidator>
#include <QDoubleValidator>
#include "UI/waitingspinnerwidget.h"
#include "UI/CutDialog/cut_photo_dialog.h"


namespace Ui {
class AddProductDialog;
}

class AddProductDialog : public QDialog
{
    Q_OBJECT

signals:
    void refresh_table();


public:
    explicit AddProductDialog(QWidget *parent = 0);
    ~AddProductDialog();
    void edit_product(Product &product);

private slots:
    void on_btnMenu_Close_clicked();
    void submit();
    void recv_info(Response);
    void stock_checked(bool checked);

    void on_btnUpload_clicked();

    void receive_photo_data(QByteArray data);


private:
    Ui::AddProductDialog *ui;
    WaitingSpinnerWidget *waiting;
    CutPhotoDialog *cut_photo;
    Product product;
    bool isedit=false;
};

#endif // ADD_PRODUCT_DIALOG_H
