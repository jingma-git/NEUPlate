#include "centered_checkbox.h"

CenteredCheckBox::CenteredCheckBox(QWidget *parent) :
    QWidget(parent)
{

    checkBox = new QCheckBox();
    layout = new QHBoxLayout();
    layout->addWidget(checkBox);
    layout->setMargin(0);
    layout->setAlignment(Qt::AlignCenter);
    this->setLayout(layout);
}
bool CenteredCheckBox::isChecked(){
    return checkBox->isChecked();
}
