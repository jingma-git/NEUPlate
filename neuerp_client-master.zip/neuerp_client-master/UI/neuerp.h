﻿#ifndef NEUERP_H
#define NEUERP_H

#include <QWidget>

#include "purchaseManage/purchase_manage.h"
#include "employeeAndAccountManage/employee_and_account_manage.h"
#include "personalCenter/personal_center.h"
#include "productAndStockManage/product_and_stock_manage.h"
#include "saleManage/sale_manage.h"
#include "supplierManage/supplier_manage.h"
#include "main_page.h"

class QToolButton;

namespace Ui {
class NEUERP;
}

class NEUERP : public QWidget
{
    Q_OBJECT

public:
    explicit NEUERP(QWidget *parent = 0);
    ~NEUERP();
    void init_permission();

private:
    Ui::NEUERP *ui;    

    QList<int> pixCharMain;
    QList<QToolButton *> btnsMain;

    QList<int> pixCharConfig;
    QList<QToolButton *> btnsConfig;

    MainPage *main_page;
    EmployeeAndAccountManage *employee_and_account_manage;
    PersonalCenter *personal_center;
    ProductAndStockManage *product_and_stock_manage;
    PurchaseManage *purchase_manage;
    SaleManage *sale_manage;
    SupplierManage *supplier_manage;



private slots:
    void initForm();
    void buttonClick();
    void init_stacked_widget();
    void error_arrive(QString);
    void close_connection();
private slots:
    void on_btnMenu_Min_clicked();
    void on_btnMenu_Max_clicked();
    void on_btnMenu_Close_clicked();
};

#endif // UIDEMO08_H
