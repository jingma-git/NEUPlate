/**
* @projectName   NEUERP_client
* @brief         beautify QMessageBox
* @author        chenhanlin
* @date          2018-07-07
*/

#ifndef MSGBOX_H
#define MSGBOX_H

#include <QString>
#include <QWidget>

class MsgBox
{
public:
    MsgBox();
    static const int YES = 0;
    static const int NO = 1;

    static void information(QWidget *parent, const QString &title, const QString &text, const QString &confirm="确认");
    static void error(QWidget *parent, const QString &title, const QString &text, const QString &confirm="确认");
    static int question(QWidget *parent, const QString &title, const QString &text, const QString &yes="确认", const QString &no="取消");
    static void warming(QWidget *parent, const QString &title, const QString &text, const QString &confirm="确认");
    static void success(QWidget *parent, const QString &title, const QString &text, const QString &confirm="确认");
private:
    static QString style;
};

#endif // MSGBOX_H
