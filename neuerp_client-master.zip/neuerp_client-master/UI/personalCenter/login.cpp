#include <QMessageBox>
#include "login.h"
#include "ui_login.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "status_code.h"
#include "UI/msgbox.h"
#include "UI/iconhelper.h"
#include "usercontroller.h"

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login),
    fgp(nullptr),
    ufd(nullptr),
    uid(nullptr),
    wait(nullptr)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
    auto &client = MainClient::get_instance();
    connect(&client, SIGNAL(notify_close()), this, SLOT(close_connection()));
    connect(&client, SIGNAL(notify_error(QString)), this, SLOT(error_arrive(QString)));
}

Login::~Login()
{
    delete ui;
    delete fgp;
    delete ufd;
    delete uid;
    delete wait;
}

/**
* @functionName  on_loginButton_clicked
* @Description   get data to login system
* @author        chenhanlin
* @date          2018-07-07
* @parameter     void
* @return        void
*/
void Login::on_loginButton_clicked()
{
    Request req;
    req.set_module("user");
    req.set_func("login");
    e_id = this->ui->usernameBox->text();
    QString passwd(this->ui->passwordBox->text());
    req.put("e_id", e_id);
    req.put("passwd", passwd);
    auto &client = MainClient::get_instance();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(message_arrive(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  on_forget_passwd_button_clicked
* @Description   show the forget_passwd page
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void Login::on_forget_passwd_button_clicked()
{
    if(nullptr == fgp) fgp = new Forget_passwd;
    fgp->setModal(true);
    fgp->show();
}

/**
* @functionName  message_arrive
* @Description   when server's response arrive, it handle this message
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void Login::message_arrive(Response resp)
{
    if("user" != resp.get_module() || "login" != resp.get_func()) return;
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(message_arrive(Response)));
    this->wait->stop();
    auto &controller = UserController::get_instance();
    QJsonObject code_table;
    QJsonObject code_desc;
    int choic = 0;
    switch (resp.get_status_code()) {
    case SUCCESS:
//        MsgBox::success(this, tr("登录"), tr("登录成功"));
        // init user's e_id
        controller.set_e_id(e_id);
        // init user'access code
        controller.set_access_code(resp.get_int("code"));
        // init access table
        code_table = resp.get_json("permission_set");
        code_desc = resp.get_json("permission_desc");
        qDebug() << code_desc;
        for(const auto &key : code_table.keys()){
            controller.add_permission(key, code_table[key].toInt(), code_desc[key].toString());
        }
        disconnect(&client, SIGNAL(notify_close()), this, SLOT(close_connection()));
        disconnect(&client, SIGNAL(notify_error(QString)), this, SLOT(error_arrive(QString)));
        accept();
        break;
    case EMPTY_QUERY:
    case ERROR_PASSWD:
        MsgBox::information(this, tr("登录"), tr("用户名或密码错误"));
        break;
    case LOGINED:
        MsgBox::information(this, tr("登录"), tr("账户已登录"));
        break;
    case FROZEN:
        choic = MsgBox::question(this, tr("登录"), tr("账户已冻结"), tr("解冻"));
        if (MsgBox::YES == choic){
            if(nullptr == ufd) ufd = new UnfrozenDialog;
            ufd->setModal(true);
            ufd->show();
        }
        break;
    case CLOSED:
        MsgBox::information(this, tr("登录"), tr("账户已关闭，请联系管理人员"));
        break;
    case NEW:
        MsgBox::information(this, tr("登录"), tr("请进行账户初始化设置。"));
        // init
        if(nullptr == uid) uid = new UserInitDialog(e_id);
        uid->setModal(true);
        uid->show();
        break;
    default:
        break;
    }
    qDebug() << "disconnect signal(notify_resp)";
}

void Login::error_arrive(QString)
{
    MsgBox::error(this, tr("网络错误"), tr("无法连接至网络，请重试"));
    if(nullptr != fgp)
        fgp->close();
    if(nullptr != uid)
        uid->close();
    if(nullptr != ufd)
        ufd->close();
    close();
}

void Login::close_connection()
{
    MsgBox::error(this, tr("网络错误"), tr("与服务器断开连接，请稍后再试。"));
    if(nullptr != fgp)
        fgp->close();
    if(nullptr != uid)
        uid->close();
    if(nullptr != ufd)
        ufd->close();
    close();
}

void Login::on_btnMenu_Close_clicked()
{
    if(nullptr != fgp)
        fgp->close();
    if(nullptr != uid)
        uid->close();
    if(nullptr != ufd)
        ufd->close();
    close();
}
