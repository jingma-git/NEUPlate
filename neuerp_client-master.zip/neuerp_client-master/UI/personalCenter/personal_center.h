#ifndef PERSONAL_CENTER_H
#define PERSONAL_CENTER_H

#include <QWidget>
#include <QToolButton>
#include "profile_manage.h"
#include "password_manage.h"
#include "question_manage.h"


namespace Ui {
class PersonalCenter;
}

class PersonalCenter : public QWidget
{
    Q_OBJECT

public:
    explicit PersonalCenter(QWidget *parent = 0);
    ~PersonalCenter();
    void  init_menu();

private slots:
    void  menu_click();

private:
    Ui::PersonalCenter *ui;
    ProfileManage *profile_manage;
    PasswordManage *password_manage;
    QuestionManage *question_manage;

    QList<int> pixChars;
    QList<QToolButton *> btns;

    void  init_widget();

};

#endif // PERSONAL_CENTER_H
