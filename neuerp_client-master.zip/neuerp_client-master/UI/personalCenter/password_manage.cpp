#include "password_manage.h"
#include "usercontroller.h"
#include "ui_password_manage.h"
#include "Network/Body/request.h"
#include "UI/msgbox.h"
#include "status_code.h"
#include <Network/Client/mainclient.h>

PasswordManage::PasswordManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PasswordManage)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
}

PasswordManage::~PasswordManage()
{
    delete ui;
    delete wait;
}

void PasswordManage::reset()
{
    ui->origin_passwd->clear();
    ui->new_passwd->clear();
    ui->new_passwd_confirm->clear();
}

/**
* @functionName  message_arrive
* @Description   handler response when server send to this gui
* @author        chenhanlin
* @date          2018-07-07
* @parameter     Response resp
* @return        void
*/
void PasswordManage::message_arrive(Response resp)
{
    if ("user" != resp.get_module() && "change_passwd" != resp.get_func()){
        return;
    }
    MainClient &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(message_arrive(Response)));
    wait->stop();
    switch (resp.get_status_code()) {
    case OLD_PASSWD_ERROR:
        MsgBox::information(this, tr("修改密码"),tr("原密码输入错误"));
        break;
    case SUCCESS:
        MsgBox::information(this, tr("修改密码"),tr("修改成功"));
        this->ui->origin_passwd->setText("");
        this->ui->new_passwd->setText("");
        this->ui->new_passwd_confirm->setText("");
        break;
    default:
        MsgBox::information(this, tr("修改密码"),tr("系统错误，请稍后再试"));
        break;
    }
}
void PasswordManage::on_confirm_button_clicked()
{
    Request req;
    req.set_module("user");
    req.set_func("change_passwd");
    QString origin(ui->origin_passwd->text());
    QString new_passwd(ui->new_passwd->text());
    QString new_passwd_confirm(ui->new_passwd_confirm->text());
    // input shuold not empty
    if (origin.isEmpty() || new_passwd.isEmpty() || new_passwd_confirm.isEmpty()){
        MsgBox::information(this, tr("修改密码"),tr("输入不能为空。"));
        return;
    }
    // the passwd input twice shuold be the same
    if(new_passwd != new_passwd_confirm){
        MsgBox::information(this, tr("修改密码"),tr("两次输入的密码不一致。"));
        return;
    }
    req.put("new_passwd", new_passwd);
    req.put("old_passwd", origin);
    req.put("e_id", UserController::get_instance().get_e_id());
    MainClient &client = MainClient::get_instance();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(message_arrive(Response)));
    client.send(req);
    wait->start();
}
