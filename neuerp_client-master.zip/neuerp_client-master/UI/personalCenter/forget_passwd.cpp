#include "forget_passwd.h"
#include "UI/iconhelper.h"
#include "Network/Body/request.h"
#include "UI/msgbox.h"
#include "status_code.h"
#include <QJsonObject>
#include <QStringList>

/**
* @functionName  Forget_passwd
* @Description   contructor, it will init some feature and icon
* @author        chenhanlin
* @date          2018-07-08
* @parameter     QWidget *parent
* @return        void
*/
Forget_passwd::Forget_passwd(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Forget_passwd),
    client(MainClient::get_instance())
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->ui->stackedWidget->setCurrentIndex(0);
}

Forget_passwd::~Forget_passwd()
{
    delete ui;
    delete wait;
}

/**
* @functionName  on_btnMenu_Close_clicked
* @Description   close this window
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void Forget_passwd::on_btnMenu_Close_clicked()
{
    close();
}

/**
* @functionName  on_confirm_button_clicked
* @Description   invoke the find_passwd function, it will send message to server
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void Forget_passwd::on_confirm_button_clicked()
{
    // get input
    QString new_passwd(this->ui->new_passwd->text());
    QString new_passwd_confirm(this->ui->new_passwd_confirm->text());
    QString answer(this->ui->answer->text());
    QString question(this->ui->questions->currentText());
    auto iter = question_table.find(question);
    // check input
    if(question_table.end() == iter){
        MsgBox::information(this, tr("找回密码"), tr("请选择密保问题"));
        return;
    }
    if (new_passwd != new_passwd_confirm){
        MsgBox::information(this, tr("找回密码"), tr("两次输入的密码不一致"));
        return;
    }
    if (answer.isEmpty()){
        MsgBox::information(this, tr("找回密码"), tr("请输入回答"));
        return;
    }
    // build request
    Request req;
    req.set_module("user");
    req.set_func("forget_passwd");
    req.put("e_id", e_id);
    req.put("q_id", iter->second);
    req.put("answer", answer);
    req.put("passwd", new_passwd);
    // build connect signal and function
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_find_passwd(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  on_cancel_button_clicked
* @Description   close the window
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void Forget_passwd::on_cancel_button_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->username->clear();
}

/**
* @functionName  handle_query_question
* @Description   when query_question's response arrive, it will invoke
* @author        chenhanlin
* @date          2018-07-08
* @parameter     Response resp
* @return        void
*/
void Forget_passwd::handle_query_question(Response resp)
{
    // check response
    if("user" != resp.get_module() || "query_question" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_query_question(Response)));
    wait->stop();

    // check status code
    if (EMPTY_QUERY == resp.get_status_code()){
        MsgBox::information(this, tr("找回密码"), tr("请先初始化用户"));
        return;
    }

    if(QUERY_ERROR == resp.get_status_code()){
        MsgBox::information(this, tr("找回密码"), tr("系统忙碌，请稍后再试"));
        return;
    }

    // get question
    QStringList keys = resp.keys();
    for(const auto &key : keys){
        QString question(resp.get_string(key));
        this->question_table.insert(std::map<QString, QString>::value_type(question, key));
        this->ui->questions->addItem(question);
    }
    // jump page
    ui->stackedWidget->setCurrentIndex(1);
}

/**
* @functionName  handle_find_passwd
* @Description   when find_passwd's response arrive, it will show some message
* @author        chenhanlin
* @date          2018-07-08
* @parameter     Response resp
* @return        void
*/
void Forget_passwd::handle_find_passwd(Response resp)
{
    if("user" != resp.get_module() || "forget_passwd" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_find_passwd(Response)));
    switch (resp.get_status_code()) {
    case SUCCESS:
        MsgBox::success(this, tr("找回密码"), tr("密码修改成功"));
        accept();
        break;
    case WRONG_ANSWER:
        MsgBox::information(this, tr("找回密码"), tr("密保问题回答错误"));
        break;
    default:
        MsgBox::warming(this, tr("找回密码"), tr("系统错误，请稍后再试"));
        break;
    }
}

/**
* @functionName  on_confirm_username_clicked
* @Description   query user's securtiy question
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void Forget_passwd::on_confirm_username_clicked()
{
    e_id = this->ui->username->text();
    if(e_id.isEmpty()){
        MsgBox::information(this, tr("找回密码"), tr("请输入用户名"));
        return;
    }
    Request req;
    req.set_module("user");
    req.set_func("query_question");
    req.put("e_id", e_id);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_query_question(Response)));
    client.send(req);
    wait->start();
}

void Forget_passwd::on_cancel_username_clicked()
{
    close();
    reset();
}

void Forget_passwd::reset()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->username->clear();
    ui->answer->clear();
    ui->new_passwd->clear();
    ui->new_passwd_confirm->clear();
    ui->questions->clear();
    ui->questions->addItem(tr("选择密保问题"));
}
