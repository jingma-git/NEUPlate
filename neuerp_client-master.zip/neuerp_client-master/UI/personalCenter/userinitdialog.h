#ifndef USERINITDIALOG_H
#define USERINITDIALOG_H

#include <QDialog>
#include <Network/Body/response.h>
#include <map>
#include <Network/Client/mainclient.h>
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class UserInitDialog;
}

class UserInitDialog : public QDialog
{
    Q_OBJECT

public:
    explicit UserInitDialog(const QString &e_id, QWidget *parent = 0);
    ~UserInitDialog();

private slots:
    void on_btnMenu_Close_clicked();

    void on_cancel_button_clicked();

    void on_submit_button_clicked();

    void question_arrive(Response);
    void init_arrive(Response);

    void on_questions1_currentIndexChanged(const QString &arg1);

    void on_questions2_currentIndexChanged(const QString &arg1);

    void on_questions3_currentIndexChanged(const QString &arg1);

private:
    Ui::UserInitDialog *ui;
    QString e_id;
    MainClient &client;
    std::map<QString, QString> question_table;
    std::map<QString, QString> selected;
    WaitingSpinnerWidget *wait;

    void get_questions();
    void reset();

};

#endif // USERINITDIALOG_H
