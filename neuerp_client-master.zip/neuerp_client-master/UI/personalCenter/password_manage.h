#ifndef PASSWORD_MANAGE_H
#define PASSWORD_MANAGE_H

#include <QWidget>
#include <Network/Body/response.h>
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class PasswordManage;
}

class PasswordManage : public QWidget
{
    Q_OBJECT

public:
    explicit PasswordManage(QWidget *parent = 0);
    ~PasswordManage();
    void reset();

private slots:
    void message_arrive(Response);

    void on_confirm_button_clicked();

private:
    Ui::PasswordManage *ui;
    WaitingSpinnerWidget *wait;
};

#endif // PASSWORD_MANAGE_H
