#ifndef FORGET_PASSWD_H
#define FORGET_PASSWD_H

#include <QDialog>
#include <QString>
#include "ui_forget_passwd.h"
#include "Network/Body/response.h"
#include "Network/Client/mainclient.h"
#include <map>
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class Forget_passwd;
}

class Forget_passwd : public QDialog
{
    Q_OBJECT

public:
    explicit Forget_passwd(QWidget *parent = 0);
    ~Forget_passwd();

private slots:
    void on_btnMenu_Close_clicked();
    void on_confirm_button_clicked();
    void on_cancel_button_clicked();

    void handle_query_question(Response);
    void handle_find_passwd(Response);

    void on_confirm_username_clicked();

    void on_cancel_username_clicked();

private:
    Ui::Forget_passwd *ui;
    std::map<QString, QString> question_table;
    QString e_id;
    MainClient &client;
    WaitingSpinnerWidget *wait;

    void reset();
};

#endif // FORGET_PASSWD_H
