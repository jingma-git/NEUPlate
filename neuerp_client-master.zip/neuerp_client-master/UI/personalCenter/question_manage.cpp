#include "question_manage.h"
#include "ui_question_manage.h"
#include "status_code.h"
#include "Network/Body/request.h"
#include "UI/msgbox.h"

QuestionManage::QuestionManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QuestionManage),
    client(MainClient::get_instance()),
    invoke_changed(false)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    this->ui->stackedWidget->setCurrentIndex(0);
}

QuestionManage::~QuestionManage()
{
    delete ui;
    delete wait;
}

/**
* @functionName  init
* @Description   query user's question for use
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void QuestionManage::init()
{
    invoke_changed = false;
    this->ui->stackedWidget->setCurrentIndex(0);
    ui->questions->clear();
    ui->questions1->clear();
    ui->questions2->clear();
    ui->questions3->clear();
    ui->questions->addItem(tr("选择密保问题"));
    ui->questions1->addItem(tr("选择密保问题1"));
    ui->questions2->addItem(tr("选择密保问题2"));
    ui->questions3->addItem(tr("选择密保问题3"));
    ui->answer->clear();
    ui->answer1->clear();
    ui->answer2->clear();
    ui->answer3->clear();
    invoke_changed = true;
    Request req;
    req.set_module("user");
    req.set_func("query_question");
    req.put("e_id", "");
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_query_question(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  handle_query_question
* @Description   handle response from query_question
* @author        chenhanlin
* @date          2018-07-08
* @parameter     Response
* @return        void
*/
void QuestionManage::handle_query_question(Response resp)
{
    // check response
    if("user" != resp.get_module() || "query_question" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_query_question(Response)));

    // check status code
    if (SUCCESS != resp.get_status_code()){
        MsgBox::information(this, tr("密保问题"), tr("系统错误，请稍后再试"));
        return;
    }

    QString default_str(this->ui->questions->itemText(0));
    this->ui->questions->clear();
    this->ui->questions->addItem(default_str);
    // get question
    QStringList keys = resp.keys();
    for(const auto &key : keys){
        QString question(resp.get_string(key));
        this->question_table.insert(std::map<QString, QString>::value_type(question, key));
        this->ui->questions->addItem(question);
    }
    // jump page
    wait->stop();
}

void QuestionManage::handle_check(Response resp)
{
    if("user" != resp.get_module() || "check_question" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_check(Response)));
    wait->stop();
    switch (resp.get_status_code()) {
    case SUCCESS:
        get_question();
        this->ui->stackedWidget->setCurrentIndex(1);
        break;
    case WRONG_ANSWER:
        MsgBox::information(this, tr("密保管理"), tr("密保问题回答错误"));
        this->ui->questions->setCurrentIndex(0);
        this->ui->answer->setText("");
        break;
    default:
        MsgBox::warming(this, tr("密保管理"), tr("系统错误，请稍后再试"));
        break;
    }
}

/**
* @functionName  question_arrive
* @Description   handle the query of security questions
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void QuestionManage::question_arrive(Response resp)
{
    if("user" != resp.get_module() || "security_question" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(question_arrive(Response)));
    wait->stop();
    QString question;
    QStringList keys;
    question_table.clear();
    invoke_changed = false;
    ui->questions1->clear();
    ui->questions2->clear();
    ui->questions3->clear();
    ui->questions1->addItem(tr("选择密保问题1"));
    ui->questions2->addItem(tr("选择密保问题2"));
    ui->questions3->addItem(tr("选择密保问题3"));
    ui->answer1->clear();
    ui->answer2->clear();
    ui->answer3->clear();
    invoke_changed = true;
    switch (resp.get_status_code()) {
    case SUCCESS:
        keys = resp.keys();
        for(const auto &key : keys){
            question = resp.get_string(key);
            this->question_table.insert(std::map<QString, QString>::value_type(question, key));
            this->ui->questions1->addItem(question);
            this->ui->questions2->addItem(question);
            this->ui->questions3->addItem(question);
        }
        break;
    default:
        MsgBox::information(this, tr("密保管理"), tr("系统错误，请稍后再试"));
        this->ui->stackedWidget->setCurrentIndex(0);
        break;
    }
}

/**
* @functionName  commit_arrive
* @Description   handler the response after submit
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void QuestionManage::commit_arrive(Response resp)
{
    if ("user" != resp.get_module() || "set_question" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(commit_arrive(Response)));
    wait->stop();

    if(SUCCESS == resp.get_status_code()){
        MsgBox::success(this, tr("密保管理"), tr("修改成功"));
    }else{
        MsgBox::warming(this, tr("密保管理"), tr("系统错误，请稍后再试"));
    }
    this->ui->stackedWidget->setCurrentIndex(0);
    this->ui->questions->setCurrentIndex(0);
    this->ui->answer->setText("");
}

void QuestionManage::on_confirm_button_clicked()
{
    // get input
    QString answer(this->ui->answer->text());
    QString question(this->ui->questions->currentText());
    auto iter = question_table.find(question);
    // check input
    if(question_table.end() == iter){
        MsgBox::information(this, tr("密保管理"), tr("请选择密保问题"));
        return;
    }
    if (answer.isEmpty()){
        MsgBox::information(this, tr("密保管理"), tr("请输入回答"));
        return;
    }
    // build request
    Request req;
    req.set_module("user");
    req.set_func("check_question");
    req.put("e_id", "");
    req.put("q_id", iter->second);
    req.put("answer", answer);
    // build connect signal and function
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_check(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  get_question
* @Description   query all securtiy question from server
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void QuestionManage::get_question()
{
    Request req;
    req.set_module("user");
    req.set_func("security_question");
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(question_arrive(Response)));
    client.send(req);
    wait->start();
}

void QuestionManage::on_questions1_currentIndexChanged(const QString &arg1)
{
    if(!invoke_changed) return;
    int index = this->ui->questions1->findText(arg1);
    // get combo box name
    QString object_name(this->ui->questions1->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->questions2->addItem(old);
        this->ui->questions3->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->questions2->findText(arg1);
        this->ui->questions2->removeItem(index);
        index = this->ui->questions3->findText(arg1);
        this->ui->questions3->removeItem(index);
    }
}

void QuestionManage::on_questions2_currentIndexChanged(const QString &arg1)
{
    if(!invoke_changed) return;
    int index = this->ui->questions2->findText(arg1);
    // get combo box name
    QString object_name(this->ui->questions2->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->questions1->addItem(old);
        this->ui->questions3->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->questions1->findText(arg1);
        this->ui->questions1->removeItem(index);
        index = this->ui->questions3->findText(arg1);
        this->ui->questions3->removeItem(index);
    }
}

void QuestionManage::on_questions3_currentIndexChanged(const QString &arg1)
{
    if(!invoke_changed) return;
    int index = this->ui->questions3->findText(arg1);
    // get combo box name
    QString object_name(this->ui->questions3->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->questions2->addItem(old);
        this->ui->questions1->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->questions2->findText(arg1);
        this->ui->questions2->removeItem(index);
        index = this->ui->questions1->findText(arg1);
        this->ui->questions1->removeItem(index);
    }
}

void QuestionManage::on_cancel_button_clicked()
{
    this->ui->stackedWidget->setCurrentIndex(0);
    this->ui->questions->setCurrentIndex(0);
    this->ui->answer->setText("");
}

void QuestionManage::on_submit_button_clicked()
{
    if(0 == this->ui->questions1->currentIndex() || 0 == this->ui->questions2->currentIndex() || 0 == this->ui->questions3->currentIndex()){
        MsgBox::information(this, tr("密保管理"), tr("请选择密保问题"));
        return;
    }
    QString question1(this->ui->questions1->currentText());
    QString question2(this->ui->questions2->currentText());
    QString question3(this->ui->questions3->currentText());
    QString answer1(this->ui->answer1->text());
    QString answer2(this->ui->answer2->text());
    QString answer3(this->ui->answer3->text());
    if (answer1.isEmpty() || answer2.isEmpty() || answer3.isEmpty()){
        MsgBox::information(this, tr("密保管理"), tr("请输入回答"));
        return;
    }
    QJsonObject questions;
    questions.insert(question_table[question1], answer1);
    questions.insert(question_table[question2], answer2);
    questions.insert(question_table[question3], answer3);
    Request req;
    req.set_module("user");
    req.set_func("set_question");
    req.put("e_id", "");
    req.put("questions", questions);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(commit_arrive(Response)));
    client.send(req);
    wait->start();
}
