#include "profile_manage.h"
#include "ui_profile_manage.h"
#include "Network/Body/request.h"
#include "usercontroller.h"
#include "UI/msgbox.h"
#include "Exception/nullexception.h"
#include "Entity/employee.h"
#include "status_code.h"

#include <QDate>
#include <QPixmap>
#include <QByteArray>
#include <QIcon>

ProfileManage::ProfileManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ProfileManage),
    client(MainClient::get_instance()),
    employee(nullptr),
    is_init(false)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    this->ui->submit_button->hide();
    this->ui->cancel_button->hide();
}

ProfileManage::~ProfileManage()
{
    delete ui;
    delete employee;
    delete wait;
}

/**
* @functionName  init
* @Description   init this gui, query this user's employee information from server
* @author        chenhanlin
* @date          2018-07-09
* @parameter     void
* @return        void
*/
void ProfileManage::init()
{
    Request req;
    req.set_module("employee");
    req.set_func("query_employee");
    req.put("keyword", UserController::get_instance().get_e_id());
    req.put("page", 0);
    req.put("item", 1);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(init_message(Response)));
    client.send(req);
    wait->start();
}

void ProfileManage::on_edit_button_clicked()
{
    this->ui->submit_button->show();
    this->ui->cancel_button->show();
    this->ui->edit_button->hide();

    ui->birthday->setEnabled(true);
    ui->birth_place->setEnabled(true);
    ui->sex->setEnabled(true);
    ui->nation->setEnabled(true);
    ui->married->setEnabled(true);
    ui->political_status->setEnabled(true);
    ui->edu->setEnabled(true);
    ui->address->setEnabled(true);
    ui->phone->setEnabled(true);
    ui->email->setEnabled(true);
    ui->e_c_name->setEnabled(true);
    ui->e_c_phone->setEnabled(true);
    ui->e_c_address->setEnabled(true);
}

/**
* @functionName  init_message
* @Description   handle the response of init(), response contain user's information
* @author        chenhanlin
* @date          2018-07-09
* @parameter     Response resp
* @return        void
*/
void ProfileManage::init_message(Response resp)
{
    if("employee" != resp.get_module() || "query_employee" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(init_message(Response)));
    wait->stop();

    if(SUCCESS != resp.get_status_code()){
        MsgBox::information(this, tr("系统错误"),tr("系统错误，请稍后再试"));
        return;
    }

    QJsonObject e_info;
    try{
        e_info = resp.get_json(UserController::get_instance().get_e_id());
    }catch(NullException e){
        MsgBox::information(this, tr("系统错误"),tr("系统错误，请稍后再试"));
        return;
    }

    // get data
    QString name(e_info["name"].toString());
    QString dept(e_info["department"].toString());
    QString position(e_info["position"].toString());
    Gender gender(Gender(e_info["gender"].toInt()));
    QDate birthday(QDate::fromString(e_info["birthday"].toString()));
    QString birth_place(e_info["birth_place"].toString());
    QString nation(e_info["nation"].toString());
    bool married(e_info["married"].toBool());
    QString political_status(e_info["political_status"].toString());
    Education edu(Education(e_info["education"].toInt()));
    QString id(e_info["id"].toString());
    QString address(e_info["address"].toString());
    QString phone(e_info["telephone"].toString());
    QString email(e_info["email"].toString());
    QString photo_base64(e_info["photo"].toString());
    QString e_c_name(e_info["emergency_contact_name"].toString());
    QString e_c_phone(e_info["emergency_contact_phone"].toString());
    QString e_c_address(e_info["emergency_contact_address"].toString());
    employee_state state(employee_state(e_info["state"].toInt()));

    if(nullptr != this->employee){
        delete this->employee;
        this->employee = nullptr;
    }
    QPixmap photo;
    photo.loadFromData(QByteArray::fromBase64(photo_base64.toUtf8()));

    // save in employee
    this->employee = new Employee(name, dept, position, gender, birthday, birth_place,
                                  nation, married, political_status, edu, id, address,
                                  phone, email, photo, e_c_name, e_c_phone, e_c_address, state);

    // show in gui
    ui->name->setText(name);
    ui->id->setText(id);
    ui->state->setText(employee->get_str_state());
    ui->sex->setCurrentIndex(int(gender));
    ui->birthday->setDate(birthday);
    ui->dept->setText(dept);
    ui->position->setText(position);
    ui->phone->setText(phone);
    ui->email->setText(email);
    ui->edu->setCurrentIndex(int(edu));
    ui->married->setCurrentIndex(int(married));
    ui->birth_place->setText(birth_place);
    ui->address->setText(address);
    ui->political_status->setText(political_status);
    ui->nation->setText(nation);
    ui->e_c_name->setText(e_c_name);
    ui->e_c_phone->setText(e_c_phone);
    ui->e_c_address->setText(e_c_address);
    ui->photo->setPixmap(photo);

    this->is_init = true;
}

/**
* @functionName  submit_message
* @Description   handler the modify_part method's response
* @author        chenhanlin
* @date          2018-07-09
* @parameter     Response resp
* @return        void
*/
void ProfileManage::submit_message(Response resp)
{
    if("employee" != resp.get_module() || "modify_part" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(submit_message(Response)));
    wait->stop();

    if(SUCCESS != resp.get_status_code()){
        MsgBox::information(this, tr("系统错误"),tr("系统错误，请稍后再试"));
        return;
    }
    MsgBox::success(this, tr("系统提示"), tr("修改成功"));

    int sex = ui->sex->currentIndex();
    QDate birthday(ui->birthday->date());
    QString birth_place(ui->birth_place->text());
    QString nation(ui->nation->text());
    QString email(ui->email->text());
    QString address(ui->address->text());
    int edu = ui->edu->currentIndex();
    int married = ui->married->currentIndex();
    QString phone(ui->phone->text());
    QString political_status(ui->political_status->text());
    QString e_c_name(ui->e_c_name->text());
    QString e_c_phone(ui->e_c_phone->text());
    QString e_c_address(ui->e_c_address->text());

    employee->set_gender(Gender(sex));
    employee->set_birthday(birthday);
    employee->set_birth_place(birth_place);
    employee->set_nation(nation);
    employee->set_email(email);
    employee->set_address(address);
    employee->set_education(Education(edu));
    employee->set_married(bool(married));
    employee->set_telephone(phone);
    employee->set_political_status(political_status);
    employee->set_emergency_contact_name(e_c_name);
    employee->set_emergency_contact_phone(e_c_phone);
    employee->set_emergency_contact_address(e_c_address);
    this->ui->cancel_button->click();
}

bool ProfileManage::Is_init() const
{
    return is_init;
}

void ProfileManage::on_cancel_button_clicked()
{
    this->ui->submit_button->hide();
    this->ui->cancel_button->hide();
    this->ui->edit_button->show();

    // disable tool
    ui->birthday->setEnabled(false);
    ui->sex->setEnabled(false);
    ui->birth_place->setEnabled(false);
    ui->nation->setEnabled(false);
    ui->married->setEnabled(false);
    ui->political_status->setEnabled(false);
    ui->edu->setEnabled(false);
    ui->address->setEnabled(false);
    ui->phone->setEnabled(false);
    ui->email->setEnabled(false);
    ui->e_c_name->setEnabled(false);
    ui->e_c_phone->setEnabled(false);
    ui->e_c_address->setEnabled(false);

    // reset data
    ui->sex->setCurrentIndex(int(employee->get_gender()));
    ui->birthday->setDate(employee->get_birthday());
    ui->phone->setText(employee->get_telephone());
    ui->email->setText(employee->get_email());
    ui->edu->setCurrentIndex(int(employee->get_education()));
    ui->married->setCurrentIndex(int(employee->is_married()));
    ui->birth_place->setText(employee->get_birth_place());
    ui->address->setText(employee->get_address());
    ui->political_status->setText(employee->get_political_status());
    ui->nation->setText(employee->get_nation());
    ui->e_c_name->setText(employee->get_emergency_contact_name());
    ui->e_c_phone->setText(employee->get_emergency_contact_phone());
    ui->e_c_address->setText(employee->get_emergency_contact_address());
//    ui->photo->setIcon(QIcon(photo));
}

void ProfileManage::on_submit_button_clicked()
{
    int sex = ui->sex->currentIndex();
    QDate birthday(ui->birthday->date());
    QString birth_place(ui->birth_place->text());
    QString nation(ui->nation->text());
    QString email(ui->email->text());
    QString address(ui->address->text());
    int edu = ui->edu->currentIndex();
    int married = ui->married->currentIndex();
    QString phone(ui->phone->text());
    QString political_status(ui->political_status->text());
    QString e_c_name(ui->e_c_name->text());
    QString e_c_phone(ui->e_c_phone->text());
    QString e_c_address(ui->e_c_address->text());

    if(email.isEmpty() || phone.isEmpty()){
        MsgBox::information(this, tr("添加员工"), tr("请填写完整信息"));
        return;
    }
    QRegExp email_check("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$");
    QRegExp phone_check("^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$");
    if(!email_check.exactMatch(email)){
        MsgBox::information(this, tr(""), tr("请输入正确的电子邮件"));
        return;
    }
    if(!phone_check.exactMatch(phone) || (!e_c_phone.isEmpty() && !phone_check.exactMatch(e_c_phone))){
        MsgBox::information(this, tr(""), tr("请输入正确的电话号码"));
        return;
    }

    Request req;
    req.set_module("employee");
    req.set_func("modify_part");
    req.put("e_id", UserController::get_instance().get_e_id());
    req.put("year", birthday.year());
    req.put("month", birthday.month());
    req.put("day", birthday.day());
    req.put("birth_place", birth_place);
    req.put("nation", nation);
    req.put("gender", sex);
    req.put("married", bool(married));
    req.put("political_status", political_status);
    req.put("education", edu);
    req.put("address", address);
    req.put("telephone", phone);
    req.put("email", email);
    req.put("e_c_name", e_c_name);
    req.put("e_c_phone", e_c_phone);
    req.put("e_c_address", e_c_address);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(submit_message(Response)));
    client.send(req);
    wait->start();
}


/**
* @functionName  init_lineedit
* @Description       add contraint at line edit
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         void
* @return               void
*/
void ProfileManage::init_lineedit()
{
    QRegExp email("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$");
    QRegExpValidator *pemail = new QRegExpValidator(email, this);
    ui->email->setValidator(pemail);
    QRegExp phone("^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$");
    QRegExpValidator *pphone = new QRegExpValidator(phone, this);
    ui->phone->setValidator(pphone);
    ui->e_c_phone->setValidator(pphone);
}
