#include "unforzendialog.h"
#include "ui_unforzendialog.h"
#include "UI/iconhelper.h"
#include "UI/msgbox.h"
#include "Network/Body/request.h"
#include "status_code.h"

UnfrozenDialog::UnfrozenDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UnforzenDialog),
    client(MainClient::get_instance())
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->ui->stackedWidget->setCurrentIndex(0);
}

UnfrozenDialog::~UnfrozenDialog()
{
    delete ui;
    delete wait;
}

void UnfrozenDialog::on_btnMenu_Close_clicked()
{
    close();
    reset();
}

/**
* @functionName  on_confirm_username_clicked
* @Description   query user's securtiy question
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void UnfrozenDialog::on_confirm_button_clicked()
{
    e_id = this->ui->username->text();
    if(e_id.isEmpty()){
        MsgBox::information(this, tr("解冻账户"), tr("请输入用户名"));
        return;
    }
    Request req;
    req.set_module("user");
    req.set_func("query_question");
    req.put("e_id", e_id);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_query_question(Response)));
    client.send(req);
    wait->start();
}

void UnfrozenDialog::on_cancel_button2_clicked()
{
    close();
    reset();
}

void UnfrozenDialog::handle_query_question(Response resp)
{
    // check response
    if("user" != resp.get_module() || "query_question" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_query_question(Response)));
    wait->stop();

    // check status code
    if (EMPTY_QUERY == resp.get_status_code()){
        MsgBox::information(this, tr("找回密码"), tr("请先初始化用户"));
        return;
    }

    if(QUERY_ERROR == resp.get_status_code() || ERROR_PARAMS == resp.get_status_code()){
        MsgBox::information(this, tr("找回密码"), tr("系统忙碌，请稍后再试"));
        return;
    }

    // get question
    QStringList keys = resp.keys();
    question_table.clear();
    for(const auto &key : keys){
        QString question(resp.get_string(key));
        this->question_table.insert(std::map<QString, QString>::value_type(question, key));
        this->ui->questions->addItem(question);
    }
    // jump page
    ui->stackedWidget->setCurrentIndex(1);
}

void UnfrozenDialog::handle_unfrozen(Response resp)
{
    if("user" != resp.get_module() || "unfrozen" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_unfrozen(Response)));
    wait->stop();
    switch (resp.get_status_code()) {
    case SUCCESS:
        MsgBox::success(this, tr("解冻账户"), tr("账户已解冻"));
        accept();
        break;
    case WRONG_ANSWER:
        MsgBox::information(this, tr("解冻账户"), tr("密保问题回答错误"));
        break;
    default:
        MsgBox::warming(this, tr("解冻账户"), tr("系统错误，请稍后再试"));
        break;
    }
}

void UnfrozenDialog::on_cancel_button_clicked()
{
    this->ui->stackedWidget->setCurrentIndex(0);
}

void UnfrozenDialog::on_submit_button_clicked()
{
    // get input
    QString answer(this->ui->answer->text());
    QString question(this->ui->questions->currentText());
    auto iter = question_table.find(question);
    // check input
    if(question_table.end() == iter){
        MsgBox::information(this, tr("解冻账户"), tr("请选择密保问题"));
        return;
    }
    if (answer.isEmpty()){
        MsgBox::information(this, tr("解冻账户"), tr("请输入回答"));
        return;
    }
    // build request
    Request req;
    req.set_module("user");
    req.set_func("unfrozen");
    req.put("e_id", e_id);
    req.put("q_id", iter->second);
    req.put("answer", answer);
    // build connect signal and function
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(handle_unfrozen(Response)));
    client.send(req);
    wait->start();
}

void UnfrozenDialog::reset()
{
    ui->username->clear();
    ui->answer->clear();
    ui->questions->clear();
    ui->questions->addItem(tr("选择密保问题"));
}
