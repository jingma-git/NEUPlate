#include "personal_center.h"
#include "ui_personal_center.h"
#include "UI/iconhelper.h"

PersonalCenter::PersonalCenter(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PersonalCenter)
{
    ui->setupUi(this);
    profile_manage=new ProfileManage();
    password_manage=new PasswordManage();
    question_manage=new QuestionManage();

    this->init_widget();
}


void PersonalCenter::init_menu(){
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf2bc << 0xf023 << 0xf084;
    btns<<ui->btnProfile<<ui->btnQuestion<<ui->btnPassword;

    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btnProfile->click();

}


void PersonalCenter::init_widget(){
    ui->stackedWidget->insertWidget(0,profile_manage);
    ui->stackedWidget->insertWidget(1,question_manage);
    ui->stackedWidget->insertWidget(2,password_manage);
}


void PersonalCenter::menu_click(){

    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);

    if(b==ui->btnProfile){
        if(!profile_manage->Is_init())
            profile_manage->init();
        ui->stackedWidget->setCurrentIndex(0);
    }else if(b==ui->btnQuestion){
        question_manage->init();
        ui->stackedWidget->setCurrentIndex(1);
    }else if(b==ui->btnPassword){
        password_manage->reset();
        ui->stackedWidget->setCurrentIndex(2);
    }

}

PersonalCenter::~PersonalCenter()
{
    delete ui;
    delete profile_manage;
    delete password_manage;
    delete question_manage;
}
