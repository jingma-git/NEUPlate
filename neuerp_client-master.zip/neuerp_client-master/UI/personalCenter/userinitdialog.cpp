#include "userinitdialog.h"
#include "ui_userinitdialog.h"
#include "UI/iconhelper.h"
#include "Network/Body/request.h"
#include "status_code.h"
#include "UI/msgbox.h"
#include <QJsonObject>

UserInitDialog::UserInitDialog(const QString &e_id, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UserInitDialog),
    e_id(e_id),
    client(MainClient::get_instance())
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
    get_questions();
}

UserInitDialog::~UserInitDialog()
{
    delete ui;
    delete wait;
}

void UserInitDialog::on_btnMenu_Close_clicked()
{
    close();
}
void UserInitDialog::on_cancel_button_clicked()
{
    close();
}

void UserInitDialog::on_submit_button_clicked()
{
    if(0 == this->ui->questions1->currentIndex() || 0 == this->ui->questions2->currentIndex() || 0 == this->ui->questions3->currentIndex()){
        MsgBox::information(this, tr("新用户初始化"), tr("请选择密保问题"));
        return;
    }
    QString question1(this->ui->questions1->currentText());
    QString question2(this->ui->questions2->currentText());
    QString question3(this->ui->questions3->currentText());
    QString answer1(this->ui->answer1->text());
    QString answer2(this->ui->answer2->text());
    QString answer3(this->ui->answer3->text());
    QString passwd1(this->ui->passwd1->text());
    QString passwd2(this->ui->passwd2->text());
    if (passwd1 != passwd2){
        MsgBox::information(this, tr("新用户初始化"), tr("两次输入的密码不一致"));
        return;
    }
    if (answer1.isEmpty() || answer2.isEmpty() || answer3.isEmpty()){
        MsgBox::information(this, tr("新用户初始化"), tr("请输入回答"));
        return;
    }
    QJsonObject questions;
    questions.insert(question_table[question1], answer1);
    questions.insert(question_table[question2], answer2);
    questions.insert(question_table[question3], answer3);
    Request req;
    req.set_module("user");
    req.set_func("new_user");
    req.put("e_id", e_id);
    req.put("passwd", passwd1);
    req.put("questions", questions);
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(init_arrive(Response)));
    client.send(req);
    wait->start();
}

/**
* @functionName  question_arrive
* @Description   when query all security question's response arrive, it will handle response
* @author        chenhanlin
* @date          2018-07-08
* @parameter     Response resp
* @return        void
*/
void UserInitDialog::question_arrive(Response resp)
{
    if("user" != resp.get_module() || "security_question" != resp.get_func()) return;
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(question_arrive(Response)));
    wait->stop();
    QString question;
    QStringList keys;
    switch (resp.get_status_code()) {
    case SUCCESS:
        keys = resp.keys();
        for(const auto &key : keys){
            question = resp.get_string(key);
            this->question_table.insert(std::map<QString, QString>::value_type(question, key));
            this->ui->questions1->addItem(question);
            this->ui->questions2->addItem(question);
            this->ui->questions3->addItem(question);
        }
        break;
    default:
        MsgBox::information(this, tr("新用户初始化"), tr("系统错误，请稍后再试"));
        break;
    }
}

void UserInitDialog::init_arrive(Response resp)
{
    if("user" != resp.get_module() && "new_user" != resp.get_func()) return;
    switch (resp.get_status_code()) {
    case SUCCESS:
        MsgBox::success(this, tr("新用户初始化"), tr("新用户初始化成功"));
        close();
        break;
    default:
        MsgBox::warming(this, tr("新用户初始化"), tr("系统错误，请稍后再试"));
        break;
    }
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(init_arrive(Response)));
}

/**
* @functionName  get_questions
* @Description   send request to sever to get all security question
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void UserInitDialog::get_questions()
{
    Request req;
    req.set_module("user");
    req.set_func("security_question");
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(question_arrive(Response)));
    client.send(req);
}

void UserInitDialog::reset()
{
    ui->questions1->clear();
    ui->questions2->clear();
    ui->questions3->clear();
    ui->questions1->addItem(tr("选择密保问题1"));
    ui->questions2->addItem(tr("选择密保问题2"));
    ui->questions3->addItem(tr("选择密保问题3"));
    ui->answer1->clear();
    ui->answer2->clear();
    ui->answer3->clear();
}

/**
* @functionName  on_question1_currentIndexChanged
* @Description   update another combo box's item
* @author        chenhanlin
* @date          2018-07-08
* @parameter     QString arg1
* @return        void
*/
void UserInitDialog::on_questions1_currentIndexChanged(const QString &arg1)
{
    int index = this->ui->questions1->findText(arg1);
    // get combo box name
    QString object_name(this->ui->questions1->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->questions2->addItem(old);
        this->ui->questions3->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->questions2->findText(arg1);
        this->ui->questions2->removeItem(index);
        index = this->ui->questions3->findText(arg1);
        this->ui->questions3->removeItem(index);
    }
}

/**
* @functionName  on_question1_currentIndexChanged
* @Description   update another combo box's item
* @author        chenhanlin
* @date          2018-07-08
* @parameter     QString arg1
* @return        void
*/
void UserInitDialog::on_questions2_currentIndexChanged(const QString &arg1)
{
    int index = this->ui->questions2->findText(arg1);
    // get combo box name
    QString object_name(this->ui->questions2->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->questions1->addItem(old);
        this->ui->questions3->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->questions1->findText(arg1);
        this->ui->questions1->removeItem(index);
        index = this->ui->questions3->findText(arg1);
        this->ui->questions3->removeItem(index);
    }
}

/**
* @functionName  on_question1_currentIndexChanged
* @Description   update another combo box's item
* @author        chenhanlin
* @date          2018-07-08
* @parameter     QString arg1
* @return        void
*/
void UserInitDialog::on_questions3_currentIndexChanged(const QString &arg1)
{
    int index = this->ui->questions3->findText(arg1);
    // get combo box name
    QString object_name(this->ui->questions3->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->questions2->addItem(old);
        this->ui->questions1->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->questions2->findText(arg1);
        this->ui->questions2->removeItem(index);
        index = this->ui->questions1->findText(arg1);
        this->ui->questions1->removeItem(index);
    }
}
