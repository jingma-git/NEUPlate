#ifndef QUESTION_MANAGE_H
#define QUESTION_MANAGE_H

#include <QWidget>
#include <map>
#include "Network/Body/response.h"
#include "Network/Client/mainclient.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class QuestionManage;
}

class QuestionManage : public QWidget
{
    Q_OBJECT

public:
    explicit QuestionManage(QWidget *parent = 0);
    ~QuestionManage();
    void init();

private slots:
    void handle_query_question(Response);
    void handle_check(Response);
    void question_arrive(Response);
    void commit_arrive(Response);

    void on_confirm_button_clicked();

    void on_questions1_currentIndexChanged(const QString &arg1);

    void on_questions2_currentIndexChanged(const QString &arg1);

    void on_questions3_currentIndexChanged(const QString &arg1);

    void on_cancel_button_clicked();

    void on_submit_button_clicked();

private:
    Ui::QuestionManage *ui;
    std::map<QString, QString> question_table;
    std::map<QString, QString> selected;
    MainClient &client;
    WaitingSpinnerWidget *wait;
    bool invoke_changed;

    void get_question();
};

#endif // QUESTION_MANAGE_H
