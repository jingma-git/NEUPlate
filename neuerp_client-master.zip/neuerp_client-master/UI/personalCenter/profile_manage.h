#ifndef PROFILE_MANAGE_H
#define PROFILE_MANAGE_H

#include <QWidget>
#include "Network/Client/mainclient.h"
#include "Network/Body/response.h"
#include "Entity/employee.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class ProfileManage;
}

class ProfileManage : public QWidget
{
    Q_OBJECT

public:
    explicit ProfileManage(QWidget *parent = 0);
    ~ProfileManage();
    void init();

    bool Is_init() const;

private slots:
    void on_edit_button_clicked();
    void init_message(Response);
    void submit_message(Response);

    void on_cancel_button_clicked();

    void on_submit_button_clicked();

private:
    Ui::ProfileManage *ui;
    MainClient &client;
    Employee *employee;
    bool is_init;
    WaitingSpinnerWidget *wait;

    void init_lineedit();
};

#endif // PROFILE_MANAGE_H
