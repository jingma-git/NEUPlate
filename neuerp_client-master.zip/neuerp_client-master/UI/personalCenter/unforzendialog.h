#ifndef UNFORZENDIALOG_H
#define UNFORZENDIALOG_H

#include <QDialog>
#include <Network/Body/response.h>
#include <Network/Client/mainclient.h>
#include <map>
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class UnforzenDialog;
}

class UnfrozenDialog : public QDialog
{
    Q_OBJECT

public:
    explicit UnfrozenDialog(QWidget *parent = 0);
    ~UnfrozenDialog();

private slots:
    void on_btnMenu_Close_clicked();

    void on_confirm_button_clicked();

    void on_cancel_button2_clicked();

    void handle_query_question(Response);
    void handle_unfrozen(Response);

    void on_cancel_button_clicked();

    void on_submit_button_clicked();

private:
    Ui::UnforzenDialog *ui;
    MainClient &client;
    QString e_id;
    std::map<QString, QString> question_table;
    WaitingSpinnerWidget *wait;

    void reset();
};

#endif // UNFORZENDIALOG_H
