#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include <Network/Body/response.h>
#include "UI/personalCenter/forget_passwd.h"
#include "UI/personalCenter/unforzendialog.h"
#include "UI/personalCenter/userinitdialog.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class Login;
}

class Login : public QDialog
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = 0);
    ~Login();

private slots:
    void on_loginButton_clicked();

    void on_forget_passwd_button_clicked();

    void message_arrive(Response);
    void error_arrive(QString);
    void close_connection();

    void on_btnMenu_Close_clicked();

private:
    Ui::Login *ui;
    QString e_id;
    Forget_passwd *fgp;
    UnfrozenDialog *ufd;
    UserInitDialog *uid;
    WaitingSpinnerWidget *wait;
};

#endif // LOGIN_H
