#include "msgbox.h"
#include <QMessageBox>
#include <QPushButton>
#include <QVariant>
#include <QPixmap>
#include <QSize>
#include <QFile>

QString MsgBox::style("background-color:#444444");

MsgBox::MsgBox()
{


}

/**
* @functionName  information
* @Description   show information messagebox
* @author        chenhanlin
* @date          2018-07-07
* @parameter     void
* @return        void
*/
void MsgBox::information(QWidget *parent, const QString &title, const QString &text, const QString &confirm)
{
    QMessageBox msg(parent);
//    msg.setWindowFlags(Qt::FramelessWindowHint | msg.windowFlags());
    msg.setProperty("canMove",true);
    msg.setStyleSheet(style);
    msg.setWindowTitle(title);
    QPixmap icon;
    icon.load(":/image/提示_1.png");
    msg.setText(text);
    msg.setIconPixmap(icon.scaled(30,30,Qt::KeepAspectRatio));
    QPushButton *bconfirm = msg.addButton(confirm, QMessageBox::AcceptRole);
    bconfirm->setProperty("btn_color","green");
    msg.exec();
}

void MsgBox::error(QWidget *parent, const QString &title, const QString &text, const QString &confirm)
{
    QMessageBox msg(parent);
    msg.setStyleSheet(style);
    msg.setWindowTitle(title);
    QPixmap icon;
    icon.load(":/image/提示.png");
    msg.setText(text);
    msg.setIconPixmap(icon.scaled(30,30,Qt::KeepAspectRatio));
    QPushButton *bconfirm = msg.addButton(confirm, QMessageBox::AcceptRole);
    bconfirm->setProperty("btn_color","green");
    msg.exec();
}

int MsgBox::question(QWidget *parent, const QString &title, const QString &text, const QString &yes, const QString &no)
{
    QMessageBox msg(parent);
    msg.setStyleSheet(style);
    msg.setWindowTitle(title);
    QPixmap icon;
    icon.load(":/image/提示_2.png");
    msg.setText(text);
    msg.setIconPixmap(icon.scaled(30,30,Qt::KeepAspectRatio));
    QPushButton *breject = msg.addButton(no, QMessageBox::RejectRole);
    QPushButton *bconfirm = msg.addButton(yes, QMessageBox::AcceptRole);

    bconfirm->setProperty("btn_color","green");
    breject->setProperty("btn_color","red");
    msg.exec();
    if(msg.clickedButton() == bconfirm){
        return YES;
    }else{
        return NO;
    }
}

void MsgBox::warming(QWidget *parent, const QString &title, const QString &text, const QString &confirm)
{
    QMessageBox msg(parent);
    msg.setStyleSheet(style);
    msg.setWindowTitle(title);
    QPixmap icon;
    icon.load(":/image/警告.png");
    msg.setText(text);
    msg.setIconPixmap(icon.scaled(30,30,Qt::KeepAspectRatio));
    QPushButton *bconfirm = msg.addButton(confirm, QMessageBox::AcceptRole);
    bconfirm->setProperty("btn_color","green");
    msg.exec();

}

void MsgBox::success(QWidget *parent, const QString &title, const QString &text, const QString &confirm)
{
    QMessageBox msg(parent);
    msg.setStyleSheet(style);
    msg.setWindowTitle(title);
    QPixmap icon;
    icon.load(":/image/确认_蓝色.png");
    msg.setText(text);
    msg.setIconPixmap(icon.scaled(30,30,Qt::KeepAspectRatio));
    QPushButton *bconfirm = msg.addButton(confirm, QMessageBox::AcceptRole);
    bconfirm->setProperty("btn_color","green");
    msg.exec();

}

