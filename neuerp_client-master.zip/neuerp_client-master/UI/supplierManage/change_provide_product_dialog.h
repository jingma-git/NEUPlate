#ifndef CHANGE_PROVIDE_PRODUCT_DIALOG_H
#define CHANGE_PROVIDE_PRODUCT_DIALOG_H

#include <QDialog>
#include <QJsonArray>
#include <QJsonObject>
#include "add_supplier_dialog.h"
#include "change_supplier_info_dialog.h"
#include "change_product_info_dialog.h"
#include "Network/Body/response.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Entity/supplier.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class ChangeProvideProductDialog;
}

class ChangeProvideProductDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ChangeProvideProductDialog(QWidget *parent = 0);
    ~ChangeProvideProductDialog();

signals:
    void change_success();

private slots:
    void get_product(const ProvideProduct&);
    void recv_save_information(Response);

    void on_btnMenu_Close_clicked();
    void on_btn_save_clicked();

private:
    Ui::ChangeProvideProductDialog *ui;
    ProvideProduct product;
    QDoubleValidator *price_validator;
    WaitingSpinnerWidget *waiting;
};

#endif // CHANGE_PROVIDE_PRODUCT_DIALOG_H
