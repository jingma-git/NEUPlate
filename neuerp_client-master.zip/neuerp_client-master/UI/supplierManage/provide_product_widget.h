#ifndef PROVIDE_PRODUCT_WIDGET_H
#define PROVIDE_PRODUCT_WIDGET_H

#include <QWidget>
#include <QJsonArray>
#include <QJsonObject>
#include "change_provide_product_dialog.h"
#include "Network/Body/response.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Entity/supplier.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class ProvideProductWidget;
}

class ProvideProductWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ProvideProductWidget(QWidget *parent = 0);
    ~ProvideProductWidget();
    void init_provide_roduct();

signals:
    void send_change_product(const ProvideProduct&);

private slots:
    void change_page(int new_index);
    void last_page();
    void next_page();
    void right_menu_action(const QPoint&);
    void change_product_info();
    void refresh_product();

    void recv_search_product(Response);
    void recv_delete_product(Response);

    void on_btn_search_clicked();
    void on_btn_delete_product_clicked();

private:
    Ui::ProvideProductWidget *ui;
    ChangeProvideProductDialog *change_provide_product;
    std::vector<ProvideProduct> products;
    QMenu *right_menu;
    QAction *edit_product;
    QAction *delete_product;
    WaitingSpinnerWidget *waiting;
    int page;
    int item = 10;
    int current_page;
    bool inited;

    void create_menu();
    void search_product();
    void show_product();
    void refresh_page();
};

#endif // PROVIDE_PRODUCT_WIDGET_H
