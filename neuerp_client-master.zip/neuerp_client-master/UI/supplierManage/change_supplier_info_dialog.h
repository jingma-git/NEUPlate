#ifndef CHANGE_SUPPLIER_INFO_DIALOG_H
#define CHANGE_SUPPLIER_INFO_DIALOG_H

#include <QDialog>
#include <UI/msgbox.h>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QJsonArray>
#include "Network/Body/response.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Entity/supplier.h"
#include "status_code.h"
#include "UI/iconhelper.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class ChangeSupplierInfoDialog;
}

class ChangeSupplierInfoDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ChangeSupplierInfoDialog(QWidget *parent = 0);
    ~ChangeSupplierInfoDialog();

signals:
    void change_success();

private slots:
    void get_supplier(const Supplier&);
    void recv_save_information(Response);

    void on_btnMenu_Close_clicked();
    void on_btn_save_clicked();

private:
    Ui::ChangeSupplierInfoDialog *ui;
    WaitingSpinnerWidget *waiting;
    Supplier supplier;
};

#endif // CHANGE_SUPPLIER_INFO_DIALOG_H
