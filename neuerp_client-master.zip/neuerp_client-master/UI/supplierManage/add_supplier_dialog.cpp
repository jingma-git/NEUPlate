#include "add_supplier_dialog.h"
#include "ui_add_supplier_dialog.h"
#include <QDebug>

/**
* @functionName  AddSupplierDialog
* @Description   the constructor taht initial class AddSupplierDialog.
* @author        luxijia
* @date          2018-7-9
*/
AddSupplierDialog::AddSupplierDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddSupplierDialog)
{
    ui->setupUi(this);
    waiting = new WaitingSpinnerWidget(this);

    //only select a complete line
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);

    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    //set tab order
    QWidget::setTabOrder(ui->ledit_supplier_name, ui->ledit_region);
    QWidget::setTabOrder(ui->ledit_region, ui->ledit_contact);
    QWidget::setTabOrder(ui->ledit_contact, ui->ledit_telephone);
    QWidget::setTabOrder(ui->ledit_telephone, ui->btn_commit);
    QWidget::setTabOrder(ui->btn_commit, ui->btn_cancel);

    //connect
    connect(ui->btn_cancel, SIGNAL(clicked()), ui->btnMenu_Close, SIGNAL(clicked()));

    // set style
    ui->ledit_contact->setProperty("type", "input");
    ui->ledit_region->setProperty("type", "input");
    ui->ledit_supplier_name->setProperty("type", "input");
    ui->ledit_telephone->setProperty("type", "input");
    ui->btn_add->setProperty("btn_color", "green");
    ui->btn_cancel->setProperty("btn_color", "red");
    ui->btn_commit->setProperty("btn_color", "green");
    ui->btn_delete->setProperty("btn_color", "green");
    ui->btn_import->setProperty("btn_color", "green");
}

/**
* @functionName  ~AddSupplierDialog
* @Description   the deconstructor taht release class AddSupplierDialog resource.
* @author        luxijia
* @date          2018-7-9
*/
AddSupplierDialog::~AddSupplierDialog()
{
    delete ui;
    delete waiting;
}

/**
* @functionName  recv_add_supplier
* @Description   a slot function that receive add supplier request's respone,
*                show whether add success, and close conncection.
* @author        luxijia
* @date          2018-7-9
* @parameter     resp network response
*/
void AddSupplierDialog::recv_add_supplier(Response resp)
{
    if ("supplier" != resp.get_module() || "add_supplier" != resp.get_func())
        return;

    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_add_supplier(Response)));

    if (SUCCESS == resp.get_status_code())
    {
        MsgBox::information(this, "成功", "添加成功!");
        emit add_success();
        remove_content();
        this->close();
    }
    else
        MsgBox::error(this, "错误", "添加失败!");
}

/**
* @functionName  on_btn_commit_clicked
* @Description   a slot function that collect add supplier information and send add supplier request
*                after clicked commit button.
* @author        luxijia
* @date          2018-7-9
*/
void AddSupplierDialog::on_btn_commit_clicked()
{
    QString supplier_name = this->ui->ledit_supplier_name->text();
    QString supplier_region = this->ui->ledit_region->text();
    QString contact = this->ui->ledit_contact->text();
    QString telephong = this->ui->ledit_telephone->text();
    int row = this->ui->tableWidget->rowCount();
    int column = this->ui->tableWidget->columnCount();
    QJsonArray product_array;

    if (supplier_name.isEmpty() || supplier_region.isEmpty() ||
            contact.isEmpty() || telephong.isEmpty())
    {
        MsgBox::warming(this, "警告", "供应商信息未填写完成");
        return;
    }

    Request req;
    req.set_module("supplier");
    req.set_func("add_supplier");
    req.put("name", supplier_name);
    req.put("telephone", telephong);
    req.put("contact", contact);
    req.put("region",supplier_region);

    for (int i = 0; i < row; i++)
    {
        QJsonObject product;
        for (int j = 0; j < column; j++)
        {
            if (this->ui->tableWidget->item(i, j) != NULL)
            {
                switch (j)
                {
                case 0:
                    product.insert("name", this->ui->tableWidget->item(i, j)->text());
                    break;
                case 1:
                    product.insert("code", this->ui->tableWidget->item(i, j)->text());
                    break;
                case 2:
                    product.insert("price", this->ui->tableWidget->item(i, j)->text().toDouble());
                    break;
                case 3:
                    product.insert("description", this->ui->tableWidget->item(i, j)->text());
                default:
                    break;
                }
            }
            else
            {
                MsgBox::warming(this, "警告", "供应商品列表未填写完成");
                return;
            }
        }
        product_array.append(product);
    }

    req.put("provide_product", product_array);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_add_supplier(Response)));
}

/**
* @functionName  on_btn_add_clicked
* @Description   a slot funtion that clicked add button
*                can add a line in table widget.
* @author        luxijia
* @date          2018-7-9
*/
void AddSupplierDialog::on_btn_add_clicked()
{
    int row = this->ui->tableWidget->rowCount();
    this->ui->tableWidget->insertRow(row);
}

/**
* @functionName  on_btn_delete_clicked
* @Description   a slot funtion that clicked delete button
*                can delete selected line in table widget.
* @author        luxijia
* @date          2018-7-9
*/
void AddSupplierDialog::on_btn_delete_clicked()
{
    QModelIndexList selected = this->ui->tableWidget->selectionModel()->selectedIndexes();

    while (!selected.isEmpty())
    {
        QModelIndexList index_list = deleteRepeatList(selected);
        QModelIndex index = index_list.first();
        this->ui->tableWidget->removeRow(index.row());
        selected = this->ui->tableWidget->selectionModel()->selectedIndexes();
    }
}

/**
* @functionName  deleteRepeatList
* @Description   copy old table widget select model index list
*                to a new model index list to resort table line
*                and avoid repeat delete.
* @author        luxijia
* @date          2018-7-9
* @parameter     index_list old model index list
* @return        new_index_list new model index list that no repeat line.
*/
QModelIndexList AddSupplierDialog::deleteRepeatList(QModelIndexList index_list)
{
    QModelIndex index, new_index;
    QModelIndexList new_index_list;

    foreach (index, index_list)
    {
        if (new_index.row() != index.row())
        {
            new_index = index;
            new_index_list.append(new_index);
        }
    }

    return new_index_list;
}

/**
* @functionName  on_btnMenu_Close_clicked
* @Description   a slot funtion that judge whether has contect in add supplier widget
*                after clicked menu close button.
*                if has, that hint whether close supplier widget.
* @author        luxijia
* @date          2018-7-9
*/
void AddSupplierDialog::on_btnMenu_Close_clicked()
{
    QString supplier_name = this->ui->ledit_supplier_name->text();
    QString supplier_region = this->ui->ledit_region->text();
    QString contact = this->ui->ledit_contact->text();
    QString telephong = this->ui->ledit_telephone->text();
    int row = this->ui->tableWidget->rowCount();
    int column = this->ui->tableWidget->columnCount();

    if (!supplier_name.isEmpty() || !supplier_region.isEmpty() ||
            !contact.isEmpty() || !telephong.isEmpty())
    {
        int flag = MsgBox::question(this, "警告", "供应商信息未提交,是否退出？");

        if (flag == MsgBox::YES)
        {
            remove_content();
            this->close();
            return;
        }
        else
            return;
    }

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < column; j++)
        {
            if (this->ui->tableWidget->item(i, j) != NULL)
            {
                int flag = MsgBox::question(this, "警告", "供应商品信息未提交,是否退出？");

                if (flag == MsgBox::YES)
                {
                    remove_content();
                    this->close();
                    return;
                }
                else
                    return;
            }
        }
    }

    this->close();
}

/**
* @functionName  remove_contect
* @Description   remove add content in table widget.
* @author        luxijia
* @date          2018-7-12
*/
void AddSupplierDialog::remove_content()
{
    this->ui->ledit_supplier_name->clear();
    this->ui->ledit_region->clear();
    this->ui->ledit_contact->clear();
    this->ui->ledit_telephone->clear();

    int row_count = this->ui->tableWidget->rowCount();

    for (int i = row_count - 1; i > -1; i--)
        this->ui->tableWidget->removeRow(i);
}

/**
* @functionName  on_btn_import_clicked
* @Description   a slot funtion that import supplier information from execl file.
*                if has, that hint whether close supplier widget.
* @author        luxijia
* @date          2018-7-9
*/
void AddSupplierDialog::on_btn_import_clicked()
{
    QString file_path = QFileDialog::getOpenFileName(this,QStringLiteral("选择Excel文件"),"",tr("Exel file(*.xls *.xlsx)"));

    if (file_path.isEmpty())
        return;

    read_file(file_path);
}

/**
* @functionName  read_file
* @Description   read excel file information and import into table widget.
* @author        luxijia
* @date          2018-7-9
*/
void AddSupplierDialog::read_file(const QString &file_path)
{
    waiting->start();
    //load excel driver
    QAxObject excel("Excel.Application");
    excel.setProperty("Visible", false);

    QAxObject *work_books  = excel.querySubObject("WorkBooks");

    work_books->dynamicCall("Open(const QString&)", file_path);

    QAxObject *work_book = excel.querySubObject("ActiveWorkBook");
    QAxObject *work_sheets = work_book->querySubObject("Sheets");
    int sheet_count = work_sheets->property("Count").toInt();

    if (sheet_count > 0)
    {
        //get frist table information
        QAxObject *work_sheet = work_book->querySubObject("Sheets(int)", 1);
        QAxObject *used_range = work_sheet->querySubObject("UsedRange");
        int row_start = used_range->property("Row").toInt();
        int column_start = used_range->property("Column").toInt();
        int row_count = used_range->querySubObject("Rows")->property("Count").toInt();
        int column_count = used_range->querySubObject("Columns")->property("Count").toInt();

        if (row_count > 4 || column_count > 2)
        {
            MsgBox::warming(this, "导入", "导入格式错误");
            return;
        }

        char start_sign = column_start + 1 + 64;
        char end_sign = column_start + 1 + 64;
        QString read_range = start_sign + QString::number(row_start) + ":" + end_sign + QString::number(row_start + row_count);
        QAxObject *cell = work_sheet->querySubObject("Range(QString)", read_range);
        QVariant cell_value = cell->dynamicCall("Value");
        QVariantList cell_list = cell_value.toList();

        this->ui->ledit_supplier_name->setText(cell_list[0].toList()[0].toString());
        this->ui->ledit_region->setText(cell_list[1].toList()[0].toString());
        this->ui->ledit_contact->setText(cell_list[2].toList()[0].toString());
        this->ui->ledit_telephone->setText(cell_list[3].toList()[0].toString());

        //get frist table information
        work_sheet = work_book->querySubObject("Sheets(int)", 2);

        used_range = work_sheet->querySubObject("UsedRange");
        row_start = used_range->property("Row").toInt();
        column_start = used_range->property("Column").toInt();
        row_count = used_range->querySubObject("Rows")->property("Count").toInt();
        column_count = used_range->querySubObject("Columns")->property("Count").toInt();

        if (column_count > 4)
        {
            MsgBox::warming(this, "导入", "导入格式错误");
            this->ui->ledit_supplier_name->clear();
            this->ui->ledit_region->clear();
            this->ui->ledit_contact->clear();
            this->ui->ledit_telephone->clear();
            return;
        }

        start_sign = column_start + 64;
        end_sign = column_start + column_count + 64;
        read_range = start_sign + QString::number(row_start) + ":" + end_sign + QString::number(row_start + row_count);
        cell = work_sheet->querySubObject("Range(QString)", read_range);
        cell_value = cell->dynamicCall("Value");
        cell_list = cell_value.toList();
        QRegExp bar_code_judge("^[0-9-\\$]{1,}$");
        QRegExp price_judge("^\\+?(?!0+(\\.00?)?$)\\d+(\\.\\d\\d?)?$");
        int judge_failed = 0;
        qDebug() << row_start << column_start << row_count << column_count;

        for (int i = row_start; i < row_count; i++)
        {
            QVariantList data_list = cell_list[i].toList();
            int row = this->ui->tableWidget->rowCount();
            this->ui->tableWidget->insertRow(row);

            for (int j = column_start; j <= column_count; j++)
            {
                if (j == column_start)
                {
                    this->ui->tableWidget->setItem(row, j - 1, new QTableWidgetItem(data_list[j - 1].toString()));
                    continue;
                }

                if (j == column_start + 1)
                {
                    if (!bar_code_judge.exactMatch(data_list[j - 1].toString()))
                    {
                        MsgBox::warming(this, "导入", "导入商品的条形码格式出错!");
                        qDebug() << data_list[j - 2].toString() << data_list[j - 1].toString() << j << i;
                        judge_failed = 1;
                        break;
                    }

                    this->ui->tableWidget->setItem(row, j - 1, new QTableWidgetItem(data_list[j - 1].toString()));
                    continue;
                }

                if (j == column_start + 2)
                {
                    qDebug() << data_list[j - 1].toString();
                    if (!price_judge.exactMatch(data_list[j - 1].toString()))
                    {
                        MsgBox::warming(this, "导入", "导入商品的价格格式出错!");
                        judge_failed = 1;
                        break;
                    }

                    this->ui->tableWidget->setItem(row, j - 1, new QTableWidgetItem(data_list[j - 1].toString()));
                    continue;
                }

                if (j == column_start + 3)
                {
                    this->ui->tableWidget->setItem(row, j - 1, new QTableWidgetItem(data_list[j - 1].toString()));
                    continue;
                }
            }

            if (1 == judge_failed)
                break;
        }

        if (1 == judge_failed)
        {
            this->ui->ledit_supplier_name->clear();
            this->ui->ledit_region->clear();
            this->ui->ledit_contact->clear();
            this->ui->ledit_telephone->clear();

            int row = this->ui->tableWidget->rowCount();

            for (int i = row - 1; i > -1; i--)
                this->ui->tableWidget->removeRow(i);
        }
    }

    work_books->dynamicCall("Close()");
    excel.dynamicCall("Quit()");
    waiting->stop();
}
