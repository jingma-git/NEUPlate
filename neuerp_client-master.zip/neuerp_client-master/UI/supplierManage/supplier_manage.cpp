#include "supplier_manage.h"
#include "ui_supplier_manage.h"

/**
* @functionName  SupplierManage
* @Description   the constructor that initial supplier manage widget
*                interface.
* @author        luxijia
* @date          2018-7-3
*/
SupplierManage::SupplierManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SupplierManage)
{
    ui->setupUi(this);

    supplier_widget = new SupplierWidget();
    provide_product_widget = new ProvideProductWidget();

    this->init_left_menu();
    this->init_stacked_widget();
}

/**
* @functionName  init_left_menu
* @Description   initial left menu int interface.
* @author        luxijia
* @date          2018-7-3
*/
void SupplierManage::init_left_menu()
{
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf0d1 << 0xf1b3;
    btns << ui->btn_supplier << ui->btn_provide_product;

    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btn_supplier->click();
}

/**
* @functionName  init_stacked_widget
* @Description   initial statcked order int interface.
* @author        luxijia
* @date          2018-7-3
*/
void SupplierManage::init_stacked_widget()
{
    ui->stackedWidget->insertWidget(0, supplier_widget);
    ui->stackedWidget->insertWidget(1, provide_product_widget);
}

/**
* @functionName  menu_click
* @Description   enter menu button to change menu.
* @author        luxijia
* @date          2018-7-3
*/
void SupplierManage::menu_click()
{
    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);

    if(b == ui->btn_supplier){
        ui->stackedWidget->setCurrentIndex(0);
    }else if(b == ui->btn_provide_product){
        ui->stackedWidget->setCurrentIndex(1);
        provide_product_widget->init_provide_roduct();
    }
}

/**
* @functionName  SupplierManage
* @Description   the deconstructor that release class SupplierManage resource.
*                interface.
* @author        luxijia
* @date          2018-7-3
*/
SupplierManage::~SupplierManage()
{
    delete ui;
    delete supplier_widget;
    delete provide_product_widget;
}

/**
* @functionName  init_supplier
* @Description   init supplier search interface after click supplier manage button.
* @author        luxijia
* @date          2018-7-11
*/
void SupplierManage::init_supplier_manage()
{
    supplier_widget->init_supplier();
}
