#include "suppplier_widget.h"
#include "ui_suppplier_widget.h"
#include "usercontroller.h"
#include <QTextCodec>

/**
* @functionName  SupplierWidget
* @Description   the constructor that initial supplier widget
*                interface.
* @author        luxijia
* @date          2018-7-10
*/
SupplierWidget::SupplierWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SupplierWidget)
{
    ui->setupUi(this);
    item = 10;
    inited = false;

    waiting = new WaitingSpinnerWidget(this);
    add_supplier = new AddSupplierDialog();
    change_supplier = new ChangeSupplierInfoDialog();
    change_product = new ChangeProductInfoDialog();

    ui->ledit_serach->setFocus();
    //fixed table rows number
    ui->tableWidget->setRowCount(item);
    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    //set tool button
    ui->tbtn_left->setArrowType(Qt::LeftArrow);
    ui->tbtn_right->setArrowType(Qt::RightArrow);

    //set right mouse button menu
    create_menu();

    //connect search line deit return presss signal with search button clicked signal
    connect(ui->ledit_serach, SIGNAL(returnPressed()), ui->btn_search, SIGNAL(clicked()));

    //connect left and right tool button whth last page and next page function
    connect(ui->tbtn_left, SIGNAL(clicked()), this, SLOT(last_page()));
    connect(ui->tbtn_right, SIGNAL(clicked()), this, SLOT(next_page()));

    //connect change_supplier to class ChangeSupplierInforDialog get_supplier
    connect(this, SIGNAL(send_supplier_to_change_supplier(Supplier)), change_supplier, SLOT(get_supplier(Supplier)));
    connect(this, SIGNAL(send_supplier_to_change_product(Supplier)), change_product, SLOT(get_supplier(Supplier)));


    //connect return message
    connect(add_supplier, SIGNAL(add_success()), this, SLOT(refresh_supplier()));
    connect(change_supplier, SIGNAL(change_success()), this, SLOT(refresh_supplier()));

    // set style
    ui->btn_add_supplier->setProperty("btn_color", "green");
    ui->btn_delete_supplier->setProperty("btn_color", "red");
    ui->btn_remove_supplier->setProperty("btn_color", "red");
    ui->btn_renew->setProperty("btn_color", "green");
    ui->btn_search->setProperty("btn_color", "green");
    ui->tbtn_left->setProperty("btn_color", "green");
    ui->tbtn_right->setProperty("btn_color", "green");
    ui->ledit_serach->setProperty("type", "input");

    auto &user = UserController::get_instance();
    if(!user.check_access_code("dept_supplier_manager")){
        ui->btn_delete_supplier->hide();
    }
}

/**
* @functionName  ~SupplierWidget
* @Description   the constructor that release supplier widget resource.
*                interface.
* @author        luxijia
* @date          2018-7-10
*/
SupplierWidget::~SupplierWidget()
{
    delete ui;
    delete add_supplier;
    delete change_supplier;
    delete change_product;
    delete right_menu;
    delete edit_supplier;
    delete edit_provide_product;
    delete remove_supplier;
    delete delete_supplier;
    delete renew_supplier;
    delete waiting;
}

/**
* @functionName  create_menu
* @Description   crete table widget right mouse menu
* @author        luxijia
* @date          2018-7-10
*/
void SupplierWidget::create_menu()
{
    right_menu = new QMenu(this->ui->tableWidget);

    edit_supplier = new QAction(this);
    edit_provide_product = new QAction(this);
    remove_supplier = new QAction(this);
    renew_supplier = new QAction(this);

    edit_supplier->setText(QString("修改信息"));
    edit_provide_product->setText(QString("供应商品"));
    remove_supplier->setText(QString("停止供应"));
    renew_supplier->setText(QString("恢复供应"));

    right_menu->addAction(edit_supplier);
    right_menu->addAction(edit_provide_product);
    right_menu->addAction(remove_supplier);
    right_menu->addAction(renew_supplier);

    auto &user = UserController::get_instance();
    if(user.check_access_code("dept_supplier_manager")){
        delete_supplier = new QAction(this);
        delete_supplier->setText(QString("删除"));
        right_menu->addAction(delete_supplier);
        connect(delete_supplier, SIGNAL(triggered()), this, SLOT(on_btn_delete_supplier_clicked()));
    }
    //connect action
    connect(remove_supplier, SIGNAL(triggered()), this, SLOT(on_btn_remove_supplier_clicked()));
    connect(edit_supplier, SIGNAL(triggered()), this , SLOT(change_supplier_info()));
    connect(edit_provide_product, SIGNAL(triggered()), this, SLOT(change_product_info()));
    connect(renew_supplier, SIGNAL(triggered()), this, SLOT(on_btn_renew_clicked()));
    connect(this->ui->tableWidget, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(right_menu_action(const QPoint&)));
}

/**
* @functionName  right_menu_action
* @Description   show right menu item
* @author        luxijia
* @date          2018-7-10
* @parameter     QPoint dialog postion
*/
void SupplierWidget::right_menu_action(const QPoint &pos)
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();
    int rows = count / this->ui->tableWidget->columnCount();
    int row = -1;
    int remove_count = 0, support_count = 0;

    if (rows > 0)
    {
        edit_supplier->setEnabled(true);
        edit_provide_product->setEnabled(true);
        remove_supplier->setEnabled(true);
        delete_supplier->setEnabled(true);
        renew_supplier->setEnabled(true);

        if (rows > 1)
        {
            edit_supplier->setDisabled(true);
            edit_provide_product->setDisabled(true);
        }

        for (int i = 0; i < count; i++)
        {
            if (row != this->ui->tableWidget->row(items.at(i)))
            {
                row = this->ui->tableWidget->row(items.at(i));
                if (0 == suppliers[row].getSp_state())
                    remove_count++;

                if (1 == suppliers[row].getSp_state())
                    support_count++;
            }
        }

        if (0 != support_count && 0 != remove_count)
        {
            renew_supplier->setDisabled(true);
            remove_supplier->setDisabled(true);
        }

        if (0 == remove_count)
            renew_supplier->setDisabled(true);

        if (0 == support_count)
            remove_supplier->setDisabled(true);

        right_menu->exec(QCursor::pos());
    }
}

/**
* @functionName  refresh_page
* @Description   refresh combobox context and set current page.
* @author        luxijia
* @date          2018-7-10
*/
void SupplierWidget::refresh_page()
{
    disconnect(this->ui->comboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(change_page(int)));
    this->ui->tbtn_left->setEnabled(!(current_page == 1));
    this->ui->tbtn_right->setEnabled(!(current_page == page));
    this->ui->comboBox->clear();

    for (int i = 0; i < page; i++)
        this->ui->comboBox->insertItem(i, QString("第%1页").arg(i+1));

    this->ui->comboBox->setCurrentIndex(current_page - 1);
    connect(this->ui->comboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(change_page(int)));
}

/**
* @functionName  change_page
* @Description   change current page number and search supplier
* @author        luxijia
* @date          2018-7-10
* @parameter     new_index combobox next state index
*/
void SupplierWidget::change_page(int new_index)
{
    current_page = new_index + 1;
    search_supplier();
}

/**
* @functionName  init_supplier
* @Description   set all state to default and search supplier information
* @author        luxijia
* @date          2018-7-15
* @parameter     new_index combobox next state index
*/
void SupplierWidget::init_supplier()
{
    if (inited)
        return;

    inited = true;
    current_page = 1;
    this->ui->ledit_serach->clear();
    this->ui->cbox_supporting->clicked(false);
    this->ui->cbox_stop->clicked(false);
    search_supplier();
}

/**
* @functionName  last_page
* @Description   a slot funtion that return last page.
* @author        luxijia
* @date          2018-7-10
*/
void SupplierWidget::last_page()
{
    //since combobox index begin in 0, and actually page begin in 1,
    //index need sub 1 and then sub 1
    int index = current_page - 2;

    if (index < 0)
        index = 0;

    change_page(index);
}

/**
* @functionName  next_page
* @Description   a slot funtion that return last page.
* @author        luxijia
* @date          2018-7-10
*/
void SupplierWidget::next_page()
{
    //since combobox index begin in 0, and actually page begin in 1,
    //index need and 1 and then sub 1
    int index = current_page;

    if (index > page)
        index = page;

    change_page(current_page);
}

/**
* @functionName  on_btn_add_supplier_clicked
* @Description   a slot function that open add supplier dialog.
* @author        luxijia
* @date          2018-7-9
*/
void SupplierWidget::on_btn_add_supplier_clicked()
{
    add_supplier->setModal(true);
    add_supplier->show();
}


/**
* @functionName  on_btn_search_clicked
* @Description   a slot function that send search request
*                after click search botton.
* @author        luxijia
* @date          2018-7-10
*/
void SupplierWidget::on_btn_search_clicked()
{
    current_page = 1;
    search_supplier();
}

/**
* @functionName  search_supplier
* @Description   send search supplier request to server.
* @author        luxijia
* @date          2018-7-10
*/
void SupplierWidget::search_supplier()
{
    Request req;
    req.set_module("supplier");
    req.set_func("search");

    int state;

    if (ui->cbox_supporting->isChecked() == true)
        state = 1;

    if (ui->cbox_stop->isChecked() == true)
        state = 0;

    if ((ui->cbox_supporting->isChecked() == true && ui->cbox_stop->isChecked() == true)
            || (ui->cbox_supporting->isChecked() == false && ui->cbox_stop->isChecked() == false))
        state = -1;

    req.put("state", state);
    req.put("keyword", this->ui->ledit_serach->text());
    req.put("page_number", current_page);
    req.put("page_item", item);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_search_supplier(Response)));
}

/**
* @functionName  recv_search_supplier
* @Description   a slot function that receive search supplier request's respone,
*                show whether search success, and close conncection.
* @author        luxijia
* @date          2018-7-10
* @parameter     resp network response
*/
void SupplierWidget::recv_search_supplier(Response resp)
{
    if ("supplier" != resp.get_module() || "search" != resp.get_func())
        return;

    //close connection
    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_search_supplier(Response)));

    if (EMPTY_QUERY == resp.get_status_code())
    {
        MsgBox::warming(this, "提示", "没有此供应商!");
        return;

    }
    else if (QUERY_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "查询失败!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "发送参数出错!");
        return;
    }

    suppliers.clear();
    page = ceil((double)resp.get_int("all_result_num") / item);
    QJsonArray supplier_array = resp.get_array("suppliers");

    if (!supplier_array.isEmpty())
    {
        int size = supplier_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = supplier_array.at(i);

            if (value.isObject())
            {
                QJsonObject supplier_object = value.toObject();
                Supplier supplier;
                supplier.setSp_id(supplier_object.value("id").toString());
                supplier.setSp_name(supplier_object.value("name").toString());
                supplier.setSp_region(supplier_object.value("region").toString());
                supplier.setContact(supplier_object.value("contact").toString());
                supplier.setSp_state(supplier_object.value("state").toInt());
                supplier.setSp_phone(supplier_object.value("phone").toString());
                suppliers.push_back(supplier);
            }
        }
    }

    refresh_page();
    show_supplier();
}

/**
* @functionName  show_supplier
* @Description   show supplier information in table widget.
* @author        luxijia
* @date          2018-7-10
*/
void SupplierWidget::show_supplier()
{
    int size = suppliers.size();
    this->ui->tableWidget->clearContents();

    for (int i = 0; i < size; i++)
    {
        this->ui->tableWidget->setItem(i, 0, new QTableWidgetItem(suppliers[i].getSp_name()));
        this->ui->tableWidget->setItem(i, 1, new QTableWidgetItem(suppliers[i].getContact()));
        this->ui->tableWidget->setItem(i, 2, new QTableWidgetItem(suppliers[i].getSp_phone()));
        this->ui->tableWidget->setItem(i, 3, new QTableWidgetItem(suppliers[i].getSp_region()));

        if (1 == suppliers[i].getSp_state())
            this->ui->tableWidget->setItem(i, 4, new QTableWidgetItem("正在供应"));
        else
            this->ui->tableWidget->setItem(i, 4, new QTableWidgetItem("停止供应"));
    }
}

/**
* @functionName  on_btn_remove_supplier_clicked
* @Description   a slot function that remove selected supplier
*                and send request.
* @author        luxijia
* @date          2018-7-9
*/
void SupplierWidget::on_btn_remove_supplier_clicked()
{
    Request req;
    req.set_module("supplier");
    req.set_func("remove_supplier");


    //get remove supplier id
    QJsonArray supplier_id;
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();
    int row = -1;

    for (int i = 0; i < count; i++)
    {
        if (row != this->ui->tableWidget->row(items.at(i)))
        {
            row = this->ui->tableWidget->row(items.at(i));
            supplier_id.append(suppliers[row].getSp_id());
            qDebug() << row << "..." << suppliers[row].getSp_id();

            if (0 == suppliers[row].getSp_state())
            {
                MsgBox::warming(this, "警告", "试图移除停止供应的供应商");
                return;
            }
        }
    }

    req.put("supplier_id", supplier_id);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_remove_supplier(Response)));
}

/**
* @functionName  recv_remove_supplier
* @Description   a slot function that receive remove supplier request's respone,
*                show whether reomve success, and close conncection.
* @author        luxijia
* @date          2018-7-10
* @parameter     resp network response
*/
void SupplierWidget::recv_remove_supplier(Response resp)
{
    if ("supplier" != resp.get_module() || "remove_supplier" != resp.get_func())
        return;

    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_remove_supplier(Response)));

    if (REMOVE_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "移除供应商失败!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "发送参数出错!");
        return;
    }

    search_supplier();
}

/**
* @functionName  on_btn_delete_supplier_clicked
* @Description   a slot function that delete selected supplier
*                and send request.
* @author        luxijia
* @date          2018-7-9
*/
void SupplierWidget::on_btn_delete_supplier_clicked()
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();

    if (0 == count)
        return;

    int flag = MsgBox::question(this, "注意", "是否确认删除供应商,此操作无法撤销!");

    if (flag == MsgBox::NO)
        return;

    Request req;
    req.set_module("supplier");
    req.set_func("delete_supplier");

    //get remove supplier id
    QJsonArray supplier_id;
    int row = -1;

    for (int i = 0; i < count; i++)
    {
        if (row != this->ui->tableWidget->row(items.at(i)))
        {
            row = this->ui->tableWidget->row(items.at(i));
            supplier_id.append(suppliers[row].getSp_id());
        }
    }

    req.put("supplier_id", supplier_id);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_delete_supplier(Response)));
}

/**
* @functionName  recv_delete_supplier
* @Description   a slot function that receive delete supplier request's respone,
*                show whether delete success, and close conncection.
* @author        luxijia
* @date          2018-7-10
* @parameter     resp network response
*/
void SupplierWidget::recv_delete_supplier(Response resp)
{
    if ("supplier" != resp.get_module() || "delete_supplier" != resp.get_func())
        return;

    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_delete_supplier(Response)));

    if (DELETE_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "删除供应商失败!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "发送参数出错!");
        return;
    }

    this->ui->ledit_serach->clear();

    search_supplier();
}

/**
* @functionName  change_supplier_info
* @Description   a slot function that send signal with argument supplier to change supplier inforamtion dialog
*                after triggered change supplier action.
* @author        luxijia
* @date
* @parameter
* @return
*/
void SupplierWidget::change_supplier_info()
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int row = this->ui->tableWidget->row(items.at(0));

    emit send_supplier_to_change_supplier(suppliers[row]);
}

/**
* @functionName  change_product_info
* @Description   a slot function that send signal with argument supplier to change product inforamtion dialog
*                after triggered change supplier action.
* @author        luxijia
* @date          2018-7-11
*/
void SupplierWidget::change_product_info()
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int row = this->ui->tableWidget->row(items.at(0));

    emit send_supplier_to_change_product(suppliers[row]);
}

/**
* @functionName  refresh_supplier
* @Description   a slot function that refresh supplier
*                after change supplier success.
* @author        luxijia
* @date          2018-7-10
*/
void SupplierWidget::refresh_supplier()
{
    search_supplier();
}

/**
* @functionName  on_btn_renew_clicked
* @Description   a slot function that rener selected supplier
*                and send request.
* @author        luxijia
* @date          2018-7-9
*/
void SupplierWidget::on_btn_renew_clicked()
{
    Request req;
    req.set_module("supplier");
    req.set_func("renew_supplier");

    //get remove supplier id
    QJsonArray supplier_id;
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();
    int row = -1;

    for (int i = 0; i < count; i++)
    {
        if (row != this->ui->tableWidget->row(items.at(i)))
        {
            row = this->ui->tableWidget->row(items.at(i));
            supplier_id.append(suppliers[row].getSp_id());

            if (1 == suppliers[row].getSp_state())
            {
                MsgBox::warming(this, "警告", "试图恢复正在供应的供应商");
                return;
            }
        }
    }

    req.put("supplier_id", supplier_id);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_renew_supplier(Response)));
}

/**
* @functionName  recv_drenew_supplier
* @Description   a slot function that receive delete supplier request's respone,
*                show whether delete success, and close conncection.
* @author        luxijia
* @date          2018-7-10
* @parameter     resp network response
*/
void SupplierWidget::recv_renew_supplier(Response resp)
{
    if ("supplier" != resp.get_module() || "renew_supplier" != resp.get_func())
        return;

    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_search_supplier(Response)));

    if (DELETE_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "恢复供应商供应失败!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "发送参数出错!");
        return;
    }

    search_supplier();
}
