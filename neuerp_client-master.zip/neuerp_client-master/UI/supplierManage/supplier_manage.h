#ifndef SUPPLIER_MANAGE_H
#define SUPPLIER_MANAGE_H

#include <QWidget>
#include <QToolButton>
#include "UI/iconhelper.h"
#include "suppplier_widget.h"
#include "provide_product_widget.h"

namespace Ui {
class SupplierManage;
}

class SupplierManage : public QWidget
{
    Q_OBJECT

public:
    explicit SupplierManage(QWidget *parent = 0);
    ~SupplierManage();
    void init_supplier_manage();

private:
    Ui::SupplierManage *ui;
    QList<int> pixChars;
    QList<QToolButton *> btns;
    SupplierWidget *supplier_widget;
    ProvideProductWidget *provide_product_widget;
    void init_left_menu();
    void init_stacked_widget();

private slots:
    void menu_click();
};

#endif // SUPPLIER_MANAGE_H
