#include "change_supplier_info_dialog.h"
#include "ui_change_supplier_info_dialog.h"

/**
* @functionName  ChangeSupplierInfoDialog
* @Description   the constructor taht initial class ChangeSupplierInfoDialog.
* @author        luxijia
* @date          2018-7-10
*/
ChangeSupplierInfoDialog::ChangeSupplierInfoDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChangeSupplierInfoDialog)
{
    ui->setupUi(this);
    waiting = new WaitingSpinnerWidget(this);

    //set tab order
    QWidget::setTabOrder(ui->ledit_supplier_name, ui->ledit_region);
    QWidget::setTabOrder(ui->ledit_region, ui->ledit_contact);
    QWidget::setTabOrder(ui->ledit_contact, ui->ledit_telephone);
    QWidget::setTabOrder(ui->ledit_telephone, ui->rbtn_stop);
    QWidget::setTabOrder(ui->rbtn_stop, ui->rbtn_support);
    QWidget::setTabOrder(ui->rbtn_support, ui->btn_save);
    QWidget::setTabOrder(ui->btn_save, ui->btn_cancel);
    QWidget::setTabOrder(ui->btn_cancel, ui->btnMenu_Close);

    //set no border
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);


    //connect cancel button clicked signal with close menu button clicked signal
    connect(ui->btn_cancel, SIGNAL(clicked()), ui->btnMenu_Close, SIGNAL(clicked()));

    // set style
    ui->btn_cancel->setProperty("btn_color", "red");
    ui->btn_save->setProperty("btn_color", "green");
    ui->ledit_contact->setProperty("type", "input");
    ui->ledit_region->setProperty("type", "input");
    ui->ledit_supplier_name->setProperty("type", "input");
    ui->ledit_telephone->setProperty("type", "name");
}

/**
* @functionName  ChangeSupplierInfoDialog
* @Description   the constructor taht release class ChangeSupplierInfoDialog resource.
* @author        luxijia
* @date          2018-7-10
*/
ChangeSupplierInfoDialog::~ChangeSupplierInfoDialog()
{
    delete ui;
    delete waiting;
}

/**
* @functionName  get_supplier
* @Description   a slot function get supplier information from supplier widget.
* @author        luxijia
* @date          2018-7-10
* @parameter     send_supplier supplier onject that store supplier information
*/
void ChangeSupplierInfoDialog::get_supplier(const Supplier &send_supplier)
{
    supplier = send_supplier;

    this->ui->ledit_supplier_name->setText(supplier.getSp_name());
    this->ui->ledit_contact->setText(supplier.getContact());
    this->ui->ledit_region->setText(supplier.getSp_region());
    this->ui->ledit_telephone->setText(supplier.getSp_phone());

    if (0 == supplier.getSp_state())
        this->ui->rbtn_stop->click();
    else
        this->ui->rbtn_support->click();

    ui->ledit_supplier_name->setFocus();
    this->show();
}

/**
* @functionName  on_btnMenu_Close_clicked
* @Description   a slot funtion that close change supplier information dialog
*                that judge supplier information whether change after clicked menu button.
*                if change then show message wheher give save.
* @author        luxijia
* @date          2018-7-10
*/
void ChangeSupplierInfoDialog::on_btnMenu_Close_clicked()
{
    int state = -1;

    if (true == this->ui->rbtn_stop->isChecked())
        state = 0;

    if (true == this->ui->rbtn_support->isChecked())
        state = 1;


    if (this->ui->ledit_supplier_name->text() != supplier.getSp_name() || this->ui->ledit_contact->text() != supplier.getContact() ||
            this->ui->ledit_region->text() != supplier.getSp_region() || this->ui->ledit_telephone->text() != supplier.getSp_phone() ||
            state != supplier.getSp_state())
    {
        int flag = MsgBox::question(this, "退出", "供应商信息已更改，是否放弃保存？");

        if (MsgBox::YES == flag)
            this->close();

        return;
    }

    this->close();
}

/**
* @functionName  on_btn_save_clicked
* @Description   a slot funtion that send change supplier request to server.
*                after clicked save button.
* @author        luxijia
* @date          2018-7-10
*/
void ChangeSupplierInfoDialog::on_btn_save_clicked()
{
    Request req;
    req.set_module("supplier");
    req.set_func("change");

    int state = -1;

    if (true == this->ui->rbtn_stop->isChecked())
        state = 0;

    if (true == this->ui->rbtn_support->isChecked())
        state = 1;


    if (this->ui->ledit_supplier_name->text() == supplier.getSp_name() && this->ui->ledit_contact->text() == supplier.getContact() &&
            this->ui->ledit_region->text() == supplier.getSp_region() && this->ui->ledit_telephone->text() == supplier.getSp_phone() &&
            state == supplier.getSp_state())
    {
        MsgBox::information(this, "保存", "保存供应商信息成功");
        this->close();
        return;
    }

    req.put("id", supplier.getSp_id());
    req.put("name", this->ui->ledit_supplier_name->text());
    req.put("phone", this->ui->ledit_telephone->text());
    req.put("region", this->ui->ledit_region->text());
    req.put("contact", this->ui->ledit_contact->text());
    req.put("state", state);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_save_information(Response)));
}

/**
* @functionName  recv_save_information
* @Description   a slot function that receive change supplier information request's respone,
*                show whether change success, and close conncection.
* @author        luxijia
* @date          2018-7-10
* @parameter     resp network response
*/
void ChangeSupplierInfoDialog::recv_save_information(Response resp)
{
    if ("supplier" != resp.get_module() || "change" != resp.get_func())
        return;

    //close connection
    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_save_information(Response)));

    if (CHANGE_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "修改供应商信息失败!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "参数出错!");
        return;
    }

    MsgBox::information(this, "修改", "修改供应商信息成功");

    emit change_success();
    this->close();
}
