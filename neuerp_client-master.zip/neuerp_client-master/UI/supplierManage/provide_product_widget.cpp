#include "provide_product_widget.h"
#include "ui_provide_product_widget.h"
#include "usercontroller.h"

/**
* @functionName  ProvideProductWidget
* @Description   the constructor that initial poduct widget
*                interface.
* @author        luxijia
* @date          2018-7-11
*/
ProvideProductWidget::ProvideProductWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ProvideProductWidget)
{
    ui->setupUi(this);
    item = 10;
    inited = false;

    waiting = new WaitingSpinnerWidget(this);
    change_provide_product = new ChangeProvideProductDialog();

    //fixed table rows number
    ui->tableWidget->setRowCount(item);
    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    //set tool button
    ui->tbtn_left->setArrowType(Qt::LeftArrow);
    ui->tbtn_right->setArrowType(Qt::RightArrow);

    //set right mouse button menu
    create_menu();

    //connect search line deit return presss signal with search button clicked signal
    connect(ui->ledit_serach, SIGNAL(returnPressed()), ui->btn_search, SIGNAL(clicked()));

    //connect change_supplier to class ChangeSupplierInforDialog get_supplier
    connect(this, SIGNAL(send_change_product(ProvideProduct)), change_provide_product, SLOT(get_product(ProvideProduct)));

    //connect left and right tool button whth last page and next page function
    connect(ui->tbtn_left, SIGNAL(clicked()), this, SLOT(last_page()));
    connect(ui->tbtn_right, SIGNAL(clicked()), this, SLOT(next_page()));

    //connect return message
    connect(change_provide_product, SIGNAL(change_success()), this, SLOT(refresh_product()));

    // set style
    ui->ledit_serach->setProperty("type", "input");
    ui->btn_delete_product->setProperty("btn_color", "red");
    ui->btn_search->setProperty("btn_color", "green");
    ui->tbtn_left->setProperty("btn_color", "green");
    ui->tbtn_right->setProperty("btn_color", "green");

    auto &user = UserController::get_instance();
    if(!user.check_access_code("dept_supplier_manager")){
        ui->btn_delete_product->hide();
    }
}

/**
* @functionName  ~ProvideProductWidget
* @Description   the constructor that release provide product widget resource.
*                interface.
* @author        luxijia
* @date          2018-7-11
*/
ProvideProductWidget::~ProvideProductWidget()
{
    delete ui;
    delete change_provide_product;
    delete right_menu;
    delete edit_product;
    delete delete_product;
    delete waiting;
}

/**
* @functionName  create_menu
* @Description   crete table widget right mouse menu
* @author        luxijia
* @date          2018-7-11
*/
void ProvideProductWidget::create_menu()
{
    right_menu = new QMenu(this->ui->tableWidget);

    edit_product = new QAction(this);

    edit_product->setText(QString("编辑"));

    right_menu->addAction(edit_product);

    auto &user = UserController::get_instance();
    if(user.check_access_code("dept_supplier_manager")){
        delete_product = new QAction(this);
        delete_product->setText(QString("删除"));
        right_menu->addAction(delete_product);
        connect(delete_product, SIGNAL(triggered()), this , SLOT(on_btn_delete_product_clicked()));
    }
    //connect action
    connect(edit_product, SIGNAL(triggered()), this, SLOT(change_product_info()));
    connect(this->ui->tableWidget, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(right_menu_action(const QPoint&)));
}

/**
* @functionName  right_menu_action
* @Description   show right menu item
* @author        luxijia
* @date          2018-7-11
* @parameter     QPoint dialog postion
*/
void ProvideProductWidget::right_menu_action(const QPoint &pos)
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();
    int rows = count / this->ui->tableWidget->columnCount();

    if (rows > 0)
    {
        edit_product->setEnabled(true);
        delete_product->setEnabled(true);

        if (rows > 1)
            edit_product->setDisabled(true);

        right_menu->exec(QCursor::pos());
    }
}

/**
* @functionName  refresh_page
* @Description   refresh combobox context and set current page.
* @author        luxijia
* @date          2018-7-10
*/
void ProvideProductWidget::refresh_page()
{
    disconnect(this->ui->comboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(change_page(int)));
    this->ui->tbtn_left->setEnabled(!(current_page == 1));
    this->ui->tbtn_right->setEnabled(!(current_page == page));
    this->ui->comboBox->clear();

    for (int i = 0; i < page; i++)
        this->ui->comboBox->insertItem(i, QString("第%1页").arg(i+1));

    this->ui->comboBox->setCurrentIndex(current_page - 1);
    connect(this->ui->comboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(change_page(int)));
}

/**
* @functionName  refresh_product
* @Description   a slot function that refresh procide product table
*                after change supplier success.
* @author        luxijia
* @date          2018-7-11
*/
void ProvideProductWidget::refresh_product()
{
    search_product();
}

/**
* @functionName  init_provide_roduct
* @Description   set provide product widget search condition to default.
* @author        luxijia
* @date          2018-7-15
*/
void ProvideProductWidget::init_provide_roduct()
{
    if (inited)
        return;

    inited = true;
    current_page = 1;
    this->ui->ledit_serach->clear();
    search_product();
}

/**
* @functionName  change_page
* @Description   change current page number and search supplier
* @author        luxijia
* @date          2018-7-10
* @parameter     new_index combobox next state index
*/
void ProvideProductWidget::change_page(int new_index)
{
    current_page = new_index + 1;
    search_product();
}

/**
* @functionName  last_page
* @Description   a slot funtion that return last page.
* @author        luxijia
* @date          2018-7-10
*/
void ProvideProductWidget::last_page()
{
    //since combobox index begin in 0, and actually page begin in 1,
    //index need sub 1 and then sub 1
    int index = current_page - 2;

    if (index < 0)
        index = 0;

    change_page(index);
}

/**
* @functionName  next_page
* @Description   a slot funtion that return last page.
* @author        luxijia
* @date          2018-7-10
*/
void ProvideProductWidget::next_page()
{
    //since combobox index begin in 0, and actually page begin in 1,
    //index need and 1 and then sub 1
    int index = current_page;

    if (index > page)
        index = page;

    change_page(current_page);
}

/**
* @functionName  on_btn_search_clicked
* @Description   a slot function that send search provide product request
*                after click search botton.
* @author        luxijia
* @date          2018-7-10
*/
void ProvideProductWidget::on_btn_search_clicked()
{
    current_page = 1;
    search_product();
}

/**
* @functionName  search_product
* @Description   send search product request to server.
* @author        luxijia
* @date          2018-7-11
*/
void ProvideProductWidget::search_product()
{
    Request req;
    req.set_module("provide_product");
    req.set_func("search_product");

    req.put("keyword", this->ui->ledit_serach->text());
    req.put("page_number", current_page);
    req.put("page_item", item);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_search_product(Response)));
}

/**
* @functionName  recv_search_supplier
* @Description   a slot function that receive search supplier request's respone,
*                show whether search success, and close conncection.
* @author        luxijia
* @date          2018-7-10
* @parameter     resp network response
*/
void ProvideProductWidget::recv_search_product(Response resp)
{
    if ("provide_product" != resp.get_module() || "search_product" != resp.get_func())
        return;

    //close connection
    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_search_product(Response)));

    if (EMPTY_QUERY == resp.get_status_code())
    {
        MsgBox::warming(this, "提示", "没有供应商品!");
        return;

    }
    else if (QUERY_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "查询失败!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "发送参数出错!");
        return;
    }

    products.clear();
    page = ceil((double)resp.get_int("all_result_num") / item);
    QJsonArray product_array = resp.get_array("products");

    if (!product_array.isEmpty())
    {
        int size = product_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = product_array.at(i);

            if (value.isObject())
            {
                QJsonObject product_object = value.toObject();
                ProvideProduct product;
                product.setSp_id(product_object.value("sp_id").toString());
                product.setSp_name(product_object.value("sp_name").toString());
                product.setPp_id(product_object.value("pp_id").toString());
                product.setPp_name(product_object.value("pp_name").toString());
                product.setPp_price(product_object.value("pp_price").toInt());
                product.setPp_desc(product_object.value("pp_desc").toString());
                products.push_back(product);
            }
        }
    }

    refresh_page();
    show_product();
}

/**
* @functionName  show_product
* @Description   show product information in table widget.
* @author        luxijia
* @date          2018-7-10
*/
void ProvideProductWidget::show_product()
{
    int size = products.size();
    this->ui->tableWidget->clearContents();

    for (int i = 0; i < size; i++)
    {
        this->ui->tableWidget->setItem(i, 0, new QTableWidgetItem(products[i].getSp_name()));
        this->ui->tableWidget->setItem(i, 1, new QTableWidgetItem(products[i].getPp_name()));
        this->ui->tableWidget->setItem(i, 2, new QTableWidgetItem(products[i].getPp_id()));
        this->ui->tableWidget->setItem(i, 3, new QTableWidgetItem(QString("%1").arg(products[i].getPp_price())));
        this->ui->tableWidget->setItem(i, 4, new QTableWidgetItem(products[i].getPp_desc()));
    }
}

/**
* @functionName  on_btn_delete_supplier_clicked
* @Description   a slot function that delete selected product
*                and send request.
* @author        luxijia
* @date          2018-7-11
*/
void ProvideProductWidget::on_btn_delete_product_clicked()
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();

    if (0 == count)
        return;

    int flag = MsgBox::question(this, "注意", "是否确认删除供应商品,此操作无法撤销!");

    if (flag == MsgBox::NO)
        return;

    Request req;
    req.set_module("provide_product");
    req.set_func("delete_list");

    //get remove supplier id
    QJsonArray supplier_id;
    QJsonArray product_id;
    int row = -1;

    for (int i = 0; i < count; i++)
    {
        if (row != this->ui->tableWidget->row(items.at(i)))
        {
            row = this->ui->tableWidget->row(items.at(i));
            supplier_id.append(products[row].getSp_id());
            product_id.append(products[row].getPp_id());
        }
    }

    req.put("supplier_id", supplier_id);
    req.put("product_id", product_id);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_delete_product(Response)));
}

/**
* @functionName  recv_delete_product
* @Description   a slot function that receive delete provid product request's respone,
*                show whether delete success, and close conncection.
* @author        luxijia
* @date          2018-7-11
* @parameter     resp network response
*/
void ProvideProductWidget::recv_delete_product(Response resp)
{
    if ("provide_product" != resp.get_module() || "delete_list" != resp.get_func())
        return;

    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_search_product(Response)));

    if (DELETE_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "删除供应商品列表!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "发送参数出错!");
        return;
    }

    search_product();
}

/**
* @functionName  change_product_info
* @Description   a slot function that send signal with argument supplier to change product inforamtion dialog
*                after triggered change supplier action.
* @author        luxijia
* @date          2018-7-11
*/
void ProvideProductWidget::change_product_info()
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int row = this->ui->tableWidget->row(items.at(0));

    emit send_change_product(products[row]);
}
