#include "change_provide_product_dialog.h"
#include "ui_change_provide_product_dialog.h"

/**
* @functionName  ChangeProvideProductDialog
* @Description   the constructor taht initial class ChangeProvideProductDialog.
* @author        luxijia
* @date          2018-7-11
*/
ChangeProvideProductDialog::ChangeProvideProductDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChangeProvideProductDialog)
{
    ui->setupUi(this);
    this->setModal(true);

    waiting = new WaitingSpinnerWidget(this);

    //set price line edit only input number
    price_validator = new QDoubleValidator();
    ui->ledit_product_price->setValidator(price_validator);

    //set tab order
    QWidget::setTabOrder(ui->ledit_supplier_name, ui->ledit_product_name);
    QWidget::setTabOrder(ui->ledit_product_name, ui->ledit_product_code);
    QWidget::setTabOrder(ui->ledit_product_code, ui->ledit_product_price);
    QWidget::setTabOrder(ui->ledit_product_price, ui->ledit_product_desc);
    QWidget::setTabOrder(ui->ledit_product_desc, ui->btn_save);
    QWidget::setTabOrder(ui->btn_save, ui->btn_cancel);
    QWidget::setTabOrder(ui->btn_cancel, ui->btnMenu_Close);

    //set no border
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);


    //connect cancel button clicked signal with close menu button clicked signal
    connect(ui->btn_cancel, SIGNAL(clicked()), ui->btnMenu_Close, SIGNAL(clicked()));


    // set style
    ui->ledit_product_code->setProperty("type", "input");
    ui->ledit_product_desc->setProperty("type", "input");
    ui->ledit_product_name->setProperty("type", "input");
    ui->ledit_product_price->setProperty("type", "input");
    ui->ledit_supplier_name->setProperty("type", "input");

    ui->btn_cancel->setProperty("btn_color", "red");
    ui->btn_save->setProperty("btn_color", "green");
}

/**
* @functionName  ChangeProvideProductDialog
* @Description   the constructor taht release class ChangeProvideProductDialog resource.
* @author        luxijia
* @date          2018-7-11
*/
ChangeProvideProductDialog::~ChangeProvideProductDialog()
{
    delete ui;
    delete price_validator;
    delete waiting;
}

/**
* @functionName  get_supplier
* @Description   a slot function get supplier information from supplier widget.
* @author        luxijia
* @date          2018-7-10
* @parameter     send_supplier supplier onject that store supplier information
*/
void ChangeProvideProductDialog::get_product(const ProvideProduct &send_product)
{
    product = send_product;

    this->ui->ledit_supplier_name->setText(product.getSp_name());
    this->ui->ledit_product_name->setText(product.getPp_name());
    this->ui->ledit_product_code->setText(product.getPp_id());
    this->ui->ledit_product_price->setText(QString("%1").arg(product.getPp_price()));
    this->ui->ledit_product_desc->setText(product.getPp_desc());

    this->ui->ledit_supplier_name->setDisabled(true);
    this->show();
}

/**
* @functionName  on_btnMenu_Close_clicked
* @Description   a slot funtion that close change provide product information dialog
*                that judge supplier information whether change after clicked menu button.
*                if change then show message wheher give save.
* @author        luxijia
* @date          2018-7-11
*/
void ChangeProvideProductDialog::on_btnMenu_Close_clicked()
{
    if (this->ui->ledit_product_name->text() != product.getPp_name() || this->ui->ledit_product_code->text() != product.getPp_id() ||
            this->ui->ledit_product_price->text().toDouble() != product.getPp_price() || this->ui->ledit_product_desc->text() != product.getPp_desc())
    {
        int flag = MsgBox::question(this, "退出", "供应商品信息已更改，是否放弃保存？");

        if (MsgBox::YES == flag)
            this->close();

        return;
    }

    this->close();
}

/**
* @functionName  on_btn_save_clicked
* @Description   a slot funtion that send change provide product information request to server.
*                after clicked save button.
* @author        luxijia
* @date          2018-7-10
*/
void ChangeProvideProductDialog::on_btn_save_clicked()
{
    Request req;
    QJsonArray product_array;

    req.set_module("provide_product");
    req.set_func("change");

    if (this->ui->ledit_product_name->text() == product.getPp_name() && this->ui->ledit_product_code->text() == product.getPp_id() &&
            this->ui->ledit_product_price->text().toDouble() == product.getPp_price() && this->ui->ledit_product_desc->text() == product.getPp_desc())
    {
        MsgBox::information(this, "保存", "保存供应商品信息成功");
        this->close();
        return;
    }

    QJsonObject product_object;
    product_object.insert("code", this->ui->ledit_product_code->text());
    product_object.insert("name", this->ui->ledit_product_name->text());
    product_object.insert("price", this->ui->ledit_product_price->text().toDouble());
    product_object.insert("description", this->ui->ledit_product_desc->text());
    product_object.insert("sp_id", product.getSp_id());
    product_array.append(product_object);

    req.put("products", product_array);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_save_information(Response)));
}

/**
* @functionName  recv_save_information
* @Description   a slot function that receive change provide product information request's respone,
*                show whether change success, and close conncection.
* @author        luxijia
* @date          2018-7-10
* @parameter     resp network response
*/
void ChangeProvideProductDialog::recv_save_information(Response resp)
{
    if ("provide_product" != resp.get_module() || "change" != resp.get_func())
        return;

    //close connection
    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_save_information(Response)));

    if (CHANGE_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "修改供应商品信息失败!");
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "参数出错!");
        return;
    }

    MsgBox::information(this, "修改", "修改供应商品信息成功");

    emit change_success();
    this->close();
}
