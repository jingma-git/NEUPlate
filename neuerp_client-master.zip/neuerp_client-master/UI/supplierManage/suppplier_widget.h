#ifndef SUPPLIER_WIDGET_H
#define SUPPLIER_WIDGET_H

#include <QWidget>
#include <QJsonArray>
#include <QJsonObject>
#include "add_supplier_dialog.h"
#include "change_supplier_info_dialog.h"
#include "change_product_info_dialog.h"
#include "Network/Body/response.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Entity/supplier.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class SupplierWidget;
}

class SupplierWidget : public QWidget
{
    Q_OBJECT

public:
    explicit SupplierWidget(QWidget *parent = 0);
    ~SupplierWidget();
    void init_supplier();

signals:
    void send_supplier_to_change_supplier(const Supplier&);
    void send_supplier_to_change_product(const Supplier&);

private slots:

    void change_page(int new_index);
    void last_page();
    void next_page();
    void right_menu_action(const QPoint&);
    void change_supplier_info();
    void change_product_info();
    void refresh_supplier();

    void recv_search_supplier(Response);
    void recv_remove_supplier(Response);
    void recv_delete_supplier(Response);
    void recv_renew_supplier(Response);

    void on_btn_add_supplier_clicked();
    void on_btn_search_clicked();
    void on_btn_remove_supplier_clicked();
    void on_btn_delete_supplier_clicked();
    void on_btn_renew_clicked();

private:
    Ui::SupplierWidget *ui;
    AddSupplierDialog *add_supplier;
    ChangeSupplierInfoDialog *change_supplier;
    ChangeProductInfoDialog *change_product;
    std::vector<Supplier> suppliers;
    QMenu *right_menu;
    QAction *edit_supplier;
    QAction *edit_provide_product;
    QAction *remove_supplier;
    QAction *delete_supplier;
    QAction *renew_supplier;
    WaitingSpinnerWidget *waiting;
    int page;
    int item;
    int current_page;
    bool inited;

    void refresh_page();
    void search_supplier();
    void show_supplier();
    void create_menu();
};

#endif // SUPPLIER_WIDGET_H
