#ifndef CHANGE_PRODUCT_INFO_DIALOG_H
#define CHANGE_PRODUCT_INFO_DIALOG_H

#include <QDialog>
#include <UI/msgbox.h>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QJsonArray>
#include "Network/Body/response.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Entity/supplier.h"
#include "Entity/provide_product.h"
#include "status_code.h"
#include "UI/iconhelper.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class ChangeProductInfoDialog;
}

class ChangeProductInfoDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ChangeProductInfoDialog(QWidget *parent = 0);
    ~ChangeProductInfoDialog();

private slots:
    void get_supplier(const Supplier&);
    void change_information(int, int);

    void recv_provide_product(Response);
    void recv_add_product(Response);
    void recv_delete_product(Response);
    void recv_change_product(Response);

    void on_btnMenu_Close_clicked();
    void on_btn_edit_clicked();
    void on_btn_add_clicked();
    void on_btn_cancel_clicked();
    void on_btn_delete_clicked();
    void on_btn_save_clicked();

private:
    Ui::ChangeProductInfoDialog *ui;
    Supplier supplier;
    std::vector<ProvideProduct> products;
    std::vector<int> change_line;
    std::vector<ProvideProduct> delete_produts;
    QMutex mutex;
    QDoubleValidator *price_validator;
    WaitingSpinnerWidget *waiting;

    void search_provide_product();
    void show_provide_product();
    void refresh_change_lien(int row);
    void send_add_product();
    void send_delete_product();
    void send_change_product();
    void in_edit();
    void exit_edit();
    QModelIndexList deleteRepeatList(QModelIndexList index_list);
};

#endif // CHANGE_PRODUCT_INFO_DIALOG_H
