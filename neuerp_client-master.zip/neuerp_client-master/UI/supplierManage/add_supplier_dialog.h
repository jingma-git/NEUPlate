#ifndef ADD_SUPPLIER_DIALOG_H
#define ADD_SUPPLIER_DIALOG_H

#include <QDialog>
#include <UI/msgbox.h>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QJsonArray>
#include <ActiveQt/QAxObject>
#include <QFileDialog>
#include <QVariant>
#include <QRegExp>
#include "Network/Body/response.h"
#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "status_code.h"
#include "UI/iconhelper.h"
#include "UI/waitingspinnerwidget.h"

namespace Ui {
class AddSupplierDialog;
}

class AddSupplierDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddSupplierDialog(QWidget *parent = 0);
    ~AddSupplierDialog();

signals:
    void add_success();

private slots:
    void recv_add_supplier(Response);

    void on_btn_commit_clicked();
    void on_btn_add_clicked();
    void on_btn_delete_clicked();
    void on_btnMenu_Close_clicked();
    void on_btn_import_clicked();

private:
    Ui::AddSupplierDialog *ui;
    WaitingSpinnerWidget *waiting;

    void remove_content();
    QModelIndexList deleteRepeatList(QModelIndexList index_list);
    void read_file(const QString &file_path);
};

#endif // ADD_SUPPLIER_DIALOG_H
