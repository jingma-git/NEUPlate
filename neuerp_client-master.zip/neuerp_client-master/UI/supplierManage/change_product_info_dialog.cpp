#include "change_product_info_dialog.h"
#include "ui_change_product_info_dialog.h"

/**
* @functionName  ChangeProductInfoDialog
* @Description   the constructor taht initial class ChangeProductInfoDialog.
* @author        luxijia
* @date          2018-7-10
*/
ChangeProductInfoDialog::ChangeProductInfoDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ChangeProductInfoDialog)
{
    ui->setupUi(this);
    this->setModal(true);

    waiting = new WaitingSpinnerWidget(this);

    //set price line edit only input number
    price_validator = new QDoubleValidator();
    price_validator->setBottom(0.0);
    ui->ledit_proudct_price->setValidator(price_validator);

    //set tab order
    QWidget::setTabOrder(ui->ledit_product_name, ui->ledit_product_code);
    QWidget::setTabOrder(ui->ledit_product_code, ui->ledit_proudct_price);
    QWidget::setTabOrder(ui->ledit_proudct_price, ui->ledit_desc);
    QWidget::setTabOrder(ui->ledit_desc, ui->btn_save);
    QWidget::setTabOrder(ui->btn_save, ui->btn_cancel);
    QWidget::setTabOrder(ui->btn_cancel, ui->btnMenu_Close);

    //set no border
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    //set table widget style
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);

    //connect table widget change with
    connect(ui->tableWidget, SIGNAL(cellChanged(int,int)), this, SLOT(change_information(int,int)));

    // set style
    ui->ledit_contact->setProperty("type", "input");
    ui->ledit_region->setProperty("type", "input");
    ui->ledit_supplier_name->setProperty("type", "input");
    ui->ledit_telephone->setProperty("type", "input");
    ui->ledit_product_code->setProperty("type", "input");
    ui->ledit_desc->setProperty("type", "input");
    ui->ledit_product_name->setProperty("type", "input");
    ui->ledit_proudct_price->setProperty("type", "input");
    ui->btn_add->setProperty("btn_color", "green");
    ui->btn_cancel->setProperty("btn_color", "red");
    ui->btn_delete->setProperty("btn_color", "red");
    ui->btn_edit->setProperty("btn_color", "green");
    ui->btn_save->setProperty("btn_color", "green");
}

/**
* @functionName  ChangeProductInfoDialog
* @Description   the constructor taht release class ChangeProductInfoDialog resource.
* @author        luxijia
* @date          2018-7-10
*/
ChangeProductInfoDialog::~ChangeProductInfoDialog()
{
    delete ui;
    delete price_validator;
    delete waiting;
}

/**
* @functionName  get_supplier
* @Description   a slot function get supplier information from supplier widget.
* @author        luxijia
* @date          2018-7-11
* @parameter     send_supplier supplier onject that store supplier information
*/
void ChangeProductInfoDialog::get_supplier(const Supplier &send_supplier)
{
    supplier = send_supplier;

    this->ui->ledit_supplier_name->setText(supplier.getSp_name());
    this->ui->ledit_contact->setText(supplier.getContact());
    this->ui->ledit_region->setText(supplier.getSp_region());
    this->ui->ledit_telephone->setText(supplier.getSp_phone());

    if (0 == supplier.getSp_state())
        this->ui->rbtn_stop->click();
    else
        this->ui->rbtn_support->click();

    search_provide_product();

    //set line eidt disable
    this->ui->ledit_supplier_name->setDisabled(true);
    this->ui->ledit_region->setDisabled(true);
    this->ui->ledit_contact->setDisabled(true);
    this->ui->ledit_telephone->setDisabled(true);
    this->ui->rbtn_stop->setDisabled(true);
    this->ui->rbtn_support->setDisabled(true);

    exit_edit();

    this->show();
}

/**
* @functionName  in_deit
* @Description   set input line edit enabled and add/delete button show.
* @author        luxijia
* @date          2018-7-11
*/
void ChangeProductInfoDialog::in_edit()
{
    this->ui->ledit_product_name->setEnabled(true);
    this->ui->ledit_product_code->setEnabled(true);
    this->ui->ledit_proudct_price->setEnabled(true);
    this->ui->ledit_desc->setEnabled(true);

    //hiden save button and cancel button
    ui->tableWidget->setEditTriggers(QAbstractItemView::AllEditTriggers);
    this->ui->btn_save->show();
    this->ui->btn_cancel->show();
    this->ui->btn_add->show();
    this->ui->btn_delete->show();
    this->ui->btn_edit->hide();
}

/**
* @functionName  in_deit
* @Description   set input line edit disabled and add/delete button hiden.
* @author        luxijia
* @date          2018-7-11
*/
void ChangeProductInfoDialog::exit_edit()
{
    this->ui->ledit_product_name->setDisabled(true);
    this->ui->ledit_product_code->setDisabled(true);
    this->ui->ledit_proudct_price->setDisabled(true);
    this->ui->ledit_desc->setDisabled(true);

    //hiden save button and cancel button
    this->ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    this->ui->btn_save->hide();
    this->ui->btn_cancel->hide();
    this->ui->btn_add->hide();
    this->ui->btn_delete->hide();
    this->ui->btn_edit->show();
}

/**
* @functionName  on_btnMenu_Close_clicked
* @Description   a slot funtion that close change provide poduct information dialog
*                that judge provide product whether change after clicked menu button.
*                if change then show message wheher give save.
* @author        luxijia
* @date          2018-7-10
*/
void ChangeProductInfoDialog::on_btnMenu_Close_clicked()
{
    if (change_line.size() != 0 || delete_produts.size() != 0)
    {
        int flag = MsgBox::question(this, "退出", "供应商品信息已更改，是否放弃保存？");

        if (MsgBox::YES == flag)
        {
            change_line.clear();
            delete_produts.clear();
            products.clear();

            this->close();
        }

        return;
    }

    this->close();
}

/**
* @functionName  on_btn_cancel_clicked
* @Description   a slot funtion that exit edit model and
*                quest whether give save.
* @author        luxijia
* @date          2018-7-10
*/
void ChangeProductInfoDialog::on_btn_cancel_clicked()
{
    int product_size = products.size();
    int row = this->ui->tableWidget->rowCount();
    int change_size = change_line.size();
    int delete_size = delete_produts.size();

    if (change_size != 0 || delete_size != 0 || row > product_size)
    {
        int flag = MsgBox::question(this, "退出", "供应商品信息已更改，是否放弃保存？");

        if (MsgBox::YES == flag)
        {
            for (int i = 0; i < delete_size; i++)
                products.push_back(delete_produts[i]);

            change_line.clear();
            delete_produts.clear();

            exit_edit();
            show_provide_product();
        }

        return;
    }

    exit_edit();
    show_provide_product();
}

/**
* @functionName  search_provide_product
* @Description   send search provide product request to server.
* @author        luxijia
* @date          2018-7-10
*/
void ChangeProductInfoDialog::search_provide_product()
{
    Request req;
    req.set_module("provide_product");
    req.set_func("search_provide_product");

    req.put("sp_id", supplier.getSp_id());

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_provide_product(Response)));
}

/**
* @functionName  recv_provide_product
* @Description   a slot function that receive search provide product request's respone,
*                show whether change success, and close conncection.
* @author        luxijia
* @date          2018-7-10
* @parameter     resp network response
*/
void ChangeProductInfoDialog::recv_provide_product(Response resp)
{
    if ("provide_product" != resp.get_module() || "search_provide_product" != resp.get_func())
        return;

    //close connection
    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_provide_product(Response)));

    if (EMPTY_QUERY == resp.get_status_code())
    {
        return;
    }
    else if (QUERY_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "查询失败!");
        this->close();
        return;
    }
    else if (ERROR_PARAMS == resp.get_status_code())
    {
        MsgBox::error(this, "失败", "查询参数出错!");
        this->close();
        return;
    }

    products.clear();

    QJsonArray poduct_array = resp.get_array("provide_product");

    if (!poduct_array.isEmpty())
    {
        int size = poduct_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = poduct_array.at(i);

            if (value.isObject())
            {
                QJsonObject product_object = value.toObject();
                ProvideProduct product;
                product.setSp_id(product_object.value("sp_id").toString());
                product.setSp_name(product_object.value("sp_name").toString());
                product.setPp_id(product_object.value("pp_id").toString());
                product.setPp_name(product_object.value("pp_name").toString());
                product.setPp_price(product_object.value("pp_price").toDouble());
                product.setPp_desc(product_object.value("pp_desc").toString());
                products.push_back(product);
            }
        }
    }

    show_provide_product();
}

/**
* @functionName  show_provide_product
* @Description   show provide product in table widget.
* @author        luxijia
* @date          2018-7-11
*/
void ChangeProductInfoDialog::show_provide_product()
{
    disconnect(ui->tableWidget, SIGNAL(cellChanged(int,int)), this, SLOT(change_information(int,int)));
    int row_count = ui->tableWidget->rowCount();

    for (int i = row_count - 1; i > -1; i--)
        this->ui->tableWidget->removeRow(i);

    int size = products.size();

    for (int j = 0; j < size; j++)
    {
        int row = this->ui->tableWidget->rowCount();
        this->ui->tableWidget->insertRow(row);

        this->ui->tableWidget->setItem(row, 0, new QTableWidgetItem(products[j].getPp_name()));
        this->ui->tableWidget->setItem(row, 1, new QTableWidgetItem(products[j].getPp_id()));
        this->ui->tableWidget->setItem(row, 2, new QTableWidgetItem(QString("%1").arg(products[j].getPp_price())));
        this->ui->tableWidget->setItem(row, 3, new QTableWidgetItem(products[j].getPp_desc()));
//        this->ui->tableWidget->item(row, 1)->setFlags(Qt::NoItemFlags);
    }

    connect(ui->tableWidget, SIGNAL(cellChanged(int,int)), this, SLOT(change_information(int,int)));
}

/**
* @functionName  on_btnMenu_Close_clicked
* @Description   a slot funtion that open edit model to edit provide product
*                after clicked menu button.
* @author        luxijia
* @date          2018-7-10
*/
void ChangeProductInfoDialog::on_btn_edit_clicked()
{
    in_edit();
}

/**
* @functionName  on_btn_add_clicked
* @Description   a slot funtion that add a item in table widget
*                after clicked add button.
* @author        luxijia
* @date          2018-7-11
*/
void ChangeProductInfoDialog::on_btn_add_clicked()
{

    if (this->ui->ledit_product_name->text().isEmpty() || this->ui->ledit_product_code->text().isEmpty() ||
            this->ui->ledit_proudct_price->text().isEmpty() || this->ui->ledit_desc->text().isEmpty())
    {
        MsgBox::warming(this, "警告", "商品信息未填写完全");
        return;
    }

    int row = this->ui->tableWidget->rowCount();
    this->ui->tableWidget->insertRow(row);

    this->ui->tableWidget->setItem(row, 0, new QTableWidgetItem(this->ui->ledit_product_name->text()));
    this->ui->tableWidget->setItem(row, 1, new QTableWidgetItem(this->ui->ledit_product_code->text()));
    this->ui->tableWidget->setItem(row, 2, new QTableWidgetItem(this->ui->ledit_proudct_price->text()));
    this->ui->tableWidget->setItem(row, 3, new QTableWidgetItem(this->ui->ledit_desc->text()));

    this->ui->ledit_product_name->clear();
    this->ui->ledit_product_code->clear();
    this->ui->ledit_proudct_price->clear();
    this->ui->ledit_desc->clear();
}

/**
* @functionName  on_btn_delete_clicked
* @Description   a slot funtion that delete a item in table widget
*                after clicked delete button.
* @author        luxijia
* @date          2018-7-10
*/
void ChangeProductInfoDialog::on_btn_delete_clicked()
{
    QModelIndexList selected = this->ui->tableWidget->selectionModel()->selectedIndexes();

    while (!selected.isEmpty())
    {
        QModelIndexList index_list = deleteRepeatList(selected);
        QModelIndex index = index_list.first();

        //删除一行
        this->ui->tableWidget->removeRow(index.row());

        //若删除的是本身有的供应商品则记录
        int size = products.size();

        if (index.row() < size)
        {
            int line = index.row();

            ProvideProduct delete_product = products[line];
            delete_produts.push_back(delete_product);

            std::vector<ProvideProduct>::iterator it;

            for (it = products.begin(); it != products.end();)
            {
                if ((*it).getPp_id() == delete_product.getPp_id()
                        && (*it).getSp_id() == delete_product.getSp_id())
                    it = products.erase(it);
                else
                    ++it;
            }
            refresh_change_lien(line);
        }

        selected = this->ui->tableWidget->selectionModel()->selectedIndexes();
    }
}

/**
* @functionName  deleteRepeatList
* @Description   copy old table widget select model index list
*                to a new model index list to resort table line
*                and avoid repeat delete.
* @author        luxijia
* @date          2018-7-11
* @parameter     index_list old model index list
* @return        new_index_list new model index list that no repeat line.
*/
QModelIndexList ChangeProductInfoDialog::deleteRepeatList(QModelIndexList index_list)
{
    QModelIndex index, new_index;
    QModelIndexList new_index_list;

    foreach (index, index_list)
    {
        if (new_index.row() != index.row())
        {
            new_index = index;
            new_index_list.append(new_index);
        }
    }

    return new_index_list;
}

/**
* @functionName  refresh_change_lien
* @Description   refresh change line information if row lese then products number
* @author        luxijia
* @date          2018-7-11
* @parameter     row delete row number
*/
void ChangeProductInfoDialog::refresh_change_lien(int row)
{
    std::vector<int>::iterator it;

    for (it = change_line.begin(); it != change_line.end();)
    {
        if (*it == row)
            it = change_line.erase(it);
        else if (*it > row)
            (*it) = (*it) - 1;
        else
            ++it;
    }
}

/**
* @functionName  change_information
* @Description   a slot funtion that send record change table postion
*                and add into change line after change product has information.
* @author        luxijia
* @date          2018-7-10
*/
void ChangeProductInfoDialog::change_information(int px, int py)
{
    int product_size = products.size();
    int change_size = change_line.size();

    qDebug() << product_size << change_size << px;

    for (int i = 0; i < change_size; i++)
    {
        if (change_line[i] == px)
            return;
    }

    if (px < product_size)
        change_line.push_back(px);
}


/**
* @functionName  on_btn_save_clicked
* @Description   a slot funtion that send add ,change, delete products request
*                to server after clicked svae button.
* @author        luxijia
* @date          2018-7-10
*/
void ChangeProductInfoDialog::on_btn_save_clicked()
{
    int row = this->ui->tableWidget->rowCount();
    int column = this->ui->tableWidget->columnCount();
    int count = 0;

    for (int i = 0; i < row; i++)
        for (int j = 0; j < column; j++)
            if (this->ui->tableWidget->item(i, j) == NULL || this->ui->tableWidget->item(i, j)->text() == "")
                count++;

    if (count > 0)
    {
        MsgBox::warming(this, "警告", "供应商品有信息未填写!");
        return;
    }

    QMutexLocker lock(&mutex);

    send_add_product();
    send_change_product();
    send_delete_product();

    exit_edit();
    delete_produts.clear();
    change_line.clear();
}

/**
* @functionName  send_add_product
* @Description   send add product request to server.
* @author        luxijia
* @date          2018-7-11
* @parameter     resp network response
*/
void ChangeProductInfoDialog::send_add_product()
{
    int size = products.size();
    int row = this->ui->tableWidget->rowCount();
    int column = this->ui->tableWidget->columnCount();

    QJsonArray product_array;

    for (int i = size; i < row; i++)
    {
        QJsonObject product_object;
        ProvideProduct product;
        for (int j = 0; j < column; j++)
        {
            if (this->ui->tableWidget->item(i, j) != NULL)
            {
                switch (j)
                {
                case 0:
                    product_object.insert("name", this->ui->tableWidget->item(i, j)->text());
                    product.setPp_name(this->ui->tableWidget->item(i, j)->text());
                    break;
                case 1:
                    product_object.insert("code", this->ui->tableWidget->item(i, j)->text());
                    product.setPp_id(this->ui->tableWidget->item(i, j)->text());
                    break;
                case 2:
                    product_object.insert("price", this->ui->tableWidget->item(i, j)->text().toDouble());
                    product.setPp_price(this->ui->tableWidget->item(i, j)->text().toDouble());
                    break;
                 case 3:
                    product_object.insert("description", this->ui->tableWidget->item(i, j)->text());
                    product.setPp_desc(this->ui->tableWidget->item(i, j)->text());
                default:
                    break;
                }
            }
        }
        products.push_back(product);
        product_array.append(product_object);
    }

    Request req;
    req.set_module("provide_product");
    req.set_func("add_product");
    req.put("products", product_array);
    req.put("sp_id", supplier.getSp_id());

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_add_product(Response)));
}

/**
* @functionName  recv_add_peoduct
* @Description   a slot function that receive add product request's respone,
*                show whether add success, and close conncection.
* @author        luxijia
* @date          2018-7-9
* @parameter     resp network response
*/
void ChangeProductInfoDialog::recv_add_product(Response resp)
{
    if ("provide_product" != resp.get_module() || "add_product" != resp.get_func())
        return;

    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_add_product(Response)));

    if (ADD_ERROR == resp.get_status_code())
        MsgBox::error(this, "错误", "添加失败!");
}

/**
* @functionName  send_change_product
* @Description   send add product request to server.
* @author        luxijia
* @date          2018-7-11
* @parameter     resp network response
*/
void ChangeProductInfoDialog::send_change_product()
{
    int size = change_line.size();

    if (0 == size)
        return;

    QJsonArray product_array;

    int column = this->ui->tableWidget->columnCount();

    for (int i = 0; i < size; i++)
    {
        QJsonObject product;
        for (int j = 0; j < column; j++)
        {
            if (this->ui->tableWidget->item(change_line[i], j)->text() != "")
            {
                switch (j)
                {
                case 0:
                    product.insert("name", this->ui->tableWidget->item(i, j)->text());
                    break;
                case 1:
                    product.insert("code", this->ui->tableWidget->item(i, j)->text());
                    break;
                case 2:
                    product.insert("price", this->ui->tableWidget->item(i, j)->text().toDouble());
                    break;
                 case 3:
                    product.insert("description", this->ui->tableWidget->item(i, j)->text());
                default:
                    break;
                }
            }
        }
        product.insert("sp_id", products[i].getSp_id());
        product_array.append(product);
    }

    Request req;
    req.set_module("provide_product");
    req.set_func("change");
    req.put("products", product_array);

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_change_product(Response)));
}


/**
* @functionName  recv_add_peoduct
* @Description   a slot function that receive add product request's respone,
*                show whether add success, and close conncection.
* @author        luxijia
* @date          2018-7-9
* @parameter     resp network response
*/
void ChangeProductInfoDialog::recv_change_product(Response resp)
{
    if ("provide_product" != resp.get_module() || "change" != resp.get_func())
        return;

    waiting->start();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_change_product(Response)));

    if (CHANGE_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "错误", "修改商品失败!");
        return;
    }
}

/**
* @functionName  send_delete_product
* @Description   send delete product request to server.
* @author        luxijia
* @date          2018-7-11
* @parameter     resp network response
*/
void ChangeProductInfoDialog::send_delete_product()
{
    int size = delete_produts.size();

    if (0 == size)
        return;

    QJsonArray product_id;

    for (int i = 0; i < size; i++)
        product_id.append(delete_produts[i].getPp_id());

    Request req;
    req.set_module("provide_product");
    req.set_func("delete_product");
    req.put("product_id", product_id);
    req.put("sp_id", supplier.getSp_id());

    auto &client = MainClient::get_instance();
    client.send(req);
    waiting->start();
    connect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_delete_product(Response)));
}

/**
* @functionName  recv_delete_product
* @Description   a slot function that receive delete product request's respone,
*                show whether delete success, and close conncection.
* @author        luxijia
* @date          2018-7-9
* @parameter     resp network response
*/
void ChangeProductInfoDialog::recv_delete_product(Response resp)
{
    if ("provide_product" != resp.get_module() || "delete_product" != resp.get_func())
        return;

    waiting->stop();
    auto &client = MainClient::get_instance();
    disconnect(&client, SIGNAL(notify_resp(Response)), this, SLOT(recv_delete_product(Response)));

    if (DELETE_ERROR == resp.get_status_code())
    {
        MsgBox::error(this, "错误", "删除商品失败!");
        return;
    }
}
