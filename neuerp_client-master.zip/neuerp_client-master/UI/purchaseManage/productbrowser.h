#ifndef PRODUCTBROWSER_H
#define PRODUCTBROWSER_H

#include <QWidget>
#include <QTimer>
#include <QTime>
#include "Entity/product_to_buy.h"
#include "ui/msgbox.h"
#include <QDebug>

namespace Ui {
class ProductBrowser;
}

class ProductBrowser : public QWidget
{
    Q_OBJECT

public:
    explicit ProductBrowser(QWidget *parent = 0);
    ~ProductBrowser();
    void init(const ProductToBuy &p);
    void stop_timer();
    bool has_flash_ended();

signals:
    void addToBuyList(ProductToBuy pro,int buy_amt, int sp_idx);

private slots:
    void change_price(int);
    void addBtnClicked();
    void timeUpdate();


private:
    Ui::ProductBrowser *ui;
    QTimer *timer;
    int timer_cnt = 0;

    ProductToBuy pro;
    QString p_name;
    int cur_sp_idx;
    QString cur_sp_id;
    QString cur_sp_name;
    double pp_price;
    bool has_flash_end=true;
};

#endif // PRODUCTBROWSER_H
