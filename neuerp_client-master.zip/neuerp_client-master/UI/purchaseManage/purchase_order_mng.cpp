#include "purchase_order_mng.h"
#include "ui_purchase_order_mng.h"
#include "usercontroller.h"

PurchaseOrderMng::PurchaseOrderMng(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PurchaseOrderMng)
{
    ui->setupUi(this);
    ui->splitter->setStretchFactor(0,2);
    ui->splitter->setStretchFactor(1,1);
    wait = new WaitingSpinnerWidget(this);

    ui->tableWidgetOrders->setShowGrid(true);
    ui->tableWidgetOrders->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidgetOrders->verticalHeader()->setVisible(false);
    ui->tableWidgetOrders->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidgetOrders->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableWidgetOrders->setRowCount(page_size);


    ui->tableWidgetOrderInfo->setShowGrid(true);
    ui->tableWidgetOrderInfo->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidgetOrderInfo->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidgetOrderInfo->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidgetOrderInfo->verticalHeader()->setVisible(false);
    ui->tableWidgetOrderInfo->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidgetOrderInfo->horizontalHeader()->setSectionsClickable(false);
   // ui->tableWidgetOrderInfo->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableWidgetOrderInfo->setRowCount(100);


    connect(ui->tableWidgetOrders, SIGNAL(currentCellChanged(int,int,int,int)), this, SLOT(changeCurOrder(int)));
   // connect(ui->tableWidgetOrderInfo, SIGNAL(cellClicked(int, int)), this, SLOT(changeCurOrderItem(int,int)));
   // connect(ui->tableWidgetOrderInfo, SIGNAL(cellChanged(int, int)), this, SLOT(changeCurOrderItem(int,int)));
   // connect(ui->tableWidgetOrderInfo, SIGNAL(cellPressed(int, int)), this, SLOT(changeCurOrderItem(int,int)));
    //connect(ui->tableWidgetOrderInfo, SIGNAL(cellActivated(int, int)), this, SLOT(changeCurOrderItem(int,int)));
    connect(ui->tableWidgetOrderInfo, SIGNAL(currentCellChanged(int,int,int,int)), this, SLOT(changeCurOrderItem(int,int)));
    connect(ui->btnLastPage,SIGNAL(clicked()),this,SLOT(last_page()));
    connect(ui->btnNextPage,SIGNAL(clicked()),this,SLOT(next_page()));
    connect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));

    auto &user = UserController::get_instance();
    if(!user.check_access_code("dept_purchase_manager")){
        ui->deleteOrderBtn->hide();
    }
}

PurchaseOrderMng::~PurchaseOrderMng()
{
    delete ui;
}

void PurchaseOrderMng::first_init(){
//    if(inited) return;
//    inited = true;
    ui->radioBtnOnPay->click();
}
void PurchaseOrderMng::query_orders(){
    wait->start();
    qDebug()<<"PurchaseOrderMng::query_orders()";
    Request req;
    req.set_module("purchase_order");

    req.set_func("query_orders_by_state");
    req.put("state",order_state);
    req.put("page",current_page);
    req.put("page_size",page_size);

    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_orders(Response)));
}

void PurchaseOrderMng::query_order_items(){
    wait->start();
    qDebug()<<"PurchaseOrderMng::query_order_items()";
    Request req;
    req.set_module("purchase_order");

    req.set_func("query_order_items");
    req.put("order_id",cur_order.order_id);

    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_order_items(Response)));
}

void PurchaseOrderMng::recv_orders(Response resp){
    wait->stop();
    qDebug()<<"PurchaseOrderMng::recv_orders(Response resp)";
    orders.clear();

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_orders(Response)));

    QJsonArray orderArray = resp.get_array("orders");
    foreach(const QJsonValue &val,orderArray){
        QJsonObject order_obj =val.toObject();
        PurchaseOrder pOrder(order_obj);
        orders.push_back(pOrder);
    }
    max_page=resp.get_int("all_page");
    order_state=resp.get_int("state");
    refresh_page_bar();
    refresh_table_orders();
    changeCurOrder(0);
}

void PurchaseOrderMng::recv_order_items(Response resp){
    wait->stop();
    qDebug()<<"PurchaseOrderMng::recv_order_items(Response resp)";
    cur_order.orderItems.clear();

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_order_items(Response)));

    QJsonArray orderArray = resp.get_array("order_items");
    foreach(const QJsonValue &val,orderArray){
        OrderItem orderItem(val.toObject());
        cur_order.orderItems.push_back(orderItem);
    }
    refresh_order_info();
}

void PurchaseOrderMng::refresh_order_info(){
    qDebug()<<"PurchaseOrderMng::refresh_order_info()";
    ui->tableWidgetOrderInfo->clearContents();
    ui->orderIdLabel->setText(cur_order.order_id);

    //
    std::vector<OrderItem> &orderItems = cur_order.orderItems;
    int size = orderItems.size(); qDebug()<<" int size = orderItems.size(); "<<QString::number(size);
    int total_price = 0;
    QString sp_name;
    for(int i=0; i<size; i++){
        OrderItem &orderItem = orderItems[i];
        sp_name = orderItem.sp_name;
        ui->tableWidgetOrderInfo->setItem(i,0, new QTableWidgetItem(orderItem.product_name));
        qDebug()<<"order_state==PurchaseOrder::WAIT_TO_PAY"<<QString::number(order_state);
        if(order_state==PurchaseOrder::WAIT_TO_PAY){
            QSpinBox *spinBox = new QSpinBox();
            spinBox->setMinimum(1);
            spinBox->setValue(orderItem.amt);
            ui->tableWidgetOrderInfo->setCellWidget(i,1,spinBox);
            connect(spinBox,SIGNAL(valueChanged(int)),this,SLOT(changeBuyAmt(int)));

            CenteredCheckBox *checkBox = new CenteredCheckBox();
            ui->tableWidgetOrderInfo->setCellWidget(i,3,checkBox);
        }else{
            ui->tableWidgetOrderInfo->setItem(i,1,new QTableWidgetItem(QString::number(orderItem.amt)));
        }
        ui->tableWidgetOrderInfo->setItem(i,2, new QTableWidgetItem(QString::number(orderItem.pp_price,'f',2)));
        total_price+=orderItem.pp_price;
    }
    ui->spNameLabel->setText(sp_name);
    ui->totalPriceLabel->setText(QString::number(total_price, 'f', 2));
}

void PurchaseOrderMng::next_page()
{
    qDebug()<<"PurchaseOrderMng::next_page()";
    change_page(current_page-1+1);
}

void PurchaseOrderMng::last_page()
{
    change_page(current_page-1-1);
}
void PurchaseOrderMng::change_page(int new_index){
    qDebug()<<"PurchaseOrderMng::change_page(int new_index)";
    int new_page=new_index + 1;
    current_page=new_page;
    query_orders();
}


void PurchaseOrderMng::refresh_page_bar(){
    disconnect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));
    ui->btnLastPage->setEnabled(!(current_page==1));
    ui->btnNextPage->setEnabled(!(current_page==max_page));
    ui->comboBoxPage->clear();

    for(int i=0;i<max_page;i++){
        ui->comboBoxPage->insertItem(i,QString("第%1页").arg(i+1));
    }
    ui->comboBoxPage->setCurrentIndex(current_page-1);
    connect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));
}

void PurchaseOrderMng::changeBuyAmt(int amt){
  //  qDebug()<<"changeBuyAmt "<<QString::number(amt);
    int size = cur_order.orderItems.size();
   // qDebug()<<"cur_row_order_info-------- "<<QString::number(cur_row_order_info);
    if(cur_row_order_info>=0 && cur_row_order_info<size){
   //     qDebug()<<"cur_row_order_info++++++++ "<<QString::number(cur_row_order_info);
        OrderItem &orderItem = cur_order.orderItems[cur_row_order_info];
        orderItem.amt = amt;
        double total_price = cur_order.total_price();
        ui->totalPriceLabel->setText(QString::number(total_price, 'f', 2));
        orders[cur_row_orders]=cur_order;
    }

}
void PurchaseOrderMng::changeCurOrderItem(int row, int col){
   // qDebug()<<"PurchaseOrderMng::changeCurOrderItem(int row, int col)"
   //        <<QString::number(row)<<","<<QString::number(col);
    cur_row_order_info = row;
}



void PurchaseOrderMng::changeCurOrder(int row){
   qDebug()<<" PurchaseOrderMng::changeCurOrder(int row)"<<QString::number(row);
   int orders_size = orders.size();qDebug()<<"int orders_size = orders.size();"<<QString::number(orders_size);
    if(row>=0 && row<orders_size){
           cur_order = orders[row];
           cur_row_orders = row;
           refresh_order_info();
    }
    if(orders_size==0){
        ui->orderIdLabel->clear();
        ui->spNameLabel->clear();
        ui->totalPriceLabel->clear();
        ui->tableWidgetOrderInfo->clearContents();
    }
}




void PurchaseOrderMng::refresh_table_orders(){
    int size = orders.size();
    ui->tableWidgetOrders->clearContents();

    for(int i=0; i<size; i++){
        PurchaseOrder &pOrder = orders[i];
        ui->tableWidgetOrders->setItem(i,0, new QTableWidgetItem(pOrder.order_id));
        CenteredCheckBox *checkBox = new CenteredCheckBox();
        ui->tableWidgetOrders->setCellWidget(i,1, checkBox);
    }
}


void PurchaseOrderMng::on_payBtn_clicked()
{
    qDebug()<<"PurchaseOrderMng::on_payBtn_clicked";
    QString ord_list = "";
    double sum = 0;
    QJsonArray o_id_array;
    QJsonArray orders_array;
    int i=0;
    for(PurchaseOrder ord:orders){
        CenteredCheckBox *checkBox = (CenteredCheckBox*)ui->tableWidgetOrders->cellWidget(i,1);
        if(checkBox->isChecked()){
            qDebug()<<ord.order_id<<" .... "<<ord.total_price();
            double total_price = ord.total_price();
            sum += total_price;
            o_id_array.append(orders[i].order_id);
            orders_array.append(ord.toJSON());
            ord_list += ord.order_id + " "+QString::number(total_price, 'f', 2)+"\n";
        }
        ++i;
    }
    if(o_id_array.size()==0){
        MsgBox::warming(this,"警告","支付订单不能为空，请先勾选要支付的订单");
        return;
    }

    QString str = "支付订单列表：\n\n" + ord_list + "\n  总共需要支付:"+QString::number(sum, 'f',2)+"元";
    int ans = MsgBox::question(this,"支付",str,"确认支付","不了,谢谢");
    if(ans==MsgBox::NO) return;


    qDebug()<<"PurchaseOrderMng::update_orders_state()";
    Request req;
    req.set_module("purchase_order");

    req.set_func("update_orders_state");
    req.put("state",PurchaseOrder::ON_DELIVER);
    req.put("order_ids",o_id_array);
    req.put("orders",orders_array);
    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_update_orders_state(Response)));
    wait->start();
}

void PurchaseOrderMng::on_confirmBtn_clicked()
{
    wait->start();
    qDebug()<<"PurchaseOrderMng::on_confirmBtn_clicked";
    Request req;
    req.set_module("purchase_order");

    req.set_func("update_order_state");
    req.put("state",PurchaseOrder::CONFIRMED);
    req.put("order_id", cur_order.order_id);
    req.put("order", cur_order.toJSON());
    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_update_order_state(Response)));
}

void PurchaseOrderMng::on_radioBtnOnPay_clicked()
{
    ui->payBtn->setVisible(true);
    ui->deleteOrderItemBtn->setVisible(true);
    ui->deleteOrderBtn->setVisible(true);
    ui->confirmBtn->setVisible(false);
    ui->tableWidgetOrders->showColumn(1);
    ui->tableWidgetOrderInfo->showColumn(3);
    order_state = PurchaseOrder::WAIT_TO_PAY;
    query_orders();
}

void PurchaseOrderMng::on_radioBtnOnDeliver_clicked()
{
    ui->payBtn->setVisible(false);
    ui->deleteOrderBtn->setVisible(false);
    ui->deleteOrderItemBtn->setVisible(false);
    ui->confirmBtn->setVisible(true);
    ui->tableWidgetOrders->hideColumn(1);
    ui->tableWidgetOrderInfo->hideColumn(3);
    order_state = PurchaseOrder::ON_DELIVER;
    query_orders();
}

void PurchaseOrderMng::on_radioBtnConfirmed_clicked()
{
    ui->payBtn->setVisible(false);
    ui->confirmBtn->setVisible(false);
    ui->deleteOrderBtn->setVisible(true);
    ui->deleteOrderItemBtn->setVisible(false);
    ui->tableWidgetOrders->showColumn(1);
    ui->tableWidgetOrderInfo->hideColumn(3);
    order_state = PurchaseOrder::CONFIRMED;
    query_orders();
}

void PurchaseOrderMng::on_deleteOrderBtn_clicked()
{
    QString ord_id_str ="";
    QJsonArray o_id_array;
    int orders_size = orders.size();
    for(int i=0; i<orders_size; i++){
        CenteredCheckBox *checkBox = (CenteredCheckBox*)ui->tableWidgetOrders->cellWidget(i,1);
        if(checkBox->isChecked()){
            o_id_array.append(orders[i].order_id);
            ord_id_str += orders[i].order_id+"\n";
        }
    }

    if(ord_id_str.isEmpty()){
        MsgBox::warming(this,"操作失败","要删除的订单不能为空");
        return;
    }else{
        int ans = MsgBox::question(this,"删除订单","确认要删除以下订单？\n"+ord_id_str,"我意已决","容我再想想...");
        if(ans==MsgBox::NO){
            return;
        }
    }
    delete_orders(o_id_array);
}

void PurchaseOrderMng::delete_orders(QJsonArray& o_id_array){
    Request req;
    req.set_module("purchase_order");

    req.set_func("delete_orders");
    req.put("order_ids",o_id_array);

    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_delete_orders(Response)));
    wait->start();
}

void PurchaseOrderMng::on_deleteOrderItemBtn_clicked()
{
    //qDebug()<<"on_deleteOrderItemBtn_clicked()";
    QJsonArray o_item_id_array;
    std::vector<OrderItem> &orderItems = cur_order.orderItems;

    int size = orderItems.size();

    QString ordItemStr = "";
    for(int i=0; i<size; i++){
        CenteredCheckBox *checkBox = (CenteredCheckBox*)ui->tableWidgetOrderInfo->cellWidget(i,3);
        if(checkBox->isChecked()){
            OrderItem &orderItem = orderItems[i];
            o_item_id_array.append(orderItem.toJSON());
            ordItemStr += orderItem.product_name + " " + orderItem.sp_name+"\n";
        }
    }

    if(ordItemStr.isEmpty()){
        MsgBox::warming(this,"操作失败","要删除的商品不能为空");
        return;
    }

    if(size==1){
        int ans = MsgBox::question(this,"删除","亲，订单中只有一件商品喽，您的订单也会被删除哦\n"
                                   "您确定吗","我意已决","容我再想想...");
        if(ans==MsgBox::YES){
            QJsonArray o_id_array;
            o_id_array.append(cur_order.order_id);
            delete_orders(o_id_array);
        }
        return;
    }


    if(!ordItemStr.isEmpty()){
        int ans = MsgBox::question(this,"删除商品","确认要删除以下商品？\n"+ordItemStr,"我意已决","容我再想想...");
        if(ans==MsgBox::NO){
            return;
        }
    }

    Request req;
    req.set_module("purchase_order");

    req.set_func("delete_order_items");
    req.put("order_items",o_item_id_array);

    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_delete_order_items(Response)));
    wait->start();
}

void PurchaseOrderMng::recv_delete_orders(Response resp){
    wait->stop();

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_delete_orders(Response)));

    int status = resp.get_status_code();
    if(status==SUCCESS){
        MsgBox::success(this,"订单已成功删除","恭喜你，订单已成功删除");
        query_orders();
    }else{
        MsgBox::error(this,"删除订单失败","删除订单失败,请再次尝试");
    }
}

void PurchaseOrderMng::recv_update_orders_state(Response resp){
    wait->stop();

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_update_orders_state(Response)));

    int status = resp.get_status_code();

    if(status==SUCCESS){
        MsgBox::success(this, "支付成功","支付成功");
        query_orders();
    }else{
        MsgBox::error(this,"订单支付失败","订单支付失败,请再次尝试");
    }
}

void PurchaseOrderMng::recv_update_order_state(Response resp){
    wait->stop();

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_update_order_state(Response)));

    int status = resp.get_status_code();

    if(status==SUCCESS){
        MsgBox::success(this, "订单确认成功","已通知商家，订单确认成功");
        query_orders();
    }else{
        MsgBox::error(this,"订单确认失败","订单确认失败,请再次尝试");
    }
}

void PurchaseOrderMng::recv_delete_order_items(Response resp){
    qDebug()<<"PurchaseOrderMng::recv_delete_order_items(Response resp)";
    wait->stop();

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_delete_order_items(Response)));

    int status = resp.get_status_code();

    if(status==SUCCESS){
        MsgBox::success(this, "商品已成功删除","商品已成功删除");
        query_order_items();
    }else{
        MsgBox::error(this,"商品删除失败","商品删除失败,请再次尝试");
    }
}

