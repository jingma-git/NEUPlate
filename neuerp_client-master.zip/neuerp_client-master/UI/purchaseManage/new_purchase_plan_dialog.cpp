#include "new_purchase_plan_dialog.h"
#include "ui_new_purchase_plan_dialog.h"
#include <QDebug>


NewPurchasePlanDialog::NewPurchasePlanDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::NewPurchasePlanDialog)
{
    ui->setupUi(this);
    this->setModal(true);
    this->setWindowTitle("添加采购计划名称");
}

NewPurchasePlanDialog::~NewPurchasePlanDialog()
{
    delete ui;
}
QString NewPurchasePlanDialog::getPlanName(){
    return this->plan_name;
}

void NewPurchasePlanDialog::on_saveBtn_clicked()
{
    //qDebug()<<"NewPurchasePlanDialog::on_saveBtn_clicked()";
    this->plan_name = ui->lineEdit->text();

    if(plan_name.isEmpty()){
        ui->warnLabel->setText(QString::fromUtf8("文件名不能为空,请输入文件名"));
    }else{
        emit send_plan_name(plan_name); // is_new=true
        ui->lineEdit->clear();
        this->close();
    }
}

void NewPurchasePlanDialog::on_cancelBtn_clicked()
{
    ui->lineEdit->clear();
    this->close();
}
