#ifndef EDIT_PURCHASE_PLAN_H
#define EDIT_PURCHASE_PLAN_H
#include <vector>
#include <map>
#include <set>

#include <QWidget>
#include <QDateTime>
#include <QLayout>
#include <QSpinBox>
#include <QMenu>
#include <QTimer>
#include <QProgressBar>

#include "UI/msgbox.h"
#include "UI/waitingspinnerwidget.h"
#include "product_displayer.h"
#include "new_purchase_plan_dialog.h"

#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Network/Body/response.h"

#include "usercontroller.h"
#include "Entity/purchase_plan.h"
#include "Entity/product_to_buy.h"
#include "Entity/planitem.h"
#include "Entity/purchase_order.h"
#include "Entity/order_item.h"
#include "status_code.h"


namespace Ui {
class EditPurchasePlan;
}

class EditPurchasePlan : public QWidget
{
    Q_OBJECT

public:
    explicit EditPurchasePlan(QWidget *parent = 0);
    ~EditPurchasePlan();
    void init_new_plan(QString plan_name);
    void init_old_plan(Purchase_Plan);
    void stopTimer();

signals:
    void editPlanEnd();
    void sendNewOrders(std::vector<PurchaseOrder>);

private slots:
    void recv_plan_name(QString);
    void recv_new_plan(Response resp);
    void recv_plan_items(Response resp);
    void confirm_planItems_saved(Response);
    void recv_update_plan_state(Response);
    void insert_to_plan_list(ProductToBuy pro,int buy_amt, int sp_idx);
    void delete_select_pro(); 
    void changeBuyAmt(int);
    void changeCurRowCol(int, int);
    void save_plan_items();

    void on_tableWidget_customContextMenuRequested(const QPoint &pos);

    void on_savePlanBtn_clicked();

    void on_addNewPlanBtn_clicked();

    void on_exitBtn_clicked();

    void on_generateOrderBtn_clicked();

private:
    Ui::EditPurchasePlan *ui;
    QVBoxLayout *layout;
    ProductDisplayer *displayer;
    QMenu *right_menu;
    NewPurchasePlanDialog *dialog;
    WaitingSpinnerWidget *wait;
    QTimer *timer;
    int cur_row=0, cur_col=0;

    Purchase_Plan plan;
    bool is_plan_saved = false;
    std::vector<PlanItem> planItems;
    int list_len = 0;

    const static int  SpinBox_MIN=1;
    const static int SpinBox_MAX=100000;

    void init_plan_displayer();
    void init_product_displayer();
    int find(QString p_id, QString sp_name);
    void refresh_table();
    void clear_plan_info();

};

#endif // EDIT_PURCHASE_PLAN_H
