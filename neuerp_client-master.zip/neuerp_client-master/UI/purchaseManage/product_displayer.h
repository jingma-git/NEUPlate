#ifndef PRODUCT_DISPLAYER_H
#define PRODUCT_DISPLAYER_H

#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Network/Body/response.h"

#include <QWidget>
#include <QHBoxLayout>
#include <QVector>
#include "productbrowser.h"
#include "Entity/product_to_buy.h"
#include "ui/msgbox.h"
#include "ui/waitingspinnerwidget.h"
#include "status_code.h"

namespace Ui {
class ProductDisplayer;
}

class ProductDisplayer : public QWidget
{
    Q_OBJECT

public:
    explicit ProductDisplayer(QWidget *parent = 0);
    ~ProductDisplayer();
    void init();
    ProductBrowser *browser1;
    ProductBrowser *browser2;
    ProductBrowser *browser3;
    ProductBrowser *browser4;

private slots:
    void query_clicked();
    void query_productsToBuy();
    void recv_productsToBuy(Response);
    void refresh_product_browsers();
    void change_page(int new_index);
    void refresh_page_bar();
    void next_page();
    void last_page();

private:
    Ui::ProductDisplayer *ui;
    QVBoxLayout *layout;
    QVector<ProductBrowser*> proBrowsers;
    QVector<ProductToBuy> prosToBuy;
    WaitingSpinnerWidget *wait;

    QString keyword;
    int current_page=1;
    int max_page=1;
    int page_size=4;
    bool asc_order=true;
};

#endif // PRODUCT_DISPLAYER_H
