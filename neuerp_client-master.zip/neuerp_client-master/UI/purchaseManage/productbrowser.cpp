/**
* @brief         单个商品展示模块
* @author        majing
* @date          2018-07-02
* @modify_author XXXX
* @modify_date   2018-07-02
*/
#include "productbrowser.h"
#include "ui_productbrowser.h"

ProductBrowser::ProductBrowser(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ProductBrowser)
{  
    ui->setupUi(this);
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),this, SLOT(timeUpdate()));

    connect(ui->comboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(change_price(int)));
    connect(ui->addBtn, SIGNAL(clicked()), this, SLOT(addBtnClicked()));
}

void ProductBrowser::timeUpdate()                  // 定时器溢出处理
{
    timer_cnt++;
   // qDebug()<<QString::number(timer_cnt);
   // qDebug()<<"....................................."<<ui->stockLabel->text();
    QTime time = QTime::currentTime();      // 获取当前时间
    if((time.second() % 2) == 0) {
        ui->stockLabel->setStyleSheet("color:white");
        ui->stockLabel->setText("库存为0，需要进货啦");
    }else{
        ui->stockLabel->setStyleSheet("color:#933;");
        ui->stockLabel->setText("库存为0，需要进货啦");
    }
    if(timer_cnt == 50){
        timer_cnt = 0;
        timer->stop();
        has_flash_end=true;
        ui->stockLabel->setStyleSheet("color:#933;");
        ui->stockLabel->setText("库存为0，需要进货啦");
    }

}

void ProductBrowser::stop_timer(){
    timer_cnt =0;
    timer->stop();
}

bool ProductBrowser::has_flash_ended(){
    return has_flash_end;
}

void ProductBrowser::init(const ProductToBuy &p){
    //qDebug()<<"initBrowser "<< p.getName();
    pro=p;
    ui->idLabel->setText(pro.getP_id());
    ui->nameLabel->setText(pro.getName());
   // qDebug()<<"++++++++++++++++++++++++++++++stock amt "<<pro.getStock_amount();
    if(pro.getStock_amount()==0){
       // qDebug()<<"+++++++++++++++++++++++++++++++++++++start timer";
        ui->stockLabel->setText("库存为0，需要进货啦");
        timer->start(250);
        has_flash_end = false;
    }else{
        ui->stockLabel->setStyleSheet("color:white;");
        ui->stockLabel->setText(QString::number(pro.getStock_amount()));
    }


    QPixmap photo;
    qDebug() << pro.getImg();
    photo.loadFromData(QByteArray::fromBase64(pro.getImg().toUtf8()));
    ui->imgLabel->setPixmap(photo);
    ui->imgLabel->show();

    ui->comboBox->clear();
    std::vector<QString> sp_names = pro.get_sp_names();
    int size = sp_names.size();
    for(int i=0; i<size; i++){
        ui->comboBox->insertItem(i, sp_names[i]);
    }

    cur_sp_idx = 0;
    ui->comboBox->setCurrentIndex(cur_sp_idx);
    cur_sp_id = pro.get_sp_ids()[cur_sp_idx];  
}

void ProductBrowser::change_price(int newIdx){
    cur_sp_idx = newIdx;
    double price = pro.get_pp_prices()[cur_sp_idx];
    QString priceStr =QString::number(price,'f', 2)+"元";
    ui->pp_priceLabel->setText(priceStr);
}

void ProductBrowser::addBtnClicked()
{
    qDebug()<<"ProductBrowser::on_addBtn_clicked()";
    if(ui->comboBox->currentText().isEmpty()){
        QString err = "供应商不能为空";
        MsgBox::error(this,err,err);
        return;
    }
    int buy_amt = ui->amtSpinBox->value();
    //qDebug()<<"before emit addToBuyList(pro, buy_amt, cur_sp_idx);";
    emit addToBuyList(pro,buy_amt, cur_sp_idx);
    //qDebug()<<"after emit addToBuyList(pro, buy_amt, cur_sp_idx);";
}

ProductBrowser::~ProductBrowser()
{
    delete ui;
}
