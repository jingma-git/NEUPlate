/**
* @brief         采购计划管理
* @author        majing
* @date          2018-07-01
* @modify_author XXXX
* @modify_date   2018-07-01
*/
#include "purchase_plan_mng.h"
#include "ui_purchase_plan_mng.h"

PurchasePlanMng::PurchasePlanMng(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PurchasePlanMng)
{
    ui->setupUi(this);
    ui->tableWidget->setRowCount(10);
    dialog = new NewPurchasePlanDialog(this);
    wait = new WaitingSpinnerWidget(this);

    connect(dialog,SIGNAL(send_plan_name(QString)), this, SLOT(recv_plan_name(QString)));
    connect(ui->btnQuery,SIGNAL(clicked()),this,SLOT(query_clicked()));
    connect(ui->ledit_keyword,SIGNAL(returnPressed()),ui->btnQuery,SIGNAL(clicked()));
    connect(ui->btnLastPage,SIGNAL(clicked()),this,SLOT(last_page()));
    connect(ui->btnNextPage,SIGNAL(clicked()),this,SLOT(next_page()));
    connect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));

    ui->startDateEdit->setCalendarPopup(true);
    ui->endDateEdit->setCalendarPopup(true);
    ui->startDateEdit->setDate(QDate::currentDate().addDays(-1));
    ui->endDateEdit->setDate(QDate::currentDate().addDays(1));

    ui->btnQuery->setProperty("btn_color", "green");

    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
}

void PurchasePlanMng::first_init(){
    query_clicked();
}

void PurchasePlanMng::query_clicked(){
   //qDebug()<<"query btn clicked";
   if(ui->editRadioBtn->isChecked()){
       editable = true;
   }else{
       editable = false;
   }
   keyword = ui->ledit_keyword->text();
   start_date = ui->startDateEdit->dateTime();
   end_date = ui->endDateEdit->dateTime();  
   if(start_date > end_date){
       MsgBox::error(this,"日期错误","开始日期不能大于结束日期，请重新输入");
       return;
   }
   query_plans();
}

void PurchasePlanMng::query_plans(){
    Request req;
    req.set_module("purchase_plan");

    req.set_func("query");
    req.put("keyword",keyword);


    req.put("start_time", start_date.toString("yyyy-MM-dd hh:mm:ss"));
    req.put("end_time", end_date.toString("yyyy-MM-dd hh:mm:ss"));
    req.put("state",editable);
    req.put("page",current_page);
    req.put("page_size",page_size);

    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_plans(Response)));
    wait->start();

}

void PurchasePlanMng::recv_plans(Response resp){
    if(resp.get_module()!="purchase_plan"||resp.get_func()!="query"){
        return;
    }

    wait->stop();

    plans.clear();

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_plans(Response)));
    if(ILLEGAL_ACCESS == resp.get_status_code()) return;

    if(resp.get_status_code()==SUCCESS){
        QJsonArray plans_json=resp.get_array("plans");
        foreach(const QJsonValue &plan_json, plans_json){
            QJsonObject plan_obj = plan_json.toObject();
            Purchase_Plan plan(plan_obj);
            plans.push_back(plan);
        }

        max_page=resp.get_int("all_page");

        refresh_page_bar();
        refresh_table();
    }else{
       MsgBox::error(this,"查询计划失败","查询计划失败");
    }
}

void PurchasePlanMng::refresh_table(){
    unsigned int plan_len=plans.size();
    QTableWidget &table= *(ui->tableWidget);
    table.clearContents();
    for(unsigned int i=0;i<plan_len;i++){
        Purchase_Plan &p=plans.at(i);

        table.setItem(i,0,new QTableWidgetItem(p.get_plan_id()));
        table.setItem(i,1,new QTableWidgetItem(p.get_name()));
        table.setItem(i,2,new QTableWidgetItem(p.get_date()));

        QString state_string;
        if(p.get_state()==1){
            state_string="未完成";
        }else{
            state_string="已完成";
        }
        table.setItem(i,3,new QTableWidgetItem(state_string));

    }
}

void PurchasePlanMng::change_page(int new_index){
    int new_page=new_index + 1;
    current_page=new_page;
    query_plans();
}

void PurchasePlanMng::next_page()
{
    change_page(current_page-1+1);
}

void PurchasePlanMng::last_page()
{
    change_page(current_page-1-1);
}

void PurchasePlanMng::refresh_page_bar(){
    disconnect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));
    ui->btnLastPage->setEnabled(!(current_page==1));
    ui->btnNextPage->setEnabled(!(current_page==max_page));
    ui->comboBoxPage->clear();

    for(int i=0;i<max_page;i++){
        ui->comboBoxPage->insertItem(i,QString("第%1页").arg(i+1));
    }
    ui->comboBoxPage->setCurrentIndex(current_page-1);
    connect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));
}
void PurchasePlanMng::recv_plan_name(QString plan_name){
    //qDebug()<<"PurchasePlanMng::recv_plan_name(QString file_name) "<<plan_name;
    emit sendNewPlan(plan_name);
}

void PurchasePlanMng::on_btnAdd_clicked()
{
    //qDebug()<<"PurchasePlanMng::on_btnAdd_clicked()";
    dialog->setModal(true);
    dialog->show();
}

PurchasePlanMng::~PurchasePlanMng()
{
    delete ui;
    delete dialog;
}

void PurchasePlanMng::on_editRadioBtn_clicked()
{
    ui->editPlanBtn->setText("编辑计划");
    query_clicked();
}

void PurchasePlanMng::on_finishRadioBtn_clicked()
{
    ui->editPlanBtn->setText("计划详情");
    query_clicked();
}

void PurchasePlanMng::on_editPlanBtn_clicked()
{
  // qDebug()<<"PurchasePlanMng::on_editPlanBtn_clicked()";
   QList<QTableWidgetItem*> items = ui->tableWidget->selectedItems();
   if(!items.isEmpty()){
       int cur_row = ui->tableWidget->currentRow();
       Purchase_Plan &plan=plans.at(cur_row);
       emit sendOldPlan(plan);
   }else{
       MsgBox::error(this,"请先选择计划","请先选择计划");
   }
}
