#include "purchase_manage.h"
#include "ui_purchase_manage.h"
#include "UI/iconhelper.h"

PurchaseManage::PurchaseManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PurchaseManage)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);


    purchase_order_mng = new PurchaseOrderMng();
    purchase_plan_mng = new PurchasePlanMng();
    purchase_plan_edit = new EditPurchasePlan();

    connect(purchase_plan_mng, SIGNAL(sendNewPlan(QString)), this, SLOT(receive_new_plan(QString)));
    connect(purchase_plan_edit,SIGNAL(editPlanEnd()), this, SLOT(showPurchasePlanMng()));
    connect(purchase_plan_mng, SIGNAL(sendOldPlan(Purchase_Plan)), this, SLOT(receive_old_plan(Purchase_Plan)));
    connect(purchase_plan_edit, SIGNAL(sendNewOrders(std::vector<PurchaseOrder>)),
            this, SLOT(recvNewOrders(std::vector<PurchaseOrder>)));


    this->init_left_menu();
    this->init_stacked_widget();
}

void PurchaseManage::init_left_menu(){
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf0ae << 0xf0cb;
    btns<< ui->btnPurchasePlan<<ui->btnOrder;

    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btnPurchasePlan->click();
}

void PurchaseManage::init_stacked_widget(){
    ui->stackedWidget->insertWidget(0,purchase_plan_mng);
    ui->stackedWidget->insertWidget(1,purchase_order_mng);
    ui->stackedWidget->insertWidget(2,purchase_plan_edit);
}


void PurchaseManage::menu_click(){
    //sender:Returns the object that emitted the signal.
    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);

    if(b==ui->btnPurchasePlan){
        ui->stackedWidget->setCurrentIndex(0);
        purchase_plan_mng->first_init();
    }else if(b==ui->btnOrder){
        ui->stackedWidget->setCurrentIndex(1);
        purchase_order_mng->first_init();
    }

}
void PurchaseManage::showPurchasePlanMng(){
    ui->stackedWidget->setCurrentIndex(0);
    purchase_plan_mng->first_init();
}

void PurchaseManage::receive_new_plan(QString plan_name){
    qDebug()<<"Purchase Manager "<<plan_name;
    purchase_plan_edit->init_new_plan(plan_name);
    ui->stackedWidget->setCurrentIndex(2);
}

void PurchaseManage::receive_old_plan(Purchase_Plan plan){
    qDebug()<<" PurchaseManage::receive_old_plan(Purchase_Plan plan) "<< plan.get_plan_id();
    purchase_plan_edit->init_old_plan(plan);
    ui->stackedWidget->setCurrentIndex(2);
}
void PurchaseManage::recvNewOrders(std::vector<PurchaseOrder> newOrders){
    qDebug()<<"PurchaseMng::recvNewOrders(std::vector<PurchaseOrder> newOrders)";

    //收到新形成的订单,将订单加入到数据库,并展示
    Request req;
    req.set_module("purchase_order");
    req.set_func("add_orders");

    QJsonArray orderArray;
    for(PurchaseOrder order:newOrders){

        orderArray.append(order.toJSON());
    }
    req.put("orders", orderArray);
    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_add_orders(Response)));
    wait->start();
}

void PurchaseManage::recv_add_orders(Response resp){
    qDebug()<<"PurchaseMng::recv_add_orders(Response resp)"<<QString::number(resp.get_status_code());
    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_add_orders(Response)));
    wait->stop();


    if(resp.get_status_code()==SUCCESS){
       QJsonArray ordIdArray = resp.get_array("orders");
       QString ordIdStr = "订单号：\n";
       foreach(const QJsonValue &val, ordIdArray){
           PurchaseOrder order(val.toObject());
           ordIdStr += order.orderItems[0].sp_name+": "+order.order_id+"\n";
       }

       MsgBox::success(this,"订单已成功生成",ordIdStr);
       ui->btnOrder->click();
    }else{
         MsgBox::error(this,QString::fromLocal8Bit("加入订单失败"),QString::fromLocal8Bit("加入订单失败"));
    }
}

PurchaseManage::~PurchaseManage()
{
    delete ui;
    delete purchase_order_mng;
    delete purchase_plan_mng;
    delete purchase_plan_edit;
}
