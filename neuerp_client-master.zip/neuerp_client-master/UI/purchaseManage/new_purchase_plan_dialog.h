#ifndef NEW_PURCHASE_PLAN_DIALOG_H
#define NEW_PURCHASE_PLAN_DIALOG_H

#include <QDialog>

namespace Ui {
class NewPurchasePlanDialog;
}

class NewPurchasePlanDialog : public QDialog
{
    Q_OBJECT

public:
    explicit NewPurchasePlanDialog(QWidget *parent = 0);
    ~NewPurchasePlanDialog();
    QString getPlanName();
signals:
    void send_plan_name(QString);
private slots:
    void on_saveBtn_clicked();
    void on_cancelBtn_clicked();

private:
    Ui::NewPurchasePlanDialog *ui;
    QString plan_name="";
};

#endif // NEW_PURCHASE_PLAN_DIALOG_H
