#ifndef PURCHASE_PLAN_MNG_H
#define PURCHASE_PLAN_MNG_H

#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Network/Body/response.h"

#include <QWidget>
#include <vector>
#include <QDateTime>
#include <QJsonArray>
#include <QDebug>
#include <QTime>

#include "ui/msgbox.h"
#include "new_purchase_plan_dialog.h"
#include "ui/waitingspinnerwidget.h"

#include "Entity/purchase_plan.h"
#include "status_code.h"





namespace Ui {
class PurchasePlanMng;
}

class PurchasePlanMng : public QWidget
{
    Q_OBJECT

public:
    explicit PurchasePlanMng(QWidget *parent = 0);
    ~PurchasePlanMng();
    void first_init();

signals:
    void sendNewPlan(QString plan_name);
    void sendOldPlan(Purchase_Plan);

private slots:
    void query_clicked();
    void query_plans();
    void recv_plans(Response resp);
    void refresh_table();
    void change_page(int new_index);
    void refresh_page_bar();
    void next_page();
    void last_page();
    void recv_plan_name(QString);

    void on_btnAdd_clicked();

    void on_editRadioBtn_clicked();

    void on_finishRadioBtn_clicked();

    void on_editPlanBtn_clicked();

private:
    Ui::PurchasePlanMng *ui;
    NewPurchasePlanDialog *dialog;
    WaitingSpinnerWidget *wait;

    int editable=1;
    QString keyword;
    QDateTime start_date;
    QDateTime end_date;
    std::vector<Purchase_Plan> plans;

    //分页
    int current_page=1;
    int max_page=1;
    int page_size=10;
};

#endif // PURCHASE_PLAN_MNG_H
