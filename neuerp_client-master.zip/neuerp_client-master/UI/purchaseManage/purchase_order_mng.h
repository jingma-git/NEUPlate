#ifndef PURCHASE_ORDER_MNG_H
#define PURCHASE_ORDER_MNG_H

#include <QWidget>
#include <QCheckBox>
#include <QSpinBox>
#include "ui/msgbox.h"
#include "ui/waitingspinnerwidget.h"
#include "ui/centered_checkbox.h"

#include "Network/Body/request.h"
#include "Network/Client/mainclient.h"
#include "Network/Body/response.h"
#include "status_code.h"

#include "Entity/purchase_order.h"
#include "Entity/order_item.h"
namespace Ui {
class PurchaseOrderMng;
}

class PurchaseOrderMng : public QWidget
{
    Q_OBJECT

public:
    explicit PurchaseOrderMng(QWidget *parent = 0);
    ~PurchaseOrderMng();
    void first_init();
    void query_orders();
    void query_order_items();
    void show_cur_order();

private slots:
    void recv_orders(Response);
    void recv_order_items(Response);
    void changeCurOrder(int);
    void changeCurOrderItem(int,int);
    void changeBuyAmt(int);
    void change_page(int new_index);
    void next_page();
    void last_page();
    void recv_delete_orders(Response);
    void recv_update_orders_state(Response);
    void recv_update_order_state(Response);
    void recv_delete_order_items(Response);

    void on_payBtn_clicked();

    void on_confirmBtn_clicked();

    void on_radioBtnOnPay_clicked();

    void on_radioBtnOnDeliver_clicked();

    void on_radioBtnConfirmed_clicked();

    void on_deleteOrderBtn_clicked();

    void on_deleteOrderItemBtn_clicked();

    void delete_orders(QJsonArray& order_ids);

private:
    Ui::PurchaseOrderMng *ui;
    WaitingSpinnerWidget *wait;

    std::vector<PurchaseOrder> orders;
    PurchaseOrder cur_order;
    int order_state = PurchaseOrder::WAIT_TO_PAY;
    int cur_row_order_info = 0;
    int cur_row_orders = 0;


    bool inited = false;
    int current_page=1;
    int max_page=1;
    int page_size=20;


    const static int SpinBox_MIN=1;

    void refresh_table_orders();
    void refresh_order_info();
    void refresh_page_bar();
};

#endif // PURCHASE_ORDER_H
