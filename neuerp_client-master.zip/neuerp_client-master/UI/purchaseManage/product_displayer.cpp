/**
* @brief         商品列表展示模块
* @author        majing
* @date          2018-07-03
* @modify_author XXXX
* @modify_date   2018-07-03
*/
#include "product_displayer.h"
#include "ui_product_displayer.h"

ProductDisplayer::ProductDisplayer(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ProductDisplayer)
{
    qDebug()<<"ProductDisplayer::ProductDisplayer";
    ui->setupUi(this);

    this->layout = new QVBoxLayout();
    browser1 = new ProductBrowser(this);
    browser2 = new ProductBrowser(this);
    browser3 = new ProductBrowser(this);
    browser4 = new ProductBrowser(this);
    wait = new WaitingSpinnerWidget(this);

    proBrowsers.append(browser1);
    proBrowsers.append(browser2);
    proBrowsers.append(browser3);
    proBrowsers.append(browser4);
    for(int i=0; i<page_size; i++){
        this->layout->addWidget(proBrowsers[i]);
        proBrowsers[i]->setVisible(false);
    }
    ui->itemsFrame->setLayout(this->layout);

    connect(ui->btnQuery,SIGNAL(clicked()),this,SLOT(query_clicked()));
    connect(ui->ledit_keyword,SIGNAL(returnPressed()),ui->btnQuery,SIGNAL(clicked()));
    connect(ui->btnLastPage,SIGNAL(clicked()),this,SLOT(last_page()));
    connect(ui->btnNextPage,SIGNAL(clicked()),this,SLOT(next_page()));
    connect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));

}
void ProductDisplayer::init(){
    query_clicked();
}


void ProductDisplayer::query_clicked(){
   qDebug()<<"ProductDisplayer::query_clicked()";
   if(ui->ascRadioBtn->isChecked()){
       asc_order = true;
   }else{
       asc_order = false;
   }
   qDebug()<<"++++++++++++++++++++++++++++++++++++asc_order"<<QString::number(asc_order);
   keyword = ui->ledit_keyword->text();
   query_productsToBuy();
}
void ProductDisplayer::query_productsToBuy(){
    //qDebug()<<"ProductDisplayer::query_productsToBuy()";
    for(int i=0; i<4; i++){
        if(!proBrowsers[i]->has_flash_ended()){
            proBrowsers[i]->stop_timer();
        }
    }
    Request req;
    req.set_module("purchase_plan");

    req.set_func("query_productsToBuy");
    req.put("keyword",keyword);
    req.put("asc_order", asc_order);
    req.put("page",current_page);
    req.put("page_size",page_size);

    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_productsToBuy(Response)));
    wait->start();
}

void ProductDisplayer::recv_productsToBuy(Response resp){
   // qDebug()<<"ProductDisplayer::recv_productsToBuy(Response resp)";
    if(resp.get_module()!="purchase_plan"||resp.get_func()!="query_productsToBuy"){
        return;
    }
    wait->stop();
    prosToBuy.clear();

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_productsToBuy(Response)));

    if(resp.get_status_code()==SUCCESS){
        QJsonArray pros_json=resp.get_array("prosToBuy");

        foreach(const QJsonValue &pro_json, pros_json){
            QJsonObject pro_obj = pro_json.toObject();
            ProductToBuy pro(pro_obj);
            prosToBuy.push_back(pro);
        }

        max_page=resp.get_int("all_page");

        refresh_page_bar();
        refresh_product_browsers();
    }else{
       MsgBox::error(this,"查询失败","查询失败");
    }
}
void ProductDisplayer::refresh_product_browsers(){

    for(int i=0; i<page_size; i++){
        proBrowsers[i]->setVisible(false);
    }

    int pros_size = prosToBuy.size();
    for(int i=0; i<pros_size; i++){
        proBrowsers[i]->setVisible(true);
        proBrowsers[i]->init(prosToBuy[i]);
    }

}

void ProductDisplayer::refresh_page_bar(){
     disconnect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));
     ui->btnLastPage->setEnabled(!(current_page==1));
     ui->btnNextPage->setEnabled(!(current_page==max_page));
     ui->comboBoxPage->clear();

     for(int i=0;i<max_page;i++){
         ui->comboBoxPage->insertItem(i,QString("第%1页").arg(i+1));
     }
     ui->comboBoxPage->setCurrentIndex(current_page-1);
     connect(ui->comboBoxPage,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));
}

void ProductDisplayer::next_page()
{
    change_page(current_page-1+1);
}

void ProductDisplayer::last_page()
{
    change_page(current_page-1-1);
}
void ProductDisplayer::change_page(int new_index){
    int new_page=new_index + 1;
    current_page=new_page;
    query_productsToBuy();
}
ProductDisplayer::~ProductDisplayer()
{
    delete layout;
    delete browser1;
    delete browser2;
    delete browser3;
    delete browser4;
    delete ui;
}
