#include "edit_purchase_plan.h"
#include "ui_edit_purchase_plan.h"


EditPurchasePlan::EditPurchasePlan(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::EditPurchasePlan)
{
    ui->setupUi(this);

    wait = new WaitingSpinnerWidget(this);
    dialog = new NewPurchasePlanDialog(this);
    timer = new QTimer(this);
    ui->progressBar->setVisible(false);
    connect(dialog,SIGNAL(send_plan_name(QString)), this, SLOT(recv_plan_name(QString)));
    /*
    connect(timer,SIGNAL(timeout()),this, SLOT(save_plan_items()));
    timer->start(10000); //自动保存计划
    */
}


void EditPurchasePlan::init_new_plan(QString plan_name){
    //qDebug()<<"EditPurchasePlan::first_int(QString file_name, bool is_new)";
    ui->splitter->setStretchFactor(0,2);
    ui->splitter->setStretchFactor(1,1);
    init_product_displayer();
    init_plan_displayer();
    clear_plan_info();

    Request req;
    req.set_module("purchase_plan");
    req.set_func("add");

    UserController& login_user = UserController::get_instance();
    QString handler_id = login_user.get_e_id();
    req.put("plan_name", plan_name);
    req.put("handler_id", handler_id);
    req.put("date", QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));


    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_new_plan(Response)));

    //wait->start();
}

void EditPurchasePlan::init_old_plan(Purchase_Plan plan){
   // qDebug()<<"EditPurchasePlan::init_old_plan(Purchase_Plan)" << plan.get_plan_id();
    this->plan = plan;
    ui->planIdLabel->setText(plan.get_plan_id());
    ui->planNameLabel->setText(plan.get_name());
    ui->dateLabel->setText(plan.get_date());
    ui->stateLabel->setText(plan.get_state()?"可编辑":"已完成");


    if(plan.get_state()==Purchase_Plan::COMPLETED){
        ui->splitter->setStretchFactor(0,0);
        ui->splitter->setStretchFactor(1,1);
        ui->savePlanBtn->setVisible(false);
        ui->generateOrderBtn->setVisible(false);
    }else{
        ui->splitter->setStretchFactor(0,2);
        ui->splitter->setStretchFactor(1,1);
        init_product_displayer();
        init_plan_displayer();
    }

    Request req;
    req.set_module("purchase_plan");
    req.set_func("load_plan_items");

    req.put("plan_id", plan.get_plan_id());

    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_plan_items(Response)));
}

void EditPurchasePlan::stopTimer(){
    timer->stop();
}

void EditPurchasePlan::init_plan_displayer(){
    qDebug()<<"EditPurchasePlan::init_plan_displayer()";
    ui->savePlanBtn->setVisible(true);    
    ui->generateOrderBtn->setVisible(true);


    ui->tableWidget->setRowCount(100);
    ui->tableWidget->setShowGrid(true);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    right_menu = new QMenu(ui->tableWidget);
    QAction *delete_pro = right_menu->addAction(tr("删除商品"));
    connect(delete_pro, SIGNAL(triggered(bool)), this, SLOT(delete_select_pro()));
    connect(ui->tableWidget, SIGNAL(cellEntered(int, int)), this, SLOT(changeCurRowCol(int, int)));
    //qDebug()<<"End EditPurchasePlan::init_plan_displayer()";
}

void EditPurchasePlan::init_product_displayer(){
    layout = new QVBoxLayout();
    displayer = new ProductDisplayer();
    layout->addWidget(displayer);
    ui->displayFrame->setLayout(this->layout);

    connect(displayer->browser1,SIGNAL(addToBuyList(ProductToBuy,int,int)), this, SLOT(insert_to_plan_list(ProductToBuy,int,int)));
    connect(displayer->browser2,SIGNAL(addToBuyList(ProductToBuy,int,int)), this, SLOT(insert_to_plan_list(ProductToBuy,int,int)));
    connect(displayer->browser3,SIGNAL(addToBuyList(ProductToBuy,int,int)), this, SLOT(insert_to_plan_list(ProductToBuy,int,int)));
    connect(displayer->browser4,SIGNAL(addToBuyList(ProductToBuy,int,int)), this, SLOT(insert_to_plan_list(ProductToBuy,int,int)));

    displayer->init();
}

void EditPurchasePlan::recv_new_plan(Response resp){
    if(resp.get_module()!="purchase_plan"||resp.get_func()!="add"){
        return;
    }

   // wait->stop();

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_new_plan(Response)));

    if(resp.get_status_code()==SUCCESS){
        QJsonObject plan_obj = resp.get_json("plan_info");
        plan.fromJSON(plan_obj);

        ui->planIdLabel->setText(plan.get_plan_id());
        ui->planNameLabel->setText(plan.get_name());
        ui->dateLabel->setText(plan.get_date());
        QString stateStr = plan.get_state()?"可编辑":"已完成";
        ui->stateLabel->setText(stateStr);
    }else{
       MsgBox::error(this,"添加计划失败","添加计划失败");
    }
}

void EditPurchasePlan::recv_plan_items(Response resp){
   qDebug()<<" EditPurchasePlan::recv_plan_items(Response resp)";
    if(resp.get_module()!="purchase_plan"||resp.get_func()!="load_plan_items"){
        return;
    }

    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_plan_items(Response)));
    //qDebug()<<"resp.get_status_code()"<<QString::number(resp.get_status_code());
    int status_code = resp.get_status_code();
    if(status_code==SUCCESS){
        QJsonArray planItems_json = resp.get_array("plan_items");
        foreach(const QJsonValue &planItem_json,planItems_json){
            QJsonObject planItem_obj = planItem_json.toObject();
            PlanItem planItem(planItem_obj);
            planItems.push_back(planItem);
        }

        list_len = planItems.size();

    }else if(status_code==SQL_EXEC_ERROR){
       MsgBox::error(this,"对不起，服务器崩溃了","对不起，服务器崩溃了");
    }

    for(int i=0; i<list_len; i++){
        PlanItem &planItem = planItems.at(i);
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(planItem.product_id));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(planItem.product_name));
        ui->tableWidget->setItem(i,3, new QTableWidgetItem(planItem.sp_name));
        ui->tableWidget->setItem(i,4, new QTableWidgetItem(QString::number(planItem.pp_price,'g',2)));
        if(plan.get_state() == Purchase_Plan::COMPLETED){
             ui->tableWidget->setItem(i,2,new QTableWidgetItem(QString::number(planItem.amt)));
        }else{
            QSpinBox *spinBox = new QSpinBox();
            spinBox->setMinimum(SpinBox_MIN);
            spinBox->setMaximum(SpinBox_MAX);
            spinBox->setValue(planItem.amt);
            connect(spinBox, SIGNAL(valueChanged(int)), this, SLOT(changeBuyAmt(int)));
            ui->tableWidget->setCellWidget(i,2,spinBox);
        }
    }
}

void EditPurchasePlan::insert_to_plan_list(ProductToBuy pro,int buy_amt, int sp_idx){
    qDebug()<<"EditPurchasePlan::insert_to_plan_list()";
    /*
    for(int i=0; i<list_len; i++){
        qDebug()<<planItems[i].product_id <<" " << QString::number(planItems[i].amt);
    }*/
    QString p_id = pro.getP_id();
    QString p_name = pro.getName();
    std::vector<QString> sp_names = pro.get_sp_names();
    QString sp_name = sp_names[sp_idx];    
    double pp_price = pro.get_pp_prices()[sp_idx];

    int row = find(p_id,sp_name);
    //qDebug()<<"row "<<QString::number(row);
    if(row != -1){
        //qDebug()<<"EditPurchasePlan::insert_to_plan_list() planItem.amt += buy_amt; "<< QString::number(planItems[row].amt);
        planItems[row].amt += buy_amt;
        QSpinBox *spinBox = (QSpinBox*)ui->tableWidget->cellWidget(row,2);
        spinBox->setValue(spinBox->value()+buy_amt);
    }else{
        ui->tableWidget->setItem(list_len,0,new QTableWidgetItem(p_id));
        ui->tableWidget->setItem(list_len,1,new QTableWidgetItem(p_name));
        ui->tableWidget->setItem(list_len,3,new QTableWidgetItem(sp_name));
        ui->tableWidget->setItem(list_len,4,new QTableWidgetItem(QString::number(pp_price)));
        QSpinBox *spinBox = new QSpinBox();
        spinBox->setMinimum(1);
        spinBox->setMaximum(100000);
        spinBox->setValue(buy_amt);
        ui->tableWidget->setCellWidget(list_len,2,spinBox);

        PlanItem planItem;
        planItem.plan_id = plan.get_plan_id();
        planItem.product_id = p_id;
        planItem.product_name = p_name;
        planItem.sp_id = pro.get_sp_ids()[sp_idx];
        planItem.sp_name = sp_name;
        planItem.amt = buy_amt;
        planItem.pp_price = pp_price;
        planItems.push_back(planItem);
        ++list_len;
    }
    is_plan_saved = false;
    //ui->progressBar->setValue(0);
}

/**
* @functionName  find
* @Description   find whether the given p_id in the tablewidget
* @author        majing
* @date          %{CurrentDate:2018-07-10}
* @parameter     product id
* @return        -1 if not find, otherwise the index in the tablewidget
*/

int EditPurchasePlan::find(QString p_id, QString sp_name){
    qDebug()<<"EditPurchasePlan::find(QString p_id)";
    for(int i=0; i<list_len; i++){
        if(p_id==ui->tableWidget->item(i,0)->text() && sp_name==ui->tableWidget->item(i,3)->text()){
            qDebug()<<QString::number(i)<<" "<<p_id<<" "<< planItems[i].product_id;
            return i;
        }
    }
    return -1;
}

EditPurchasePlan::~EditPurchasePlan()
{
    delete ui;
}

void EditPurchasePlan::on_tableWidget_customContextMenuRequested(const QPoint &pos)
{  
    QList<QTableWidgetItem*> items = ui->tableWidget->selectedItems();
    if(items.count() > 0){
     //   qDebug()<<"EditPurchasePlan::on_tableWidget_customContextMenuRequested(const QPoint &pos)";
        right_menu->exec(QCursor::pos());
    }
}

void EditPurchasePlan::delete_select_pro(){
   // qDebug()<<"EditPurchasePlan::delete_select_pro()";
    QList<QTableWidgetItem*> items = ui->tableWidget->selectedItems();
    int size = items.size();
    //qDebug()<<"size "<<QString::number(size);
    int tmp = -1;
    for(int i=0; i<size; i++){
        if(items[i]->row() != tmp){
           std::vector<PlanItem>::iterator it = planItems.begin();
           tmp = items[i]->row();
           planItems.erase(it+items[i]->row());
        }
    }
    list_len = planItems.size();
    refresh_table();
    is_plan_saved = false;
}

void EditPurchasePlan::changeBuyAmt(int amt){
    planItems[cur_row].amt = amt;
}
void EditPurchasePlan::changeCurRowCol(int row, int col){
    cur_row = row;
    cur_col = col;
}


void EditPurchasePlan::refresh_table(){
    //qDebug()<<"EditPurchasePlan::refresh_table()";
    ui->tableWidget->clearContents();
    //qDebug()<<"clear contents";
    //qDebug()<<QString::number(list_len);
    for(int i=0; i<list_len; i++){
        qDebug()<<"plan item "<<planItems[i].product_id;
        ui->tableWidget->setItem(i,0,new QTableWidgetItem(planItems[i].product_id));
        ui->tableWidget->setItem(i,1,new QTableWidgetItem(planItems[i].product_name));
        ui->tableWidget->setItem(i,3,new QTableWidgetItem(planItems[i].sp_name));
        ui->tableWidget->setItem(i,4, new QTableWidgetItem(planItems[i].pp_price));
        QSpinBox *spinBox = new QSpinBox();
        spinBox->setMinimum(1);
        spinBox->setMaximum(100000);
        connect(spinBox, SIGNAL(valueChanged(int)), this, SLOT(changeBuyAmt(int)));
        spinBox->setValue(planItems[i].amt);
        ui->tableWidget->setCellWidget(i,2,spinBox);
    }
}

void EditPurchasePlan::on_savePlanBtn_clicked()
{

   save_plan_items();
}

void EditPurchasePlan::save_plan_items(){
    //qDebug()<<",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"<<"EditPurchasePlan::save_plan_items()";
    if(!is_plan_saved){
        Request req;
        req.set_module("purchase_plan");
        req.set_func("update_plan_items");

        QJsonArray planItems_json;
        for(int i=0; i<list_len; i++){
            planItems_json.append(planItems[i].toJSON());
            qDebug()<<planItems[i].product_id;
        }
        req.put("plan_id", plan.get_plan_id());
        req.put("planItems", planItems_json);

        auto &client=MainClient::get_instance();
        client.send(req);
        connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(confirm_planItems_saved(Response)));
        wait->start();
    }
}
void EditPurchasePlan::confirm_planItems_saved(Response resp){
    qDebug()<<"EditPurchasePlan::confirm_planItems_saved";
    if(resp.get_module()!="purchase_plan"||resp.get_func()!="update_plan_items"){
        return;
    }
    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(confirm_planItems_saved(Response)));
    wait->stop();

    qDebug()<<".................."<<resp.get_status_code();
    if(resp.get_status_code()==SUCCESS){
       QString plan_id = resp.get_string("plan_id");
       ui->planIdLabel->setText(plan_id);
       is_plan_saved=true;
       int ans = MsgBox::question(this,"操作成功","恭喜你，计划保存成功\n"
                                              "想要生成订单吗？","是的","不了，继续编辑计划");
       if(ans==MsgBox::YES){
           ui->generateOrderBtn->click();
       }

    }else{
       MsgBox::error(this,"保存失败","保存失败");
    }
}

void EditPurchasePlan::recv_plan_name(QString plan_name){
    init_new_plan(plan_name);
}

void EditPurchasePlan::on_addNewPlanBtn_clicked()
{
    if(!is_plan_saved){
       int ans = MsgBox::question(this,"","当前计划还未保存，确定新建计划？");
       if(ans==MsgBox::NO){
           return;
       }
    }
    dialog->show();
}

void EditPurchasePlan::clear_plan_info(){
    qDebug()<<"EditPurchasePlan::clear_plan_info()";
    planItems.clear();
    list_len = 0;
    ui->dateLabel->clear();
    ui->planIdLabel->clear();
    ui->planNameLabel->clear();
    ui->stateLabel->clear();
    ui->tableWidget->clearContents();
}

void EditPurchasePlan::on_exitBtn_clicked()
{
    if(!is_plan_saved){
       int ans = MsgBox::question(this,"","当前计划还未保存，确定退出？");
       if(ans==MsgBox::NO){
           return;
       }
    }
    emit editPlanEnd();
}

void EditPurchasePlan::on_generateOrderBtn_clicked()
{
    //采购计划为空时不能生成订单
    if(planItems.empty()){
        MsgBox::warming(this,"警告","进货计划不能为空");
        return;
    }
    //update plan items
    if(!is_plan_saved){
        MsgBox::warming(this,"警告","当前计划尚未保存，请先保存订单");
        return;
    }

    plan.set_state(Purchase_Plan::COMPLETED);

    //update plan state as COMPLETED
    Request req;
    req.set_module("purchase_plan");
    req.set_func("update_state");

    req.put("plan_id", plan.get_plan_id());
    req.put("state", plan.get_state());

    auto &client=MainClient::get_instance();
    client.send(req);
    connect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_update_plan_state(Response)));
}

void EditPurchasePlan::recv_update_plan_state(Response resp){
    qDebug()<<"EditPurchasePlan::recv_update_plan_state(Response resp)";
    if(resp.get_module()!="purchase_plan"||resp.get_func()!="update_state"){
        return;
    }
    auto &client=MainClient::get_instance();
    disconnect(&client,SIGNAL(notify_resp(Response)),this,SLOT(recv_update_plan_state(Response)));

    if(resp.get_status_code()!=SUCCESS){
       MsgBox::error(this,"更新计划状态失败","更新计划状态失败");
       return;
    }

    //generate order
    std::map<QString,PurchaseOrder> ordMap; //将plan item按照供应商分类
    qDebug()<<"std::map<QString,PurchaseOrder> ordMap;";
    for(std::map<QString,PurchaseOrder>::iterator it=ordMap.begin(); it!=ordMap.end(); ++it){
        qDebug()<<it->first;
        qDebug()<<it->second.toString();
    }
    for(PlanItem planItem:planItems){
        QString  sp_id = planItem.sp_id;
        PurchaseOrder &order = ordMap[sp_id];

        OrderItem orderItem;
        orderItem.product_id = planItem.product_id;
        orderItem.product_name = planItem.product_name;
        orderItem.sp_id = planItem.sp_id;
        orderItem.sp_name = planItem.sp_name;
        orderItem.amt = planItem.amt;
        orderItem.pp_price = planItem.pp_price;

        if(ordMap.count(sp_id)==1){
            order.order_id = QDateTime::currentDateTime().toString("yyyyMMddhhmmss")+sp_id;
            order.sp_id = sp_id;
            order.state = PurchaseOrder::WAIT_TO_PAY;
            order.date = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
        }
        orderItem.order_id = order.order_id;
        order.orderItems.push_back(orderItem);
        //qDebug()<<" order.orderItems.push_back(orderItem);"<<order.toString();
    }

    std::vector<PurchaseOrder> orders;
    for(std::map<QString,PurchaseOrder>::iterator it=ordMap.begin(); it!=ordMap.end(); ++it){
       qDebug()<<" for(std::map<QString,PurchaseOrder>::iterator it=";
       qDebug()<<it->second.toString();
        PurchaseOrder order = it->second;
        orders.push_back(order);
    }
    //for(PurchaseOrder order:orders)
    //    qDebug()<< order.toString();
    emit sendNewOrders(orders); //将新形成的order发送到purchase order模块进行处理
}
