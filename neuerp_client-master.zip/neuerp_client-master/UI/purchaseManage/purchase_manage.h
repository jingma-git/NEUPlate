#ifndef PURCHASE_MANAGE_H
#define PURCHASE_MANAGE_H

#include <QWidget>
#include <QToolButton>
#include "ui/waitingspinnerwidget.h"
#include "purchase_order_mng.h"
#include "purchase_plan_mng.h"
#include "edit_purchase_plan.h"
namespace Ui {
class PurchaseManage;
}

class PurchaseManage : public QWidget
{
    Q_OBJECT

public:
    explicit PurchaseManage(QWidget *parent = 0);
    ~PurchaseManage();

private:
    Ui::PurchaseManage *ui;
    QList<int> pixChars;
    QList<QToolButton *> btns;
    WaitingSpinnerWidget *wait;

    PurchaseOrderMng *purchase_order_mng;
    PurchasePlanMng *purchase_plan_mng;
    EditPurchasePlan *purchase_plan_edit;
    void init_left_menu();

private slots:
    void menu_click();
    void init_stacked_widget();
    void receive_new_plan(QString);
    void receive_old_plan(Purchase_Plan);
    void showPurchasePlanMng();
    void recvNewOrders(std::vector<PurchaseOrder> newOrders);
    void recv_add_orders(Response);

};

#endif // PURCHASE_MANAGE_H
