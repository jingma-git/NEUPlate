#include "usercontroller.h"
#include <QDebug>

UserController::UserController()
{

}

UserController::~UserController()
{

}

UserController::UserController(const UserController &controller)
{

}

UserController &UserController::operator =(const UserController &controller)
{

}

int UserController::get_access_code() const
{
    return access_code;
}

void UserController::set_access_code(int value)
{
    access_code = value;
}

/**
* @functionName  add_permission
* @Description       add permission into permission table, usually used in init
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         QString permission, int code
* @return               void
*/
void UserController::add_permission(const QString &permission, int code, const QString &desc)
{
    this->permission.insert(std::map<QString, int>::value_type(permission, code));
    this->permission_desc.insert(std::map<QString, QString>::value_type(permission, desc));
}

/**
* @functionName  check_access_code
* @Description       check input access code if has permission to access
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         QString permission, int access_code
* @return               void
*/
bool UserController::check_access_code(const QString &permission, int access_code)
{
    auto iter = this->permission.find(permission);
    if(this->permission.end() != iter){
        qDebug() << iter->second;
        qDebug() << access_code;
        if(iter->second & access_code){
            return true;
        }
    }
    return false;
}

/**
* @functionName  check_access_code
* @Description       check login user whether have permision to access
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         QString permission
* @return               void
*/
bool UserController::check_access_code(const QString &permission)
{
    auto iter = this->permission.find(permission);
    if(this->permission.end() != iter){
        if(iter->second & access_code){
            return true;
        }
    }
    return false;
}

/**
* @functionName  get_permission
* @Description       get all permission in system
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         void
* @return               std::vector<QString>
*/
std::vector<QString> UserController::get_permission_desc()
{
    std::vector<QString> permission_list;
    for(const auto &item : permission_desc){
        permission_list.push_back(item.second);
    }
    return permission_list;
}

/**
* @functionName  get_access_code
* @Description       get permission's access code
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         QString permission
* @return               int
*/
int UserController::get_access_code(const QString &permission) const
{
    auto iter = this->permission.find(permission);
    if(this->permission.end() != iter){
        return iter->second;
    }else{
        return 0;
    }
}

/**
* @functionName  get_permission
* @Description       get permission by it's description
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         void
* @return               void
*/
QString UserController::get_permission(const QString &desc)
{
    for(const auto &item : permission_desc){
        if(item.second == desc){
            return item.first;
        }
    }
    return QString();
}

UserController &UserController::get_instance()
{
    static UserController controller;
    return controller;
}

QString UserController::get_e_id() const
{
    return e_id;
}

void UserController::set_e_id(const QString &value)
{
    e_id = value;
}
