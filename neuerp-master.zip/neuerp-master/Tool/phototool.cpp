#include "phototool.h"
#include <QFile>
#include <QDataStream>
#include <QByteArray>
#include <QUuid>

/**
* @functionName  check_photo
* @Description   check if the photo is consistent
* @author        chenhanlin
* @date          2018-07-05
* @parameter     QString photo_path, QString photo_data
* @return        bool
*/
bool PhotoTool::check_photo(const QString &photo_path, const QString &photo_data)
{
    QFile file(photo_path);
    file.open(QIODevice::ReadOnly);
    QDataStream in(&file);
    QByteArray origin_data;
    in >> origin_data;
    origin_data = origin_data.toBase64();
    QString origin_str(origin_data);
    if (origin_data == photo_data){
        return true;
    }else{
        return false;
    }
}

/**
* @functionName  delete_photo
* @Description   delete photo
* @author        chenhanlin
* @date          2018-07-05
* @parameter     QString photo_path
* @return        void
*/
void PhotoTool::delete_photo(const QString &photo_path)
{
    QFile file(photo_path);
    file.remove();
}

/**
* @functionName  save_photo
* @Description   save the photo on disk, name is generate by random and it will return
                 if failuer, will return empty string
* @author        chenhanlin
* @date          2018-07-01
* @parameter     QByteArray photo_data
* @return        std::string
*/
QString PhotoTool::save_photo(const QString &photo_data_base64)
{
    QUuid id = QUuid::createUuid();
    QString filename(id.toString().remove("{").remove("}").remove("-"));
    QFile file(filename);
    file.open(QIODevice::WriteOnly);
    QByteArray photo_data(QByteArray::fromBase64(photo_data_base64.toUtf8()));
    file.write(photo_data);
    file.close();
    return filename;
}

/**
* @functionName  load_photo
* @Description   read photo data from disk and encode to base64
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
QString PhotoTool::load_photo(const QString &photo_path)
{
    QFile file(photo_path);
    file.open(QIODevice::ReadOnly);
    QByteArray data(file.readAll());
    return QString(data.toBase64());
}
