/**
* @projectName   neuerp_server
* @brief         control User and UserDAO
* @author        chenhanlin
* @date          2018-07-04
*/

#ifndef USERCONTROLLER_H
#define USERCONTROLLER_H

#include <Network/Route/controller.h>
#include "entity/user.h"
#include <QString>
#include <map>
#include <QSqlDatabase>

class UserController : public Controller
{
    DECLEAR_CONTROLLER(UserController)
public:
    static int add_user(const QString &employee_id, const QSqlDatabase &db);
    static int remove_user(const QString &employee_id, const QSqlDatabase &db);
    static int close_user(const QString &employee_id);
    static int reopen_user(const QString &employee_id);
    static bool check_access_code(const QString &handler_id, const QString &func);
    static void init_access_code();
    static void logout(const QString &handler_id);
    static const User* get_logined(const QString &handler_id);

private:
    void modify_access_code();
    void query_access_code();
    void modify_passwd();
    void find_passwd();
    void get_all_access_code();
    void get_security_question();
    void check_security_question();
    void set_security_question();
    void get_all_security_question();
    void init_user();
    void check_user();
    void unfrozen_user();
    void remove_user_state();
    void add_user_state();
    static int remove_user_state(const QString &employee_id, int status);
    static int add_user_state(const QString &employee_id, int status);
    static int update_all_access_code(const std::map<QString, int> &codes, const std::map<QString, int> &old_codes);
    static int reset_all_user_access_code();

private:
    static std::map<QString, int> login_try;
    static std::map<QString, User> logined;
    static std::map<QString, int> func_permission;
    static std::map<QString, int> permission_set;
    static std::map<QString, QString> permission_desc; // permission set's chinese description;
};

#endif // USERCONTROLLER_H
