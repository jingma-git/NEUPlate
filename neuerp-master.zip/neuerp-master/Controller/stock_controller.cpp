#include "stock_controller.h"
#include <QDebug>
#include <QJsonObject>
#include <QJsonArray>
#include "status_code.h"
#include "Exception/nullexception.h"

IMPLEMENT_CONSTROLLER_BEGIN(StockController, stock)
BIND(set_stock, set_stock, StockController)
BIND(get_stock, get_stock, StockController)
BIND(check_stock, check_stock, StockController)
IMPLEMENT_CONTROLLER_END

int StockController::check_stock(const QString &product_id, int &stock, bool &enough)
{
    if(stock<0){
        return ERROR_PARAMS;
    }

    int curr_stock;
    int result = stock_dao.get_stock(product_id, curr_stock);
    if (result == SUCCESS)
    {
        enough = curr_stock > stock;
    }
    return result;
}

int StockController::set_stock(const QString &product_id, const int &stock)
{
    if(stock<0){
        return ERROR_PARAMS;
    }
    int result = stock_dao.set_stock(product_id, stock);
    return result;
}

int StockController::get_stock(const QString &product_id, int &stock)
{
    int result = stock_dao.get_stock(product_id, stock);
    return result;
}

void StockController::get_stock()
{
    qDebug()<<"get stock";
    QString product_id;
    int stock,result;
    try
    {   
        product_id=req->get_string("product_id");
    }
    catch (NullException e)
    {
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    qDebug()<<product_id;

    result=get_stock(product_id,stock);
    resp->set_status_code(result);
    if(result==SUCCESS){
        resp->set_desc("success");
        resp->put("stock_amount",stock);
        resp->put("product_id",product_id);
    }else{
        resp->set_desc("failed");
    }
}

void StockController::set_stock()
{
    qDebug()<<"set stock";
    QString product_id;
    int stock,result;
    try
    {
        product_id=req->get_string("product_id");
        stock=req->get_int("stock_amount");
    }
    catch (NullException e)
    {
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    qDebug()<<product_id;

    result=set_stock(product_id,stock);
    resp->set_status_code(result);
    if(result==SUCCESS){
        resp->set_desc("success");
    }else if(result==ERROR_PARAMS){
        resp->set_desc("stock illegal");
    }else{
        resp->set_desc("failed");
    }
}

void StockController::check_stock()
{
    qDebug()<<"check stock";
    QString product_id;
    int stock,result;
    bool enough;

    try
    {
        product_id=req->get_string("product_id");
        stock=req->get_int("stock_amount");
    }
    catch (NullException e)
    {
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    qDebug()<<product_id;

    result=check_stock(product_id,stock,enough);
    resp->set_status_code(result);
    if(result==SUCCESS){
        resp->put("enough",enough);
        resp->put("product_id",product_id);
        resp->set_desc("success");
    }else{
        resp->set_desc("failed");
    }
}

