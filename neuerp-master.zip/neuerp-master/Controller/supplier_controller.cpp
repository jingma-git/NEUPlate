#include "supplier_controller.h"
#include "Entity_DAO/supplier_dao.h"

/**
* @projectName   neuerp_server
* @brief         Implements the supplier controller that parse json data
*                and deal with request.
* @author        luxijia
* @date          2018-7-3
* @modify_author
* @modify_date
*/

IMPLEMENT_CONSTROLLER_BEGIN(SupplierController, supplier)
BIND(search, search_supplier, SupplierController)
BIND(add_supplier, add_supplier, SupplierController)
BIND(remove_supplier, remove_supplier, SupplierController)
BIND(delete_supplier, delete_supplier, SupplierController)
BIND(change, change_information, SupplierController)
BIND(renew_supplier, renew_supplier, SupplierController)
IMPLEMENT_CONTROLLER_END

/**
* @functionName  search_supplier
* @Description   parse search supplier request json data ,then put the data
*                to search supplier processing function, finally packaging the result
*                into response.
* @author        luxijia
* @date          2018-7-3
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query suppliers has result
*                EMPTY_SET is query suppliers noe result
*/
int SupplierController::query_supplier(std::vector<Supplier>  &suppliers, const QString &bar_code)
{
    SupplierDao s_dao;
    return s_dao.query_supplier_by_id(suppliers, bar_code);
}

/**
* @functionName  search_supplier
* @Description   Deal with query supplier request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-3
*/
void SupplierController::search_supplier()
{
    QString keyword;
    int page_number;
    int page_item;
    int state;
    int all_resule_num = 0;
    int flag = EMPTY_SET;
    std::vector<Supplier> suppliers;
    QJsonArray supplier_array;

    try
    {
        keyword = this->req->get_string("keyword");
        page_number = this->req->get_int("page_number");
        page_item = this->req->get_int("page_item");
        state = this->req->get_int("state");
    }
    catch(NullException e)
    {
        qWarning() << " Accept search suppliers request error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

     flag = search_supplier(suppliers, keyword, all_resule_num, page_number, page_item, state);


    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("search suppliers success");

        int size = suppliers.size();

        for (int i = 0; i < size; i++)
        {
            QJsonObject supplier;
            supplier.insert("id", suppliers[i].getSp_id());
            supplier.insert("name", suppliers[i].getSp_name());
            supplier.insert("region", suppliers[i].getSp_region());
            supplier.insert("phone", suppliers[i].getSp_phone());
            supplier.insert("state", suppliers[i].getSp_state());
            supplier.insert("contact", suppliers[i].getContact());
            supplier_array.append(supplier);
        }

        this->resp->put("all_result_num", all_resule_num);
        this->resp->put("suppliers",supplier_array);
    }
    else if (EMPTY_SET == flag)
    {
        this->resp->set_status_code(EMPTY_QUERY);
        this->resp->set_desc("no such suppliers");
    }
    else
    {
        this->resp->set_status_code(QUERY_ERROR);
        this->resp->set_desc("query suppliers failed");
    }
}

/**
* @functionName  search_product
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with search supplier bussiness that can search by keyword and fuzzy search
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-3
* @parameter     suppliers search suppliers result collection
* @parameter     keyword search keyword
* @parameter     page_number page number of queries
* @parameter     page_item the number of item each page
* @parameter     state the state of supplier
* @parameter     all_result_num all result number
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query suppliers has result
*                EMPTY_SET is query suppliers noe result
*/
int SupplierController::search_supplier(std::vector<Supplier> &suppliers, QString keyword, int &all_result_num,
                                        int page_mnumber, int page_item, int state)
{
    int offset = (page_mnumber - 1) * page_item;
    return supplier_dao.query_supplier(suppliers, keyword, all_result_num, offset, page_item, state);
}

/**
* @functionName  add_supplier
* @Description   Deal with add supplier request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-3
*/
void SupplierController::add_supplier()
{
    QString name;
    QString telephone;
    QString region;
    QString contact;
    QJsonArray product_array;
    std::vector<ProvideProduct> products;
    int flag = ADD_ERROR;

    try
    {
        name = this->req->get_string("name");
        telephone = this->req->get_string("telephone");
        region = this->req->get_string("region");
        contact = this->req->get_string("contact");
        product_array = this->req->get_array("provide_product");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet add supplier reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!product_array.isEmpty())
    {
        int size = product_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = product_array.at(i);

            if (value.isObject())
            {
                ProvideProduct provide_product;
                QJsonObject product = value.toObject();
                provide_product.setPp_id(product.value("code").toString());
                provide_product.setPp_name(product.value("name").toString());
                provide_product.setPp_price(product.value("price").toDouble());
                provide_product.setPp_desc(product.value("description").toString());
                products.push_back(provide_product);
            }
        }
    }

    flag = add_supplier(name,telephone, region, contact, products);


    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("add supplier success");
    }
    else
    {
        this->resp->set_status_code(ADD_ERROR);
        this->resp->set_desc("add supplier failed");
    }
}

/**
* @functionName  add_supplier
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with add supplier bussiness
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-3
* @parameter     name supplier name
* @parameter     telephone caontact telephone
* @parameter     country suplier country
* @parameter     province supplier province
* @parameter     city supplier city
* @parameter     contact supplier contact
* @parameter     products supplier support provide products collerction
* @return        ADD_ERROR is add supplier error
*                SUCCESS is add supplier success
*/
int SupplierController::add_supplier(const QString &name, const QString &telephone, const QString &region, const QString &contact,
                                     std::vector<ProvideProduct> &products)
{
    Supplier supplier;
    supplier.setSp_name(name);
    supplier.setSp_phone(telephone);
    supplier.setSp_region(region);
    supplier.setContact(contact);
    int save_supplier_flag = ADD_ERROR, save_product_flag = ADD_ERROR;
    QString sp_id = "";

    save_supplier_flag = supplier_dao.save_suppleir(supplier, sp_id);

    if (SUCCESS == save_supplier_flag)
    {
        if (products.size() != 0)
            save_product_flag = ProvideProductController::add_supplier_product(sp_id, products);
        else
            save_product_flag = SUCCESS;
    }

    if (SUCCESS == save_supplier_flag && SUCCESS == save_product_flag)
    {
        return SUCCESS;
    }
    else
    {
        return ADD_ERROR;
    }
}

/**
* @functionName  remove_supplier
* @Description   Deal with remove supplier request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-3
*/
void SupplierController::remove_supplier()
{
    QJsonArray ids;
    QString id = "";
    int flag = REMOVE_ERROR;

    try
    {
        ids = this->req->get_array("supplier_id");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet reomcve supplier reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!ids.isEmpty())
    {
        int size = ids.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = ids.at(i);

            if (value.isString())
            {
                qDebug() << value.toString();
                id += value.toString() + ",";
            }
        }

        flag =remove_supplier(id);
    }

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("remove supplier success");
    }
    else
    {
        this->resp->set_status_code(REMOVE_ERROR);
        this->resp->set_desc("remove supplier failed");
    }
}

/**
* @functionName  remvove_supplier
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with remove supplier bussiness that change supplier support state
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-3
* @parameter     id supplier id
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is update suppliers information success
*/
int SupplierController::remove_supplier(QString &id)
{
    id.chop(1);
    return supplier_dao.update_supplier_state_stop(id);
}

/**
* @functionName  delete_supplier
* @Description   Deal with delete supplier request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-3
*/
void SupplierController::delete_supplier()
{
    QJsonArray ids;
    QString id = "";
    int flag = DELETE_ERROR;

    try
    {
        ids = this->req->get_array("supplier_id");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet delete supplier reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!ids.isEmpty())
    {
        int size = ids.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = ids.at(i);

            if (value.isString())
            {
                qDebug() << value.toString();
                id += value.toString() + ",";
            }
        }

        flag = delete_supplier(id);
    }

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("delete supplier success");
    }
    else
    {
        this->resp->set_status_code(REMOVE_ERROR);
        this->resp->set_desc("delete supplier failed");
    }
}

/**
* @functionName  delete_supplier
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with delete supplier bussiness that can batch delete supplier.
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-3
* @parameter     id a supplier id are connected using commas
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is delete suppliers success
*                DELETE_ERROR is delete suppliers failed
*/
int SupplierController::delete_supplier(QString &id)
{
    id.chop(1);
    return supplier_dao.delete_supplier_record(id);
}

/**
* @functionName  change_information
* @Description   Deal with change supplier information request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-3
*/
void SupplierController::change_information()
{
    QString id;
    QString name;
    QString phone;
    QString region;
    QString contact;
    int state;
    int flag = CHANGE_ERROR;

    try
    {
        id = this->req->get_string("id");
        name = this->req->get_string("name");
        phone = this->req->get_string("phone");
        region = this->req->get_string("region");
        contact = this->req->get_string("contact");
        state = this->req->get_int("state");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet change supplier information reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    flag = change_information(id, name, phone, region, contact, state);


    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("change supplier information success");
    }
    else
    {
        this->resp->set_status_code(CHANGE_ERROR);
        this->resp->set_desc("change supplier information failed");
    }
}

/**
* @functionName  change_information
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with change information bussiness that can change supplier information.
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-3
* @parameter     id supplier id
* @parameter     name supplier name
* @parameter     telephone caontact telephone
* @parameter     country suplier country
* @parameter     province supplier province
* @parameter     city supplier city
* @parameter     contact supplier contact
* @parameter     state supplier support state
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is update suppliers information success
*/
int SupplierController::change_information(const QString &id, const QString &name, const QString &telephone, const QString &region, const QString &contact, int state)
{
    Supplier supplier;
    supplier.setSp_id(id);
    supplier.setSp_name(name);
    supplier.setSp_phone(telephone);
    supplier.setSp_region(region);
    supplier.setContact(contact);
    supplier.setSp_state(state);
    return supplier_dao.update_supplier_information(supplier);
}

/**
* @functionName  renew_supplier
* @Description   Deal with renew request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-7
*/
void SupplierController::renew_supplier()
{
    QJsonArray ids;
    QString id = "";
    int flag = CHANGE_ERROR;

    try
    {
        ids = this->req->get_array("supplier_id");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet renew supplier reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!ids.isEmpty())
    {
        int size = ids.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = ids.at(i);

            if (value.isString())
            {
                qDebug() << value.toString();
                id += value.toString() + ",";
            }
        }

        flag = renew_supplier(id);
    }

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("renew supplier success");
    }
    else
    {
        this->resp->set_status_code(REMOVE_ERROR);
        this->resp->set_desc("renew supplier failed");
    }
}

/**
* @functionName  renew_supplier
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with renew supplier bussiness that change supplier support state
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-11
* @parameter     id supplier id
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is update suppliers information success
*/
int SupplierController::renew_supplier(QString &id)
{
    id.chop(1);
    return supplier_dao.update_supplier_state_support(id);
}
