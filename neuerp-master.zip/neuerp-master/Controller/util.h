#ifndef UTIL_H
#define UTIL_H
#include <QtNetwork/QHostAddress>
#include <QtNetwork/QAbstractSocket>
#include <QDateTime>

static QString gen_uuid(QString handler_id){
    return QDateTime::currentDateTime().toString("yyyyMMddhhmmss")+handler_id;
}

#endif // UTIL_H
