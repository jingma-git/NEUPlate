#ifndef ALL_CONTROLLER_H
#define ALL_CONTROLLER_H

#include "demo/hellocontroller.h"
#include "Controller/usercontroller.h"
#include "supplier_controller.h"
#include "provide_product_controller.h"
#include "purchase_plan_controller.h"
#include "product_controller.h"
#include "employeecontroller.h"

#endif // ALL_CONTROLLER_H
