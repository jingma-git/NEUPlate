#ifndef PURCHASE_PLAN_CONTROLLER_H
#define PURCHASE_PLAN_CONTROLLER_H
#include <Network/Route/controller.h>
#include "Entity_DAO/purchase_plan_dao.h"
#include "Entity/product_to_buy.h"
#include "entity/purchaseplan.h"
#include "entity/product_to_buy.h"
#include "util.h"
#include "Exception/nullexception.h"

class PurchasePlanController: public Controller
{
    DECLEAR_CONTROLLER(PurchasePlanController)
private:
   void add(PurchasePlan plan);

   PurchasePlan load(QString plan_id); //load all the detail of this plan, including the plan item

   int query(std::vector<PurchasePlan> &plan_list, QString keyword, int &all_results_num,
             QString start, QString end, int state, int page_number,int page_item);

   int query_productsToBuy(std::vector<ProductToBuy> &products, QString keyword,
                                int &all_results_num, bool asc_order,int page,int page_size);
   int load_plan_items(QString plan_id, std::vector<PlanItem> &planItems);
   int update_plan_items(QString plan_id, std::vector<PlanItem> &plan_items);



   void add();
   void load();
   void query();
   void query_productsToBuy();
   void load_plan_items();
   void update_plan_items();
   void update_state();

   PurchasePlanDao planDao;
};

#endif // PURCHASE_PLAN_CONTROLLER_H
