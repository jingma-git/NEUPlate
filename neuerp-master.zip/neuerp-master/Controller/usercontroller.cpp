#include <vector>
#include <map>
#include <QStringList>
#include <QSettings>
#include <QJsonArray>
#include <QTextCodec>
#include "usercontroller.h"
#include "Entity_DAO/userdao.h"
#include "status_code.h"
#include "Exception/nullexception.h"
#include "Entity_DAO/connection_pool.h"

IMPLEMENT_CONSTROLLER_BEGIN(UserController, user)
BIND(change_code, modify_access_code, UserController)
BIND(query_permission, query_access_code, UserController)
BIND(change_passwd, modify_passwd, UserController)
BIND(forget_passwd, find_passwd, UserController)
BIND(query_question, get_security_question, UserController)
BIND(check_question, check_security_question, UserController)
BIND(set_question, set_security_question, UserController)
BIND(security_question, get_all_security_question, UserController)
BIND(new_user, init_user, UserController)
BIND(login, check_user, UserController)
BIND(unfrozen, unfrozen_user, UserController)
BIND(add_state, add_user_state, UserController)
BIND(remove_state, remove_user_state, UserController)
IMPLEMENT_CONTROLLER_END

std::map<QString, int> UserController::login_try;
std::map<QString, User> UserController::logined;
std::map<QString, int> UserController::func_permission;
std::map<QString, QString> UserController::permission_desc;
std::map<QString, int> UserController::permission_set;

/**
* @functionName  add_user
* @Description   add a user info into system
* @author        chenhanlin
* @date          2018-07-04
* @parameter     QString employee_id
* @return        int
*/
int UserController::add_user(const QString &employee_id, const QSqlDatabase &db)
{
    static const QString default_passwd("123456");
    UserDAO dao(db);
    User user(employee_id, default_passwd);
    int code = dao.save_user(user);
    if (SUCCESS == code) return SUCCESS;
    else return ADD_ERROR;
}

/**
* @functionName  remove_user
* @Description   delete a user from system
* @author        chenhanlin
* @date          2018-07-04
* @parameter     QString employee_id
* @return        int
*/
int UserController::remove_user(const QString &employee_id, const QSqlDatabase &db)
{
    UserDAO dao(db);
    int code = dao.delete_user(employee_id);
    if(SUCCESS == code) return SUCCESS;
    else return REMOVE_ERROR;
}

/**
* @functionName  close_user
* @Description   set user status to close
* @author        chenhanlin
* @date          2018-07-04
* @parameter     QString employee_id
* @return        int
*/
int UserController::close_user(const QString &employee_id)
{
    int code = UserController::add_user_state(employee_id, User::USER_CLOSED);
    if(SUCCESS == code) return SUCCESS;
    else return MODIFY_ERROR;
}

/**
* @functionName  reopen_user
* @Description   set user status to normal
* @author        chenhanlin
* @date          2018-07-04
* @parameter     QString employee_id
* @return        int
*/
int UserController::reopen_user(const QString &employee_id)
{
    int code = UserController::remove_user_state(employee_id, User::USER_CLOSED);
    if(SUCCESS == code) return SUCCESS;
    else return MODIFY_ERROR;
}

/**
* @functionName  check_access_code
* @Description   check the user's permission
* @author        chenhanlin
* @date          2018-07-04
* @parameter     int handler_id, int access_code
* @return        bool
*/
bool UserController::check_access_code(const QString &handler_id, const QString &func)
{
    std::map<QString, int>::iterator c_iter = func_permission.find(func);
    if(func_permission.end() == c_iter) return false;
    int code = c_iter->second;
    if(code & 1) return true;
    std::map<QString, User>::iterator iter = logined.find(handler_id);
    if (logined.end() == iter){
        return false;
    }
    if (iter->second.get_access_code() & code){
        return true;
    }else{
        return false;
    }
}

/**
* @functionName  init_access_code
* @Description   read permission from setting and compare with database, if difference, update database
* @author        chenhanlin
* @date          2018-07-04
* @parameter     void
* @return        void
*/
void UserController::init_access_code()
{
    std::map<QString, int> codes_in_db;
    UserDAO dao;
    // read code from database
    int code = dao.query_all_access_code(codes_in_db);
    if(SQL_EXEC_ERROR == code){
        qWarning() << "query access code from db error";
        exit(1);
    }
    qDebug() << "query access code in db";
    bool empty_config = true;
    // read setting from file
    QSettings setting(":/app.ini",QSettings::IniFormat);
    setting.setIniCodec("UTF-8");
    setting.beginGroup("personal permission");
    QStringList codes = setting.childKeys();
    int module_code = 0;
    if(!codes.empty()){
        empty_config = false;
        for(const auto &code : codes){
        UserController::func_permission.insert(std::map<QString,int>::value_type(code, setting.value(code).toInt()));
        module_code |= setting.value(code).toInt();
        }
    }
    setting.endGroup();
    auto sections = setting.childGroups().filter("dept_");
    for(const auto &key : sections){
        setting.beginGroup(key);
        QStringList codes = setting.childKeys();
        module_code = 0;
        if(!codes.empty()){
            empty_config = false;
            for(const auto &code : codes){
                UserController::func_permission.insert(std::map<QString,int>::value_type(code, setting.value(code).toInt()));
                module_code |= setting.value(code).toInt();
            }
        }
        permission_set.insert(std::map<QString, int>::value_type(key, module_code));
        setting.endGroup();
    }
    setting.beginGroup("permission map");
    auto desc = setting.childKeys();
    for(const auto &key : desc){
        auto iter = permission_set.find(key);
        if(permission_set.end() != iter){
            permission_desc.insert(std::map<QString, QString>::value_type(key, setting.value(key).toString()));
        }
    }
    setting.endGroup();
    if(!empty_config){
        qDebug() << "read permission from setting successful";
    }
    // if empty database and empyt config, it will error
    if(EMPTY_SET == code && empty_config){
    // update database
        qCritical() << "lost all permission, user cannot access to system, should config app.ini";
        exit(1);
    }
    // if empty config and not empyt database, use database
    if(empty_config && SUCCESS == code){
        for(const auto &i : codes_in_db){
            UserController::func_permission.insert(std::map<QString,int>::value_type(i.first, i.second));
            return;
        }
    }
    // if only have config and empty database, should reset all user's access code
    if(!empty_config && EMPTY_SET == code){
        int code = reset_all_user_access_code();
        if(SUCCESS == code){
            code = dao.update_all_access_code(func_permission);
            if(SUCCESS != code){
                qWarning() << "update permission database failed";
                exit(1);
            }
            qDebug() << "update db success";
        }
        return;
    }
    // if both no empty and setting has permission and database not have, update database
    // compare code between file and db
    for(const auto &i : func_permission){
        if(codes_in_db.find(i.first) == codes_in_db.end() || codes_in_db[i.first] != i.second){
            code = update_all_access_code(func_permission, codes_in_db);
            if(SUCCESS != code){
                qWarning() << "update permission database failed";
                exit(1);
            }
            qDebug() << "update db and user";
            return;
        }
    }

}

/**
* @functionName  logout
* @Description   user sign out
* @author        chenhanlin
* @date          2018-07-05
* @parameter     int handler_id
* @return        void
*/
void UserController::logout(const QString &handler_id)
{
    std::map<QString, User>::iterator iter = logined.find(handler_id);
    if(logined.end() != iter){
        qDebug() << iter->second.get_e_id() << " logout the system";
        logined.erase(iter);
    }
}

/**
* @functionName  get_logined
* @Description   get the user logined by handler_id
* @author        chenhanlin
* @date          2018-07-05
* @parameter     int handler_id
* @return        void
*/
const User* UserController::get_logined(const QString &handler_id)
{
    std::map<QString, User>::iterator iter = logined.find(handler_id);
    if(logined.end() != iter){
        return &(iter->second);
    }else{
        return nullptr;
    }
}

/**
* @functionName  modify_access_code
* @Description   change user's permission
* @author        chenhanlin
* @date          2018-07-04
* @parameter     void
* @return        void
*/
void UserController::modify_access_code()
{
    // get data
    QString e_id;
    int new_access_code;
    try{
        e_id = req->get_string("e_id");
        new_access_code = req->get_int("access_code");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    UserDAO dao;
    std::vector<User> users;
    // query user
    int code = dao.query_user(e_id, users);

    // if error, handle error
    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(MODIFY_ERROR);
        resp->set_desc("modify access code failed");
        return;
    }else if(EMPTY_SET == code){
        // empty query
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such user");
        return;
    }

    const User *user = UserController::get_logined(this->m_i_handler_id);
    if(user->get_e_id() == e_id || user->get_permission_level() > users[0].get_permission_level()){
        resp->set_status_code(ILLEGAL_ACCESS);
        resp->set_desc("illegal access");
        return;
    }

    // just change a user
    users[0].set_access_code(new_access_code);
    code = dao.save_user(users[0]);

    resp->set_status_code(SUCCESS);
    resp->set_desc("modify access code successful");
}

/**
* @functionName  query_access_code
* @Description       query user's access code
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         void
* @return               void
*/
void UserController::query_access_code()
{
    QString e_id;
    try{
        e_id = req->get_string("e_id");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    UserDAO dao;
    std::vector<User> users;
    int code = dao.query_user(e_id, users);

    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("modify access code failed");
        return;
    }else if(EMPTY_SET == code){
        // empty query
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such user");
        return;
    }

    resp->put("code", users[0].get_access_code());
    resp->set_status_code(SUCCESS);
    resp->set_desc("query user's access code successful");
}

/**
* @functionName  modify_passwd
* @Description   change a user's password
* @author        chenhanlin
* @date          2018-07-04
* @parameter     void
* @return        void
*/
void UserController::modify_passwd()
{
    // get data
    QString e_id;
    QString new_passwd;
    QString old_passwd;
    try{
        e_id = req->get_string("e_id");
        new_passwd = req->get_string("new_passwd");
        old_passwd = req->get_string("old_passwd");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    // if empty, get e_id from userController
    if (e_id.isEmpty()){
        const User *user = UserController::get_logined(this->m_i_handler_id);
        e_id = user->get_e_id();
    }

    UserDAO dao;
    std::vector<User> users;
    // query user
    int code = dao.query_user(e_id, users);
    // if error, handle error
    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(MODIFY_ERROR);
        resp->set_desc("modify password failed");
        return;
    }else if(EMPTY_SET == code){
        // empty query
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such user");
        return;
    }

    // just change a user
    if (users[0].get_passwd() == old_passwd){
        users[0].set_passwd(new_passwd);
        code = dao.save_user(users[0]);
    }else{
        resp->set_status_code(OLD_PASSWD_ERROR);
        resp->set_desc("the origin password is wrong");
        return;
    }

    // handle result code
    if (SUCCESS == code){
        resp->set_status_code(SUCCESS);
        resp->set_desc("password has been updated");
    }else{
        resp->set_status_code(MODIFY_ERROR);
        resp->set_desc("modify password failed");
    }
}

/**
* @functionName  find_passwd
* @Description   change user's password by check security_question
* @author        chenhanlin
* @date          2018-07-04
* @parameter     void
* @return        void
*/
void UserController::find_passwd()
{
    //get data
    QString e_id;
    QString q_id;
    QString answer;
    QString new_passwd;
    try{
        e_id = req->get_string("e_id");
        q_id = req->get_string("q_id");
        answer = req->get_string("answer");
        new_passwd = req->get_string("passwd");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    bool checked = false;
    UserDAO dao;
    std::vector<User> users;

    // query user
    int code = dao.check_security_question(q_id, e_id, answer, checked);
    if (SQL_EXEC_ERROR == code){
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query failed");
    }
    if(!checked){
        resp->set_status_code(WRONG_ANSWER);
        resp->set_desc("wrong answer");
        return;
    }

    code = dao.query_user(e_id, users);
    if(SQL_EXEC_ERROR == code){
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query failed");
        return;
    }else if(EMPTY_SET == code){
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such user");
        return;
    }
    // just change a user
    users[0].set_passwd(new_passwd);
    code = dao.save_user(users[0]);

    if (SQL_EXEC_ERROR == code){
        resp->set_status_code(MODIFY_ERROR);
        resp->set_desc("modify failed");
    }else{
        resp->set_status_code(SUCCESS);
        resp->set_desc("modify successful");
    }
}

/**
* @functionName  get_all_access_code
* @Description   get the permission system now have
* @author        chenhanlin
* @date          2018-07-04
* @parameter     void
* @return        void
*/
void UserController::get_all_access_code()
{
    QJsonObject code_set;
    QJsonObject code_desc;
    for(auto &c : permission_set){
        code_set.insert(c.first, c.second);
    }
    for(const auto &i : permission_desc){
        code_desc.insert(i.first, i.second);
    }
    resp->put("permission_set", code_set);
    resp->put("permission_desc", code_desc);
}

/**
* @functionName  get_security_question
* @Description   get a user's security question
* @author        chenhanlin
* @date          2018-07-04
* @parameter     void
* @return        void
*/
void UserController::get_security_question()
{
    QString e_id;
    try{
        e_id = req->get_string("e_id");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    if(e_id.isEmpty()){
        e_id = UserController::get_logined(this->m_i_handler_id)->get_e_id();
    }
    std::map<QString, QString> questions;
    UserDAO dao;

    int code = dao.query_security_question(questions, e_id);

    if(SQL_EXEC_ERROR == code){
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query failed");
        return;
    }else if(EMPTY_SET == code){
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("user no security questions now");
        return;
    }

    resp->set_status_code(SUCCESS);
    resp->set_desc("query user's security question successful");
    for(const auto &question : questions){
        resp->put(question.first, question.second);
    }
}

/**
* @functionName  check_security_question
* @Description   check if user's security question is correct
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void UserController::check_security_question()
{

    QString e_id;
    QString q_id;
    QString answer;
    try{
        e_id = req->get_string("e_id");
        q_id = req->get_string("q_id");
        answer = req->get_string("answer");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    if(e_id.isEmpty()){
        e_id = UserController::get_logined(this->m_i_handler_id)->get_e_id();
    }

    UserDAO dao;
    bool checked;
    int code = dao.check_security_question(q_id, e_id, answer, checked);
    if(SQL_EXEC_ERROR == code){
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query failed");
        return;
    }

    if (checked){
        // return success
        resp->set_status_code(SUCCESS);
        resp->set_desc("correct answer");
    }else{
        // return error
        resp->set_status_code(WRONG_ANSWER);
        resp->set_desc("error answer");
    }
}

/**
* @functionName  set_security_question
* @Description   set user's security question
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void UserController::set_security_question()
{
    QString e_id;
    QString q_id;
    QString answer;
    QJsonObject j_questions;
    try{
        e_id = req->get_string("e_id");
        j_questions = req->get_json("questions");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    if(e_id.isEmpty()){
        e_id = UserController::get_logined(this->m_i_handler_id)->get_e_id();
    }

    UserDAO dao;
    dao.transaction();

    std::map<QString, QString> questions;

    for (const auto &key : j_questions.keys()) {
        questions.insert(std::map<QString, QString>::value_type(key, j_questions.value(key).toString()));
    }

    // add security question
    int code = dao.update_security_question(questions, e_id);
    if(SQL_EXEC_ERROR == code){
        resp->set_status_code(MODIFY_ERROR);
        resp->set_desc("modify failed");
        dao.rollback();
        return;
    }
    // return success
    resp->set_status_code(SUCCESS);
    resp->set_desc("modify successful");
    dao.commit();
}

/**
* @functionName  get_all_security_question
* @Description   get all security question system can offer
* @author        chenhanlin
* @date          2018-07-04
* @parameter     void
* @return        void
*/
void UserController::get_all_security_question()
{
    UserDAO dao;
    std::map<QString, QString> questions;
    int code = dao.query_all_security_question(questions);

    if(SQL_EXEC_ERROR == code){
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query failed");
        return;
    }else if(EMPTY_QUERY == code){
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no security questions now");
        return;
    }

    for(const auto &question : questions){
        resp->put(question.first, question.second);
    }
    resp->set_status_code(SUCCESS);
    resp->set_desc("query all security question successful");
}

/**
* @functionName  inti_user
* @Description   when user first login, should init first
* @author        chenhanlin
* @date          2018-07-04
* @parameter     void
* @return        void
*/
void UserController::init_user()
{
    QJsonObject j_questions;
    QString passwd;
    QString e_id;
    try{
        j_questions = req->get_json("questions");
        passwd = req->get_string("passwd");
        e_id = req->get_string("e_id");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    std::map<QString, QString> questions;
    std::vector<User> user;
    UserDAO dao;
    dao.transaction();

    for (const auto &key : j_questions.keys()) {
        questions.insert(std::map<QString, QString>::value_type(key, j_questions.value(key).toString()));
    }

    // add security question
    int code = dao.update_security_question(questions, e_id);
    if(SQL_EXEC_ERROR == code){
        resp->set_status_code(MODIFY_ERROR);
        resp->set_desc("modify failed");
        dao.rollback();
        return;
    }
    code = dao.query_user(e_id, user);

    if(SQL_EXEC_ERROR == code){
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query failed");
        dao.rollback();
        return;
    }else if(EMPTY_QUERY == code){
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such user");
        dao.rollback();
        return;
    }

    // update password
    user[0].set_passwd(passwd);
    user[0].set_status(User::USER_NORMAL);
    code = dao.save_user(user[0]);
    if(SQL_EXEC_ERROR == code){
        resp->set_status_code(MODIFY_ERROR);
        resp->set_desc("modify failed");
        dao.rollback();
        return;
    }
    dao.commit();
    resp->set_status_code(SUCCESS);
    resp->set_desc("init user successful");
}

/**
* @functionName  check_user
* @Description   check user's password and if new user, should init first
* @author        chenhanlin
* @date          2018-07-04
* @parameter     void
* @return        void
*/
void UserController::check_user()
{
    QString e_id;
    QString passwd;
    try{
        e_id = req->get_string("e_id");
        passwd = req->get_string("passwd");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    for(const auto & user : logined){
        if(user.second.get_e_id() == e_id){
            resp->set_status_code(LOGINED);
			resp->set_desc("user logined");
			return;
        }
    }
    std::vector<User> user;
    UserDAO dao;
    // query user
    int code = dao.query_user(e_id, user);

    if(SQL_EXEC_ERROR == code){
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query failed");
        return;
    }else if(EMPTY_SET == code){
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such user");
        return;
    }

    int u_state =user[0].get_status();
    if(u_state & User::USER_CLOSED){
        resp->set_status_code(CLOSED);
        resp->set_desc("user is closed");
        return;
    }

    if(u_state & User::USER_FROZN){
        resp->set_status_code(FROZEN);
        resp->set_desc("user is frozen");
        return;
    }

    if(u_state & User::USER_NEW){
        resp->set_status_code(NEW);
        resp->set_desc("user need init");
        return;
    }

    if(u_state & User::USER_NORMAL){
        if(user[0].get_passwd() == passwd){
            // if login, save user, keep connection
            logined.insert(std::map<QString, User>::value_type(m_i_handler_id, user[0]));
            std::map<QString, int>::iterator iter = login_try.find(e_id);
            if(login_try.end() != iter) login_try.erase(iter);
            resp->set_status_code(SUCCESS);
            resp->set_desc("username and password correctly");
            resp->put("code", user[0].get_access_code());
            this->get_all_access_code();
        }else{
        // if not login, record error time
            login_try[e_id]++;
            if(login_try[e_id] >= 3){
                user[0].set_status(User::USER_FROZN | u_state);
                code = dao.save_user(user[0]);
            }
            resp->set_status_code(ERROR_PASSWD);
            resp->set_desc("invaild password");
        }
        return;
    }
}

/**
* @functionName  unforzen_user
* @Description   set user state to normal
* @author        chenhanlin
* @date          2018-07-04
* @parameter     void
* @return        void
*/
void UserController::unfrozen_user()
{
    QString e_id;
    QString q_id;
    QString answer;
    try{
        e_id = req->get_string("e_id");
        q_id = req->get_string("q_id");
        answer = req->get_string("answer");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    UserDAO dao;
    bool checked;
    int code = dao.check_security_question(q_id, e_id, answer, checked);
    if(SQL_EXEC_ERROR == code){
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query failed");
        return;
    }

    if (checked){
        this->remove_user_state(e_id, User::USER_FROZN);
        // return success
        resp->set_status_code(SUCCESS);
        resp->set_desc("correct answer");
    }else{
        // return error
        resp->set_status_code(WRONG_ANSWER);
        resp->set_desc("error answer");
    }
}

/**
* @functionName  remove_user_state
* @Description   remove a user's state
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void UserController::remove_user_state()
{
    QJsonArray e_ids;
    int state;
    try{
        e_ids = req->get_array("e_ids");
        state = req->get_int("state");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    UserDAO dao;
    std::vector<User> users;
    dao.transaction();
    for(const auto &e_id : e_ids){
        users.clear();
        int code = dao.query_user(e_id.toString(), users);

        if(SQL_EXEC_ERROR == code){
            resp->set_status_code(QUERY_ERROR);
            resp->set_desc("query failed");
            return;
        }else if(EMPTY_SET == code){
            resp->set_status_code(EMPTY_QUERY);
            resp->set_desc("no such user");
            return;
        }
        if(!(users[0].get_status() & state)) continue;

        users[0].set_status(state ^ users[0].get_status());
        code = dao.save_user(users[0]);

        if(SQL_EXEC_ERROR == code){
            resp->set_status_code(MODIFY_ERROR);
            resp->set_desc("modify failed");
            dao.rollback();
            return;
        }
    }
    dao.commit();
    resp->set_status_code(SUCCESS);
    resp->set_desc("modify user's state succesdful");
}

/**
* @functionName  add_user_state
* @Description   add a user's state
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void UserController::add_user_state()
{
    QJsonArray e_ids;
    int state;
    try{
        e_ids = req->get_array("e_ids");
        state = req->get_int("state");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    UserDAO dao;
    std::vector<User> users;
    dao.transaction();
    for(const auto &e_id : e_ids){
        users.clear();
        int code = dao.query_user(e_id.toString(), users);

        if(SQL_EXEC_ERROR == code){
            resp->set_status_code(QUERY_ERROR);
            resp->set_desc("query failed");
            return;
        }else if(EMPTY_SET == code){
            resp->set_status_code(EMPTY_QUERY);
            resp->set_desc("no such user");
            return;
        }
        if(users[0].get_status() & state) continue;

        users[0].set_status(state | users[0].get_status());
        code = dao.save_user(users[0]);

        if(SQL_EXEC_ERROR == code){
            resp->set_status_code(MODIFY_ERROR);
            resp->set_desc("modify failed");
            dao.rollback();
            return;
        }
    }
    dao.commit();
    resp->set_status_code(SUCCESS);
    resp->set_desc("modify user's state succesdful");
}

/**
* @functionName  remove user state
* @Description   remove a state from user's state
* @author        chenhanlin
* @date          2018-07-04
* @parameter     QString employee_id, int status
* @return        int
*/
int UserController::remove_user_state(const QString &employee_id, int status)
{
    UserDAO dao;
    std::vector<User> users;
    int code = dao.query_user(employee_id, users);
    if(SUCCESS != code) return code;
    for (auto &user : users){
        user.set_status(status ^ user.get_status());
        code = dao.save_user(user);
        if(SUCCESS != code) return code;
    }
    return code;
}

/**
* @functionName  add user state
* @Description   add a state from user's state
* @author        chenhanlin
* @date          2018-07-04
* @parameter     QString employee_id, int status
* @return        int
*/
int UserController::add_user_state(const QString &employee_id, int status)
{
    UserDAO dao;
    std::vector<User> users;
    int code = dao.query_user(employee_id, users);
    if(SUCCESS != code) return code;
    for (auto &user : users){
        user.set_status(status | user.get_status());
        code = dao.save_user(user);
        if(SUCCESS != code) return code;
    }
    return code;
}

/**
* @functionName  update_all_access_code
* @Description   update user's access code by new code table
* @author        chenhanlin
* @date          2018-07-06
* @parameter     map<QString, int> codes, map<QString, int> old_codes
* @return        int
*/
int UserController::update_all_access_code(const std::map<QString, int> &codes, const std::map<QString, int> &old_codes)
{
    UserDAO dao;
    dao.transaction();
    std::vector<User> users;
    int code = dao.query_all_user(users);
    if(SQL_EXEC_ERROR == code){
        return QUERY_ERROR;
    }
    for(auto &user : users){
        int new_code = 1;
        int user_code = user.get_access_code();
        // set all for admin
        if(user.get_permission_level() <= 1){
            for (const auto &c : codes){
                new_code |= c.second;
            }
        }else{
            for(const auto &old : old_codes){
                if(user_code & old.second){
                    if(codes.find(old.first) != codes.end()){
                        new_code = new_code | codes.at(old.first);
                    }
                }
            }
        }
        user.set_access_code(new_code);
        code = dao.save_user(user);
        if(SQL_EXEC_ERROR == code){
            dao.rollback();
            return MODIFY_ERROR;
        }
    }
    code = dao.update_all_access_code(codes);
    if(SQL_EXEC_ERROR == code){
        dao.rollback();
        return MODIFY_ERROR;
    }
    dao.commit();
    return SUCCESS;
}

/**
* @functionName  rest_all_user_access_code
* @Description   reset all user's access code to 1, it's danger, it usually use in system first use
* @author        chenhanlin
* @date          2018-07-06
* @parameter     void
* @return        int
*/
int UserController::reset_all_user_access_code()
{
    UserDAO dao;
    dao.transaction();
    std::vector<User> users;
    int code = dao.query_all_user(users);
    if(SQL_EXEC_ERROR == code){
        return QUERY_ERROR;
    }
    for(auto &user : users){
        // do not modify admin
        if(user.get_permission_level() > 1){
            user.set_access_code(1);
            code = dao.save_user(user);
            if(SQL_EXEC_ERROR == code){
                dao.rollback();
                return MODIFY_ERROR;
            }
        }
    }
    dao.commit();
    return SUCCESS;
}
