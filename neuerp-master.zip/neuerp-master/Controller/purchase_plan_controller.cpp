#include "purchase_plan_controller.h"

// implement controller,should pass class name and module name, system will invoke by module name
IMPLEMENT_CONSTROLLER_BEGIN(PurchasePlanController, purchase_plan)
// bind the function with function name, system will invoke function by the name, you should pass function_name, actual fucntion name, class name
BIND(add, add, PurchasePlanController)
BIND(load, load, PurchasePlanController)
BIND(query, query, PurchasePlanController)
BIND(query_productsToBuy, query_productsToBuy, PurchasePlanController)
BIND(update_plan_items, update_plan_items, PurchasePlanController)
BIND(load_plan_items, load_plan_items, PurchasePlanController)
BIND(update_state, update_state, PurchasePlanController)
IMPLEMENT_CONTROLLER_END

void PurchasePlanController::add(){
    qDebug()<<"PurchasePlanController::add()";
    QString plan_id;
    QString plan_name;
    QString date;
    QString handler_id;


    try
    {
        date = this->req->get_string("date");
        plan_name = this->req->get_string("plan_name");
        handler_id = this->req->get_string("handler_id");
        plan_id = gen_uuid(handler_id);
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    PurchasePlan plan;
    plan.set_plan_id(plan_id);
    plan.set_name(plan_name);
    plan.set_date(date);
    plan.set_state(1); //1 represent editable
   // qDebug()<<plan.to_string();
    if(planDao.add(plan)){
        this->resp->set_status_code(SUCCESS);
        this->resp->put("plan_info",plan.toJSON());
        this->resp->set_desc("add plan success");
    }else{
        this->resp->set_status_code(SQL_EXEC_ERROR);
    }

}
void PurchasePlanController::load(){
    QString plan_id;
    try
    {
       plan_id = this->req->get_string("plan_id");

    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    PurchasePlan plan = planDao.load(plan_id);
    std::vector<PlanItem> plan_items = plan.get_plan_items();
    QJsonArray plan_array;
    int size = plan_items.size();

    for (int i = 0; i < size; i++)
    {
        QJsonObject list;
        list.insert("plan_id", plan_id);
        list.insert("p_id",  plan_items[i].get_product_id());
        list.insert("sp_id", plan_items[i].get_supplier_id());
        list.insert("amt", plan_items[i].get_amt());
        plan_array.append(list);
    }

    this->resp->put("plan_items", plan_array);

    this->resp->set_status_code(SUCCESS);
    this->resp->set_desc("load plan success");

}


void PurchasePlanController::query(){
   // qDebug()<<".......................................query plans";
    QString keyword;
    QString start_time;
    QString end_time;
    int page,page_size,state,all_results_num;
    try{
        keyword=this->req->get_string("keyword");
        start_time=this->req->get_string("start_time");
        end_time=this->req->get_string("end_time");
        state=this->req->get_int("state");

        page=this->req->get_int("page");
        page_size=this->req->get_int("page_size");


    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

   // qDebug()<<"......................................query plans dao";

    std::vector<PurchasePlan> plans;    
    int result= query(plans,keyword,all_results_num,start_time,end_time,state,page, page_size);
    qDebug()<<"result:"<<result;
    if(result==SUCCESS){
        //查找成功
        QJsonArray plans_json;
        foreach(PurchasePlan plan,plans){
            plans_json.append(plan.toJSON());
        }
       resp->put("plans",plans_json);
       int all_page_num=ceil((double)all_results_num/page_size);
       resp->put("all_page",all_page_num);

       resp->set_status_code(SUCCESS);
    }else if(result==1){
        //没查到
        resp->put("msg","can't find plans in db");
        resp->set_status_code(EMPTY_QUERY);

    }else if(result==2){
        //发生错误
        resp->put("msg","SQL EXEC ERROR");
        resp->set_status_code(SQL_EXEC_ERROR);
    }
}

void PurchasePlanController::query_productsToBuy(){
    qDebug()<<"PurchasePlanController::query_productsToBuy()";
    QString keyword;
    bool asc_order;

    int page,page_size,all_results_num;
    try{
        keyword=this->req->get_string("keyword");
        asc_order=this->req->get_bool("asc_order");
        page=this->req->get_int("page");
        page_size=this->req->get_int("page_size");

    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    std::vector<ProductToBuy> products;
    int result= query_productsToBuy(products,keyword,all_results_num, asc_order,page, page_size);
    qDebug()<<"result:"<<result;
    if(result==SUCCESS){
        //查找成功
        QJsonArray prosToBuy_json;
        foreach(ProductToBuy pro,products){
            prosToBuy_json.append(pro.toJSON());
        }
        qDebug()<<"prosToBuy_json "<<QString::number(prosToBuy_json.size());
       resp->put("prosToBuy",prosToBuy_json);
       int all_page_num=ceil((double)all_results_num/page_size);
       resp->put("all_page",all_page_num);

       resp->set_status_code(SUCCESS);
    }else if(result==1){
        //没查到
        resp->put("msg","can't find available products in db");
        resp->set_status_code(EMPTY_QUERY);

    }else if(result==2){
        //发生错误
        resp->put("msg","SQL EXEC ERROR");
        resp->set_status_code(SQL_EXEC_ERROR);
    }
}

int PurchasePlanController::query_productsToBuy(std::vector<ProductToBuy> &products, QString keyword,
                             int &all_results_num, bool asc_order,int page,int page_size){
    return planDao.query_productsToBuy(products, keyword, all_results_num, asc_order, page, page_size);
}

void PurchasePlanController::update_plan_items(){
    QString plan_id = this->req->get_string("plan_id");
    QJsonArray plan_item_array;
    plan_item_array = this->req->get_array("planItems");

    std::vector<PlanItem> plan_items;
    int size = plan_item_array.size();
    for (int i = 0; i < size; i++)
    {
        QJsonValue value = plan_item_array.at(i);

        if (value.isObject())
        {
            PlanItem item(value.toObject());
            plan_items.push_back(item);
        }
    }

    int feedback = update_plan_items(plan_id, plan_items);
    if(feedback==SUCCESS){
        resp->set_status_code(SUCCESS);
        resp->put("plan_id", plan_id);
    }else if(feedback==SQL_EXEC_ERROR){
        resp->set_status_code(SQL_EXEC_ERROR);
    }
}
void PurchasePlanController::load_plan_items(){
   // qDebug()<<" PurchasePlanController::load_plan_items()";
    QString plan_id = this->req->get_string("plan_id");

    std::vector<PlanItem> plan_items;
    int status = load_plan_items(plan_id, plan_items);

    if(status==SUCCESS && !plan_items.empty()){
        QJsonArray planItems_json;
        foreach(const PlanItem &planItem, plan_items){
            PlanItem p(planItem);
            planItems_json.append(p.toJSON());
        }

        resp->set_status_code(SUCCESS);
        resp->put("plan_id", plan_id);
        resp->put("plan_items", planItems_json);

    }else if(status==SQL_EXEC_ERROR){
        resp->set_status_code(SQL_EXEC_ERROR);
    }else if(plan_items.empty()){
        resp->set_status_code(EMPTY_QUERY);
    }
}

void PurchasePlanController::update_state(){
    QString plan_id = this->req->get_string("plan_id");
    int state = this->req->get_int("state");
    int status = planDao.update_state(plan_id, state);
    resp->set_status_code(SUCCESS);
}

int PurchasePlanController::query
(std::vector<PurchasePlan> &plans, QString keyword, int &all_results_num, QString start_time, QString end_time, int state, int page,int page_size){
   return planDao.query(plans,keyword,all_results_num,start_time,end_time,state,page, page_size);
}


int PurchasePlanController::update_plan_items(QString plan_id, std::vector<PlanItem> &plan_items){
    return planDao.update_plan_items(plan_id, plan_items);
}
int PurchasePlanController::load_plan_items(QString plan_id, std::vector<PlanItem> &plan_items){
    qDebug()<<"PurchasePlanController::load_plan_items(QString plan_id, std::vector<PlanItem> &plan_items)";
    return planDao.load_plan_items(plan_id, plan_items);
}
