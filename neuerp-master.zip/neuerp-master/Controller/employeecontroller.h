#ifndef EMPLOYEECONTROLLER_H
#define EMPLOYEECONTROLLER_H

#include "Network/Route/controller.h"

class EmployeeController : public Controller
{
    DECLEAR_CONTROLLER(EmployeeController)
public:

private:
    void add_employee();
    void modify_employee_base();
    void modify_employee_higher();
    void remove_employee();
    void get_all_employee();
    void get_employee();
    void condition_get_employee();
    void set_employee_state();
};

#endif // EMPLOYEECONTROLLER_H
