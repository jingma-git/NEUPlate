#ifndef PROVIDE_PRODUCT_CONTROLLER_H
#define PROVIDE_PRODUCT_CONTROLLER_H

/**
* @projectName   neuerp_server
* @brief         This class inhernt class Controller that
*                deal with user request from clinet about provide product operation.
* @author        luxijia
* @date          2018-7-4
* @modify_author
* @modify_date
*/
#include <Network/Route/controller.h>
#include <entity/supplier.h>
#include <entity/provide_product.h>
#include <Entity_DAO/supplier_dao.h>
#include <Entity_DAO/provide_product_dao.h>
#include <Exception/nullexception.h>
#include <status_code.h>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>

class ProvideProductController : public Controller
{
    DECLEAR_CONTROLLER(ProvideProductController)
public:
    static int add_supplier_product(const QString &sp_id, std::vector<ProvideProduct> &products);
private:
    void search_product();
    void search_product_by_id();
    void add_provide_product();
    void delete_provide_product();
    void delete_provide_list();
    void change_product_information();
    int search_product(std::vector<ProvideProduct> &products,const QString &keyword, int &all_result_all, int page_mnumber, int page_item);
    int search_product_by_id(const QString &sp_id, std::vector<ProvideProduct> &products);
    int add_provide_product(const QString &sp_id, std::vector<ProvideProduct> &products);
    int delete_provide_product(const QString &sp_id, QString &pp_id);
    int delete_provide_list(QString &sp_id, QString &pp_id);
    int change_product_information(std::vector<ProvideProduct> &products);
    ProvideProductDao provide_product_dao;
};

#endif // PROVIDE_PRODUCT_CONTROLLER_H
