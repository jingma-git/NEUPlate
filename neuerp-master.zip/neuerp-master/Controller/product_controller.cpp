#include "product_controller.h"
#include <QDebug>
#include <QJsonObject>
#include <QJsonArray>
#include "status_code.h"
#include "Exception/nullexception.h"
#include "math.h"
#include "Tool/phototool.h"

IMPLEMENT_CONSTROLLER_BEGIN(ProductController,product)
BIND(add_product,add_product,ProductController)
BIND(update_product,update_product,ProductController)
BIND(change_product_state,change_product_state,ProductController)
BIND(delete_product,delete_product,ProductController)
BIND(valid_product,valid_product,ProductController)
BIND(get_product,get_product,ProductController)
BIND(get_products,get_products,ProductController)
BIND(get_product_by_bar_code,get_product_by_bar_code,ProductController)
IMPLEMENT_CONTROLLER_END




int ProductController::add_product(QString bar_code,QString name, double price,QString description, QString image_URL, int init_state ,int stock_amount)
{
   return product_dao.add_product(bar_code, name, price,description, image_URL, init_state,stock_amount);
}



int ProductController::update_product(QString p_id,QString bar_code,QString name, double price, QString image_URL, QString description, int state,int stock_amount)
{
     return  product_dao.update_product(p_id,bar_code,name,price,description,image_URL,state,stock_amount);
}

int ProductController::change_product_state(std::vector<QString> product_ids, int state)
{
    return product_dao.change_product_state(state,product_ids);
}

int ProductController::delete_product(QString product_id)
{
    return product_dao.delete_product(product_id);
}

int ProductController::valid_product(QString product_id)
{
    //返回0，则有效，返回1，无效。返回3：连接错误
    Product tmp_product;
    return product_dao.query_product(tmp_product,product_id);
}

int ProductController::get_product(Product &product, QString product_id)
{
    return product_dao.query_product(product,product_id);
}

int ProductController::get_product_by_bar_code(Product &product, QString bar_code)
{
    int result=product_dao.query_product_by_bar_code(product,bar_code);
    return result;
}

int ProductController::get_products(std::vector<Product> &products, QString keyword, int &all_results_num,
                       double lowest_price, double highest_price,int order_by_price,
                       int low_stock, int high_stock, int order_by_stock,
                       int page, int page_size, int state)
{
    return product_dao.query_products(products, keyword,all_results_num, lowest_price,highest_price,order_by_price,
    low_stock,high_stock,order_by_stock,
    page,page_size,state);
}


void ProductController::update_product()
{

    qDebug()<<"update product";
    QString p_id;
    QString product_name;
    QString bar_code;
    QString description;
    QString photo;
    double price;
    int state;
    int stock_amount;
    try{
        p_id=req->get_string("p_id");
        product_name=req->get_string("name");
        bar_code=req->get_string("bar_code");
        description=req->get_string("description");
        photo=req->get_string("photo");
        price=req->get_double("price");
        state =req->get_int("state");
        stock_amount=req->get_int("stock_amount");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    QString img_url = PhotoTool::save_photo(photo);
    int result=update_product(p_id,bar_code,product_name,price,img_url,description,state,stock_amount);

    if(result==SUCCESS){
        //成功
        resp->put("msg","update product success");
        resp->set_status_code(SUCCESS);

    }else if(result==BAR_CODE_ERROR){
        resp->set_status_code(BAR_CODE_ERROR);
        resp->put("msg","bar code conflic");

    }else{
        //失败
        resp->set_status_code(SQL_EXEC_ERROR);
        resp->put("msg","update product fail");
    }


    qDebug()<<"update_product\n";
}

void ProductController::add_product()
{
    qDebug()<<"add_product\n";
    QString product_name;
    QString bar_code;
    QString description;
    QString photo;
    double price;
    int state;
    int stock_amount;
    try{
        product_name=req->get_string("name");
        bar_code=req->get_string("bar_code");
        description=req->get_string("description");
        photo=req->get_string("photo");
        price=req->get_double("price");
        state =req->get_int("state");
        stock_amount=req->get_int("stock_amount");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    QString img_url = PhotoTool::save_photo(photo);

    int result=add_product(bar_code,product_name,price,description,img_url,state,stock_amount);
    if(result==SUCCESS){
        //成功
        resp->set_status_code(SUCCESS);
        resp->put("msg","add product success");
    }else if(result==BAR_CODE_ERROR){
        resp->set_status_code(BAR_CODE_ERROR);
        resp->put("msg","bar code conflict");
    }
    else{
        //失败
        resp->set_status_code(SQL_EXEC_ERROR);
        resp->put("msg","add fail");
    }
}

void ProductController::change_product_state()
{
    qDebug()<<"change state";
    QJsonArray product_ids_json;
    std::vector<QString> product_ids;
    int state;
    try{
        product_ids_json=req->get_array("p_ids");
        state=req->get_int("state");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    if(state!=0 && state!=1){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("state illegal");
        return ;
        
    }

    foreach (const QVariant &product_id, product_ids_json) {
        product_ids.push_back(product_id.toString());
    }
    int result=change_product_state(product_ids,state);
    if(result==SUCCESS){
        //成功
        resp->set_status_code(SUCCESS);
        resp->set_desc("successly change state");
    }else{
        //失败
        resp->put("msg","change state failed");
        resp->set_status_code(SQL_EXEC_ERROR);
    }

    qDebug()<<"change_product_state\n";
}

void ProductController::delete_product()
{

    qDebug()<<"delete_product\n";
    QString product_id;
    try{
        product_id=req->get_string("p_id");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    qDebug()<<"p_id"<<product_id;
    int result=delete_product(product_id);
    if(result==SUCCESS){
        resp->set_status_code(SUCCESS);
        resp->set_desc("delete success");

    }else if(result==STOCK_NOT_EMPTY){
        resp->set_status_code(STOCK_NOT_EMPTY);
        resp->set_desc("stock not empty");
    }
    else{
        resp->set_status_code(SQL_EXEC_ERROR);
        resp->set_desc("delete failed");
    }

}

void ProductController::valid_product()
{

    qDebug()<<"valid_product\n";
    QString product_id;

    try{
        product_id=req->get_string("product_id");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    int result=valid_product(product_id);
    if(result==SUCCESS){
        //有效
        resp->put("valid",true);
    }else if(result==P_ID_NOT_FIND){
        resp->put("valid",false);
    }else if(result==SQL_EXEC_ERROR){
        //连接错误
        resp->set_desc("sql error");
    }
    resp->set_status_code(result);
}

void ProductController::get_product_by_bar_code()
{

    
    qDebug()<<"get_product by bar_code\n";
    QString bar_code;
    try{
          bar_code=this->req->get_string("bar_code");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    qDebug()<<"bar_code:"<<bar_code<<"\n";
    Product product;
    int result=product_dao.query_product_by_bar_code(product,bar_code);
    qDebug()<<result<<"\n";
    if(result==0){
        //成功
        resp->put("product",product.toJSON());
        resp->set_status_code(SUCCESS);

    }else if(result==1){
        //
        resp->set_status_code(EMPTY_QUERY);
        resp->put("msg","not find this id in db");
    }else if(result==2){
        //错误
        resp->set_status_code(SQL_EXEC_ERROR);
        resp->put("msg","db error");
    }
}

void ProductController::get_product()
{

    qDebug()<<"get_product by p_id\n";
    QString product_id;
    try{
          product_id=this->req->get_string("product_id");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    qDebug()<<"p_id:"<<product_id<<"\n";
    Product product;
    int result=product_dao.query_product(product,product_id);
    qDebug()<<"result:"<<result<<"\n";
    if(result==0){
        //成功
        resp->put("product",product.toJSON());
        resp->set_status_code(SUCCESS);

    }else if(result==1){
        //
        resp->set_status_code(EMPTY_QUERY);
        resp->put("msg","not find this id in db");
    }else if(result==2){
        //错误
        resp->set_status_code(SQL_EXEC_ERROR);
        resp->put("msg","db error");
    }
}

void ProductController::get_products()
{

    qDebug()<<"get_products";
    QString keyword;
    double lowest_price,highest_price;
    int order_by_price,order_by_stock;
    int lowest_stock,highest_stock;
    int page,page_size,state,all_results_num;
    try{
        keyword=this->req->get_string("keyword");

        lowest_price=this->req->get_double("lowest_price");
        highest_price=this->req->get_double("highest_price");
        order_by_price=this->req->get_int("order_by_price");

        lowest_stock=this->req->get_double("lowest_stock");
        highest_stock=this->req->get_double("highest_stock");
        order_by_stock=this->req->get_int("order_by_stock");

        page=this->req->get_int("page");
        page_size=this->req->get_int("page_size");
        state=this->req->get_int("state");

    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    qDebug()<<"get_products";

    std::vector<Product> products;
    int result= get_products(products,keyword,all_results_num,
    lowest_price,highest_price,order_by_price,
    lowest_stock,highest_stock,order_by_stock,
    page,page_size,state);
    if(result==SUCCESS){
        //查找成功
        QJsonArray products_json;
        foreach(Product product,products){
            products_json.append(product.toJSON());
        }
       resp->put("products",products_json);
       int all_page_num=ceil((double)all_results_num/page_size);
       resp->put("all_page",all_page_num);

       resp->set_status_code(SUCCESS);
    }else if(result==SQL_EXEC_ERROR){
        //发生错误
        resp->set_desc("SQL EXEC ERROR");
        resp->set_status_code(SQL_EXEC_ERROR);
    }
}
