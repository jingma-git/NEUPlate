#ifndef SALE_CONTROLLER_H
#define SALE_CONTROLLER_H

/**
* @projectName   enuerp
* @brief         This class inhernt class Controller that
*                deal with user request from clinet about supplier operation.
* @author        luxijia
* @date          2018-7-5
* @modify_author
* @modify_date
*/
#include <Network/Route/controller.h>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>
#include <QtDebug>
#include <QDateTime>
#include <QtGlobal>
#include <Exception/nullexception.h>
#include "entity/sale_list.h"
#include "entity/sale_item.h"
#include "Entity_DAO/sale_dao.h"

class SaleController : public Controller
{
    DECLEAR_CONTROLLER(SaleController)
private:
    void add_sale();
    void delete_sales();
    void search_sales();
    void search_sale_item();
    void cancle_sale();
    int add_sale(const QString &date, const QString &client_name, const QString &client_address,
                 const QString &client_phone, const QString &salesman, const QString &handler_id,
                 const QString &remark, std::vector<SaleItem> &items);
    int delete_sales(QString& sale_id);
    int search_sales(std::vector<SaleList> &sale_list, int &all_result_num , const QString &keyword, const QString &start_time,
                     const QString &end_time, int page_number, int page_item, int state);
    int search_sale_item(std::vector<SaleItem> &sale_item,const QString &sale_id);
    int cancle_sale(QString &sale_id);
    SaleDao sale_dao;
};

#endif // SALE_CONTROLLER_H
