#include "statistics_controller.h"
#include <QJsonArray>
#include <QJsonObject>
#include <QDateTime>
#include <QStringList>


IMPLEMENT_CONSTROLLER_BEGIN(StatisticsController, statistics)
BIND(statistics,statistics, StatisticsController)

IMPLEMENT_CONTROLLER_END



void StatisticsController::statistics()
{

    //商品

    QDateTime end_m=QDateTime::currentDateTime();
    QDateTime start_m=end_m.addDays(-29);
//    QDateTime start_m=QDateTime::fromTime_t(end_m.toTime_t()-60*60*24*29);

    //7天内商品
    QStringList product_name_week;
    QStringList product_id_week;
    QStringList product_volume_week;


    int result_product_week=statistics_dao.top_product_week(
                product_id_week,product_name_week,product_volume_week);
    if(result_product_week==SQL_EXEC_ERROR){
        resp->set_status_code(SQL_EXEC_ERROR);
        return;
    }


    resp->put("top_product_week_name",QJsonArray::fromStringList( product_name_week));
    resp->put("top_product_week_volume",QJsonArray::fromStringList(product_volume_week));


    //30天内
    QStringList product_name_month;
    QStringList product_id_month;
    QStringList product_volume_month;

    int reuslt_product_month=statistics_dao.top_product_month(
                product_id_month,product_name_month,product_volume_month);
    if(reuslt_product_month==SQL_EXEC_ERROR){
        resp->set_status_code(SQL_EXEC_ERROR);
        return;
    }
    resp->put("top_product_month_name",QJsonArray::fromStringList(product_name_month));
    resp->put("top_product_month_volume",QJsonArray::fromStringList(product_volume_month));

    //商品趋势
    QJsonArray product_trend_volume;
    QJsonArray product_trend_date;
    QStringList a_trend;
    QStringList a_date;
    QStringList a_trend_completed;
    QStringList a_date_completed;
    for(int i=0;i<product_id_month.size();i++){
        a_trend_completed.clear();
        a_date_completed.clear();
        a_trend.clear();
        a_date.clear();
        int result_product_trend=statistics_dao.top_product_trend(
                    product_id_month.at(i),a_trend,a_date);
        if(result_product_trend==SQL_EXEC_ERROR){
            resp->set_status_code(SQL_EXEC_ERROR);
            return;
        }
        complete_date(a_trend,a_date,start_m.toString("yyyy-MM-dd"),end_m.toString("yyyy-MM-dd")
                      ,a_trend_completed,a_date_completed);

        product_trend_volume.append(QJsonArray::fromStringList(a_trend_completed));
        product_trend_date.append(QJsonArray::fromStringList(a_date_completed));

    }

    //还需要对空缺的日期处理,时间间隔是一天


    resp->put("top_product_month_trend_volume",product_trend_volume);
    resp->put("top_product_month_trend_date",QJsonArray::fromStringList(a_date_completed));


    //销售员7天
    QStringList salesman_name_week;
    QStringList salesman_saleroom_week;


    int result_salesman_week=statistics_dao.top_salesman_week(
                salesman_name_week,salesman_saleroom_week);
    if(result_salesman_week==SQL_EXEC_ERROR){
        resp->set_status_code(SQL_EXEC_ERROR);
        return;
    }
    resp->put("top_salesman_week_name",QJsonArray::fromStringList(salesman_name_week));
    resp->put("top_salesman_week_saleroom",QJsonArray::fromStringList(salesman_saleroom_week));


    //销售员30天
    QStringList salesman_name_month;
    QStringList salesman_saleroom_month;

    int result_salesman_month=statistics_dao.top_salesman_month(
                salesman_name_month,salesman_saleroom_month);
    if(result_salesman_month==SQL_EXEC_ERROR){
        resp->set_status_code(SQL_EXEC_ERROR);
        return;
    }
    resp->put("top_salesman_month_name",QJsonArray::fromStringList(salesman_name_month));
    resp->put("top_salesman_month_saleroom",QJsonArray::fromStringList(salesman_saleroom_month));




    //销售员趋势
    QJsonArray salesman_trend_saleroom;
    QJsonArray salesman_trend_date;

    QStringList a_trend_saleroom;
    QStringList a_trend_date;
    QStringList a_trend_saleroom_completed;
    QStringList a_trend_date_completed;

    for(int i=0;i<salesman_name_month.size();i++){
        a_trend_saleroom_completed.clear();
        a_trend_date_completed.clear();
        a_trend_saleroom.clear();
        a_trend_date.clear();


        int result_salesman_trend=statistics_dao.top_salesman_trend(
                    salesman_name_month.at(i),a_trend_saleroom,a_trend_date);
        if(result_salesman_trend==SQL_EXEC_ERROR){
            resp->set_status_code(SQL_EXEC_ERROR);
            return;
        }
        complete_date(a_trend_saleroom,a_trend_date,start_m.toString("yyyy-MM-dd"),
                      end_m.toString("yyyy-MM-dd"),a_trend_saleroom_completed,a_trend_date_completed);
        salesman_trend_saleroom.append(QJsonArray::fromStringList(a_trend_saleroom_completed));
        salesman_trend_date.append(QJsonArray::fromStringList(a_trend_date_completed));
    }
    //还需要对空缺的日期处理，时间间隔是1天

    resp->put("top_salesman_month_trend_date",QJsonArray::fromStringList(a_trend_date_completed));
    resp->put("top_salesman_month_trend_saleroom",salesman_trend_saleroom);







    //年趋势
    QStringList saleroom_year_saleroom;
    QStringList saleroom_year_date;

    int result_saleroom_year=statistics_dao.total_saleroom_year(
                saleroom_year_saleroom,saleroom_year_date);
    if(result_saleroom_year==SQL_EXEC_ERROR){
        resp->set_status_code(SQL_EXEC_ERROR);
        return;
    }
    QStringList saleroom_year_saleroom_completed;
    QStringList saleroom_year_date_completed;

    //这里可能有坑
    QDateTime start_y=QDateTime::fromString(QDateTime::currentDateTime().toString("yyyy"),"yyyy");
    complete_date(saleroom_year_saleroom,saleroom_year_date,start_y.toString("yyyy-MM"),"",
                  saleroom_year_saleroom_completed,saleroom_year_date_completed,'M');


    //还需要对空缺的日期处理，间隔是一个月

    resp->put("total_saleroom_year_saleroom",QJsonArray::fromStringList(saleroom_year_saleroom_completed));
    resp->put("total_saleroom_year_date",QJsonArray::fromStringList(saleroom_year_date_completed));

    //30天趋势
    QStringList saleroom_month_saleroom;
    QStringList saleroom_month_date;



    int result_saleroom_month=statistics_dao.total_saleroom_month(
                saleroom_month_saleroom,saleroom_month_date);

    if(result_saleroom_month==SQL_EXEC_ERROR){
        resp->set_status_code(SQL_EXEC_ERROR);
        return;
    }
    //还需要对空缺的日期处理，间隔是1天
    QStringList saleroom_month_saleroom_completed;
    QStringList saleroom_month_date_completed;

    complete_date(saleroom_month_saleroom,saleroom_month_date,
                  start_m.toString("yyyy-MM-dd"),end_m.toString("yyyy-MM-dd"),
                  saleroom_month_saleroom_completed,saleroom_month_date_completed);

    resp->put("total_saleroom_month_date",QJsonArray::fromStringList(saleroom_month_date_completed));
    resp->put("total_saleroom_month_saleroom",QJsonArray::fromStringList(saleroom_month_saleroom_completed));

    resp->set_status_code(SUCCESS);


}

void StatisticsController::complete_date(const QStringList &origin_string, const QStringList &origin_date,
                                         const QString start, const QString end, QStringList &output_string,
                                         QStringList &output_date, QChar interval)
{
    if('d'==interval){
        QDateTime start_time=QDateTime::fromString(start,"yyyy-MM-dd");
        QDateTime end_time=QDateTime::fromString(end,"yyyy-MM-dd");
        QString end_string=end_time.addDays(1).toString("yyyy-MM-dd");
        int i=0;
        for(QDateTime cur_time=start_time;cur_time.toString("yyyy-MM-dd")!=end_string;cur_time=cur_time.addDays(1)){
            output_date.append(cur_time.toString("MM-dd"));
            if(i<origin_date.size()&&origin_date.at(i)==cur_time.toString("yyyy-MM-dd")){
                output_string.append(origin_string.at(i));
                i++;
            }else{
                output_string.append(QString::number(0));
            }
        }
    }else{
        //interval=month
        QDateTime start_time=QDateTime::fromString(start,"yyyy-MM");
        QString year_string=start_time.toString("yyyy");
        int i=0;

        for(QDateTime cur_time=start_time;cur_time.toString("yyyy")==year_string;cur_time=cur_time.addMonths(1)){
            output_date.append(cur_time.toString("MM"));
            if(i<origin_date.size()&&origin_date.at(i)==cur_time.toString("yyyy-MM")){
                output_string.append(origin_string.at(i));
                i++;
            }else{
                output_string.append(QString::number(0));
            }

        }
    }


}
