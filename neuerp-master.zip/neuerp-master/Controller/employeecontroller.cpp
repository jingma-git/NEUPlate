#include "employeecontroller.h"
#include "Entity_DAO/employeedao.h"
#include <QFile>
#include <QDataStream>
#include <QJsonArray>
#include "Controller/usercontroller.h"
#include <QSqlDatabase>
#include "entity/employee.h"
#include "entity/user.h"
#include "entity/employeeuser.h"
#include "Exception/nullexception.h"
#include "Entity_DAO/connection_pool.h"
#include "Tool/phototool.h"
#include <QDate>
#include <QUuid>

IMPLEMENT_CONSTROLLER_BEGIN(EmployeeController, employee)
BIND(add_employee, add_employee, EmployeeController)
BIND(modify_part, modify_employee_base, EmployeeController)
BIND(modify_all, modify_employee_higher, EmployeeController)
BIND(remove_employee, remove_employee, EmployeeController)
BIND(query_employees, get_all_employee, EmployeeController)
BIND(query_employee, get_employee, EmployeeController)
BIND(condition_query, condition_get_employee, EmployeeController)
BIND(change_state, set_employee_state, EmployeeController)
IMPLEMENT_CONTROLLER_END


/**
* @functionName  add_employee
* @Description   get data from request and add a new employee in the system, create a user for this employee
* @author        chenhanlin
* @date          2018-07-02
* @parameter     void
* @return        void
*/
void EmployeeController::add_employee()
{
    QString name;
    QString dept;
    QString position;
    Gender gender;
    QDate birthday;
    QString birth_place;
    QString nation;
    bool married;
    QString political_status;
    Education education;
    QString id;
    QString address;
    QString telephone;
    QString email;
    QString photo_data_base64;
    QString emergency_contact_name;
    QString emergency_contact_phone;
    QString emergency_contact_address;
    try{
        // get data from request
        name = req->get_string("name");
        dept = req->get_string("department");
        position = req->get_string("position");
        gender = Gender(req->get_int("gender"));
        birthday = QDate(req->get_int("year"), req->get_int("month"), req->get_int("day"));
        birth_place = req->get_string("birth_place");
        nation = req->get_string("nation");
        married = req->get_int("married");
        political_status = req->get_string("political_status");
        education = Education(req->get_int("education"));
        id = req->get_string("id");
        address = req->get_string("address");
        telephone = req->get_string("telephone");
        email = req->get_string("email");

        // save the photo
        photo_data_base64 = req->get_string("photo");

        emergency_contact_name = req->get_string("e_c_name");
        emergency_contact_phone = req->get_string("e_c_phone");
        emergency_contact_address = req->get_string("e_c_address");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    qDebug() << "get employee data successful";
    QString photo_path(PhotoTool::save_photo(photo_data_base64));
    qDebug() << "save photo successful";

    // constructor employee
    Employee employee(name, dept, position, gender, birthday, birth_place,
                      nation, married, political_status, education,
                      id, address, telephone, email, photo_path, emergency_contact_name,
                      emergency_contact_phone, emergency_contact_address);

    // save employee
    EmployeeDAO e_dao;
    e_dao.transaction();
    int code = e_dao.save_employee(employee);
    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(ADD_ERROR);
        resp->set_desc("add employee failed");
        qDebug() << "save employee faile";
        e_dao.rollback();
        return;
    }
    // add user
    code = UserController::add_user(employee.get_e_id(), e_dao.get_connection());
    if(ADD_ERROR == code){
//        e_dao.delete_employee(employee.get_e_id());
        resp->set_status_code(ADD_ERROR);
        resp->set_desc("add employee failed");
        qDebug() << "add user failed";
        e_dao.rollback();
        return;
    }
    //build response
    e_dao.commit();
    resp->set_status_code(SUCCESS);
    resp->set_desc("add employee successful");
    resp->put("e_id", employee.get_e_id());
}

/**
* @functionName  modify_employee_base
* @Description   change employee's basic infomation
* @author        chenhanlin
* @date          2018-07-05
* @parameter     void
* @return        void
*/
void EmployeeController::modify_employee_base()
{
    QString e_id;
    QDate birthday;
    QString birth_place;
    QString nation;
    Gender gender;
    bool married;
    QString political_status;
    Education education;
    QString address;
    QString telephone;
    QString email;
    QString emergency_contact_name;
    QString emergency_contact_phone;
    QString emergency_contact_address;
    try{
        // get data from request
        e_id = req->get_string("e_id");
        birthday = QDate(req->get_int("year"), req->get_int("month"), req->get_int("day"));
        birth_place = req->get_string("birth_place");
        nation = req->get_string("nation");
        gender = Gender(req->get_int("gender"));
        married = req->get_int("married");
        political_status = req->get_string("political_status");
        education = Education(req->get_int("education"));
        address = req->get_string("address");
        telephone = req->get_string("telephone");
        email = req->get_string("email");

        emergency_contact_name = req->get_string("e_c_name");
        emergency_contact_phone = req->get_string("e_c_phone");
        emergency_contact_address = req->get_string("e_c_address");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    // query employee
    EmployeeDAO e_dao;
    std::vector<Employee> employees;
    int code = e_dao.query_employee(e_id, employees);
    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query employee failed");
        return;
    }else if(EMPTY_SET == code){
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such employee");
        return;
    }
    // modify employee
    Employee &employee = employees[0];
    employee.set_birthday(birthday);
    employee.set_birth_place(birth_place);
    employee.set_nation(nation);
    employee.set_married(married);
    employee.set_political_status(political_status);
    employee.set_education(education);
    employee.set_address(address);
    employee.set_telephone(telephone);
    employee.set_email(email);
    employee.set_gender(gender);
    employee.set_emergency_contact_name(emergency_contact_name);
    employee.set_emergency_contact_phone(emergency_contact_phone);
    employee.set_emergency_contact_address(emergency_contact_address);

    // save employee
    code = e_dao.save_employee(employee);
    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(MODIFY_ERROR);
        resp->set_desc("modify employee failed");
        return;
    }

    //build response
    resp->set_status_code(SUCCESS);
    resp->set_desc("modify employee successful");
}

/**
* @functionName  modify_employee_higher
* @Description   can modify a employee's all information
* @author        chenhanlin
* @date          2018-07-05
* @parameter     void
* @return        void
*/
void EmployeeController::modify_employee_higher()
{
    QString e_id;
    QString name;
    QString dept;
    QString position;
    Gender gender;
    QDate birthday;
    QString birth_place;
    QString nation;
    bool married;
    QString political_status;
    Education education;
    QString id;
    QString address;
    QString telephone;
    QString email;
    QString photo_data_base64;
    QString emergency_contact_name;
    QString emergency_contact_phone;
    QString emergency_contact_address;
    try{
        // get data from request
        e_id = req->get_string("e_id");
        name = req->get_string("name");
        dept = req->get_string("department");
        position = req->get_string("position");
        gender = Gender(req->get_int("gender"));
        birthday = QDate(req->get_int("year"), req->get_int("month"), req->get_int("day"));
        birth_place = req->get_string("birth_place");
        nation = req->get_string("nation");
        married = req->get_int("married");
        political_status = req->get_string("political_status");
        education = Education(req->get_int("education"));
        id = req->get_string("id");
        address = req->get_string("address");
        telephone = req->get_string("telephone");
        email = req->get_string("email");

        // save the photo
        photo_data_base64 = req->get_string("photo");

        emergency_contact_name = req->get_string("e_c_name");
        emergency_contact_phone = req->get_string("e_c_phone");
        emergency_contact_address = req->get_string("e_c_address");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
//    QString photo_path(save_photo(photo_data_base64));

    // query employee
    EmployeeDAO e_dao;
    std::vector<Employee> employees;
    int code = e_dao.query_employee(e_id, employees);
    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query employee failed");
        return;
    }else if(EMPTY_SET == code){
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such employee");
        return;
    }
    // modify employee
    Employee &employee = employees[0];
    employee.set_name(name);
    employee.set_department(dept);
    employee.set_position(position);
    employee.set_gender(gender);
    employee.set_birthday(birthday);
    employee.set_birth_place(birth_place);
    employee.set_nation(nation);
    employee.set_married(married);
    employee.set_political_status(political_status);
    employee.set_education(education);
    employee.set_id(id);
    employee.set_address(address);
    employee.set_telephone(telephone);
    employee.set_email(email);
    employee.set_emergency_contact_name(emergency_contact_name);
    employee.set_emergency_contact_phone(emergency_contact_phone);
    employee.set_emergency_contact_address(emergency_contact_address);
    if(!PhotoTool::check_photo(employee.get_photo_path(), photo_data_base64)){
        // delete orgin
        PhotoTool::delete_photo(employee.get_photo_path());
        // save photo
        employee.set_photo_path(PhotoTool::save_photo(photo_data_base64));
    }

    // save employee
    code = e_dao.save_employee(employee);
    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(MODIFY_ERROR);
        resp->set_desc("modify employee failed");
        return;
    }

    //build response
    resp->set_status_code(SUCCESS);
    resp->set_desc("modify employee successful");
}

/**
* @functionName  remove_employee
* @Description   remove employees by e_id
* @author        chenhanlin
* @date          2018-07-05
* @parameter     void
* @return        void
*/
void EmployeeController::remove_employee()
{
    QJsonArray e_ids;
    try{
        e_ids = req->get_array("e_id");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    EmployeeDAO dao;
    dao.transaction();
    for(const auto id : e_ids){
        QString e_id(id.toString());
        if (e_id.isEmpty()){
            resp->set_status_code(ERROR_PARAMS);
            resp->set_desc("invaild parameter");
            return;
        }
        int code = UserController::remove_user(e_id, dao.get_connection());
        if(REMOVE_ERROR == code){
            resp->set_status_code(REMOVE_ERROR);
            resp->set_desc("remove user failed");
            qDebug() << "remove user failed";
            dao.rollback();
            return;
        }
        code = dao.delete_employee(e_id);
        if(SQL_EXEC_ERROR == code || REMOVE_ERROR == code){
            // excute sql error
            resp->set_status_code(REMOVE_ERROR);
            resp->set_desc("remove employee failed");
            qDebug() << "remove employee failed";
            return;
        }
    }
    dao.commit();
    resp->set_status_code(SUCCESS);
    resp->set_desc("delete employee success");
}

/**
* @functionName  get_all_employee()
* @Description   query employees
* @author        chenhanlin
* @date          2018-07-05
* @parameter     void
* @return        void
*/
void EmployeeController::get_all_employee()
{
    int page_num;
    int item_num;
    try{
        page_num = req->get_int("page");
        item_num = req->get_int("item");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    EmployeeDAO dao;
    std::vector<Employee> employees;
    int code = dao.query_all_employee(employees, page_num, item_num);
    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query employee failed");
        return;
    }else if(EMPTY_SET == code){
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such employee");
        return;
    }
    for(const auto &employee : employees){
        resp->put(employee.get_e_id(), employee.to_json());
    }
    resp->set_status_code(SUCCESS);
    resp->set_desc("query successful");
}

/**
* @functionName  get_employee
* @Description   query employee by keyword
* @author        chenhanlin
* @date          2018-07-05
* @parameter     void
* @return        void
*/
void EmployeeController::get_employee()
{
    QString keyword;
    int page_num;
    int item_num;
    try{
        keyword = req->get_string("keyword");
        page_num = req->get_int("page");
        item_num = req->get_int("item");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }
    EmployeeDAO dao;
    std::vector<Employee> employees;
    int code = dao.query_employee(keyword, employees);
    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query employee failed");
        return;
    }else if(EMPTY_SET == code){
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such employee");
        return;
    }
    for(const auto &employee : employees){
        resp->put(employee.get_e_id(), employee.to_json());
    }
    resp->set_status_code(SUCCESS);
    resp->set_desc("query successful");
}

/**
* @functionName  condition_get_employee
* @Description   get employee and user's basic information by some condition
* @author        chenhanlin
* @date          2018-07-11
* @parameter     void
* @return        void
*/
void EmployeeController::condition_get_employee()
{
    QString keyword;
    QString dept;
    employee_state e_state;
    int u_state;
    Gender gender;
    bool has_e_state;
    bool has_u_state;
    bool has_gender;
    int page;
    int item;
    try{
        keyword = req->get_string("keyword");
        dept = req->get_string("dept");
        e_state = employee_state(req->get_int("e_state"));
        u_state = req->get_int("u_state");
        gender = Gender(req->get_int("gender"));
        has_e_state = req->get_bool("has_e_state");
        has_u_state = req->get_bool("has_u_state");
        has_gender = req->get_bool("has_gender");
        page = req->get_int("page");
        item = req->get_int("item");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    EmployeeDAO dao;
    std::vector<EmployeeUser> users;
    QJsonArray e_u;
    int total;
    int code = dao.query_employee(total, users, page, item, keyword, e_state, has_e_state, u_state, has_u_state, dept, gender, has_gender);

    if(SQL_EXEC_ERROR == code){
        // excute sql error
        resp->set_status_code(QUERY_ERROR);
        resp->set_desc("query employee failed");
        return;
    }else if(EMPTY_SET == code){
        resp->set_status_code(EMPTY_QUERY);
        resp->set_desc("no such employee");
        return;
    }
    for(const auto &user : users){
        e_u.push_back(user.to_json());
    }
    resp->put("users", e_u);
    resp->put("total", total);
    resp->set_status_code(SUCCESS);
    resp->set_desc("query successful");
}

/**
* @functionName  set_employee_state
* @Description   set employee state
* @author        chenhanlin
* @date          2018-07-05
* @parameter     void
* @return        void
*/
void EmployeeController::set_employee_state()
{
    QJsonObject e_ids;
    try{
        e_ids = req->get_json("e_ids");
    }catch(NullException e){
        resp->set_status_code(ERROR_PARAMS);
        resp->set_desc("invaild parameter");
        return;
    }

    EmployeeDAO e_dao;
    e_dao.transaction();
    employee_state state;
    for(const auto &id : e_ids.keys()){
        // check e_id
        QString e_id(id);
        state = employee_state(e_ids[e_id].toInt());
        if (e_id.isEmpty()){
            resp->set_status_code(ERROR_PARAMS);
            resp->set_desc("invaild parameter");
            return;
        }
        // query user
        std::vector<Employee> employees;
        int code = e_dao.query_employee(e_id, employees);
        Employee &employee = employees[0];
        // if the same jump setting
        if(employee.get_state() == state)
            continue;
        // set employee's state
        employee.set_state(state);
        // save employee
        code = e_dao.save_employee(employee);
        if(SQL_EXEC_ERROR == code){
            // excute sql error
            resp->set_status_code(MODIFY_ERROR);
            resp->set_desc("modify employee failed");
            e_dao.rollback();
            return;
        }
        // set user state
        if (employee_state::resignation == state)
            code = UserController::close_user(e_id);
        else
            code = UserController::reopen_user(e_id);
        if(MODIFY_ERROR == code){
            resp->set_status_code(MODIFY_ERROR);
            resp->set_desc("modify employee's account failed");
            e_dao.rollback();
            return;
        }
    }
    e_dao.commit();
    resp->set_status_code(SUCCESS);
    resp->set_desc("modify employee's state success");
}
