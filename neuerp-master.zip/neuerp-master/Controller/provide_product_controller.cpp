#include "provide_product_controller.h"

/**
* @projectName   neuerp_server
* @brief         This class implements the class ProvideProductController
*                function.
* @author        luxijia
* @date          2018-7-4
* @modify_author
* @modify_date
*/

//bind function to route controller
IMPLEMENT_CONSTROLLER_BEGIN(ProvideProductController, provide_product)
BIND(add_product, add_provide_product, ProvideProductController)
BIND(delete_product, delete_provide_product, ProvideProductController)
BIND(search_provide_product, search_product_by_id, ProvideProductController)
BIND(search_product, search_product, ProvideProductController)
BIND(delete_list, delete_provide_list, ProvideProductController)
BIND(change, change_product_information, ProvideProductController)
IMPLEMENT_CONTROLLER_END

/**
* @functionName  add_supplier_product
* @Description   provide interface to Supplier Controller to add supplier
*                provide product
* @author        luxijia
* @date          2018-7-9
* @parameter     sp_id sullier id
* @parameter     products add provide product collection
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is add provide product success
*/
int ProvideProductController::add_supplier_product(const QString &sp_id, std::vector<ProvideProduct> &products)
{
    ProvideProductDao p_dao;
    return p_dao.save_provide_product(sp_id, products);
}

/**
* @functionName  add_provide_product
* @Description   Deal with add provide product request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-4
*/
void ProvideProductController::add_provide_product()
{
    std::vector<ProvideProduct> products;
    QJsonArray product_array;
    QString sp_id;
    int flag = ADD_ERROR;

    try
    {
        product_array = this->req->get_array("products");
        sp_id = this->req->get_string("sp_id");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet add provide prouduct reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!product_array.isEmpty())
    {
        int size = product_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = product_array.at(i);

            if (value.isObject())
            {
                ProvideProduct provide_product;
                QJsonObject product = value.toObject();
                provide_product.setPp_id(product.value("code").toString());
                provide_product.setPp_name(product.value("name").toString());
                provide_product.setPp_price(product.value("price").toDouble());
                provide_product.setPp_desc(product.value("description").toString());
                products.push_back(provide_product);
            }
        }

        flag = add_provide_product(sp_id, products);
    }

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("add provide product success.");
    }
    else
    {
        this->resp->set_status_code(ADD_ERROR);
        this->resp->set_desc("add provide product failed.");
    }
}

/**
* @functionName  add_provide_product
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with add provide product bussiness that can batch add products
*                call DAO layer function
* @author        luxijia
* @date          2018-7-4
* @parameter     sp_id sullier id
* @parameter     products add provide product collection
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is add provide product success
*/
int ProvideProductController::add_provide_product(const QString &sp_id, std::vector<ProvideProduct> &products)
{
    return provide_product_dao.save_provide_product(sp_id, products);
}

/**
* @functionName  delete_provide_product
* @Description   Deal with delete provide product request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-4
*/
void ProvideProductController::delete_provide_product()
{
    QString sp_id;
    QJsonArray ids;
    QString id = "";
    int flag  = DELETE_ERROR;

    try
    {
        sp_id = this->req->get_string("sp_id");
        ids =  this->req->get_array("product_id");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet delete provide prouduct reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!ids.isEmpty())
    {
        int size = ids.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = ids.at(i);

            if (value.isString())
                id += value.toString() + ",";
        }

        flag = delete_provide_product(sp_id, id);
    }

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("delete provide product success.");
    }
    else
    {
        this->resp->set_status_code(DELETE_ERROR);
        this->resp->set_desc("delete provide product failed.");
    }
}

/**
* @functionName  delete_provide_product
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with delete provide product bussiness in supplier query provide product page that can batch delete products,
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-4
* @parameter     sp_id sullier id
* @parameter     products delete provide product collection
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is delete provide product record success
*/
int ProvideProductController::delete_provide_product(const QString &sp_id, QString &pp_id)
{
    pp_id.chop(1);
    return provide_product_dao.delete_provide_product_record(sp_id, pp_id);
}

/**
* @functionName  search_product
* @Description   Deal with query provide product request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-4
*/
void ProvideProductController::search_product()
{
    QString keyword;
    int page_number;
    int page_item;
    int all_result_num;
    int flag = QUERY_ERROR;
    std::vector<ProvideProduct> products;
    QJsonArray product_array;

    try
    {
        keyword = this->req->get_string("keyword");
        page_number = this->req->get_int("page_number");
        page_item = this->req->get_int("page_item");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet search provide prouduct reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    flag = search_product(products, keyword, all_result_num, page_number, page_item);


    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("query provide product success");

        int size = products.size();

        for (int i = 0; i < size; i++)
        {
            QJsonObject product;
            product.insert("sp_id", products[i].getSp_id());
            product.insert("sp_name", products[i].getSp_name());
            product.insert("pp_id", products[i].getPp_id());
            product.insert("pp_name", products[i].getPp_name());
            product.insert("pp_price", products[i].getPp_price());
            product.insert("pp_desc", products[i].getPp_desc());
            product_array.append(product);
        }

        this->resp->put("products", product_array);
        this->resp->put("all_result_num", all_result_num);
    }
    else if (EMPTY_SET == flag)
    {
        this->resp->set_status_code(EMPTY_QUERY);
        this->resp->set_desc("no such provide product");
    }
    else
    {
        this->resp->set_status_code(QUERY_ERROR);
        this->resp->set_desc("query provide product error");
    }
}

/**
* @functionName  search_product
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with search provide product bussiness that can search by keyword and fuzzy search
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-4
* @parameter     products search products result collection
* @parameter     keyword search keyword
* @parameter     page_number page number of queries
* @parameter     page_item the number of item each page
* * @parameter     all_result_num all result rows number
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query provide product has result
*                EMPTY_SET is query provide product noe result
*/
int ProvideProductController::search_product(std::vector<ProvideProduct> &products, const QString &keyword,
                                             int &all_result_num, int page_mnumber, int page_item)
{
    int offset = (page_mnumber - 1) * page_item;
    return provide_product_dao.query_provide_product(products, keyword, all_result_num, offset, page_item);
}

/**
* @functionName  search_product_by_id
* @Description   Deal with query provide product request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-4
*/
void ProvideProductController::search_product_by_id()
{
    QString sp_id;
    int flag = QUERY_ERROR;
    std::vector<ProvideProduct> products;
    QJsonArray product_array;

    try
    {
        sp_id = this->req->get_string("sp_id");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet search provide prouduct reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    flag = search_product_by_id(sp_id, products);


    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("query provide product success");

        int size = products.size();

        for (int i = 0; i < size; i++)
        {
            QJsonObject product;
            product.insert("sp_id", products[i].getSp_id());
            product.insert("sp_name", products[i].getSp_name());
            product.insert("pp_id", products[i].getPp_id());
            product.insert("pp_name", products[i].getPp_name());
            product.insert("pp_price", products[i].getPp_price());
            product.insert("pp_desc", products[i].getPp_desc());
            product_array.append(product);
        }

        this->resp->put("provide_product", product_array);
    }
    else if (EMPTY_SET == flag)
    {
        this->resp->set_status_code(EMPTY_QUERY);
        this->resp->set_desc("no such provide product");
    }
    else
    {
        this->resp->set_status_code(QUERY_ERROR);
        this->resp->set_desc("query provide product error");
    }
}

/**
* @functionName  search_product
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with search provide product bussiness that can search by keyword and fuzzy search
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-11
* @parameter     products query result collection
* @parameter     sp_id supplier id
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query provide product has result
*                EMPTY_SET is query provide product noe result
*/
int ProvideProductController::search_product_by_id(const QString &sp_id, std::vector<ProvideProduct> &products)
{
    return provide_product_dao.query_provide_product_by_id(sp_id, products);
}

/**
* @functionName  delete_provide_list
* @Description   Deal with delete provide product list request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-4
*/
void ProvideProductController::delete_provide_list()
{
    QJsonArray supplier_array;
    QJsonArray product_array;
    QString sp_id = "";
    QString pp_id = "";
    int flag = DELETE_ERROR;

    try
    {
        supplier_array = this->req->get_array("supplier_id");
        product_array = this->req->get_array("product_id");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet delete provide prouduct reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!supplier_array.isEmpty() && !product_array.isEmpty())
    {
        int product_size = product_array.size();
        int supplier_size = supplier_array.size();

        //argrument same that we can delete
        if (product_size == supplier_size)
        {
            for (int i = 0; i < product_size; i++)
            {
                QJsonValue value = product_array.at(i);

                if (value.isString())
                    pp_id += value.toString() + ",";
            }

            for (int j = 0; j < supplier_size; j++)
            {
                QJsonValue value = supplier_array.at(j);

                if (value.isString())
                    sp_id += value.toString() + ",";
            }

            flag = delete_provide_list(sp_id, pp_id);
        }
    }

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("delete provide product list success.");
    }
    else
    {
        this->resp->set_status_code(DELETE_ERROR);
        this->resp->set_desc("delete provide product list failed.");
    }
}

/**
* @functionName  delete_provide_list
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with delete provide product bussiness in provide product query list that can batch delete
*                provide product and call DAO layer function.
* @author        luxijia
* @date          2018-7-4
* @parameter     sp_id a supplier id string are connected using commas,corresponds to pp id one by one
* @parameter     pp_id a provide product id string are connected using commas
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is delete provide product success
*/
int ProvideProductController::delete_provide_list(QString &sp_id, QString &pp_id)
{
    sp_id.chop(1);
    pp_id.chop(1);
    return provide_product_dao.delete_provide_product_list(sp_id, pp_id);
}

/**
* @functionName  change_product_information
* @Description   Deal with change provide product information request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-11
*/
void ProvideProductController::change_product_information()
{
    std::vector<ProvideProduct> products;
    QJsonArray product_array;
    int flag = CHANGE_ERROR;

    try
    {
        product_array = this->req->get_array("products");
    }
    catch(NullException e)
    {
        qWarning() << "Accpet change provide prouduct reuqest error. Error:" << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!product_array.isEmpty())
    {
        int size = product_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = product_array.at(i);

            if (value.isObject())
            {
                ProvideProduct provide_product;
                QJsonObject product = value.toObject();
                provide_product.setPp_id(product.value("code").toString());
                provide_product.setPp_name(product.value("name").toString());
                provide_product.setPp_price(product.value("price").toDouble());
                provide_product.setPp_desc(product.value("description").toString());
                provide_product.setSp_id(product.value("sp_id").toString());
                products.push_back(provide_product);
                qDebug() << provide_product.getSp_id() << provide_product.getSp_id() << provide_product.getPp_name()
                            << provide_product.getPp_id() << provide_product.getPp_price() << provide_product.getPp_price();
            }
        }

        flag = change_product_information(products);
    }

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("change provide product information success.");
    }
    else
    {
        this->resp->set_status_code(CHANGE_ERROR);
        this->resp->set_desc("change provide product information failed.");
    }
}

/**
* @functionName  change_product_information
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with change provide product information request.
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-11
* @parameter     products change product collection
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is update all product information success
*/
int ProvideProductController::change_product_information(std::vector<ProvideProduct> &products)
{
    return provide_product_dao.update_provice_product(products);
}
