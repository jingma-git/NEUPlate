#ifndef PURCHASE_ORDER_CONTROLLER_H
#define PURCHASE_ORDER_CONTROLLER_H
#include <QJsonArray>
#include <QJsonObject>
#include <QDebug>
#include <Network/Route/controller.h>

#include "entity/purchase_order.h"
#include "entity/order_item.h"
#include "entity_dao/purchase_order_dao.h"
#include "Entity_DAO/product_dao.h"

#include "Exception/nullexception.h"




class PurchaseOrderController: public Controller
{
    DECLEAR_CONTROLLER(PurchaseOrderController)
public:

    void add_orders();
    void delete_orders();
    void update_orders_state();
    void update_order_state();
    void delete_order_items();
    void query_orders_by_state();
    void query_order_items();

    int get_products(std::vector<Product> &products, std::vector<QString> pro_ids); //add by majing
    int update_products(std::vector<Product> &products);

private:
    PurchaseOrderDao orderDao;
    ProductDao proDao;
};

#endif // PURCHASE_ORDER_CONTROLLER_H
