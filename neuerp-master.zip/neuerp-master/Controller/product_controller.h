#ifndef PRODUCT_CONTROLLER_H
#define PRODUCT_CONTROLLER_H
#include <QString>
#include "entity/product.h"
#include "Entity_DAO/product_dao.h"
#include "Network/Route/controller.h"

/**
* @projectName   neuerp_server
* @brief         describtion
* @author        haoyun
* @date          2018-07-04
* @modify_author haoyun
* @modify_date   2018-07-04
*/

class ProductController:public Controller
{
    DECLEAR_CONTROLLER(ProductController)

private:
    ProductDao product_dao;
    int add_product(QString bar_code, QString name, double price,QString description, QString image_URL, int init_state,int stock_amount);
    int update_product(QString p_id,QString bar_code,QString name,double price,QString image_URL,QString description,int init_state,int stock_amout);
    int change_product_state(std::vector<QString> product_ids, int state);
    int delete_product(QString product_id);
    int valid_product(QString product_id);
    int get_product(Product &product,QString product_id);
    int get_product_by_bar_code(Product &product,QString bar_code);
    int get_products(std::vector<Product> &products, QString keyword, int &all_results_num,
                       double lowest_price, double highest_price, int order_by_price,
                       int low_stock, int high_stock,int order_by_stock,
                       int page, int page_size, int state);
    void update_product();
    void add_product();
    void change_product_state();
    void delete_product();
    void valid_product();
    void get_product_by_bar_code();
    void get_product();
    void get_products();

};

#endif // PRODUCT_CONTROLLER_H
