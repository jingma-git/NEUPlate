#include "sale_controller.h"


/**
* @projectName   neuerp_server
* @brief
* @author        luxijia
* @date          2018-7-4
* @modify_author
* @modify_date
*/

IMPLEMENT_CONSTROLLER_BEGIN(SaleController, sale)
BIND(add, add_sale, SaleController)
BIND(delete_sale, delete_sales, SaleController)
BIND(search_list, search_sales, SaleController)
BIND(search_item, search_sale_item, SaleController)
BIND(cancel, cancle_sale, SaleController)
IMPLEMENT_CONTROLLER_END

/**
* @functionName  add_sale
* @Description   Deal with add sale list request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-5
*/
void SaleController::add_sale()
{
    QString date;
    QString client_name;
    QString client_address;
    QString client_phone;
    QString salesman;
    QString handler_id;
    QString remark;
    QJsonArray sale_array;
    std::vector<SaleItem> items;
    int flag = ADD_ERROR;

    try
    {
        date = this->req->get_string("date");
        client_name = this->req->get_string("client_name");
        client_phone = this->req->get_string("client_phone");
        client_address = this->req->get_string("client_address");
        salesman = this->req->get_string("salesman");
        handler_id = this->req->get_string("handler_id");
        sale_array = this->req->get_array("sale_array");
        remark = this->req->get_string("remark");
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!sale_array.isEmpty())
    {
        int size = sale_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = sale_array.at(i);

            if (value.isObject())
            {
                SaleItem item;
                QJsonObject sale_item = value.toObject();
                item.setProduct_id(sale_item.value("id").toString());
                item.setSale_price(sale_item.value("price").toDouble());
                item.setSale_amount(sale_item.value("amount").toInt());
                qDebug() << sale_item.value("price").toDouble() << sale_item.value("amount").toInt();
                items.push_back(item);
            }
        }

        flag = add_sale(date, client_name, client_address, client_phone,
                        salesman, handler_id, remark,items);
    }

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("add sale list success");
    }
    else
    {
        this->resp->set_status_code(ADD_ERROR);
        this->resp->set_desc("add sale list failed");
    }
}

/**
* @functionName  add_sale
* @Description   add sale list and sale item into database
*                that use database transaction.
* @author        luxijia
* @date          2018-7-5
* @parameter     sale_id sale list id
* @parameter     date sale list date
* @parameter     client_name the name of sale client
* @parameter     client_address the address of sale client
* @parameter     client_phone the phone of sale client
* @parameter     salesman the salesman of sale list.
* @parameter     handler_id the handler employee id of sale client
* @pararmeter    items the sale item collection in sale list.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is add sale list success
*/
int SaleController::add_sale(const QString &date, const QString &client_name, const QString &client_address,
                             const QString &client_phone, const QString &salesman, const QString &handler_id,
                             const QString &remark ,std::vector<SaleItem> &items)
{
    QDateTime time = QDateTime::currentDateTime();
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    QString id = QString("%1%2%3").arg(time.toString("yyyyMMddhhmmss")).arg(handler_id).arg(qrand() % 100);
    int flag = ADD_ERROR, call_flag = QUERY_ERROR;

    sale_dao.transaction();
    flag = sale_dao.save_sale(id, date, client_name, client_address,
                              client_phone, salesman, handler_id, remark, items);

    if (SUCCESS == flag)
        call_flag = SUCCESS;

    if (SUCCESS == call_flag && SUCCESS == flag)
    {
        sale_dao.commit();
        return SUCCESS;
    }
    else
    {
        sale_dao.rollback();
        return ADD_ERROR;
    }
}

/**
* @functionName  delete_sales
* @Description   Deal with delete sale lists request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-5
*/
void SaleController::delete_sales()
{
    QJsonArray sale_array;
    QString sale_id;
    int flag = DELETE_ERROR;

    try
    {
        sale_array = this->req->get_array("sale_id");
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!sale_array.isEmpty())
    {
        int size = sale_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = sale_array.at(i);

            if (value.isString())
                sale_id += value.toString() + ",";
        }
         qDebug() <<sale_id;
        flag = delete_sales(sale_id);

    }

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("delete sale list success");
    }
    else
    {
        this->resp->set_status_code(DELETE_ERROR);
        this->resp->set_desc("delete sale list failed");
    }
}

/**
* @functionName  delete_sales
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with delete sale list bussiness that can batch delete sale list.
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-6
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is delete all suppliers success
*                DELETE_ERROR is delete sale list error
*/
int SaleController::delete_sales(QString& sale_id)
{
    sale_id.chop(1);
     qDebug() <<sale_id;
    return sale_dao.delete_sale(sale_id);
}

/**
* @functionName  search_sales
* @Description   Deal with query sale lists request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-5
*/
void SaleController::search_sales()
{
    QString keyword;
    QString start_time;
    QString end_time;
    int page_number;
    int page_item;
    int state;
    int flag = EMPTY_SET;
    int all_result_number = 0;
    std::vector<SaleList> sale_lists;

    try
    {
        keyword = this->req->get_string("keyword");
        page_number = this->req->get_int("page_number");
        page_item = this->req->get_int("page_item");
        start_time = this->req->get_string("start_time");
        end_time = this->req->get_string("end_time");
        state = this->req->get_int("state");
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }


    flag = search_sales(sale_lists, all_result_number, keyword, start_time, end_time, page_number, page_item, state);

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("query sale list success");

        QJsonArray sale_array;
        int size = sale_lists.size();

        for (int i = 0; i < size; i++)
        {
            QJsonObject list;
            list.insert("id", sale_lists[i].getSale_id());
            list.insert("date", sale_lists[i].getSale_date());
            list.insert("client_name", sale_lists[i].getClient_name());
            list.insert("client_address", sale_lists[i].getClient_address());
            list.insert("client_phone", sale_lists[i].getClient_phone());
            list.insert("sale_state", sale_lists[i].getSale_state());
            list.insert("salesman", sale_lists[i].getSalesman());
            list.insert("handler_id", sale_lists[i].getHandler_id());
            list.insert("handler_name", sale_lists[i].getHandler_name());
            list.insert("remark", sale_lists[i].getRemark());
            sale_array.append(list);
        }

        this->resp->put("sale_list",sale_array);
        this->resp->put("all_result_num", all_result_number);
    }
    else if (EMPTY_SET == flag)
    {
        this->resp->set_status_code(EMPTY_QUERY);
        this->resp->set_desc("no sale list");
    }
    else
    {
        this->resp->set_status_code(QUERY_ERROR);
        this->resp->set_desc("query sale list failed");
    }
}

/**
* @functionName  search_sales
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with query sale list bussiness by keyword
*                that can furry search sale list.
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-5
* @parameter     sale_list query sale list result collection
* @parameter     keyword search keyword
* @parameter     start_time query sale list start time
* @parameter     all_result_num   all table rows
* @parameter     end_time query sale list end time
* @parameter     offset the offset of query database table
* @parameter     item the number of item each page
* @parameter     state search sale list state
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query sale list in database has result
*                EMPTY_SET is query sale list in database noe result
*/
int SaleController::search_sales(std::vector<SaleList> &sale_list, int &all_result_num, const QString &keyword, const QString &start_time,
                                 const QString &end_time, int page_number, int page_item, int state)
{
    int offset = (page_number - 1) * page_item;
    return sale_dao.query_sale_list(sale_list, all_result_num, keyword, start_time, end_time, offset, page_item, state);
}

/**
* @functionName  search_sale_item
* @Description   Deal with query sale list's items request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-5
*/
void SaleController::search_sale_item()
{
    QString sale_id;
    int flag = EMPTY_SET;
    std::vector<SaleItem> sale_items;

    try
    {
        sale_id = this->req->get_string("sale_id");
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    flag = search_sale_item(sale_items, sale_id);

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("query sale list success");

        QJsonArray item_array;
        int size = sale_items.size();

        for (int i = 0; i < size; i++)
        {
            QJsonObject item;
            item.insert("id", sale_items[i].getProduct_id());
            item.insert("name", sale_items[i].getProduct_name());
            item.insert("sale_price", sale_items[i].getSale_price());
            item.insert("sale_amount", sale_items[i].getSale_amount());
            item_array.append(item);
        }

        this->resp->put("sale_item",item_array);
    }
    else if (EMPTY_SET == flag)
    {
        this->resp->set_status_code(EMPTY_QUERY);
        this->resp->set_desc("no such sale list");
    }
    else
    {
        this->resp->set_status_code(QUERY_ERROR);
        this->resp->set_desc("query sale list failed");
    }
}

/**
* @functionName  search_sale_item
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with query sale list's item bussiness by time
*                that can furry search sale list.
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-5
* @parameter     sale_list query sale list result collection
* @parameter     start_time query sale list start time
* @parameter     end_time query sale list end time
* @parameter     offset the offset of query database table
* @parameter     item the number of item each page
* @return        SUCCESS is query sale list in database has result
*                EMPTY_SET is query sale list in database noe result
*/
int SaleController::search_sale_item(std::vector<SaleItem> &sale_item, const QString &sale_id)
{
    return sale_dao.query_sale_item(sale_item, sale_id);
}


/**
* @functionName  cancle_sale
* @Description   Deal with cancel sale list request,
*                parse the front-end incoming parameters.
* @author        luxijia
* @date          2018-7-5
*/
void SaleController::cancle_sale()
{
    QString sale_id;
    QJsonArray sale_array;
    int flag =  CHANGE_ERROR;

    try
    {
        sale_array = this->req->get_array("sale_id");
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

    if (!sale_array.isEmpty())
    {
        int size = sale_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = sale_array.at(i);

            if (value.isString())
                sale_id += value.toString() + ",";
        }

        flag = cancle_sale(sale_id);
    }

    if (SUCCESS == flag)
    {
        this->resp->set_status_code(SUCCESS);
        this->resp->set_desc("cancel sale list success");
    }
    else
    {
        this->resp->set_status_code(CHANGE_ERROR);
        this->resp->set_desc("cancel sale list failed");
    }
}

/**
* @functionName  cancle_sale
* @Description   Accept argument from the same name function in Data analysis layer,
*                deal with cancel sale list bussiness
*                that can cancel sale list.
*                and call DAO layer function.
* @author        luxijia
* @date          2018-7-5
* @parameter     sale_id the id of sale list
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is cancel sale list success
*/
int SaleController::cancle_sale(QString &sale_id)
{
    sale_id.chop(1);
    return sale_dao.update_sale_state(sale_id);
}
