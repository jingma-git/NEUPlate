#ifndef STATISTICS_CONTROLLER_H
#define STATISTICS_CONTROLLER_H

#include <Network/Route/controller.h>
#include "Entity_DAO/statistics_dao.h"

class StatisticsController:public Controller
{
    DECLEAR_CONTROLLER(StatisticsController)
public:
    void statistics();

private:
    StatisticsDao statistics_dao;
    void complete_date(const QStringList &origin_string,const QStringList &origin_date,
                       const QString start,const QString end,QStringList &output_string,QStringList &output_date,QChar interval='d');
};

#endif // STATISTICS_CONTROLLER_H
