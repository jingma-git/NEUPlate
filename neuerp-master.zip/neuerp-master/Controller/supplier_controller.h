#ifndef SUPPLIER_CONTROLLER_H
#define SUPPLIER_CONTROLLER_H

/**
* @projectName   Supplier_Controller
* @brief         This class inhernt class Controller that
*                deal with user request from clinet about supplier operation.
* @author        luxijia
* @date          2018-7-2
* @modify_author
* @modify_date
*/
#include <Network/Route/controller.h>
#include <entity/supplier.h>
#include <entity/provide_product.h>
#include <Entity_DAO/supplier_dao.h>
#include <Controller/provide_product_controller.h>
#include <Exception/nullexception.h>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>

class SupplierController : public Controller
{
    DECLEAR_CONTROLLER(SupplierController)
public:
    static int query_supplier(std::vector<Supplier> &suppliers, const QString &bar_code);
private:
    void search_supplier();
    void remove_supplier();
    void add_supplier();
    void delete_supplier();
    void change_information();
    void renew_supplier();

    int search_supplier(std::vector<Supplier> &suppliers, QString keyword, int &all_result_num,
                        int page_mnumber, int page_item, int state);
    int remove_supplier(QString &id);
    int add_supplier(const QString &name, const QString &telephone, const QString &region, const QString &contact,
                     std::vector<ProvideProduct> &products);
    int delete_supplier(QString &id);
    int change_information(const QString &id, const QString &name, const QString &telephone, const QString &region, const QString &contact, int state);
    int renew_supplier(QString &id);

    SupplierDao supplier_dao;
};


#endif // SUPPLIER_CONTROLLER_H
