#ifndef STOCK_CONTROLLER_H
#define STOCK_CONTROLLER_H

#include "supplier_controller.h"
#include "Entity_DAO/stock_dao.h"
#include "status_code.h"
class StockController:public Controller
{
    DECLEAR_CONTROLLER(StockController)

private:
    StockDao stock_dao;
    int check_stock(const QString &product_id,int &stock,bool &enough);
    int set_stock(const QString &product_id,const int &stock);
    int get_stock(const QString &product_id,int &stock);
    void get_stock();
    void set_stock();
    void check_stock();


};

#endif // STOCK_CONTROLLER_H


