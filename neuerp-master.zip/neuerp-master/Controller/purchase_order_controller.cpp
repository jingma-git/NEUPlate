#include "purchase_order_controller.h"

// implement controller,should pass class name and module name, system will invoke by module name
IMPLEMENT_CONSTROLLER_BEGIN(PurchaseOrderController, purchase_order)
// bind the function with function name, system will invoke function by the name, you should pass function_name, actual fucntion name, class name
BIND(add_orders, add_orders, PurchaseOrderController)
BIND(delete_orders, delete_orders, PurchaseOrderController)
BIND(update_order_state, update_order_state, PurchaseOrderController)
BIND(update_orders_state, update_orders_state, PurchaseOrderController)
BIND(delete_order_items, delete_order_items, PurchaseOrderController)
BIND(query_order_items, query_order_items, PurchaseOrderController)
BIND(query_orders_by_state, query_orders_by_state, PurchaseOrderController)

IMPLEMENT_CONTROLLER_END


void PurchaseOrderController::add_orders(){
    qDebug()<<"PurchaseOrderController::add_orders()";

    try
    {
        std::vector<PurchaseOrder> orders;
        QJsonArray orderArray = this->req->get_array("orders");

        foreach(const QJsonValue &value, orderArray){
            PurchaseOrder order(value.toObject());
            orders.push_back(order);
        }

        int status = orderDao.add_orders(orders);

        this->resp->set_status_code(status);
        this->resp->put("orders", orderArray);
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

}

void PurchaseOrderController::delete_orders(){
    qDebug()<<"PurchaseOrderController::delete_orders()";

    try
    {
        std::vector<QString> order_ids;
        QJsonArray orderIdArray = this->req->get_array("order_ids");
        foreach(const QJsonValue &value, orderIdArray){
            order_ids.push_back(value.toString());
        }

        int status = orderDao.delete_orders(order_ids);
        this->resp->set_status_code(status);
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }
}
void PurchaseOrderController::update_orders_state(){
    qDebug()<<"PurchaseOrderController::update_orders_state()";
    try
    {
        std::vector<QString> order_ids;
        QJsonArray orderIdArray = this->req->get_array("order_ids");
        foreach(const QJsonValue &value, orderIdArray){
            order_ids.push_back(value.toString());
        }
        int state = this->req->get_int("state");
        int status = orderDao.update_orders_state(order_ids, state);
        this->resp->set_status_code(status);
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }
}



void PurchaseOrderController::update_order_state(){
    //qDebug()<<"PurchaseOrderController::update_order_state()";
    try
    {
        QString order_id = this->req->get_string("order_id");

        int state = this->req->get_int("state");
        int status = orderDao.update_order_state(order_id, state);
        QJsonObject order_obj = this->req->get_json("order");
        PurchaseOrder order(order_obj);
        //订单确认后，更新仓库中相应商品的库存
        std::map<QString,int> pro_amt; //商品id和对应的进货数量
        std::vector<QString> pro_ids;
        for(OrderItem orderItem:order.orderItems){
            QString product_id = orderItem.product_id;
            int amt = orderItem.amt;
            if(pro_amt[product_id]==0) pro_ids.push_back(product_id);
            pro_amt[product_id]+=amt;
        }

        std::vector<Product> products;
        status = get_products(products, pro_ids);
        if(status==SUCCESS){ //成功获取到商品
            for(Product pro:products){
                QString pro_id = pro.getP_id();
                QString bar_code = pro.getBar_code();
                QString name = pro.getName();
                double price = pro.getPrice();
                QString image_URL = pro.getImg_url();
                QString description = pro.getDescription();
                int state = pro.getState();

                int old_amt = pro.getStock_amount();
                int new_amt = old_amt + pro_amt[pro_id];
               // qDebug()<<"new_amt"<<new_amt;
                status = proDao.update_product(pro_id,bar_code,name, price,image_URL,description,state,new_amt);
            }
        }

        this->resp->set_status_code(status);
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }
}

void PurchaseOrderController::delete_order_items(){
//QString order_id, std::vector<OrderItem>& order_items
    qDebug()<<"PurchaseOrderController::delete_order_items()";
    try
    {
        QJsonArray ord_item_array = this->req->get_array("order_items");
        std::vector<OrderItem> orderItems;
        foreach(const QJsonValue &val,ord_item_array){
            OrderItem orderItem(val.toObject());
            orderItems.push_back(orderItem);
        }

        int status = orderDao.delete_order_items(orderItems);
        this->resp->set_status_code(status);
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }
}

void PurchaseOrderController::query_orders_by_state(){
    qDebug()<<"PurchaseOrderController::query_orders_by_state()";

    try
    {
        int state = this->req->get_int("state");
        int page = this->req->get_int("page");
        int page_size = this->req->get_int("page_size");
        std::vector<PurchaseOrder> orders;
        int all_results_num;
        int status = orderDao.query_orders_by_state(orders,state,all_results_num,page,page_size);
        if(status==SUCCESS){
            QJsonArray orderArray;
            for(PurchaseOrder order:orders){
                orderArray.append(order.toJSON());
            }
            this->resp->set_status_code(SUCCESS);
            this->resp->put("state",state);
            this->resp->put("orders", orderArray);
            int all_page = ceil((double)all_results_num/page_size);
            this->resp->put("all_page", all_page);
        }else{
            this->resp->set_status_code(SQL_EXEC_ERROR);
        }
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }

}

void PurchaseOrderController::query_order_items(){
    qDebug()<<"PurchaseOrderController::query_order_items()";

    try
    {
        QString order_id = this->req->get_string("order_id");
        std::vector<OrderItem> orderItems;

        int status = orderDao.query_order_items(orderItems, order_id);

        if(status==SUCCESS){qDebug()<<"if(status==SUCCESS)";
            QJsonArray orderItemArray;
            for(OrderItem orderItem:orderItems){qDebug()<<"for(OrderItem orderItem:orderItems)"<<orderItem.product_id;
                orderItemArray.append(orderItem.toJSON());
            }
            this->resp->set_status_code(SUCCESS);
            this->resp->put("order_items", orderItemArray);
        }else{
            this->resp->set_status_code(SQL_EXEC_ERROR);
        }
    }
    catch(NullException e)
    {
        qWarning() << e.what();
        this->resp->set_status_code(ERROR_PARAMS);
        this->resp->set_desc("invaild parameter");
        return;
    }
}

/**
* @functionName  add by majing
* @Description   brief
* @author        majing
* @date          2018-07-20
* @parameter     void
* @return        void
*/

int PurchaseOrderController::get_products(std::vector<Product> &products, std::vector<QString> pro_ids){
    qDebug()<<"^^^^^^^^^^^^^^^^^^^^^^^^^^^";
    qDebug()<<"PurchaseOrderController::get_products";
    for(QString pro_id:pro_ids){
        Product pro;
        int status = proDao.query_product(pro,pro_id);
        if(status!=SUCCESS) return status;
        products.push_back(pro);
    }
    return SUCCESS;
}

/**
* @functionName  add by majing
* @Description   update products by batch
* @author        majing
* @date          2018-07-20
* @parameter     void
* @return        void
*/
int PurchaseOrderController::update_products(std::vector<Product> &products){
    qDebug()<<"PurchaseOrderController::update_products";
    for(Product pro:products){
        QString p_id = pro.getP_id();
        QString bar_code = pro.getBar_code();
        QString name = pro.getName();
        double price = pro.getPrice();
        QString image_URL = pro.getImg_url();
        QString description = pro.getDescription();
        int state = pro.getState();
        int stock_amount = pro.getStock_amount();
        qDebug()<<"stock_amount" <<QString::number(stock_amount);
        int status = proDao.update_product(p_id,bar_code,name, price,description,image_URL,state,stock_amount);
        if(status!=SUCCESS) return status;
    }
    return SUCCESS;
}

