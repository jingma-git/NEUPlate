/**
* @projectName   neuerp_server
* @brief         main server, accept connection from client, and pass it to handler
* @author        chenhanlin
* @date          2018-07-01
*/

#ifndef MAINSERVER_H
#define MAINSERVER_H

#include <QObject>
#include <QtNetwork>

class MainServer : public QObject
{
    Q_OBJECT
public:
    explicit MainServer(int port, QObject *parent = nullptr);

private:
    QTcpServer *m_p_server;

public slots:
    void handle_new_connection();
};

#endif // MAINSERVER_H
