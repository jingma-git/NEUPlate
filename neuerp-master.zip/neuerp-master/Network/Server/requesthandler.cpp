#include "requesthandler.h"
#include <QDebug>
#include <QJsonObject>
#include <QJsonDocument>
#include <QByteArray>
#include <QStringList>
#include "Network/Body/request.h"
#include "Network/Body/response.h"
#include "Network/Route/controller.h"
#include "Controller/all_controller.h"
#include "status_code.h"
#include "QUuid"

RequestHandler::RequestHandler(QTcpSocket *p_socket, QObject *parent)
    : QObject(parent), m_p_socket(p_socket),
    m_i_handler_id(QUuid::createUuid().toString().remove("{").remove("}").remove("-")), client_name(p_socket->peerAddress().toString())
{
    connect(m_p_socket, SIGNAL(readyRead()), this, SLOT(message_arrive()));
    connect(m_p_socket, SIGNAL(disconnected()), this, SLOT(connection_close()));
}
RequestHandler::~RequestHandler()
{
    delete m_p_socket;
}

/**
* @functionName  connection_close
* @Description   when connection close, it should release some resource
* @author        chenhanlin
* @date          2018-07-01
* @parameter     void
* @return        void
*/
void RequestHandler::connection_close()
{
    qDebug() << "close connection with " << m_p_socket->peerAddress().toString() << ":" << m_p_socket->peerPort();
    m_p_socket->close();
    UserController::logout(this->m_i_handler_id);
    deleteLater();
}

/**
* @functionName  message_arrive
* @Description   when message arrived, it will receive data, handle data and send response
* @author        chenhanlin
* @date          2018-07-01
* @parameter     void
* @return        void
*/
void RequestHandler::message_arrive()
{
    cache += m_p_socket->readAll();
    QStringList reqs = cache.split("\r\n\r\n");
    // handle request after read all data
    if(!cache.endsWith("\r\n\r\n")){
        cache = reqs[reqs.size() - 1];
        for(int i=0; i<reqs.size()-1; i++){
            m_req_queue.push(reqs[i]);
        }
    }else{
        cache.clear();
        for(int i=0; i<reqs.size(); i++){
            m_req_queue.push(reqs[i]);
        }
    }
    while(!m_req_queue.empty()){
        QString message(m_req_queue.front());
        m_req_queue.pop();
        if(message.isEmpty()) continue;
        QByteArray data = message.toUtf8();
        QJsonDocument json_doc(QJsonDocument::fromJson(data));
        QJsonObject json(json_doc.object());
        Request *p_req = new Request(json);
        qDebug() << "receive task from " << client_name << ", to do" << p_req->get_module() << "/" << p_req->get_func();
        Response *p_resp = nullptr;
        // check permission
        if (! UserController::check_access_code(this->m_i_handler_id, p_req->get_module()+"_"+p_req->get_func())){
            p_resp = new Response;
            p_resp->set_status_code(ILLEGAL_ACCESS);
            p_resp->set_desc("illegal access");
        }else{
        Controller *p_c = Controller::create(p_req->get_module(), m_i_handler_id);
        // check module
        if (nullptr == p_c){
            p_resp = new Response;
            p_resp->set_status_code(NO_MODULE);
            p_resp->set_desc("invaild module");
        }else{
            p_resp = p_c->route(p_req->get_func(), p_req);
            delete p_c;
        }
        }
        // send data
        p_resp->set_module(p_req->get_module());
        p_resp->set_func(p_req->get_func());
        QByteArray send_data = (p_resp->transfer_to_json()+"\r\n\r\n").toUtf8();
        int data_len = send_data.size();
        int send_len = m_p_socket->write(send_data);
        while (send_len < data_len){
            data_len = data_len - send_len;
            send_data = send_data.right(data_len);
            send_len = m_p_socket->write(send_data);
        }
        // free memory
        delete p_req;
        delete p_resp;
    }
}
