/**
* @projectName   neuerp_server
* @brief         request's handler, to receivde data and pass it to handle, close connection
* @author        chenhanlin
* @date          2018-07-01
*/

#ifndef REQUESTHANDLER_H
#define REQUESTHANDLER_H

#include <QObject>
#include <QtNetwork>
#include <queue>

class RequestHandler : public QObject
{
    Q_OBJECT
public:
    explicit RequestHandler(QTcpSocket *p_socket, QObject *parent = nullptr);
    ~RequestHandler();

private:
    QTcpSocket *m_p_socket;
    QString m_i_handler_id;
    QString client_name;
    QString cache;
    std::queue<QString> m_req_queue;

public slots:
    void connection_close();
    void message_arrive();
};

#endif // REQUESTHANDLER_H
