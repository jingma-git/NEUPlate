#include "mainserver.h"
#include <QDebug>
#include <QThreadPool>
#include "Network/Server/requesthandler.h"

/**
* @functionName  MainServer
* @Description   class MainServer's constructor
* @author        chenhanlin
* @date          2018-07-01
* @parameter     int port, QObject *parent
*/
MainServer::MainServer(int port, QObject *parent) : QObject(parent), m_p_server(new QTcpServer(this))
{
    // listen
    if (!this->m_p_server->listen(QHostAddress::AnyIPv4, port)){
        qWarning() << "Server cannot listen at 0.0.0.0 :" << port;
        exit(1);
    }
    qDebug() << "Server start listen at 0.0.0.0 :" << port;
    // bind newconnection with handle_new_connection slot
    connect(m_p_server, SIGNAL(newConnection()), this, SLOT(handle_new_connection()));
}

void MainServer::handle_new_connection()
{
    QTcpSocket *p_socket = m_p_server->nextPendingConnection(); // accept connect
    RequestHandler *handler = new RequestHandler(p_socket, this); // pass to handler
    qDebug() << "a new connection from " << p_socket->peerAddress().toString() << ":" << p_socket->peerPort();
}
