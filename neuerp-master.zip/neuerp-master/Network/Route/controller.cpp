#include "controller.h"

Controller::Controller(const QString &handler_id):resp(new Response), m_i_handler_id(handler_id)
{

}

Controller::~Controller(){}

Controller* Controller::create(const QString &class_name, const QString &handler_id)
{
    auto &class_constructor_set = get_class_map();
    std::map<QString, class_constructor>::iterator iter = class_constructor_set.find(class_name);
    if (class_constructor_set.end() != iter){
        return ((*iter).second)(handler_id);
    }else{
        return nullptr;
    }
}

void Controller::register_class(const QString &class_name, class_constructor constructor)
{
    auto &class_constructor_set = get_class_map();
    class_constructor_set.insert(std::map<QString, class_constructor>::value_type(class_name, constructor));
}

std::map<QString, Controller::class_constructor> &Controller::get_class_map()
{
    static std::map<QString, class_constructor> class_constructor_set; // save the string mapping to constructor
    return class_constructor_set;
}
