﻿#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <map>
#include <string>
#include <iostream>
#include "Network/Body/request.h"
#include "Network/Body/response.h"
#include "status_code.h"

#define DECLEAR_CONTROLLER(CDerived)\
public:\
    CDerived(const QString &handler_id);\
    typedef void (CDerived::*pfunc)();\
    static Controller* create(const QString &handler_id);\
    static void bind();\
    Response* route(const QString &method, Request *p_req);\
    struct CDerived##_register\
    {\
        CDerived##_register();\
    };\
private:\
    static struct CDerived##_register m_##CDerived##_registered;\
    static std::map<QString, pfunc>& get_func_map();\

#define IMPLEMENT_CONSTROLLER_BEGIN(CDerived, module_name)\
CDerived::CDerived##_register m_##CDerived##_registered;\
std::map<QString, CDerived::pfunc>& CDerived::get_func_map()\
{\
    static std::map<QString, pfunc> m_func_set;\
    return m_func_set;\
}\
CDerived::CDerived(const QString &handler_id): Controller(handler_id){}\
Controller* CDerived::create(const QString &handler_id)\
{\
    return new CDerived(handler_id);\
}\
CDerived::CDerived##_register::CDerived##_register()\
{\
    static bool is_registered = false;\
    if (!is_registered){\
        Controller::register_class(#module_name, CDerived::create);\
        CDerived::bind();\
        is_registered = true;\
    }\
}\
Response* CDerived::route(const QString &method, Request *p_req)\
{\
    auto &m_func_set = get_func_map();\
    this->req = p_req;\
    pfunc func = m_func_set[method];\
    if(nullptr == func){\
        resp->set_status_code(NO_FUNC);\
        resp->set_desc("invaild function");\
    }else{\
        (this->*func)();\
    }\
    return resp;\
}\
void CDerived::bind()\
{\
    auto &m_func_set = get_func_map();

#define IMPLEMENT_CONTROLLER_END }

#define BIND(func_name,func, CDerived)\
    m_func_set.insert(std::map<QString, CDerived::pfunc>::value_type(#func_name,&CDerived::func));

class Controller
{
public:
    typedef Controller *(*class_constructor)(const QString &handler_id); // constructor function pointer
    static Controller* create(const QString &class_name, const QString &handler_id); // factory pattern
    virtual Response* route(const QString &method, Request *p_req) = 0;
    Controller(const QString &handler_id);
    virtual ~Controller();
protected:
    static void register_class(const QString &class_name, class_constructor constructor); // bind string with constructor
    Response *resp;
    Request *req;
    QString m_i_handler_id;
private:
    static std::map<QString, class_constructor>& get_class_map();
};

#endif // CONTROLLER_H
