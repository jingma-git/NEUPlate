#ifndef REQUEST_H
#define REQUEST_H

#include "body.h"

class Request : public Body
{
public:
    Request();
    Request(const QJsonObject &json);
    Request(const QString &module, const QString &func);

    QString get_module() const;
    void set_module(const QString &get_module);

    QString get_func() const;
    void set_func(const QString &get_func);

#ifdef CLIENT
    QString transfer_to_json();
#endif

private:
    QString m_str_module;
    QString m_str_func;
};

#endif // REQUEST_H
