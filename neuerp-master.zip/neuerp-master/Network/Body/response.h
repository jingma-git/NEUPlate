#ifndef RESPONSE_H
#define RESPONSE_H
#define SERVER

#include "body.h"

class Response : public Body
{
public:
    Response();
    Response(const QJsonObject &json);
    Response(int status_code, const QString &desc);

    int get_status_code() const;
    void set_status_code(int status_code);

    QString get_desc() const;
    void set_desc(const QString &desc);

#ifdef SERVER
    QString transfer_to_json();
#endif

    QString get_module() const;
    void set_module(const QString &module);

    QString get_func() const;
    void set_func(const QString &func);

private:
    int m_i_status_code;
    QString m_str_desc;
    QString m_module;
    QString m_func;
};

#endif // RESPONSE_H
