#include "request.h"
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QByteArray>

Request::Request()
{

}

Request::Request(const QJsonObject &json)
    :Body(json["params"].toObject()), m_str_module(json["module"].toString()), m_str_func(json["func"].toString())
{

}

Request::Request(const QString &module, const QString &func)
    :m_str_module(module), m_str_func(func)
{

}

QString Request::get_module() const
{
    return m_str_module;
}

void Request::set_module(const QString &str_module)
{
    m_str_module = str_module;
}

QString Request::get_func() const
{
    return m_str_func;
}

void Request::set_func(const QString &str_func)
{
    m_str_func = str_func;
}

#ifdef CLIENT
/**
* @functionName  transfer_to_json
* @Description   transfer request'data to json
* @author        chenhanlin
* @date          2018-07-03
* @parameter     void
* @return        QString
*/
QString Request::transfer_to_json()
{
    QJsonObject json;
    json.insert(QString("module"), m_str_module);
    json.insert(QString("func"), m_str_func);
    json.insert(QString("params"), m_json_params);
    QJsonDocument json_doc(json);
    QByteArray json_data(json_doc.toJson(QJsonDocument::Compact));
    return QString(json_data);
}
#endif
