/**
* @projectName   neuerp_server
* @brief         base class of request and response
* @author        chenhanlin
* @date          2018-07-03
*/

#ifndef BODY_H
#define BODY_H
#define HAVE_PUT
#include <QJsonObject>

class Body
{
public:
    Body(const QJsonObject &json);
    Body();
    virtual ~Body();

    // set function
    void set_params(const QJsonObject &json);

#ifdef HAVE_PUT
    // put function
    void put(const QString &key, int value);
    void put(const QString &key, double value);
    void put(const QString &key, bool value);
    void put(const QString &key, const QString &value);
    void put(const QString &key, const char *value);
    void put(const QString &key, const QJsonObject &json);
    void put(const QString &key, const QJsonArray &array);
#endif

    // get function
    int get_int(const QString &key) const;
    double get_double(const QString &key) const;
    QString get_string(const QString &key) const;
    bool get_bool(const QString &key) const;
    QJsonObject get_json(const QString &key) const;
    QJsonArray get_array(const QString &key) const;

protected:
    QJsonObject m_json_params;
};

#endif // BODY_H
