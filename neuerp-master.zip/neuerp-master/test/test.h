/**
* @projectName   neuerp_server
* @brief         include test function defination
* @author        chenhanlin
* @date          2018-07-04
*/

#ifndef TEST_H
#define TEST_H

// test userDAO
void test_query_save();
void test_code_question_delete();

//test usercontroller
void test_public_interface();
void test_remove();

// employee dao
void test_save_query_delete();

#endif // TEST_H
