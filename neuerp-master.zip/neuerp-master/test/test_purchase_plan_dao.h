#ifndef TEST_PURCHASE_PLAN_H
#define TEST_PURCHASE_PLAN_H
#include <QObject>
#include <Entity_DAO/purchase_plan_dao.h>
class TestPurchasePlanDao:public QObject
{
    Q_OBJECT

public:
    TestPurchasePlanDao();

private Q_SLOTS:
    void test_add();
    void test_load();
    void test_query_basic();
    void test_query();
    void test_update_plan_items();
    void test_update_state();
private:
    PurchasePlanDao planDao;

    void print_all(std::vector<PurchasePlan>);
};
#endif // TEST_PURCHASE_PLAN_H
