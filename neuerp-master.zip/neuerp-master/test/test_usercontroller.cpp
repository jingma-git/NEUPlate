#include "test.h"
#include <QDebug>
#include "entity/user.h"
#include "Entity_DAO/userdao.h"
#include "Controller/usercontroller.h"
#include <map>
#include <vector>
#include "status_code.h"
#include <QString>

void test_public_interface()
{
    QString e_id("0");
//    int code = UserController::add_user(e_id);
    int code = 0;
    if(SUCCESS == code){
        qDebug() << "add success";
    }else{
        qDebug() << "add error";
        return;
    }

    std::vector<User> users;
    UserDAO dao;
    dao.query_user(e_id, users);
    qDebug() << int(users[0].get_status());
    code = UserController::close_user(e_id);
    if(SUCCESS == code){
        qDebug() << "modify success";
    }else{
        qDebug() << "modify error";
        return;
    }
    users.clear();
    dao.query_user(e_id, users);
    qDebug() << int(users[0].get_status());
    code = UserController::reopen_user(e_id);
    if(SUCCESS == code){
        qDebug() << "modify success";
    }else{
        qDebug() << "modify error";
        return;
    }
    users.clear();
    dao.query_user(e_id, users);
    qDebug() << int(users[0].get_status());
}

void test_remove()
{
    QString e_id("0");
//    int code = UserController::remove_user(e_id);
    int code = SUCCESS;
    if(SUCCESS == code){
        qDebug() << "success";
    }else{
        qDebug() << "faile";
    }
}
