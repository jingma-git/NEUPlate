#include "test.h"
#include <QDebug>
#include "entity/user.h"
#include "Entity_DAO/userdao.h"
#include <map>
#include <vector>
#include "status_code.h"
#include <QString>

void test_query_save()
{
    QString e_id("0");
    qDebug() << "query user by e_id = 0";
    std::vector<User> users;
    UserDAO dao;
    int code = dao.query_user(e_id, users);
    if (SUCCESS == code){
        qDebug() << "query success";
    }else if(SQL_EXEC_ERROR == code){
        qDebug() << "SQL execute error";
        return;
    }else{
        qDebug() << "no such user";
        return;
    }
    User &user = users[0];
    qDebug() << "User " << user.get_e_id() << " " << user.get_u_id()
             << " " << user.get_passwd() << " " << user.get_permission_level()
             << " " << user.get_access_code() << " " << user.get_permission_level();
    user.set_passwd("123456");
    qDebug() << "set password to 123456";
    qDebug() << "try to save user";
    code = dao.save_user(user);
    if (SUCCESS == code){
        qDebug() << "save success";
    }else{
        qDebug() << "SQL execute error";
        return;
    }
    std::map<QString, QString> questions;
    code = dao.query_security_question(questions, e_id);
    if (SUCCESS == code){
        qDebug() << "query success";
    }else if(SQL_EXEC_ERROR == code){
        qDebug() << "SQL execute error";
        return;
    }else{
        qDebug() << "no questions";
        return;
    }

    for (const auto &question : questions){
        qDebug() << question.first << ":" << question.second;
    }

    bool checked = false;
    code = dao.check_security_question("a", e_id, "c", checked);
    if (SUCCESS == code){
        qDebug() << "check success";
    }else{
        qDebug() << "SQL execute error";
        return;
    }
    qDebug() << checked;

    std::map<QString, QString> answers;
    answers.insert(std::map<QString, QString>::value_type("b", "b1"));
    code = dao.update_security_question(answers, e_id);
    if (SUCCESS == code){
        qDebug() << "update success";
    }else{
        qDebug() << "SQL execute error";
        return;
    }
}

void test_code_question_delete()
{
    std::map<QString, int> codes;
    std::map<QString, QString> questions;
    UserDAO dao;
    int code = dao.query_all_access_code(codes);
    if (SUCCESS == code){
        qDebug() << "query success";
    }else if(SQL_EXEC_ERROR == code){
        qDebug() << "SQL execute error";
        return;
    }else{
        qDebug() << "no codes";
        return;
    }
    for(const auto &p : codes){
        qDebug() << p.first << " : " << p.second;
    }
    code =dao.query_all_security_question(questions);
    if (SUCCESS == code){
        qDebug() << "query success";
    }else if(SQL_EXEC_ERROR == code){
        qDebug() << "SQL execute error";
        return;
    }else{
        qDebug() << "no questions";
        return;
    }
    for(const auto &p : questions){
        qDebug() << p.first << " : " << p.second;
    }
    code = dao.delete_user("0");
    if (SUCCESS == code){
        qDebug() << "delete success";
    }else if(SQL_EXEC_ERROR == code){
        qDebug() << "SQL execute error";
        return;
    }
}
