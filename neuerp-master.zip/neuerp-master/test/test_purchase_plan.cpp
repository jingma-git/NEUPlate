#include <QString>
#include <QtTest>
#include <QCoreApplication>

#include "test_purchase_plan_dao.h"
#include "Entity_DAO/purchase_plan_dao.h"

TestPurchasePlanDao::TestPurchasePlanDao()
{
}

void TestPurchasePlanDao::test_add()
{
    PurchasePlan plan("7","seven",QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"),0);
    //planDao.add(plan);
}

void TestPurchasePlanDao::test_load(){
    qDebug()<<"test load";
    PurchasePlan p1 = planDao.load("1");
    qDebug()<<p1.to_string();
}

void TestPurchasePlanDao::test_query_basic(){
    qDebug()<<"test query basic";
    std::vector<PurchasePlan> plans;
    QDateTime start = QDateTime::fromString("2018-07-01", "yyyy-MM-dd");
    QDateTime end = QDateTime::fromString("2018-07-03", "yyyy-MM-dd");
    //planDao.query_basic(plans,start,end,0,0,6);
    print_all(plans);
}
void TestPurchasePlanDao::test_query(){
    PurchasePlanDao dao;
    std::vector<PurchasePlan> plans;
    QString keyword = "plan";
    int all_results_num;
    QString start ="2018-07-01";
    QString end = "2018-07-03";
    int state = 0;
    int page = 1;
    int page_size = 10;
    dao.query(plans,keyword,all_results_num,start,end,state,page,page_size);
    print_all(plans);
}


void TestPurchasePlanDao::test_update_plan_items(){
    qDebug()<<"Test update plan_items";
}

void TestPurchasePlanDao::test_update_state(){
    qDebug()<<"Test update plan state";
    PurchasePlan plan_old = planDao.load("1");
    int old_state = plan_old.get_state();
    int new_state = old_state?0:1;
    planDao.update_state(plan_old.get_plan_id(), new_state);
    PurchasePlan plan_new = planDao.load("1");

}

void TestPurchasePlanDao::print_all(std::vector<PurchasePlan> plans){
    for(int i=0; i<plans.size(); i++){
        qDebug()<<plans[i].to_string();
    }
}
