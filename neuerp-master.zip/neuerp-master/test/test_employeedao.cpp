#include "test.h"
#include <QDebug>
#include "entity/employee.h"
#include "Entity_DAO/employeedao.h"
#include <vector>
#include "status_code.h"

void test_save_query_delete()
{
    EmployeeDAO dao;
    std::vector<Employee> e;
    int code = dao.query_employee("0", e);
    if (SUCCESS == code){
        qDebug() << "query success";
    }else if(SQL_EXEC_ERROR == code){
        qDebug() << "SQL execute error";
        return;
    }else{
        qDebug() << "no such user";
        return;
    }
    qDebug() << int(e[0].get_state());
    Employee &em = e[0];
    em.set_name("haha");
    code = dao.save_employee(em);
    if (SUCCESS == code){
        qDebug() << "save success";
    }else if(SQL_EXEC_ERROR == code){
        qDebug() << "SQL execute error";
        return;
    }
    e.clear();
    code = dao.query_all_employee(e, 1, 10);
    if (SUCCESS == code){
        qDebug() << "query success";
    }else if(SQL_EXEC_ERROR == code){
        qDebug() << "SQL execute error";
        return;
    }else{
        qDebug() << "no such user";
        return;
    }
    for(const auto &i : e){
        qDebug() << i.get_e_id();
    }
    code = dao.delete_employee("3");
    if (SUCCESS == code){
        qDebug() << "delete success";
    }else if(SQL_EXEC_ERROR == code){
        qDebug() << "SQL execute error";
        return;
    }
}
