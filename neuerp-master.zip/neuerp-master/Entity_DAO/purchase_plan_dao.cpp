#include "purchase_plan_dao.h"


PurchasePlanDao::PurchasePlanDao()
{
    db = ConnectionPool::openConnection();
}
PurchasePlanDao::~PurchasePlanDao(){
    ConnectionPool::closeConnection(db);
}

bool PurchasePlanDao::add(PurchasePlan plan){
    qDebug()<<"PurchasePlanDao::add(PurchasePlan plan)";
    qDebug()<<plan.to_string();
    QSqlQuery query(db);
    query.prepare("insert into purchase_plan (plan_id,name,date,state)\
                   values (?,?,?,?)");
    query.addBindValue(plan.get_plan_id());
    query.addBindValue(plan.get_name());
    query.addBindValue(plan.get_date());
    query.addBindValue(plan.get_state());
    if(!query.exec()){
        qDebug()<<query.lastQuery();
        qDebug()<<query.lastError();
        return false;
    }
    return true;
}

PurchasePlan PurchasePlanDao::load(QString plan_id){
    QSqlQuery query(db);
    query.prepare("select * from purchase_plan where plan_id=?");
    query.addBindValue(plan_id);
    query.exec();
    query.first();
    PurchasePlan plan = sql_to_purchase_plan(query);
    return plan;
}


int PurchasePlanDao::query(std::vector<PurchasePlan> &plans, const QString &keyword,int &all_results_num,
                            const QString& start_time, const QString &end_time, int state,int page, int page_size){
    QString keywordStr = "";
    if(!keyword.isEmpty())
         keywordStr += "AND name LIKE '%"+ keyword+"%'";
    int offset=(page-1)*page_size;

    QString sql= "SELECT SQL_CALC_FOUND_ROWS * \
            FROM purchase_plan   \
            WHERE date BETWEEN :start_time AND :end_time " + keywordStr + \
            " AND state=:state \
            ORDER BY date DESC \
            LIMIT :offset,:page_size";

    QSqlQuery query(db);
    query.prepare(sql);
    query.bindValue(":start_time", start_time);
    query.bindValue(":end_time",end_time);
    query.bindValue(":state", state);
    query.bindValue(":offset",offset);
    query.bindValue(":page_size", page_size);

    qDebug()<<query.lastQuery();
    if(query.exec()){
        while(query.next()){
            QString plan_id=query.value("plan_id").toString();
            QString name=query.value("name").toString();
            QString date=query.value("date").toString();
            int state=query.value("state").toInt();
            PurchasePlan plan(plan_id,name,date,state);
            plans.push_back(plan);

        }

        query.exec("SELECT FOUND_ROWS()");
        query.next();
        all_results_num=query.value(0).toInt();
        qDebug()<<"all num:"<<query.value(0).toInt();
        qDebug()<<"rows error:"<<query.lastError().text();
    }else{
        qDebug()<<"Query Plan failed.Error:"<<query.lastError().text();
        return SQL_EXEC_ERROR;
    }
    return SUCCESS;
}

int PurchasePlanDao::query_productsToBuy(std::vector<ProductToBuy> &products, QString keyword,
                             int &all_results_num, bool asc_order,int page,int page_size){
    qDebug()<<"int PurchasePlanDao::query_productsToBuy";
    QTime time;
    time.start();
    qDebug()<<"open connection"<<time.elapsed()/1000.0;

    QString keywordStr = "";
    if(!keyword.isEmpty())
         keywordStr  += "WHERE name LIKE '%"+keyword+
                         "%' OR description LIKE '%"+keyword+"%'";
    int offset=(page-1)*page_size;
    QString order_str;
    if(asc_order){
       order_str ="ASC";
    }else{
       order_str = "DESC";
    }

    qDebug()<<"++++++++++++++++++++++++++++++++++order "<<order_str;
    QString sql= "SELECT SQL_CALC_FOUND_ROWS *,count(*) AS suppliers_num \
                     FROM products2buy " +keywordStr+
                    " GROUP BY bar_code \
                     ORDER BY stock_amount "+ order_str + ",bar_code ASC" +
                     " LIMIT :offset,:page_size";

    QSqlQuery query(db);
    query.prepare(sql);
    query.bindValue(":offset",offset);
    query.bindValue(":page_size", page_size);

    std::vector<int> suppliers_nums;
    if(query.exec()){
        while(query.next()){
            QString p_id=query.value("p_id").toString();
            QString bar_code=query.value("bar_code").toString();
            QString name=query.value("name").toString();
            QString desc=query.value("description").toString();
            QString img_url = query.value("img_url").toString();
            int stock_amount = query.value("stock_amount").toInt();
            ProductToBuy pro(p_id, bar_code, name, desc,img_url, stock_amount);
            int num = query.value("suppliers_num").toInt();
            if(num>0){
                suppliers_nums.push_back(num);
                products.push_back(pro);
            }
        }

        query.exec("SELECT FOUND_ROWS()");
        query.next();
        all_results_num=query.value(0).toInt();
       // qDebug()<<"all num:"<<all_results_num;
       // qDebug()<<"rows error:"<<query.lastError().text();

        int size = products.size();
        for(unsigned i=0; i<size; i++){
            QString sql2 = "SELECT sp_id,sp_name,pp_price FROM products2buy WHERE bar_code=:bar_code";
            query.prepare(sql2);
            query.bindValue(":bar_code", products[i].getBar_code());

            if(query.exec()){
                while(query.next()){
                    QString sp_id = query.value("sp_id").toString();
                    QString sp_name = query.value("sp_name").toString();
                    double pp_price = query.value("pp_price").toDouble();
                    //qDebug()<<"sp_id"<<sp_id;
                    products[i].add_supplier(sp_id,sp_name, pp_price);
                }
            }
        }

    }else{
        qDebug()<<"Query failed.Error:"<<query.lastError().text();
        return 1;
    }
    qDebug()<<"end"<<time.elapsed()/1000.0;
    return 0;
}
int PurchasePlanDao::update_state(QString plan_id, int state){
    QSqlQuery query(db);

    query.prepare("UPDATE purchase_plan SET state=:state WHERE plan_id = :plan_id");
    query.bindValue(":plan_id",plan_id);
    query.bindValue(":state", state);
    if(!query.exec()){
        return SQL_EXEC_ERROR;
    }
    return SUCCESS;
}

int PurchasePlanDao::update_plan_items(QString plan_id, std::vector<PlanItem> &planItems){
    QSqlQuery query(db);

    query.prepare("delete from plan_item where plan_id=?");
    query.addBindValue(plan_id);
    if(!query.exec()){
        return SQL_EXEC_ERROR;
    }

    query.prepare("insert into plan_item (plan_id,p_id,sp_id,amt,p_name,sp_name,pp_price)\
                  values (?,?,?,?,?,?,?)");

    QVariantList plan_ids, p_ids, sp_ids, amts, p_names, sp_names, pp_prices;

    for(vector<PlanItem>::iterator it=planItems.begin(); it!=planItems.end(); it++){
        plan_ids << plan_id;
        p_ids << it->get_product_id();
        sp_ids << it->get_supplier_id();
        amts << it->get_amt();
        p_names << it->get_product_name();
        sp_names << it->get_supplier_name();
        pp_prices << it->get_pp_price();
    }
    query.addBindValue(plan_ids);
    query.addBindValue(p_ids);
    query.addBindValue(sp_ids);
    query.addBindValue(amts);
    query.addBindValue(p_names);
    query.addBindValue(sp_names);
    query.addBindValue(pp_prices);

    if (!query.execBatch())
        return SQL_EXEC_ERROR;
    return SUCCESS;

}

int PurchasePlanDao::load_plan_items(QString plan_id, std::vector<PlanItem> &plan_items){
    qDebug()<<"PurchasePlanDao::load_plan_items";
    QSqlQuery query(db); qDebug()<<"QSqlQuery query(db); ";
    query.prepare("SELECT * FROM plan_item WHERE plan_id=:plan_id"); qDebug()<<"query.prepare(SELECT * FROM plan_item WHERE plan_id=:plan_id);";
    query.bindValue(":plan_id", plan_id);qDebug()<<"query.bindValue(:plan_id, plan_id);";

    if (query.exec()){qDebug()<<"query.exec()";
        if(query.isValid()){qDebug()<<"query.isValid()";
        while(query.next()){ qDebug()<<"query.next()";

            QString plan_id = query.value("plan_id").toString(); qDebug()<<"QString plan_id = query.value(plan_id).toString();";
            QString product_id = query.value("p_id").toString();
            QString sp_id = query.value("sp_id").toString();
            int amt = query.value("amt").toInt();
            double pp_price = query.value("pp_price").toDouble();
            QString product_name = query.value("p_name").toString();
            QString sp_name = query.value("sp_name").toString();

            qDebug()<<"plan id "<< plan_id;
            qDebug()<<"product_id "<<product_id;
            qDebug()<<"sp_id "<<sp_id;
            qDebug()<<"product_name "<<product_name;
            qDebug()<<"sp_name "<<sp_name;
            qDebug()<<"amt "<<QString::number(amt);
            qDebug()<<"pp_price "<<QString::number(pp_price,'g',2);
            PlanItem planItem;
            planItem.set_plan_id(plan_id);
            planItem.set_product_id(product_id);
            planItem.set_product_name(product_name);
            planItem.set_supplier_id(sp_id);
            planItem.set_supplier_name(sp_name);
            planItem.set_amt(amt);
            planItem.set_pp_price(pp_price);
            plan_items.push_back(planItem);
        }
        qDebug()<<"plan_items[0].toString();"<< plan_items[0].to_string();
        }else{
            return EMPTY_QUERY;
        }
    }else{
        qDebug()<<"return SQL_EXEC_ERROR;";
        return SQL_EXEC_ERROR;
    }

    return SUCCESS;
}


PurchasePlan PurchasePlanDao::sql_to_purchase_plan(QSqlQuery query){
    QString plan_id = query.value("plan_id").toString();
    QString name = query.value("name").toString();
    QString date = query.value("date").toString();
    int state = query.value("state").toInt();
    //std::vector<PlanItem> plan_items = query_plan_items(query, plan_id);
    PurchasePlan plan(plan_id,name,date,state);
    return plan;
}

/*
std::vector<PlanItem> PurchasePlanDao::query_plan_items(QSqlQuery query, QString plan_id){
    query.prepare("select * from  plan_item where plan_id=?");
    query.addBindValue(plan_id);
    query.exec();
    std::vector<PlanItem> plan_items;
    while(query.next()){

        QString product_id = query.value("p_id").toString();
        QString supplier_id = query.value("sp_id").toString();
        int amt = query.value("amt").toInt();

        PlanItem plan_item(product_id, supplier_id, amt);
        plan_items.push_back(plan_item);
        //qDebug()<< query.value("plan_id").toString();
        //qDebug()<< plan_item.to_string();
    }
    return plan_items;
}
*/
