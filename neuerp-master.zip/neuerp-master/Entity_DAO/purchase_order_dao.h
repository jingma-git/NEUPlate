#ifndef PURCHASE_ORDER_DAO_H
#define PURCHASE_ORDER_DAO_H
#include <QSqlQuery>
#include <QSqlDatabase>
#include <QString>
#include <QVariant>
#include <QDateTime>

#include "Entity_DAO/connection_pool.h"
#include "entity/purchase_order.h"
#include "entity/order_item.h"
#include "status_code.h"
class PurchaseOrderDao
{
public:
    PurchaseOrderDao();
    ~PurchaseOrderDao();
    int add(PurchaseOrder order);
    int add_orders(std::vector<PurchaseOrder> &orders);
    int delete_order(QString order_id);
    int delete_orders(std::vector<QString> &order_ids);
    int update_order_state(QString order_id, int state);
    int update_orders_state(std::vector<QString> &order_ids, int state);
    int delete_order_items(std::vector<OrderItem>& order_items);
    int query_orders_by_state(std::vector<PurchaseOrder> &orders, int state,int &all_results_num, int page, int page_size);
    int query_order_items(std::vector<OrderItem> &orderItems, QString order_id);
private:
     QSqlDatabase db;
};

#endif // PURCHASE_ORDER_DAO_H
