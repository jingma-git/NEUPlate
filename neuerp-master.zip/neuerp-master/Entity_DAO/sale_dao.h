#ifndef SALE_DAO_H
#define SALE_DAO_H

/**
* @projectName   neuerp_server
* @brief         This class interacts with the database to
*                get or save sale information.
* @author        luxijia
* @date          2018-7-5
* @modify_author
* @modify_date
*/
#include <iostream>
#include <vector>
#include <entity/sale_list.h>
#include <entity/sale_item.h>
#include <QString>
#include <QtDebug>
#include <QDate>
#include "status_code.h"
#include "connection_pool.h"

class SaleDao
{
public:
    SaleDao();
    SaleDao(const QSqlDatabase &db);
    ~SaleDao();
    void transaction();
    void commit();
    void rollback();
    int query_sale_list(std::vector<SaleList> &sale_list, int &all_result_num, const QString &keyword, const QString &start_time,
                        const QString &end_time,int offset, int item, int state);
    int query_sale_list_by_time(std::vector<SaleList> &sale_list, const QString &start_time,
                                const QString &end_time,int offset, int item);
    int query_sale_item(std::vector<SaleItem> &sale_item, const QString &sale_id);
    int save_sale(const QString &sale_id, const QString &date, const QString &client_name,
                  const QString &client_address, const QString &client_phone, const QString &salesman,
                  const QString &handler_id, const QString &remark,std::vector<SaleItem> &items);
    int delete_sale(const QString &sale_id);
    int update_sale_state(const QString &sale_id);
private:
    QSqlDatabase db;
};

#endif // SALE_DAO_H
