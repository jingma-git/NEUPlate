#ifndef EMPLOYEEDAO_H
#define EMPLOYEEDAO_H

#include "entity/employee.h"
#include "entity/user.h"
#include "entity/employeeuser.h"
#include <QSqlDatabase>
#include <vector>

class EmployeeDAO
{
public:
    EmployeeDAO();
    EmployeeDAO(const QSqlDatabase &db);
    ~EmployeeDAO();

    int save_employee(Employee &employee);
    int delete_employee(const QString &employee_id);
    int query_employee(const QString &keyword, std::vector<Employee> &employees);
    int query_all_employee(std::vector<Employee> &employees, int page_num, int page_item);
    int query_employee(int &total, std::vector<EmployeeUser> &users, int page, int item, const QString &keyword, employee_state e_state, bool has_e_state, int u_state, bool has_u_state, const QString &dept, Gender gender, bool has_gender);

    void transaction();
    void rollback();
    void commit();
    QSqlDatabase get_connection();

private:
    QSqlDatabase db_connection;

    int insert_employee(Employee &employee);
    int update_employee(const Employee &employee);
};

#endif // EMPLOYEEDAO_H
