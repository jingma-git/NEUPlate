#include "supplier_dao.h"


/**
* @projectName   neuerp_server
* @brief         Implements the function which declare in
*                class SupplierDao.
* @author        luxijia
* @date          2018-7-3
* @modify_author
* @modify_date
*/

/**
* @functionName  SupplierDao
* @Description   The constructor of class SupplierDao
*                that get a connection object from ConnectionPool.
* @author        luxijia
* @date          2018-7-6
*/
SupplierDao::SupplierDao():db(ConnectionPool::openConnection())
{

}

/**
* @functionName  ~SupplierDao
* @Description   The deconstructor of class SupplierDao
*                that return a connection object from ConnectionPool.
* @author        luxijia
* @date          2018-7-6
*/
SupplierDao::~SupplierDao()
{
    ConnectionPool::closeConnection(db);
}

/**
* @functionName  transaction
* @Description   start a trancaction.
* @author        luxijia
* @date          2018-7-9
*/
void SupplierDao::transaction()
{
    db.transaction();
}

/**
* @functionName  commit
* @Description   commit result if transaction success.
* @author        luxijia
* @date          2018-7-9
*/
void SupplierDao::commit()
{
    db.commit();
}

/**
* @functionName  rollback
* @Description   rollback result if transaction falied.
* @author        luxijia
* @date          2018-7-9
*/
void SupplierDao::rollback()
{
    db.rollback();
}

/**
* @functionName  query_supplier
* @Description   query provide products in database by keyword
*                that can furry query.
* @author        luxijia
* @date          2018-7-3
* @parameter     suppliers qeury supplier result collection
* @parameter     keyword search keyword
* @parameter     all_result_num
* @parameter     offset data offset in table
* @parameter     item the number of item each page
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query suppliers has result
*                EMPTY_SET is query suppliers noe result
*/
int SupplierDao::query_supplier(std::vector<Supplier> &suppliers, const QString &keyword, int &all_result_num,
                                int offset, int item, int state)
{
    QString state_statement = "";

    if (0 == state)
        state_statement = "AND sp_state = 0";
    else if (1 == state)
        state_statement = "AND sp_state = 1";

    QString sql = "SELECT SQL_CALC_FOUND_ROWS * FROM supplier WHERE \
                   CONCAT(IFNULL(sp_name, ''),IFNULL(sp_region, ''),IFNULL(contact,'')) \
                   LIKE :keyword " + state_statement + " LIMIT :offset, :item";
    QSqlQuery query(db);

    query.prepare(sql);
    query.bindValue(":keyword", "%" + keyword + "%");
    query.bindValue(":offset", offset);
    query.bindValue(":item", item);

    if (query.exec())
    {
        while (query.next())
        {
            Supplier supplier;
            supplier.setSp_id(query.value("sp_id").toString());
            supplier.setSp_name(query.value("sp_name").toString());
            supplier.setSp_phone(query.value("sp_phone").toString());
            supplier.setSp_state(query.value("sp_state").toInt());
            supplier.setSp_region(query.value("sp_region").toString());
            supplier.setContact(query.value("contact").toString());
            suppliers.push_back(supplier);
        }
    }
    else
    {
        qCritical() << "Query supplier with keyword failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (query.exec("SELECT FOUND_ROWS()"))
    {
        if (query.next())
            all_result_num = query.value(0).toInt();
    }
    else
    {
        qCritical() << "Query supplier rows failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (0 == suppliers.size())
        return EMPTY_SET;
    else
        return SUCCESS;
}

/**
* @functionName  query_supplier_by_id
* @Description   query provide products in database by id
*                that can furry query.
* @author        luxijia
* @date          2018-7-3
* @parameter     suppliers  class Supplier object store qeury supplier information
* @parameter     id supplier id
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query suppliers has result
*                EMPTY_SET is query suppliers noe result
*/
int SupplierDao::query_supplier_by_id(std::vector<Supplier> &suppliers, const QString &bar_code)
{
    QSqlQuery query(db);
    query.prepare("SELECT * FROM supplier,provide_product\
                  WHERE supplier.sp_id = provide_product.sp_id\
                  AND pp_id=:bar_code");
    query.bindValue(":bar_code", bar_code);

    if (query.exec())
        while (query.next())
        {
            Supplier supplier;
            supplier.setSp_id(query.value("sp_id").toString());
            supplier.setSp_name(query.value("sp_name").toString());
            supplier.setSp_phone(query.value("sp_phone").toString());
            supplier.setSp_state(query.value("sp_state").toInt());
            supplier.setSp_region(query.value("sp_region").toString());
            supplier.setContact(query.value("contact").toString());
            suppliers.push_back(supplier);
        }
    else
    {
        qCritical() << "Qeury supplier with id failed. Error:" << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (0 == suppliers.size())
        return EMPTY_SET;
    else
        return SUCCESS;
}

/**
* @functionName  save_suppleir
* @Description   save suppleir into database by procedure.
* @author        luxijia
* @date          2018-7-3
* @parameter     suppliers  class Supplier object store qeury supplier information
* @parameter     sp_id the id of supplier
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is save suppliers inforamtion to database success
*/
int SupplierDao::save_suppleir(Supplier &supplier, QString &sp_id)
{
    QSqlQuery select_id(db);
    QSqlQuery delect_id(db);
    QSqlQuery insert_supplier(db);
    QString id = "";

    select_id.prepare("SELECT id FROM id_contain LIMIT 1");

    if (select_id.exec())
    {
        if (select_id.next())
            id = select_id.value("id").toString();
    }
    else
    {
        qCritical() << "Get supplier id fialed. Errot:" << select_id.lastError().text();
        return SQL_EXEC_ERROR;
    }

    delect_id.prepare("DELETE FROM id_contain WHERE id = :id");
    delect_id.bindValue(":id", id);

    if (!delect_id.exec())
    {
        qCritical() << "Delete id in id_contain fialed. Errot:" << delect_id.lastError().text();
        return SQL_EXEC_ERROR;
    }

    insert_supplier.prepare("INSERT INTO supplier VALUES(:id, :p_name, :p_phone, 1, :p_region, :p_contact)");
    insert_supplier.bindValue(":id", id);
    insert_supplier.bindValue(":p_name", supplier.getSp_name());
    insert_supplier.bindValue(":p_phone", supplier.getSp_phone());
    insert_supplier.bindValue(":p_region", supplier.getSp_region());
    insert_supplier.bindValue(":p_contact", supplier.getContact());

    if(!insert_supplier.exec())
    {
        qCritical() << "Save supplier fialed. Errot:" << insert_supplier.lastError().text();
        return SQL_EXEC_ERROR;
    }

    sp_id = id;

    return SUCCESS;
}

/**
* @functionName  delete_supplier_record
* @Description   delete suppleir in database by procedure
*                that cn batch delete.
* @author        luxijia
* @date          2018-7-3
* @parameter     id  a supplier id string are connected using commas.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is delete suppliers success
*                DELETE_ERROR is delete suppliers failed
*/
int SupplierDao::delete_supplier_record(const QString &id)
{
    QSqlQuery query(db);

    query.prepare("CALL delete_supplier(?,?)");
    query.bindValue(0, id);
    query.bindValue(1, 0 ,QSql::Out);

    if (!query.exec())
    {
        qCritical() << "Delete supplier failed. Errror:" << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (0 == query.boundValue(1).toInt())
        return SUCCESS;
    else
        return DELETE_ERROR;
}

/**
* @functionName  update_supplier_state_stop
* @Description   change suppleir support state to stop which value is 0 in database.
* @author        luxijia
* @date          2018-7-3
* @parameter     id a supplier id string are connected using commas.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is update suppliers information success
*/
int SupplierDao::update_supplier_state_stop(const QString &id)
{
    QSqlQuery query(db);
    QString sql = QString("UPDATE supplier SET sp_state = 0 WHERE sp_id IN (%1)").arg(id);

    if (!query.exec(sql))
    {
        qCritical() << "Update supplier state failed. Error:" << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    return SUCCESS;
}

/**
* @functionName  update_supplier_state_support
* @Description   change suppleir support state to support which value is 1 in database.
* @author        luxijia
* @date          2018-7-3
* @parameter     id a supplier id string are connected using commas.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is update suppliers information success
*/
int SupplierDao::update_supplier_state_support(const QString &id)
{
    QSqlQuery query(db);

    QString sql = QString("UPDATE supplier SET sp_state=1 WHERE sp_id IN (%1)").arg(id);

    if (!query.exec(sql))
    {
        qCritical() << "Update supplier state failed. Error:" << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    return SUCCESS;
}

/**
* @functionName  update_supplier_information
* @Description   save suppleir information in database
*                that has been change.
* @author        luxijia
* @date          2018-7-3
* @parameter     id  a supplier id string are connected using commas.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is update suppliers information success
*/
int SupplierDao::update_supplier_information(Supplier &supplier)
{
    QSqlQuery query(db);
    query.prepare("UPDATE supplier SET sp_name=:name, sp_phone=:phone, \
                  sp_state=:state, sp_region=:region, \
                  contact=:contact WHERE sp_id=:id");

     query.bindValue(":name", supplier.getSp_name());
     query.bindValue(":phone", supplier.getSp_phone());
     query.bindValue(":state", supplier.getSp_state());
     query.bindValue(":region", supplier.getSp_region());
     query.bindValue(":contact", supplier.getContact());
     query.bindValue(":id", supplier.getSp_id());

    if (!query.exec())
    {
        qCritical() << "Update supplier information failed. Error:" << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    return SUCCESS;
}
