#include "employeedao.h"
#include "status_code.h"
#include "Entity_DAO/connection_pool.h"

EmployeeDAO::EmployeeDAO(): db_connection(ConnectionPool::openConnection())
{

}

EmployeeDAO::EmployeeDAO(const QSqlDatabase &db): db_connection(db)
{

}

EmployeeDAO::~EmployeeDAO()
{
    ConnectionPool::closeConnection(db_connection);
}

/**
* @functionName  save_employee
* @Description   save this object's data, if new, will invoke insert, otherwise udpate
* @author        chenhanlin
* @date          2018-07-02
* @parameter     Employee &employee
* @return        int
*/
int EmployeeDAO::save_employee(Employee &employee)
{
    // check the data is new
    if (employee.is_new()){
        return insert_employee(employee);
    }else{
        return update_employee(employee);
    }
}

/**
* @functionName  delete_employee
* @Description   delete the employee from database
* @author        chenhanlin
* @date          2018-07-02
* @parameter     int employee_id
* @return        int
*/
int EmployeeDAO::delete_employee(const QString &employee_id)
{
    QSqlQuery sql(db_connection);
    // prepare sql
//    delete_sql.prepare("CALL delete_employee(:id)");
    sql.prepare("DELETE FROM employee WHERE e_id=:id");
    sql.bindValue(":id", employee_id);
    // excute sql
    bool is_success = sql.exec();
    if(!is_success){
        qDebug() << sql.lastError();
        return SQL_EXEC_ERROR;
    }
    sql.prepare("INSERT INTO id_contain VALUES (:id)");
    sql.bindValue(":id", employee_id);
    is_success = sql.exec();
    if(!is_success){
        qDebug() << sql.lastError();
        return SQL_EXEC_ERROR;
    }
    // return result
    return SUCCESS;
}

/**
* @functionName  query_employee
* @Description   query employee from database by employee name or id
* @author        chenhanlin
* @date          2018-07-02
* @parameter     QString name, vector<Employee> &employees
* @return        int
*/
int EmployeeDAO::query_employee(const QString &keyword, std::vector<Employee> &employees)
{
    QSqlQuery query(db_connection);
    // prepare sql
    query.prepare("SELECT * FROM employee WHERE e_id = :e_id");
    query.bindValue(":e_id", keyword);
    bool is_success = query.exec();
    // check excute
    if (!is_success) {
        return SQL_EXEC_ERROR;
    }
    // get data
    while(query.next()){
        QString e_id(query.value("e_id").toString());
        QString name(query.value("name").toString());
        QString dept(query.value("department").toString());
        QString position(query.value("position").toString());
        Gender gender(Gender(query.value("gender").toInt()));

        int year = query.value("birth_year").toInt();
        int month = query.value("birth_month").toInt();
        int day = query.value("birth_day").toInt();
        QDate birthday(year, month, day);

        QString birth_place(query.value("birth_place").toString());
        QString nation(query.value("nation").toString());
        bool married = query.value("married").toInt();
        QString political_status(query.value("political_status").toString());
        Education edu(Education(query.value("education").toInt()));
        QString id(query.value("id").toString());
        QString address(query.value("address").toString());
        QString telephone(query.value("telephone").toString());
        QString email(query.value("email").toString());
        QString photo(query.value("photo_path").toString());
        QString e_c_name(query.value("emergency_contact_name").toString());
        QString e_c_phone(query.value("emergency_contact_phone").toString());
        QString e_c_address(query.value("emergency_contact_address").toString());
        employee_state state(employee_state(query.value("state").toInt()));
        employees.push_back(Employee(e_id, name, dept, position, gender, birthday, birth_place,
                                     nation, married, political_status, edu, id,
                                     address, telephone, email, photo, e_c_name,
                                     e_c_phone, e_c_address, state));
    }
    if(employees.empty()) return EMPTY_SET;
    else return SUCCESS;
}

/**
* @functionName  query_all_employee
* @Description   query all employee in the system
* @author        chenhanlin
* @date          2018-07-05
* @parameter     vector<Employee> employees
* @return        int
*/
int EmployeeDAO::query_all_employee(std::vector<Employee> &employees, int page_num, int page_item)
{
    QSqlQuery query(db_connection);
    // prepare sql
    query.prepare("SELECT * FROM employee LIMIT :page, :item");
    query.bindValue(":page", (page_num==0? 0: page_num-1)*page_item);
    query.bindValue(":item", page_item);
    bool is_success = query.exec();
    // check excute
    if (!is_success) return SQL_EXEC_ERROR;
    // get data
    while(query.next()){
        QString e_id(query.value("e_id").toString());
        QString name(query.value("name").toString());
        QString dept(query.value("department").toString());
        QString position(query.value("position").toString());
        Gender gender(Gender(query.value("gender").toInt()));

        int year = query.value("birth_year").toInt();
        int month = query.value("birth_month").toInt();
        int day = query.value("birth_day").toInt();
        QDate birthday(year, month, day);

        QString birth_place(query.value("birth_place").toString());
        QString nation(query.value("nation").toString());
        bool married = query.value("married").toInt();
        QString political_status(query.value("political_status").toString());
        Education edu(Education(query.value("education").toInt()));
        QString id(query.value("id").toString());
        QString address(query.value("address").toString());
        QString telephone(query.value("telephone").toString());
        QString email(query.value("email").toString());
        QString photo(query.value("photo_path").toString());
        QString e_c_name(query.value("emergency_contact_name").toString());
        QString e_c_phone(query.value("emergency_contact_phone").toString());
        QString e_c_address(query.value("emergency_contact_address").toString());
        employee_state state(employee_state(query.value("state").toInt()));

        employees.push_back(Employee(e_id, name, dept, position, gender, birthday, birth_place,
                                     nation, married, political_status, edu, id,
                                     address, telephone, email, photo, e_c_name,
                                     e_c_phone, e_c_address, state));
    }
    if(employees.empty()) return EMPTY_SET;
    else return SUCCESS;
}

/**
* @functionName  query_employee
* @Description   query employee's baisc information from table employee_user by some condition
* @author        chenhanlin
* @date          2018-07-11
* @parameter     int page, int item, const QString &keyword, employee_state e_state, bool has_e_state, int u_state, bool has_u_state, QString &dept, Gender gender, bool has_gendr
* @return        int
*/
int EmployeeDAO::query_employee(int &total, std::vector<EmployeeUser> &users, int page, int item, const QString &keyword, employee_state e_state, bool has_e_state, int u_state, bool has_u_state, const QString &dept, Gender gender, bool has_gender)
{
    QSqlQuery query(db_connection);

    QString sql("SELECT SQL_CALC_FOUND_ROWS e_id, name, department, position, e_state, u_state FROM employee_user ");
    QStringList condition;

    // check if need condition
    if(!keyword.isEmpty() || has_e_state || has_gender || has_u_state || !dept.isEmpty()){
        sql += "WHERE ";
    }

    if(!keyword.isEmpty()){
        condition << QString(" e_id LIKE \"%%1%\" OR name like \"%%2%\" ").arg(keyword, keyword);
    }
    if(has_e_state){
        condition << QString(" e_state = %1 ").arg(int(e_state));
    }
    if(has_u_state){
        condition << QString(" u_state & %1 ").arg(int(u_state));
    }
    if(!dept.isEmpty()){
        condition << QString(" department = \"%1\" ").arg(dept);
    }
    if(has_gender){
        condition << QString(" gender = %1 ").arg(int(gender));
    }

    if(!condition.isEmpty()){
        sql += condition.join("AND");
    }
    sql += QString("LIMIT %1, %2").arg(page < 0 ? 0 : page*item).arg(item);
    qDebug() << sql;
    bool success = query.exec(sql);
    if(!success){
        return SQL_EXEC_ERROR;
    }
    while(query.next()){
        QString e_id(query.value("e_id").toString());
        QString name(query.value("name").toString());
        QString department(query.value("department").toString());
        QString position(query.value("position").toString());
        employee_state e_state = employee_state(query.value("e_state").toInt());
        int u_state = query.value("u_state").toInt();
        users.push_back(EmployeeUser(e_id, name, department, position, e_state, u_state));
    }
    success = query.exec("SELECT FOUND_ROWS()");
    if(!success){
        return SQL_EXEC_ERROR;
    }
    query.next();
    total = query.value(0).toInt();
    if(users.empty()) return EMPTY_SET;
    else return SUCCESS;
}

/**
* @functionName  transaction
* @Description   start a transaction
* @author        chenhanlin
* @date          2018-07-06
* @parameter     void
* @return        void
*/
void EmployeeDAO::transaction()
{
    this->db_connection.transaction();
}

/**
* @functionName  rollback
* @Description   rollback transaction
* @author        chenhanlin
* @date          2018-07-06
* @parameter     void
* @return        void
*/
void EmployeeDAO::rollback()
{
    this->db_connection.rollback();
}

/**
* @functionName  commit
* @Description   commit a transaction
* @author        chenhanlin
* @date          2018-07-06
* @parameter     void
* @return        void
*/
void EmployeeDAO::commit()
{
    this->db_connection.commit();
}

/**
* @functionName  get_connection
* @Description   get the database connection, usually for transaction
* @author        chenhanlin
* @date          2018-07-06
* @parameter     void
* @return        QSqlDatabase
*/
QSqlDatabase EmployeeDAO::get_connection()
{
    return this->db_connection;
}

/**
* @functionName  insert_employee
* @Description   use INSERT to add a employee record in DB
* @author        chenhanlin
* @date          2018-07-02
* @parameter     Employee employee
* @return        int
*/
int EmployeeDAO::insert_employee(Employee &employee)
{

    QSqlQuery sql(db_connection);
    // get id
    bool success = sql.exec("SELECT A.id FROM id_contain AS A JOIN (SELECT CEIL(MAX(CAST(id AS SIGNED))*RAND())\
                 AS id FROM id_contain) AS B ON CAST(A.id AS SIGNED) >= B.id LIMIT 1");
    if (!success) return SQL_EXEC_ERROR;
    sql.next();
    QString e_id(sql.value("id").toString());
    qDebug() << "get id success";
    // prepare sql
    sql.prepare("INSERT INTO employee(e_id, name, department, position, gender, birth_place, nation, married, political_status, \
                    education, ID, address, telephone, email, photo_path, emergency_contact_name, emergency_contact_phone, \
                    emergency_contact_address, birth_year, birth_month, birth_day) VALUES (:e_id, :name, :dept, :position, :gender,\
                     :birth_place, :nation, :married, :political_status, \
                    :edu, :id, :address, :phone, :email, :photo, :e_c_name, :e_c_phone, :e_c_address, :year, :month, :day)");
    sql.bindValue(":e_id", e_id);
    sql.bindValue(":name", employee.get_name());
    sql.bindValue(":dept", employee.get_department());
    sql.bindValue(":position", employee.get_position());
    sql.bindValue(":gender", int(employee.get_gender()));
    sql.bindValue(":birth_place", employee.get_birth_place());
    sql.bindValue(":nation", employee.get_nation());
    sql.bindValue(":married", int(employee.is_married()));
    sql.bindValue(":political_status", employee.get_political_status());
    sql.bindValue(":edu", int(employee.get_education()));
    sql.bindValue(":id", employee.get_id());
    sql.bindValue(":address", employee.get_address());
    sql.bindValue(":phone", employee.get_telephone());
    sql.bindValue(":email", employee.get_email());
    sql.bindValue(":photo", employee.get_photo_path());
    sql.bindValue(":e_c_name", employee.get_emergency_contact_name());
    sql.bindValue(":e_c_phone", employee.get_emergency_contact_phone());
    sql.bindValue(":e_c_address", employee.get_emergency_contact_address());
    sql.bindValue(":year", employee.get_birthday().year());
    sql.bindValue(":month", employee.get_birthday().month());
    sql.bindValue(":day", employee.get_birthday().day());
    success = sql.exec();
    if(!success){
        qDebug() << sql.lastError();
        return SQL_EXEC_ERROR;
    }
    sql.prepare("DELETE FROM id_contain WHERE id = :e_id");
    sql.bindValue(":e_id", e_id);
    success = sql.exec();
    if(!success){
        qDebug() << sql.lastError();
        return SQL_EXEC_ERROR;
    }
    employee.set_e_id(e_id);
    qDebug() << "insert employee successful";
    return SUCCESS;
}

/**
* @functionName  update_employee
* @Description   use UPDATE to update a employee record in DB
* @author        chenhanlin
* @date          2018-07-02
* @parameter     Employee &employee
* @return        int
*/
int EmployeeDAO::update_employee(const Employee &employee)
{
    QSqlQuery update(db_connection);
    // prepare sql
    update.prepare("UPDATE employee SET name=:name, department=:dept, position=:position, gender=:gender, birth_place=:birth_place, \
                    nation=:nation, married=:married, political_status=:political_status, education=:edu, ID=:id, address=:address, \
                    telephone=:phone, email=:email, photo_path=:photo, emergency_contact_name=:e_c_name, emergency_contact_phone=:e_c_phone, \
                    emergency_contact_address=:e_c_address, state=:state, birth_year=:year, birth_month=:month, birth_day=:day WHERE e_id = :e_id");
    update.bindValue(":name", employee.get_name());
    update.bindValue(":dept", employee.get_department());
    update.bindValue(":position", employee.get_position());
    update.bindValue(":gender", int(employee.get_gender()));
    update.bindValue(":birth_place", employee.get_birth_place());
    update.bindValue(":nation", employee.get_nation());
    update.bindValue(":married", int(employee.is_married()));
    update.bindValue(":political_status", employee.get_political_status());
    update.bindValue(":edu", int(employee.get_education()));
    update.bindValue(":id", employee.get_id());
    update.bindValue(":address", employee.get_address());
    update.bindValue(":phone", employee.get_telephone());
    update.bindValue(":email", employee.get_email());
    update.bindValue(":photo", employee.get_photo_path());
    update.bindValue(":e_c_name", employee.get_emergency_contact_name());
    update.bindValue(":e_c_phone", employee.get_emergency_contact_phone());
    update.bindValue(":e_c_address", employee.get_emergency_contact_address());
    update.bindValue(":state", int(employee.get_state()));
    update.bindValue(":year", employee.get_birthday().year());
    update.bindValue(":month", employee.get_birthday().month());
    update.bindValue(":day", employee.get_birthday().day());
    update.bindValue(":e_id", employee.get_e_id());
    bool is_success = update.exec();
    if(!is_success){
        return SQL_EXEC_ERROR;
    }
    return SUCCESS;
}
