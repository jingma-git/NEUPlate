#include "provide_product_dao.h"

/**
* @functionName  ProvideProductDao
* @Description   The constructor of class SupplierDao
*                that get a connection object from ConnectionPool.
* @author        luxijia
* @date          2018-7-6
*/
ProvideProductDao::ProvideProductDao():db(ConnectionPool::openConnection())
{

}

/**
* @functionName  ~ProvideProductDao
* @Description   The deconstructor of class SupplierDao
*                that return a connection object from ConnectionPool.
* @author        luxijia
* @date          2018-7-6
*/
ProvideProductDao::~ProvideProductDao()
{
    ConnectionPool::closeConnection(db);
}

/**
* @functionName  save_provide_product
* @Description   save specific supplier support provice product collection into database
*                that can batch save.
* @author        luxijia
* @date          2018-7-4
* @parameter     sp_id supplier id
* @pararmeter    products provide products collection.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is add provide product success
*/
int ProvideProductDao::save_provide_product(const QString &sp_id, std::vector<ProvideProduct> &products)
{
    QSqlQuery query(db);
    QVariantList v1, v2, v3, v4, v5;

    db.transaction();
    query.prepare("INSERT INTO provide_product(sp_id, pp_id, pp_name, pp_price, pp_desc) VALUES(?,?,?,?,?)");

    int size = products.size();

    for(int i = 0; i < size; i++)
    {
        v1 << sp_id;
        v2 << products[i].getPp_id();
        v3 << products[i].getPp_name();
        v4 << products[i].getPp_price();
        v5 << products[i].getPp_desc();
    }

    query.addBindValue(v1);
    query.addBindValue(v2);
    query.addBindValue(v3);
    query.addBindValue(v4);
    query.addBindValue(v5);

    if (!query.execBatch())
    {
        db.rollback();
        qCritical() << "Add supplier provide product failed. Error:" << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    db.commit();
    return SUCCESS;
}

/**
* @functionName  delete_provide_product_record
* @Description   delete specific supplier support provice product collection
*                in database that can batch delete.
* @author        luxijia
* @date          2018-7-4
* @parameter     sp_id supplier id
* @pararmeter    pp_id a provide product id string are connected using commas.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is delete provide product record success
*/
int ProvideProductDao::delete_provide_product_record(const QString &sp_id, const QString &pp_id)
{
    QSqlQuery query(db);
    QString sql = QString("DELETE FROM provide_product WHERE sp_id=%1 AND pp_id IN (%2)").arg(sp_id).arg(pp_id);

    if (!query.exec(sql))
    {
        qCritical() << "Delete supplier provide product failed. Error:" << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    return SUCCESS;
}

/**
* @functionName  delete_provide_product_record
* @Description   delete specific supplier support provice product collection
*                in database that can batch delete.
* @author        luxijia
* @date          2018-7-4
* @parameter     sp_id supplier id
* @pararmeter    pp_id a provide product id string are connected using commas.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is delete all provide product success
*/
int ProvideProductDao::delete_provide_product_all(const QString &sp_id)
{
    QSqlQuery query(db);

    query.prepare("DELETE FROM provide_product WHERE sp_id=:sp_id");
    query.bindValue(":sp_id", sp_id);

    if (!query.exec())
    {
        qCritical() << "Delete supplier provide product failed. Error:" << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    return SUCCESS;
}

/**
* @functionName  query_provide_product
* @Description   query provide products in database by keyword
*                that can furry query.
* @author        luxijia
* @date          2018-7-4
* @parameter     products query result collection
* @parameter     keyword search keyword
* @parameter     offset data offset in table
* @parameter     item the number of item each page
* @parameter     all_result_num all result rows number
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query provide product has result
*                EMPTY_SET is query provide product noe result
*/
int ProvideProductDao::query_provide_product(std::vector<ProvideProduct> &products, const QString &keyword, int &all_result_num, int offset, int item)
{
    QSqlQuery query(db);

    db.transaction();
    query.prepare("SELECT SQL_CALC_FOUND_ROWS sp_id, sp_name, pp_id, pp_name, pp_price, pp_desc FROM provide_product_information\
                  WHERE CONCAT(IFNULL(pp_name, ''),IFNULL(sp_name,''),IFNULL(pp_desc,'')) LIKE :keyword LIMIT :offset, :item");

    query.bindValue(":keyword", "%" + keyword + "%");
    query.bindValue(":offset", offset);
    query.bindValue(":item", item);

    if (query.exec())
    {
        while (query.next())
        {
            ProvideProduct provide_product;
            provide_product.setSp_id(query.value(0).toString());
            provide_product.setSp_name(query.value(1).toString());
            provide_product.setPp_id(query.value(2).toString());
            provide_product.setPp_name(query.value(3).toString());
            provide_product.setPp_price(query.value(4).toDouble());
            provide_product.setPp_desc(query.value(5).toString());
            products.push_back(provide_product);
        }
    }
    else
    {
        db.rollback();
        qCritical() << "Query supplier with keyword failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (query.exec("SELECT FOUND_ROWS()"))
    {
        if (query.next())
            all_result_num = query.value(0).toInt();
    }
    else
    {   db.rollback();
        qCritical() << "Query provide product rows failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    db.commit();

    if (0 == products.size())
        return EMPTY_SET;
    else
        return SUCCESS;
}

/**
* @functionName  query_provide_product_by_id
* @Description   query provide products in database by id.
* @author        luxijia
* @date          2018-7-11
* @parameter     products query result collection
* @parameter     sp_id supplier id
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query provide product has result
*                EMPTY_SET is query provide product noe result
*/
int ProvideProductDao::query_provide_product_by_id(const QString &sp_id, std::vector<ProvideProduct> &products)
{
    QSqlQuery query(db);

    query.prepare("SELECT supplier.sp_id, sp_name, pp_id, pp_name, pp_price, pp_desc FROM supplier, provide_product\
                  WHERE provide_product.sp_id=:sp_id AND supplier.sp_id = provide_product.sp_id");
    query.bindValue(":sp_id", sp_id);

    if (query.exec())
    {
        while (query.next())
        {
            ProvideProduct provide_product;
            provide_product.setSp_id(query.value(0).toString());
            provide_product.setSp_name(query.value(1).toString());
            provide_product.setPp_id(query.value(2).toString());
            provide_product.setPp_name(query.value(3).toString());
            provide_product.setPp_price(query.value(4).toDouble());
            provide_product.setPp_desc(query.value(5).toString());
            products.push_back(provide_product);
        }
    }
    else
    {
        qCritical() << "Query supplier with keyword failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (0 == products.size())
        return EMPTY_SET;
    else
        return SUCCESS;
}

/**
* @functionName  delete_provide_product_list
* @Description   delete provide product list in database by procedure
*                that has multiple supplier id and provide product id.
* @author        luxijia
* @date          2018-7-3
* @parameter     sp_id asupplier id string are connected using commas, corresponds to pp id one by one
* @pararmeter    pp_id a provide product id string are connected using commas.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is delete provide product success
*/
int ProvideProductDao::delete_provide_product_list(const QString &sp_id, const QString &pp_id)
{
    QSqlQuery query(db);

    query.prepare("CALL delete_provide_list(?,?,?)");
    query.bindValue(0, sp_id);
    query.bindValue(1, pp_id);
    query.bindValue(2, 0 ,QSql::Out);

    if (!query.exec())
    {
        qCritical() << "Delete supplier failed. Errror:" << query.lastError().text();
        return SQL_EXEC_ERROR;
    }


    if (0 == query.boundValue(2).toInt())
        return SUCCESS;
    else
        return DELETE_ERROR;
}

/**
* @functionName  update_provice_product
* @Description   update provide product information in database.
* @author        luxijia
* @date          2018-7-11
* @parameter     products update product collection
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is update all product information success
*/
int ProvideProductDao::update_provice_product(std::vector<ProvideProduct> &products)
{
    QSqlQuery query(db);
    int size = products.size();

    db.transaction();

    for (int i = 0; i < size; i++)
    {
        query.prepare("UPDATE provide_product SET pp_name=:pp_name,\
                  pp_price=:pp_price,pp_desc=:pp_desc WHERE sp_id=:sp_id AND pp_id=:pp_id");

        query.bindValue(":pp_name",products[i].getPp_name());
        query.bindValue(":pp_price", products[i].getPp_price());
        query.bindValue(":pp_desc",products[i].getPp_desc());
        query.bindValue(":sp_id", products[i].getSp_id());
        query.bindValue(":pp_id", products[i].getPp_id());

        if (!query.exec())
        {
            db.rollback();
            qCritical() << "Update provide product failed. Error:" << query.lastError().text();
            return SQL_EXEC_ERROR;
        }
    }

    db.commit();
    return SUCCESS;
}
