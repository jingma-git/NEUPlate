#ifndef STOCK_DAO_H
#define STOCK_DAO_H
#include <QString>
#include "status_code.h"
#include <QVariantList>
#include <QDebug>

#include "connection_pool.h"
class StockDao
{
private:
    QSqlDatabase db;
public:
    StockDao();
    ~StockDao();
    int get_stock(QString product_id,int &stock);
    int set_stock(QString product_id,int stock);
};

#endif // STOCK_DAO_H
