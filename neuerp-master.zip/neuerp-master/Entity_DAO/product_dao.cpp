#include "product_dao.h"
#include <QTime>
#include "status_code.h"
#include <QDebug>
ProductDao::ProductDao()
{
    db = ConnectionPool::openConnection();
}

ProductDao::~ProductDao(){
    ConnectionPool::closeConnection(db);
}
int ProductDao::change_product_state(int state,std::vector<QString> product_ids){
    //todo add error info
    //上架1，下架0,-1
    int size=product_ids.size();
    QString where="";
    for(int i=0;i<size-1;i++){
        where=where+" p_id='"+product_ids.at(i)+"' OR ";
    }
    where=where+"p_id= '"+product_ids.at(size-1)+"';";
    QString sql="UPDATE product SET product.state=:state WHERE "+where;

    QSqlQuery query(db);
    query.prepare(sql);
    query.bindValue(":state",state);
    if(!query.exec()){
        qDebug()<<"change state failed.Error:"<<query.lastError().text();
        return SQL_EXEC_ERROR;
    };
    return SUCCESS;

}

// int ProductDao::delete_product(QString product_id){
//     //0 成功；1数据库错误；

//     QString sql=QString("CALL delete_product(:p_id)");

//     QSqlQuery query(db);
//     query.prepare(sql);
//     query.bindValue(":p_id",product_id);
//     int result=1;
//     if(query.exec()){
//         if(query.next()){
//             result=query.value("result").toInt();
//         }

//     }
//     else{
//         qDebug()<<"Delete product failed.Error:"<<query.lastError().text();
//     }
//     return result;
// }


int ProductDao::delete_product(QString product_id){
    //0 成功；1数据库错误；
    //
    int success=-1;
    QSqlQuery query(db);
    QString select_sql="SELECT stock_amount FROM product WHERE p_id=:p_id";

    query.prepare(select_sql);
    query.bindValue(":p_id",product_id);
    success=query.exec();
    if(!success){
        qDebug()<<query.lastError().text();
        return SQL_EXEC_ERROR;
    }
    query.next();
    int stock_amount=query.value(0).toInt();
    if(stock_amount!=0){
        qDebug()<<"amount:"<<stock_amount;
        return STOCK_NOT_EMPTY;//库存不为0；
    }

    db.transaction();
    QString delete_sql="DELETE FROM product WHERE p_id=:p_id";
    query.prepare(delete_sql);
    query.bindValue(":p_id",product_id);
    success=query.exec();
    if(!success){
        qDebug()<<query.lastError().text();
        db.rollback();
        return SQL_EXEC_ERROR;
    }

    QString insert_id_sql="INSERT INTO id_contain(id) VALUES (:id);";
    query.prepare(insert_id_sql);
    query.bindValue(":id",product_id);
    success= query.exec();
        if(!success){
        qDebug()<<query.lastError().text();
        db.rollback();
        return SQL_EXEC_ERROR;
    }

    db.commit();
    return SUCCESS;
}

// 返回码：0 成功，1，没找到，2，错误
int ProductDao::query_product(Product &product,QString product_id){
    QString sql="SELECT * FROM product WHERE p_id=:id;";

    QSqlQuery query(db);
    query.prepare(sql);
    query.bindValue(":id",product_id);
    qDebug()<<"sql:"<<query.lastQuery();


    if(query.exec()){
        if(query.next()){
            QString p_id=query.value(0).toString();
            QString bar_code=query.value(1).toString();
            QString name=query.value(2).toString();
            double price=query.value(3).toDouble();
            QString description=query.value(4).toString();
            QString img_url=query.value(5).toString();

            int state=query.value(6).toInt();
            int stock=query.value(7).toInt();
            product=Product(p_id,bar_code,name,price,description,img_url,state,stock);
            return SUCCESS;
        }else{
            //代表没查到
            return P_ID_NOT_FIND;
        }

    }else{
        qDebug()<<"Query product failed.Error:"<<query.lastError().text();
        return SQL_EXEC_ERROR;
    }

}

int ProductDao::query_product_by_bar_code(Product &product, QString bar_code)
{

    QString sql="SELECT * FROM product WHERE bar_code=:bar_code;";

    QSqlQuery query(db);
    query.prepare(sql);
    query.bindValue(":bar_code",bar_code);
    qDebug()<<"sql:"<<query.lastQuery();


    if(query.exec()){
        if(query.next()){
            QString p_id=query.value(0).toString();
            QString bar_code=query.value(1).toString();
            QString name=query.value(2).toString();
            double price=query.value(3).toDouble();
            QString description=query.value(4).toString();
            QString img_url=query.value(5).toString();

            int state=query.value(6).toInt();
            int stock=query.value(7).toInt();
            product=Product(p_id,bar_code,name,price,description,img_url,state,stock);
            return SUCCESS;

        }else{
            //代表没查到
            return 1;
        }

    }else{
        qDebug()<<"Query product failed.Error:"<<query.lastError().text();
        return 2;
    }
    return 0;

}

int ProductDao::query_products(std::vector<Product> &products,QString keyword,int &all_results_num,
 double lowest_price, double highest_price, int order_by_price,
 int lowest_stock,int highest_stock,int order_by_stock,
 int page, int page_size,int state){

    //state=-1 的话，就返回在售的和不在售卖的

    QTime time;
    time.start();
    qDebug()<<"open connection"<<time.elapsed()/1000.0;


    QString state_string,order_string="";
    QString order_by_price_string;
    QString order_by_stock_string;


    order_by_price_string=(order_by_price==0?" price ":" price DESC ");
    order_by_stock_string=(order_by_stock==0?" stock_amount ":" stock_amount DESC ");

    if(order_by_price!=-1&&order_by_stock!=-1){
        order_string="ORDER BY "+order_by_price_string+","+order_by_stock_string + ", p_id";
    }else if(order_by_price!=-1){
        order_string="ORDER BY "+order_by_price_string + ", p_id";
    }else if(order_by_stock!=-1) {
        order_string="ORDER BY "+order_by_stock_string + ",p_id";
    };

    if(state==-1){
        state_string="";
    }else{
        state_string=(state==1?" AND state=1 ":" AND state=0 ");
    }
    int offset=(page-1)*page_size;


/*
    QString sql="SELECT * FROM product\
                INNER JOIN (  SELECT SQL_CALC_FOUND_ROWS p_id\
                                FROM product   \
                                WHERE concat(IFNULL(name,''),IFNULL(description,''))  LIKE :keyword \
                                AND :highest_price>=price AND price>=:lowest_price "+state_string+" ORDER BY price "+order_string +" LIMIT :offset,:size) AS page USING(p_id);";
*/

    QString sql="SELECT SQL_CALC_FOUND_ROWS * \
                                    FROM product   \
                                    WHERE concat(IFNULL(name,''),IFNULL(description,''),IFNULL(p_id, ''),IFNULL(bar_code,''))  LIKE :keyword \
                                    AND stock_amount >=:lowest_stock AND stock_amount<=:highest_stock \
                                    AND price<=:highest_price AND price>=:lowest_price "+state_string+" "+order_string+" LIMIT :offset,:size;";

    QSqlQuery query(db);
    query.prepare(sql);
    query.bindValue(":keyword","%"+keyword+"%");
    query.bindValue(":highest_price",highest_price);
    query.bindValue(":lowest_price",lowest_price);
    query.bindValue(":offset",offset);
    query.bindValue(":size",page_size);
    query.bindValue(":highest_stock",highest_stock);
    query.bindValue(":lowest_stock",lowest_stock);
    qDebug()<<sql;

    qDebug()<<":keyword"<<"%"+keyword+"%";
    qDebug()<<":highest_price"<<highest_price;
    qDebug()<<":lowest_price"<<lowest_price;
    qDebug()<<":offset"<<offset;
    qDebug()<<":size"<<page_size;
    qDebug()<<":highest_stock"<<highest_stock;
    qDebug()<<":lowest_stock"<<lowest_stock;
    if(query.exec()){
        while(query.next()){
            QString p_id=query.value(0).toString();
            QString bar_code=query.value(1).toString();
            QString name=query.value(2).toString();
            double price=query.value(3).toDouble();
            QString description=query.value(4).toString();
            QString img_url=query.value(5).toString();
            int state=query.value(6).toInt();
            int amount=query.value(7).toInt();
            qDebug()<<"product name:"<<name;
            Product product=Product(p_id,bar_code,name,price,description,img_url,state,amount);
            products.push_back(product);

        }
        query.exec("SELECT FOUND_ROWS()");
        query.next();
        all_results_num=query.value(0).toInt();
        qDebug()<<"all num:"<<query.value(0).toInt();
        return SUCCESS;

    }else{
        qDebug()<<"Query product failed.Error:"<<query.lastError().text();
        return SQL_EXEC_ERROR;
    }
}

//int ProductDao::add_product(const QString &bar_code, const QString &name, double price, const QString &description, const QString &img_url, int state,int stock_amount)
//{
//    //    todo:add product,need to write a stored procedure
//    //条形码重复
//    //存储过程还返回了生成的p_id
//    QString sql="CALL add_product(:bar_code,:name,:price,:description,:img_url,:state,:amount)";

//    QSqlQuery query(db);
//    query.prepare(sql);
//    query.bindValue(":bar_code",bar_code);
//    query.bindValue(":name",name);
//    query.bindValue("description",description);
//    query.bindValue(":img_url",img_url);
//    query.bindValue(":state",state);
//    query.bindValue(":price",price);
//    query.bindValue(":amount",stock_amount);
//    int result=-1;
//    QString p_id;
//    bool exec_result=query.exec();
//    qDebug()<<exec_result;
//    if(exec_result){
//        bool next=query.next();
//        if(next){
//            result=query.value(0).toInt();
//            p_id=query.value(1).toString();

//            if(result==0){
//             return 0;
//            }else if(result==1){
//                return 1;
//            }else{
//                return 1;
//            }
//        }else{
//            qDebug()<<"next = false";
//        }
//    }else{
//        qDebug()<<query.lastError().text();
//        return 1;
//    }

//}

int ProductDao::add_product(const QString &bar_code, const QString &name, double price, const QString &description, const QString &img_url, int state,int stock_amount)
{
    //    todo:add product,need to write a stored procedure
    //条形码重复
    //存储过程还返回了生成的p_id
    QSqlQuery query(db);

    db.transaction();
    QString p_id;
    bool success = query.exec("SELECT A.id FROM id_contain AS A JOIN (SELECT CEIL(MAX(CAST(id AS SIGNED))*RAND())\
                 AS id FROM id_contain) AS B ON CAST(A.id AS SIGNED) >= B.id LIMIT 1");
    if(!success){
        db.rollback();
        return SQL_EXEC_ERROR;
    }
    query.next();
    p_id=query.value("id").toString();

    qDebug()<<"get id:"<<p_id;
    QString insert_sql="INSERT INTO neuerp.product(p_id, bar_code, name, price, description, img_url, state, stock_amount)\
     VALUES (:p_id,:bar_code,:name,:price,:description,:img_url,:state,:amount);";

    query.prepare(insert_sql);
    query.bindValue(":p_id",p_id);
    query.bindValue(":bar_code",bar_code);
    query.bindValue(":name",name);
    query.bindValue(":description",description);
    query.bindValue(":img_url",img_url);
    query.bindValue(":state",state);
    query.bindValue(":price",price);
    query.bindValue(":amount",stock_amount);
    
    success=query.exec();
    query.lastError().text();
    if(!success){
        db.rollback();
        //查看是不是条形码重复
        QString query_bar_code="SELECT * FROM product WHERE bar_code=:bar_code";
        query.prepare(query_bar_code);
        query.bindValue(":bar_code",bar_code);
        success = query.exec();
        if(!success){
            return SQL_EXEC_ERROR;
        }

        if(query.size()>0){
            //有重复的bar_code了
            return BAR_CODE_ERROR;
        }
        return SQL_EXEC_ERROR;
    }

    query.prepare("DELETE FROM id_contain WHERE id = :p_id");
    query.bindValue(":p_id",p_id);

    success=query.exec();
    if(!success){        
        db.rollback();
        return SQL_EXEC_ERROR;
    }

    db.commit();
    return SUCCESS;
}

int ProductDao::update_product(const QString p_id,const QString &bar_code, const QString &name, double price, const QString &description, const QString &img_url, int state,int stock_amount)
{   qDebug()<<" ProductDao::update_product stock amt"<<stock_amount;

    //
    QSqlQuery query(db);
    //先检查bar code是否能用
    QString bar_code_sql="SELECT * FROM product WHERE bar_code=:bar_code";
    query.prepare(bar_code_sql);
    query.bindValue(":bar_code",bar_code);
    int success = query.exec();
    if(success){
        if(query.next()){
            //找到了
            QString p_id_=query.value(0).toString();
            qDebug()<<"bar code conflic p_id"<<p_id_;
            if(p_id_!=p_id){
                return BAR_CODE_ERROR;
            }
        }
    }

    QString sql="UPDATE product SET name=:name,bar_code=:bar_code,\
                price=:price,description=:description,img_url=:img_url,\
                state=:state,stock_amount=:amount WHERE p_id=:p_id";

    query.prepare(sql);

    query.bindValue(":name",name);
    query.bindValue(":bar_code",bar_code);
    query.bindValue(":price",price);
    query.bindValue(":description",description);
    query.bindValue(":img_url",img_url);
    query.bindValue(":state",state);
    query.bindValue(":amount",stock_amount);
    query.bindValue(":p_id",p_id);

    if(!query.exec()){
       qDebug()<<"update product failed. Error:"<<query.lastError().text();
        return SQL_EXEC_ERROR;
    }
    return SUCCESS;
}

