#ifndef STATISTICS_DAO_H
#define STATISTICS_DAO_H
#include "status_code.h"
#include <QDebug>
#include <QVariantList>
#include "connection_pool.h"

class StatisticsDao
{
private:
  QSqlDatabase db;

public:
    StatisticsDao();
    ~StatisticsDao();
    int top_salesman_week(QStringList &salesman_name,QStringList &saleroom);
    int top_salesman_month(QStringList &salesman_name,QStringList &saleroom);
    int top_salesman_trend(const QString &salesman_name, QStringList &trend,QStringList &date);
    
    int top_product_week(QStringList &p_id,QStringList &name,QStringList &saleroom);
    int top_product_month(QStringList &p_id,QStringList &name,QStringList &saleroom);
    int top_product_trend(const QString &p_id,QStringList &trend,QStringList &date);

    int total_saleroom_year(QStringList &saleroom,QStringList &date);
    int total_saleroom_month(QStringList &saleroom,QStringList &date);

    
};

#endif // STATISTICS_DAO_H
