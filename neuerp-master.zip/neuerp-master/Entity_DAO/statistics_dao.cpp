#include "statistics_dao.h"
#include <QStringList>
#include <vector>

StatisticsDao::StatisticsDao()
{
    db = ConnectionPool::openConnection();
}

StatisticsDao::~StatisticsDao()
{
    ConnectionPool::closeConnection(db);
}


int StatisticsDao::top_salesman_week(QStringList &salesman_name, QStringList &saleroom)
{
    QSqlQuery query(db);
    QString sql="select * from top_ten_salesman_week";

    int success=query.exec(sql);
    if(success){
        while(query.next()){
            saleroom<<query.value(0).toString();
            salesman_name<<query.value(1).toString();
        }
        return SUCCESS;
    }else{
        return SQL_EXEC_ERROR;
    }


}

int StatisticsDao::top_salesman_month(QStringList &salesman_name, QStringList &saleroom)
{
    QSqlQuery query(db);
    QString sql="select * from top_ten_salesman_month";
    qDebug()<<"top_salesman_month";
    int success=query.exec(sql);

    if(success){
        while(query.next()){
            saleroom<<query.value(0).toString();
            salesman_name<<query.value(1).toString();
        }
        return SUCCESS;
    }else{
        return SQL_EXEC_ERROR;
    }

}

int StatisticsDao::top_salesman_trend(const QString &salesman_name, QStringList &trend, QStringList &date)
{
    QSqlQuery query(db);
    QString sql="select total_prices,DATE_FORMAT(sale_date,'%Y-%m-%d')\
            from sale_information_pro \
            where salesman=:salesman and DATE_SUB(CURDATE(), INTERVAL 29 DAY) <=sale_date \
            group by DATE_FORMAT(sale_date,'%Y-%m-%d');";
    query.prepare(sql);
    query.bindValue(":salesman",salesman_name);

    int success=query.exec();
    if(success){
        while(query.next()){
            trend<<query.value(0).toString();
            date<<query.value(1).toString();
        }
        return SUCCESS;

    }else{
        return SQL_EXEC_ERROR;
    }

}

int StatisticsDao::top_product_week(QStringList &p_id, QStringList &name, QStringList &saleroom)
{
    QSqlQuery query(db);
    QString sql="select * from top_ten_product_week;";

    int success=query.exec(sql);
    //0 产品名，1商品id，2
    if(success){
        while(query.next()){
            name<<query.value(0).toString();
            p_id<<query.value(1).toString();
            saleroom<<query.value(2).toString();
        }
        return SUCCESS;
    }else{
        return SQL_EXEC_ERROR;
    }

}

int StatisticsDao::top_product_month(QStringList &p_id, QStringList &name, QStringList &saleroom)
{
    QSqlQuery query(db);
    QString sql="select * from top_ten_product_month";

    int success=query.exec(sql);
    if(success){
        while (query.next()) {
            name<<query.value(0).toString();
            p_id<<query.value(1).toString();
            saleroom<<query.value(2).toString();
        }
        return SUCCESS;

    }else{
        return SQL_EXEC_ERROR;
    }

}

int StatisticsDao::top_product_trend(const QString &p_id, QStringList &trend, QStringList &date)
{
    QSqlQuery query(db);
    QString sql="select sum(sale_amt),DATE_FORMAT(sale_date,'%Y-%m-%d')\
            from sale_item,sale_list\
            where sale_item.sale_id=sale_list.sale_id and sale_item.p_id=:p_id\
                  and DATE_SUB(CURDATE(), INTERVAL 29 DAY) <sale_list.sale_date\
            group by DATE_FORMAT(sale_date,'%Y-%m-%d');";

    query.prepare(sql);
    query.bindValue(":p_id",p_id);
    int success=query.exec();
    if(success){
        while (query.next()) {
            trend<<query.value(0).toString();

            date<<query.value(1).toString();
        }
        return SUCCESS;
    }else{
        return SQL_EXEC_ERROR;
    }

}

int StatisticsDao::total_saleroom_year(QStringList &saleroom, QStringList &date)
{
    QSqlQuery query(db);
    QString sql="select sum(total_prices),DATE_FORMAT(sale_date,'%Y-%m') \
            from sale_information_pro \
            where year(CURDATE())=year(sale_date) \
            group by DATE_FORMAT(sale_date,'%Y-%m');";

    int success=query.exec(sql);
    if(success){
        while(query.next()){
            saleroom<<query.value(0).toString();
            date<<query.value(1).toString();
        }
        return SUCCESS;

    }else{
        return SQL_EXEC_ERROR;
    }

}

int StatisticsDao::total_saleroom_month(QStringList &saleroom, QStringList &date)
{
    QSqlQuery query(db);
    QString sql="select sum(total_prices),DATE_FORMAT(sale_date,'%Y-%m-%d')\
            from sale_information_pro\
            where DATE_SUB(CURDATE(), INTERVAL 29 DAY)<sale_date\
            group by DATE_FORMAT(sale_date,'%Y-%m-%d');";

    int success=query.exec(sql);
    if(success){
        while (query.next()) {
            saleroom<<query.value(0).toString();
            date<<query.value(1).toString();
        }
        return SUCCESS;
    }else{
        return SQL_EXEC_ERROR;
    }

}
