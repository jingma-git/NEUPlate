#ifndef CONNECTIONPOOL_H
#define CONNECTIONPOOL_H

/**
* @projectName   ConnectionPool
* @brief         Define a class Connection implements that
*                mysql connecton pool for database's operation.
* @author        luxijia
* @date          2018-6-29
* @modify_author
* @modify_date
*/

#include <QSql>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QQueue>
#include <QString>
#include <QMutex>
#include <QWaitCondition>
#include <QMutexLocker>
#include <QSettings>

class ConnectionPool
{
public:
    static void release(); //close all connection in connection pool
    static QSqlDatabase openConnection();//get a connection from connection pool
    static void closeConnection(QSqlDatabase connection);//return connection to connection pool
    ~ConnectionPool();

private:
    ConnectionPool();
    ConnectionPool(const ConnectionPool &conn);
    ConnectionPool& operator=(const ConnectionPool &conn);
    QSqlDatabase createConnection(const QString &connectionName);
    static ConnectionPool& getInstance();

    QQueue<QString> used_connection_names;//the name of use database connection
    QQueue<QString> unused_connection_names;//the name of unuse database connection

    QString host_name;
    QString database_name;
    QString user_name;
    QString password;
    QString database_type;

    bool relink;//whether relink after connection break
    QString test_sql;//verif that the connection is vaild by test sql

    int max_wait_time;//the maximum wait time of getting connection
    int wait_interval;//the interval wait time of trying to getconnection
    int init_connection_count;//initial connection count
    int max_connection_count;//maximun connection count

    static QMutex mutex;
    static QWaitCondition wait_condition;
    static ConnectionPool *instance;
};

#endif // CONNECTIONPOOL_H
