#include "purchase_order_dao.h"

PurchaseOrderDao::PurchaseOrderDao()
{
    db = ConnectionPool::openConnection();
}
PurchaseOrderDao::~PurchaseOrderDao(){
    ConnectionPool::closeConnection(db);
}

int PurchaseOrderDao::add(PurchaseOrder order){
    qDebug()<<"PurchaseOrderDao::add(PurchaseOrder order)";
    qDebug()<<order.toString();

    QSqlQuery query(db);
    query.prepare("insert into purchase_order (order_id,sp_id,state,date)\
                   values (?,?,?,?)");
    query.addBindValue(order.order_id);
    query.addBindValue(order.sp_id);
    query.addBindValue(order.state);
    query.addBindValue(order.date);

    if(!query.exec()){
        qDebug()<<"if(!query.exec())";
        qDebug() << query.lastError();
        return SQL_EXEC_ERROR;
    }

    query.prepare("insert into order_item (order_id,product_id,product_name,sp_id,sp_name,amt,pp_price)\
                   values (:order_id,:product_id,:product_name,:sp_id,:sp_name,:amt,:pp_price)");

    QVariantList order_ids, p_ids, sp_ids, amts, p_names, sp_names, pp_prices;

    for(std::vector<OrderItem>::iterator it=order.orderItems.begin(); it!=order.orderItems.end(); it++){
        order_ids << it->order_id; qDebug()<<it->order_id;
        p_ids << it->product_id; qDebug()<<it->product_id;
        sp_ids << it->sp_id; qDebug()<<it->sp_id;
        amts << it->amt; qDebug()<<it->amt;
        p_names << it->product_name; qDebug()<<it->product_name;
        sp_names << it->sp_name; qDebug()<<it->sp_name;
        pp_prices << it->pp_price;qDebug()<<it->pp_price;
   }

    query.bindValue(":order_id",order_ids);
    query.bindValue(":product_id",p_ids);
    query.bindValue(":sp_id",sp_ids);
    query.bindValue(":product_name", p_names);
    query.bindValue(":sp_name",sp_names);
    query.bindValue(":amt",amts);
    query.bindValue(":pp_price",pp_prices);

    if (!query.execBatch()){
        qDebug()<<"!query.execBatch()";
        return SQL_EXEC_ERROR;
    }


    return SUCCESS;
}

int PurchaseOrderDao::add_orders(std::vector<PurchaseOrder> &orders){
    qDebug()<<"PurchaseOrderDao::add_orders(std::vector<PurchaseOrder> &orders)";
    int status = SUCCESS;
    for(PurchaseOrder order:orders){
        qDebug()<<order.toString();
        status = add(order);
        if(status!=SUCCESS) return status;
    }

    qDebug()<<QString::number(status);
    return status;
}

int PurchaseOrderDao::delete_order(QString order_id){
    qDebug()<<"PurchaseOrderDao::delete_order(QString order_id)";

    QSqlQuery query(db);
    query.prepare("DELETE FROM order_item WHERE order_id=?");
    query.addBindValue(order_id);
    if(!query.exec()){
        return SQL_EXEC_ERROR;
    }

    query.prepare("DELETE FROM purchase_order WHERE order_id=?");
    query.addBindValue(order_id);

    if (!query.exec())
        return SQL_EXEC_ERROR;

    return SUCCESS;
}

int PurchaseOrderDao::delete_orders(std::vector<QString> &order_ids){
    int status=SUCCESS;
    for(QString order_id:order_ids){
        status = delete_order(order_id);
        if(status!=SUCCESS) return status;
    }
    return status;
}

int PurchaseOrderDao::update_order_state(QString order_id, int state){
    QSqlQuery query(db);

    query.prepare("UPDATE purchase_order SET state=:state WHERE order_id = :order_id");
    query.bindValue(":order_id",order_id);
    query.bindValue(":state", state);
    if(!query.exec()){
        return SQL_EXEC_ERROR;
    }
    return SUCCESS;
}

int PurchaseOrderDao::update_orders_state(std::vector<QString> &order_ids, int state){
    qDebug()<<" PurchaseOrderDao::update_orders_state ";
    QString id_str = "";
    int i=0;
    for(QString order_id:order_ids){
        if(i) id_str +=",";
        id_str += order_id;
        ++i;
    }
    QSqlQuery query(db);

    query.prepare("CALL update_orders_state(?, ?, ?)");
    query.bindValue(0, id_str);
    query.bindValue(1,state);
    query.bindValue(2, 0, QSql::Out);

    if(!query.exec()){
        return SQL_EXEC_ERROR;
    }

    if (0 == query.boundValue(2).toInt())
        return SUCCESS;
    else
        return MODIFY_ERROR;

    return SUCCESS;
}

int PurchaseOrderDao::delete_order_items(std::vector<OrderItem> &orderItems){
    qDebug()<<"delete_order_items(std::vector<OrderItem> &orderItems)";
    QSqlQuery query(db);
    db.transaction();

    bool flag = true;
    for(OrderItem orderItem:orderItems){
        query.prepare("DELETE FROM order_item WHERE order_id=? AND product_id=? AND sp_id=?");
        query.addBindValue(orderItem.order_id);
        query.addBindValue(orderItem.product_id);
        query.addBindValue(orderItem.sp_id);
        if(!query.exec()){
            flag=false;
            db.rollback();
            return SQL_EXEC_ERROR;
        }
    }
    if(flag){
        db.commit();
        return SUCCESS;
    }
    else
        return DELETE_ERROR;
}

int PurchaseOrderDao::query_orders_by_state(std::vector<PurchaseOrder> &orders, int state,
                                            int &all_results_num, int page, int page_size){
    qDebug()<<"PurchaseOrderDao::query_orders_by_state--state"<<QString::number(state);
    QSqlQuery query(db);
    int offset=(page-1)*page_size;

    query.prepare("SELECT SQL_CALC_FOUND_ROWS * \
                   FROM purchase_order WHERE state=:state ORDER BY date DESC,order_id DESC LIMIT :offset,:page_size");
    query.bindValue(":offset", offset);
    query.bindValue(":state", state);
    query.bindValue(":page_size", page_size);

    if(!query.exec()) return SQL_EXEC_ERROR;

    QString order_ids = "";
    std::map<QString,int> ordMap;
    int cnt = 0;
    while(query.next()){
        PurchaseOrder order;
        order.order_id = query.value("order_id").toString();
        order.sp_id = query.value("sp_id").toString();
        order.state = query.value("state").toInt();
        order.date = query.value("date").toDateTime().toString("yyyy-MM-dd hh:mm:ss");
        if(cnt)
            order_ids += ",";
        order_ids += order.order_id;
        orders.push_back(order);
        ordMap[order.order_id]=cnt;
        ++cnt;
    }

    if(!query.exec("SELECT FOUND_ROWS()"))
        return SQL_EXEC_ERROR;
    query.next();
    all_results_num = query.value(0).toInt();

    if(!query.exec())
        return SQL_EXEC_ERROR;

    query.exec("SELECT * FROM order_item WHERE order_id IN("+order_ids+")");
    while(query.next()){
        OrderItem orderItem;
        orderItem.order_id = query.value("order_id").toString();
        orderItem.product_id = query.value("product_id").toString();
        orderItem.sp_id = query.value("sp_id").toString();
        orderItem.product_name = query.value("product_name").toString();
        orderItem.sp_name = query.value("sp_name").toString();
        orderItem.amt = query.value("amt").toInt();
        orderItem.pp_price = query.value("pp_price").toDouble();

        int idx = ordMap[orderItem.order_id];
        PurchaseOrder &order = orders[idx];
        order.orderItems.push_back(orderItem);
    }

    return SUCCESS;
}

int PurchaseOrderDao::query_order_items(std::vector<OrderItem> &orderItems, QString order_id){
    qDebug()<<"PurchaseOrderDao::query_order_items(std::vector<OrderItem> &orderItems,";
    QSqlQuery query(db);

    query.prepare("SELECT * FROM order_item WHERE order_id=?");
    query.addBindValue(order_id);

    if(!query.exec()) {
        qDebug()<<query.lastError().text();
        return SQL_EXEC_ERROR;
    }
    while(query.next()){
        OrderItem orderItem;
        orderItem.order_id = query.value("order_id").toString();
        orderItem.product_id = query.value("product_id").toString();
        orderItem.sp_id = query.value("sp_id").toString();
        orderItem.product_name = query.value("product_name").toString();
        orderItem.sp_name = query.value("sp_name").toString();
        orderItem.amt = query.value("amt").toInt();
        orderItem.pp_price = query.value("pp_price").toDouble();
        orderItems.push_back(orderItem);
    }

    return SUCCESS;
}
