#ifndef PRODUCT_DAO_H
#define PRODUCT_DAO_H

#include "connection_pool.h"
#include "entity/product.h"
#include <QVariantList>
#include <vector>
class ProductDao
{
  private:
    QSqlDatabase db;

  public:
    ProductDao();
    ~ProductDao();
    int query_product(Product &product, QString product_id);
    int query_product_by_bar_code(Product &product, QString bar_code);
    int query_products(std::vector<Product> &products, QString keyword, int &all_results_num,
                       double lowest_price, double highest_price, int order_by_price,
                       int low_stock, int high_stock, int order_by_stock,
                       int page, int page_size, int state);
    int add_product(const QString &bar_code, const QString &name, double price,
                    const QString &description, const QString &img_url, int state, int amount);
    int update_product(const QString p_id, const QString &bar_code, const QString &name, double price,
                       const QString &description, const QString &img_url, int state, int stock_amount);
    int change_product_state(int state, std::vector<QString> product_ids);
    int delete_product(QString product_id);
};

#endif // PRODUCT_DAO_H
