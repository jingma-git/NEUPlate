/**
* @projectName   Connection
* @brief         Implement the funtion of class Connection
* @author        luxijia
* @date          2018-6-29
* @see           Connection
* @modify_author
* @modify_date
*/

#include "connection_pool.h"

#include <QFile>
#include <QDir>

/**
* @functionName  ConnectionPool
* @Description   class ConnectionPool constructor
* @author        luxijia
* @date          2018-6-30
* @parameter
* @return
*/
QMutex ConnectionPool::mutex;
QWaitCondition ConnectionPool::wait_condition;
ConnectionPool *ConnectionPool::instance = NULL;

ConnectionPool::ConnectionPool()
{
    QSettings setting(":/app.ini",QSettings::IniFormat);
    setting.beginGroup("database");
    host_name = setting.value("host_name").toString();
    database_name = setting.value("database_name").toString();
    user_name = setting.value("user_name").toString();
    password = setting.value("password").toString();
    database_type = QString("Q%1").arg(setting.value("database_type").toString());

    relink = true;
    test_sql = "SELECT 1";

    max_wait_time = setting.value("max_wait_time").toInt();
    wait_interval = setting.value("wait_interval").toInt();
    max_connection_count = setting.value("max_connection_count").toInt();
    init_connection_count = setting.value("init_connection_count").toInt();
    setting.endGroup();
}

/**
* @functionName  ~ConnectionPool
* @Description   class ConnectionPool deconstructor
* @author        luxijia
* @date          2018-6-30
* @parameter
* @return
*/
ConnectionPool::~ConnectionPool()
{
    foreach (QString connection_name, used_connection_names)
        QSqlDatabase::removeDatabase(connection_name);

    foreach (QString connection_name, unused_connection_names)
        QSqlDatabase::removeDatabase(connection_name);
}

/**
* @functionName  getInstance
* @Description   use Single pattern to get class ConnectionPool object
* @author        luxijia
* @date          2018-6-30
* @parameter
* @return        ConnectionPool&
*/
ConnectionPool& ConnectionPool::getInstance()
{
    if (NULL == instance)
    {
        QMutexLocker locker(&mutex);

        if (NULL == instance)
            instance = new ConnectionPool();
    }

    return *instance;
}

/**
* @functionName  createConnection
* @Description   create or reuse database connection
* @author        luxijia
* @date          2018-6-30
* @parameter     connection_name the name of QSqlDatabase connection
* @return        if create connection is vaild or has the same name connection if connection pool
*                return vaild QSqlDatabase object.
*/
QSqlDatabase ConnectionPool::createConnection(const QString &connection_name)
{
    //if connection has been create, use previous connection
    if (QSqlDatabase::contains(connection_name))
    {
        QSqlDatabase use_db = QSqlDatabase::database(connection_name);

        if (relink)
        {
            qDebug() << "Test connection, execute:'" << test_sql << "' for " << connection_name << ".\n";
            QSqlQuery query(test_sql, use_db);

            if (query.lastError().type() != QSqlError::NoError && !use_db.open())
            {
                qDebug() << "Open database error: " << use_db.lastError().text() << ".";
                return QSqlDatabase();
            }
            qDebug() << "Test connection, execute:'" << test_sql << "' for " << connection_name << " successful.\n";
        }

        return use_db;
    }

    //create new connection
    QSqlDatabase db = QSqlDatabase::addDatabase(database_type, connection_name);
    db.setHostName(host_name);
    db.setDatabaseName(database_name);
    db.setUserName(user_name);
    db.setPassword(password);

    if (!db.open())
    {
        qDebug() << "Create database error: " << db.lastError().text() << ".";
        return QSqlDatabase();
    }

    return db;
}

/**
* @functionName  openConnection
* @Description   get a connection from ConnectionPool
* @author        luxijia
* @date          2018-6-30
* @parameter
* @return        if create connection is vaild or has the same name connection if connection pool
*                return vaild QSqlDatabase object.
*/
QSqlDatabase ConnectionPool::openConnection()
{
    ConnectionPool &conn = ConnectionPool::getInstance();
    QString connection_name;

    //add lock
    QMutexLocker locker(&mutex);

    //count of connection
    int connection_count = conn.used_connection_names.size() + conn.unused_connection_names.size();


    for (int i = 0; i < conn.max_wait_time && conn.unused_connection_names.size() == 0
         && connection_count == conn.max_connection_count ; i += conn.wait_interval)
    {
        wait_condition.wait(&mutex, conn.wait_interval);
        connection_count = conn.used_connection_names.size() + conn.unused_connection_names.size();
    }

    if (conn.unused_connection_names.size() > 0)
        connection_name = conn.unused_connection_names.dequeue();
    else if (connection_count < conn.max_connection_count)
        connection_name = QString("Connection-%1").arg(connection_count + 1);
    else
    {
        qDebug() << "Cannot create more connections.";
        return QSqlDatabase();
    }

    QSqlDatabase db = conn.createConnection(connection_name);

    if (db.isOpen())
        conn.used_connection_names.enqueue(connection_name);

    return db;
}

/**
* @functionName  closeConnection
* @Description   return a connection back connection pool
* @author        luxijia
* @date          2018-6-30
* @parameter     connection using connection
* @return
*/
void ConnectionPool::closeConnection(QSqlDatabase connection)
{
    ConnectionPool &conn = ConnectionPool::getInstance();
    QString connection_name = connection.connectionName();

    QMutexLocker locker(&mutex);

    if (conn.used_connection_names.contains(connection_name))
    {
        conn.used_connection_names.removeOne(connection_name);
        conn.unused_connection_names.enqueue(connection_name);
        wait_condition.wakeOne();
    }
}

/**
* @functionName  release
* @Description   close all connection in connection pool
* @author        luxijia
* @date          2018-6-30
* @parameter
* @return
*/
void ConnectionPool::release()
{
    QMutexLocker locker(&mutex);

    delete instance;
    instance = NULL;
}

