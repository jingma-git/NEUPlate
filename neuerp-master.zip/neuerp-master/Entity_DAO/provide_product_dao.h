#ifndef PROVIDE_PRODUCT_DAO_H
#define PROVIDE_PRODUCT_DAO_H

/**
* @projectName   neuerp_server
* @brief         This class interacts with the database to
*                get or save provide product information.
* @author        luxijia
* @date          2018-7-4
* @modify_author
* @modify_date
*/

#include <iostream>
#include <vector>
#include <entity/provide_product.h>
#include <QString>
#include <status_code.h>
#include "connection_pool.h"

class ProvideProductDao
{
public:
    ProvideProductDao();
    ~ProvideProductDao();
    int query_provide_product(std::vector<ProvideProduct> &products, const QString &keyword, int &all_result_num, int offset, int item);
    int query_provide_product_by_id(const QString &sp_id, std::vector<ProvideProduct> &products);
    int save_provide_product(const QString &sp_id, std::vector<ProvideProduct> &products);
    int delete_provide_product_record(const QString &sp_id, const QString &pp_id);
    int delete_provide_product_all(const QString &sp_id);
    int delete_provide_product_list(const QString &sp_id, const QString &pp_id);
    int update_provice_product(std::vector<ProvideProduct> &products);
private:
    QSqlDatabase db;
};

#endif // PROVIDE_PRODUCT_DAO_H
