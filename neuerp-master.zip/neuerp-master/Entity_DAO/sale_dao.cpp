#include "sale_dao.h"

/**
* @projectName   neuerp_server
* @brief         Implements the function which declare in
*                class SaleDao.
* @author        luxijia
* @date          2018-7-3
* @modify_author
* @modify_date
*/

/**
* @functionName  SaleDao
* @Description   The constructor of class SupplierDao
*                that get a connection object from ConnectionPool.
* @author        luxijia
* @date          2018-7-6
*/
SaleDao::SaleDao(): db(ConnectionPool::openConnection())
{

}

SaleDao::SaleDao(const QSqlDatabase &db): db(db)
{

}

/**
* @functionName  transaction
* @Description   start a trancaction.
* @author        luxijia
* @date          2018-7-6
*/
void SaleDao::transaction()
{
    db.transaction();
}

/**
* @functionName  commit
* @Description   commit result if transaction success.
* @author        luxijia
* @date          2018-7-6
*/
void SaleDao::commit()
{
    db.commit();
}

/**
* @functionName  rollback
* @Description   rollback result if transaction falied.
* @author        luxijia
* @date          2018-7-6
*/
void SaleDao::rollback()
{
    db.rollback();
}

/**
* @functionName  ~ProvideProductDao
* @Description   The deconstructor of class SupplierDao
*                that return a connection object from ConnectionPool.
* @author        luxijia
* @date          2018-7-6
*/
SaleDao::~SaleDao()
{
    // release connection
    ConnectionPool::closeConnection(db);
}

/**
* @functionName  save_sale
* @Description   save sale list and sale item into database
*                that use database transaction.
* @author        luxijia
* @date          2018-7-6
* @parameter     sale_id sale list id
* @parameter     date sale list date
* @parameter     client_name the name of sale client
* @parameter     client_address the address of sale client
* @parameter     client_phone the phone of sale client
* @parameter     salesman the salesman of sale list.
* @parameter     handler_id the handler employee id of sale client
* @pararmeter    items the sale item collection in sale list.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is add sale list success
*/
int SaleDao::save_sale(const QString &sale_id, const QString &date, const QString &client_name, const QString &client_address,
                       const QString &client_phone, const QString &salesman, const QString &handler_id, const QString &remark,
                       std::vector<SaleItem> &items)
{
    QSqlQuery add_list(db);
    QSqlQuery add_item(db);
    QSqlQuery sub_stock(db);
    QVariantList v1, v2, v3, v4;

    db.transaction();
    add_list.prepare("INSERT INTO sale_list VALUES(:sale_id, :sale_date, :client_name,\
                     :client_address, :client_phone, 1, :salesman, :handler_id, :remark)");

    add_list.bindValue(":sale_id", sale_id);
    add_list.bindValue(":sale_date", date);
    add_list.bindValue(":client_name", client_name);
    add_list.bindValue(":client_address", client_address);
    add_list.bindValue(":client_phone", client_phone);
    add_list.bindValue(":salesman", salesman);
    add_list.bindValue(":remark", remark);
    add_list.bindValue(":handler_id", handler_id);

    if(!add_list.exec())
    {
        db.rollback();
        qCritical() << "Add sale list failed. Error:" << add_list.lastError().text();
        return SQL_EXEC_ERROR;
    }

    add_item.prepare("INSERT INTO sale_item(p_id, sale_id, sale_price, sale_amt) VALUES(?, ?, ?, ?)");

    int size = items.size();

    for(int i = 0; i < size; i++)
    {
        v1 << items[i].getProduct_id();
        v2 << sale_id;
        v3 << items[i].getSale_price();
        v4 << items[i].getSale_amount();
    }

    add_item.addBindValue(v1);
    add_item.addBindValue(v2);
    add_item.addBindValue(v3);
    add_item.addBindValue(v4);

    if (!add_item.execBatch())
    {
        db.rollback();
        qCritical() << "Add sale item failed. Error:" << add_list.lastError().text();
        return SQL_EXEC_ERROR;
    }

    v1.clear();
    v2.clear();

    sub_stock.prepare("UPDATE product SET stock_amount = stock_amount - ? WHERE p_id = ?");

    for(int j = 0; j < size; j++)
    {
        v1 << items[j].getSale_amount();
        v2 << items[j].getProduct_id();
    }

    sub_stock.addBindValue(v1);
    sub_stock.addBindValue(v2);

    if (!sub_stock.execBatch())
    {
        db.rollback();
        qCritical() << "Sub product stock failed. Error:" << sub_stock.lastError().text();
        return SQL_EXEC_ERROR;
    }

    db.commit();
    return SUCCESS;
}

/**
* @functionName  query_sale_list
* @Description   query sale list in database by keyword
*                that can furry query.
* @author        luxijia
* @date          2018-7-6
* @parameter     sale_list query sale list result collection
* @parameter     keyword search keyword
* @parameter     start_time query sale list start time
* @parameter     end_time query sale list end time
* @parameter     offset the offset of query database table
* @parameter     item the number of item each page
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query sale list in database has result
*                EMPTY_SET is query sale list in database noe result
*/
int SaleDao::query_sale_list(std::vector<SaleList> &sale_list, int &all_result_num, const QString &keyword, const QString &start_time,
                             const QString &end_time,int offset, int item, int state)
{
    //get connection
    QSqlQuery query(db);

    QString state_statement = "";

    if (0 == state)
        state_statement = "AND sale_state = 0";
    else if (1 == state)
        state_statement = "AND sale_state = 1";

    //insert sql and bind value
    query.prepare("SELECT SQL_CALC_FOUND_ROWS * FROM sale_information WHERE DATE_FORMAT(sale_date,'%Y-%m-%d') >= :start_time\
                  AND DATE_FORMAT(sale_date,'%Y-%m-%d') <= :end_time AND CONCAT(IFNULL(client_name,''), IFNULL(client_address,''),\
                  IFNULL(handler_name,''), IFNULL(salesman,''), IFNULL(remark,'')) LIKE :keyword " +
                  state_statement + " ORDER BY sale_date DESC LIMIT :offset, :item");
    query.bindValue(":start_time", start_time);
    query.bindValue(":end_time", end_time);
    query.bindValue(":keyword", "%" + keyword + "%");
    query.bindValue(":offset", offset);
    query.bindValue(":item", item);
    qDebug() << start_time << end_time << keyword;

    db.transaction();
    if (query.exec())
    {
        while (query.next())
        {
            SaleList list;
            list.setSale_id(query.value("sale_id").toString());
            list.setSale_date(query.value("sale_date").toDateTime().toString("yyyy-MM-dd hh:mm:ss"));
            list.setClient_name(query.value("client_name").toString());
            list.setClient_address(query.value("client_address").toString());
            list.setClient_phone(query.value("client_phone").toString());
            list.setSale_state(query.value("sale_state").toInt());
            list.setSalesman(query.value("salesman").toString());
            list.setHandler_id(query.value("handler_id").toString());
            list.setHandler_name(query.value("handler_name").toString());
            list.setRemark(query.value("remark").toString());
            sale_list.push_back(list);
        }
    }
    else
    {
        db.rollback();
        qCritical() << "Query sale list with keyword and time failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (query.exec("SELECT FOUND_ROWS()"))
    {
        if (query.next())
            all_result_num = query.value(0).toInt();
    }
    else
    {
        db.rollback();
        qCritical() << "Query supplier rows failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    db.commit();
    if (sale_list.empty())
        return EMPTY_SET;
    else
        return SUCCESS;
}

/**
* @functionName  query_sale_list_by_time
* @Description   query sale list in database by time.
* @author        luxijia
* @date          2018-7-6
* @parameter     sale_list query sale list result collection
* @parameter     start_time query sale list start time
* @parameter     end_time query sale list end time
* @parameter     offset the offset of query database table
* @parameter     item the number of item each page
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query sale list in database has result
*                EMPTY_SET is query sale list in database noe result
*/
int SaleDao::query_sale_list_by_time(std::vector<SaleList> &sale_list, const QString &start_time,
                                     const QString &end_time, int offset, int item)
{
    QSqlQuery query(db);

    //insert sql and bind value
    query.prepare("SELECT * FROM sale_information INNER JOIN\
                  (SELECT sale_id FROM sale_information WHERE sale_date >= :start_time AND sale_date <= :end_time\
                   LIMIT :offset, :item) AS page USING(sale_id)");
    query.bindValue(":start_time", start_time);
    query.bindValue(":end_time", end_time);
    query.bindValue(":offset", offset);
    query.bindValue(":item", item);

    if (query.exec())
    {
        while (query.next())
        {
            SaleList list;
            list.setSale_id(query.value("sale_id").toString());
            list.setSale_date(query.value("sale_date").toDateTime().toString("yyyy-MM-dd hh:mm:ss"));
            list.setClient_name(query.value("client_name").toString());
            list.setClient_address(query.value("client_address").toString());
            list.setClient_phone(query.value("client_phone").toString());
            list.setSale_state(query.value("sale_state").toInt());
            list.setSalesman(query.value("salesman").toString());
            list.setHandler_id(query.value("handler_id").toString());
            list.setHandler_name(query.value("name").toString());
            sale_list.push_back(list);
        }
    }
    else
    {
        qCritical() << "Query sale list with time failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (sale_list.empty())
        return EMPTY_SET;
    else
        return SUCCESS;
}

/**
* @functionName  query_sale_item
* @Description   query sale list's items in database.
* @author        luxijia
* @date          2018-7-6
* @parameter     sale_list query sale list's items result collection
* @parameter     start_time query sale list's items start time
* @parameter     end_time query sale list's items end time
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is query sale list's items in database has result
*                EMPTY_SET is query sale list's items in database noe result
*/
int SaleDao::query_sale_item(std::vector<SaleItem> &sale_item, const QString &sale_id)
{
    //get connection
    QSqlQuery query(db);

    //insert sql and bind value
    query.prepare("SELECT * FROM sale_item_information WHERE sale_id=:sale_id");
    query.bindValue(":sale_id", sale_id);

    if (query.exec())
    {
        while (query.next())
        {
            SaleItem item;
            item.setProduct_id(query.value("product_id").toString());
            item.setProduct_name(query.value("product_name").toString());
            item.setSale_amount(query.value("sale_amt").toInt());
            item.setSale_price(query.value("sale_price").toDouble());
            sale_item.push_back(item);
        }
    }
    else
    {
        qCritical() << "Query sale list item failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (sale_item.empty())
        return EMPTY_SET;
    else
        return SUCCESS;
}

/**
* @functionName  update_sale_state
* @Description   change sale list state to cancel
*                which value is 0.
* @author        luxijia
* @date          2018-7-3
* @parameter     id  a supplier id string are connected using commas.
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is update sale list state success
*/
int SaleDao::update_sale_state(const QString &sale_id)
{
    //get connection
    QSqlQuery query(db);

    //insert sql and bind value
    query.prepare("CALL repeal_sale_list(?, ?)");
    query.bindValue(0, sale_id);
    query.bindValue(1, 0, QSql::Out);

    if (!query.exec())
    {
        qCritical() << "Repeal sale list failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (0 == query.boundValue(1).toInt())
        return SUCCESS;
    else
        return CHANGE_ERROR;
}

/**
* @functionName  delete_sale
* @Description   delete sale list with sale list id in database
*                by procedure.
* @author        luxijia
* @date          2018-7-6
* @return        SQL_EXEC_ERROR is execute sql has a error
*                SUCCESS is delete all suppliers success
*                DELETE_ERROR is delete sale list error
*/
int SaleDao::delete_sale(const QString &sale_id)
{
    QSqlQuery query(db);

    //insert sql and bind value
    query.prepare("CALL delete_sale_list(?, ?)");
    query.bindValue(0, sale_id);
    query.bindValue(1, 0, QSql::Out);

    if (!query.exec())
    {
        qCritical() << "Query supplier with keyword failed. Error: " << query.lastError().text();
        return SQL_EXEC_ERROR;
    }

    if (0 == query.boundValue(1).toInt())
        return SUCCESS;
    else
        return DELETE_ERROR;
}
