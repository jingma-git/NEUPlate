#include "stock_dao.h"

StockDao::StockDao()
{
    db=ConnectionPool::openConnection();
}

StockDao::~StockDao()
{
    ConnectionPool::closeConnection(db);
}

int StockDao::get_stock(QString product_id,int &stock)
{
    QSqlQuery query(db);
    QString sql="SELECT stock_amount FROM product WHERE p_id=:p_id";
    query.prepare(sql);
    query.bindValue(":p_id",product_id);
    int success=-1;
    success=query.exec();
    if(success){
        if(query.size()==0){
            qDebug()<<"p_id not find";
            return P_ID_NOT_FIND;
        }
        success=query.next();
        if(success){
            stock=query.value(0).toInt();
            return SUCCESS;
        }else{
            qDebug()<<query.lastError().text();
            return SQL_EXEC_ERROR;
        }

    }else{
        qDebug()<<query.lastError().text();
        return SQL_EXEC_ERROR;
    }

}

int StockDao::set_stock(QString product_id, int stock)
{
    QSqlQuery query(db);
    QString sql="UPDATE product set stock_amount=:stock WHERE p_id=:p_id";
    query.prepare(sql);
    query.bindValue(":p_id",product_id);
    query.bindValue(":stock",stock);
    int success=-1;
    success= query.exec();
    if(success){
        return SUCCESS;
    }else{
        return SQL_EXEC_ERROR;
    }
}
