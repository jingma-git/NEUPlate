/**
* @projectName   neuerp_server
* @brief         connect user and database
* @author        chenhanlin
* @date          2018-07-04
*/

#ifndef USERDAO_H
#define USERDAO_H

#include <QSqlDatabase>
#include <entity/user.h>
#include <vector>

class UserDAO
{
public:
    UserDAO();
    UserDAO(const QSqlDatabase &db);
    ~UserDAO();
    int save_user(User &user) const;
    int delete_user(const QString &employee_id) const;

    int query_all_access_code(std::map<QString, int> &access_code) const;
    int update_all_access_code(const std::map<QString, int> &codes) const;
//    int query_security_question(std::vector<security_question> &questions, User &user) const;
    int query_security_question(std::map<QString, QString> &questions, const QString &employee_id) const;
    int query_all_security_question(std::map<QString, QString> &questions) const;
    int check_security_question(const QString &q_id, const QString &e_id, const QString &answer, bool &checked) const;
    int update_security_question(const std::map<QString, QString> &answers, const QString &e_id) const;
    int delete_security_question(const QString &q_id, const QString &u_id) const;

    int query_user(const QString &employee_id, std::vector<User> &users);
//    int query_user(const QString &username, std::vector<User> &users);
    int query_all_user(std::vector<User> &users);

    void transaction();
    void rollback();
    void commit();
private:
    QSqlDatabase db_connection;
    bool m_b_is_my;

    int insert_user(User &user) const;
    int update_user(const User &user) const;
};

#endif // USERDAO_H
