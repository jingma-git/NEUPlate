#include "userdao.h"
#include "Entity_DAO/connection_pool.h"
#include "status_code.h"
#include <QSqlQuery>

UserDAO::UserDAO(): db_connection(ConnectionPool::openConnection()), m_b_is_my(true)
{
}

UserDAO::UserDAO(const QSqlDatabase &db): db_connection(db), m_b_is_my(false)
{

}

UserDAO::~UserDAO()
{
    // release connection
    if (m_b_is_my) {
        ConnectionPool::closeConnection(db_connection);
    }
}

/**
* @functionName  save_user
* @Description   save this object's data, if new, will invoke insert, otherwise udpate
* @author        chenhanlin
* @date          2018-07-02
* @parameter     User &user
* @return        int
*/
int UserDAO::save_user(User &user) const
{
    // check the data is new
    if (user.is_new()){
        return insert_user(user);
    }else{
        return update_user(user);
    }
}

/**
* @functionName  delete_user
* @Description   delete the user from database
* @author        chenhanlin
* @date          2018-07-02
* @parameter     int employee_id
* @return        int
*/
int UserDAO::delete_user(const QString &employee_id) const
{
    QSqlQuery sql(db_connection);
    // prepare sql
    sql.prepare("SELECT u_id FROM user WHERE e_id=:id");
    sql.bindValue(":id", employee_id);
    // excute sql
    bool is_success = sql.exec();
    qDebug() << "query u_id in delete_user";
    if(!is_success){
        qDebug() << sql.lastError();
        return SQL_EXEC_ERROR;
    }
    sql.next();
    QString u_id(sql.value("u_id").toString());
    /*
    sql.prepare("DELETE FROM user_permission WHERE u_id=:id");
    sql.bindValue(":id", u_id);
    is_success = sql.exec();
    qDebug() << "delete user_permission in delete_user";
    if(!is_success){
        qDebug() << sql.lastError();
        return SQL_EXEC_ERROR;
    }
    */
    sql.prepare("DELETE FROM user_question WHERE u_id=:id");
    sql.bindValue(":id", u_id);
    is_success = sql.exec();
    qDebug() << "delete user_question in delete_user";
    if(!is_success){
        return SQL_EXEC_ERROR;
    }
    sql.prepare("DELETE FROM user WHERE u_id=:id");
    sql.bindValue(":id", u_id);
    is_success = sql.exec();
    qDebug() << "delete user in delete_user";
    if(!is_success){
        qDebug() << sql.lastError();
        return SQL_EXEC_ERROR;
    }
    sql.prepare("INSERT INTO id_contain VALUES(:id)");
    sql.bindValue(":id", u_id);
    is_success = sql.exec();
    qDebug() << "insert id in delete_user";
    if(!is_success){
        qDebug() << sql.lastError();
        return SQL_EXEC_ERROR;
    }
    // return result
    return SUCCESS;
}

/**
* @functionName  query_all_access_code
* @Description   get all permission and its access code from database
* @author        chenhanlin
* @date          2018-07-02
* @parameter     map<int, QString> &access_code
* @return        int
*/
int UserDAO::query_all_access_code(std::map<QString, int> &access_code) const
{
    QSqlQuery query(db_connection);
    bool is_success = query.exec("SELECT `access_code`, `desc` FROM permission");
    if(!is_success){
        return SQL_EXEC_ERROR;
    }
    while (query.next()) {
        access_code.insert(std::map<QString, int>::value_type(query.value("desc").toString(), query.value("access_code").toInt()));
    }
    if (access_code.empty()) return EMPTY_SET;
    else return SUCCESS;
}

/**
* @functionName  update_all_access_code
* @Description   reset access code in database
* @author        chenhanlin
* @date          2018-07-06
* @parameter     void
* @return        void
*/
int UserDAO::update_all_access_code(const std::map<QString, int> &codes) const
{
    QSqlQuery sql(db_connection);
    bool success = sql.exec("DELETE FROM permission");
    if(!success){
        return SQL_EXEC_ERROR;
    }
    sql.prepare("INSERT INTO permission(`access_code`, `desc`) VALUES (:access_code, :desc)");
    for(const auto &code : codes){
        sql.bindValue(":desc", code.first);
        sql.bindValue(":access_code", code.second);
        success = sql.exec();
        if(!success){
            qDebug() << sql.lastError();
            return SQL_EXEC_ERROR;
        }
    }
    return SUCCESS;
}

/**
* @functionName  query_security_question
* @Description   get the security question set by employee id
* @author        chenhanlin
* @date          2018-07-02
* @parameter     map<QString, QString> questions, QString employee_id
* @return        int
*/
int UserDAO::query_security_question(std::map<QString, QString> &questions, const QString &employee_id) const
{
    QSqlQuery query(db_connection);
    // prepare sql
    query.prepare("SELECT q_id, question, answer FROM user_question_answer WHERE e_id=:id");
    query.bindValue(":id", employee_id);
    bool is_success = query.exec();
    // check sql excute
    if (!is_success) return SQL_EXEC_ERROR;
    // put data
    while (query.next()) {
        QString q_id(query.value("q_id").toString());
        QString question(query.value("question").toString());
        questions.insert(std::map<QString, QString>::value_type(q_id, question));
    }
    // return result
    if (questions.empty()) return EMPTY_SET;
    else return SUCCESS;
}

/**
* @functionName  query_all_security_question
* @Description   brief
* @author        chenhanlin
* @date          2018-07-04
* @parameter     map<QString, QString> question
* @return        int
*/
int UserDAO::query_all_security_question(std::map<QString, QString> &questions) const
{
    QSqlQuery query(db_connection);
    bool success = query.exec("SELECT q_id, question FROM security_question");

    if(!success) return SQL_EXEC_ERROR;

    while(query.next()){
        questions.insert(std::map<QString, QString>::value_type(query.value("q_id").toString(), query.value("question").toString()));
    }

    if (questions.empty()) return EMPTY_SET;
    else return SUCCESS;
}

int UserDAO::check_security_question(const QString &q_id, const QString &e_id, const QString &answer, bool &checked) const
{
    QSqlQuery query(db_connection);
    // prepare sql
    query.prepare("SELECT answer FROM user_question_answer WHERE e_id=:e_id AND q_id=:q_id");
    query.bindValue(":e_id", e_id);
    query.bindValue(":q_id", q_id);
    bool success = query.exec();
    // check execute
    if (!success) return SQL_EXEC_ERROR;
    while (query.next()) {
        QString u_answer(query.value("answer").toString());
        if (answer == u_answer) checked = true;
        else checked = false;
    }
    return SUCCESS;
}

/**
* @functionName  query_user
* @Description   query user from database by employee_id
* @author        chenhanlin
* @date          2018-07-02
* @parameter     int employee_id, vector<User> &user
* @return        int
*/
int UserDAO::query_user(const QString &employee_id, std::vector<User> &users)
{
    QSqlQuery query(db_connection);
    // prepare sql
    query.prepare("SELECT u_id, passwd, e_id, status, permission_level, access_code FROM user WHERE e_id = :id");
    query.bindValue(":id",  employee_id);
    bool is_success = query.exec();
    // check excute
    if (!is_success) return SQL_EXEC_ERROR;
    // get data
    while(query.next()){
        QString u_id(query.value("u_id").toString());
        QString e_id(query.value("e_id").toString());
        int access_code = query.value("access_code").toInt();
        QString passwd(query.value("passwd").toString());
        int permission_leve = query.value("permission_level").toInt();
        int status = query.value("status").toInt();
        users.push_back(User(u_id, e_id, access_code, passwd, permission_leve, status));
    }
    if(users.empty()) return EMPTY_SET;
    else return SUCCESS;
}

/**
* @functionName  query_all_user
* @Description   query all user in database
* @author        chenhanlin
* @date          2018-07-02
* @parameter     int employee_id, vector<User> &user
* @return        int
*/
int UserDAO::query_all_user(std::vector<User> &users)
{
    QSqlQuery query(db_connection);
    // prepare sql
    bool is_success = query.exec("SELECT u_id, passwd, e_id, status, permission_level, access_code FROM user");
    // check excute
    if (!is_success) return SQL_EXEC_ERROR;
    // get data
    while(query.next()){
        QString u_id(query.value("u_id").toString());
        QString e_id(query.value("e_id").toString());
        int access_code = query.value("access_code").toInt();
        QString passwd(query.value("passwd").toString());
        int permission_leve = query.value("permission_level").toInt();
        int status = query.value("status").toInt();
        users.push_back(User(u_id, e_id, access_code, passwd, permission_leve, status));
    }
    if(users.empty()) return EMPTY_SET;
    else return SUCCESS;
}

/**
* @functionName  set_security_question
* @Description   set new security question for user
* @author        chenhanlin
* @date          2018-07-03
* @parameter     map<int, QString> answer, int u_id
* @return        int
*/
int UserDAO::update_security_question(const std::map<QString, QString> &answer, const QString &e_id)const
{
    QString u_id;
    QSqlQuery query(db_connection);
    // get u_id
    query.prepare("SELECT u_id FROM user WHERE e_id=:e_id");
    query.bindValue(":e_id", e_id);
    bool success = query.exec();
    if(!success) return SQL_EXEC_ERROR;
    while(query.next()){
        u_id = query.value("u_id").toString();
    }
    // get exist question
    // get q_id first
    query.prepare("SELECT q_id FROM user_question_answer WHERE e_id = :e_id");
    query.bindValue(":e_id", e_id);
    success = query.exec();
    if(!success) return SQL_EXEC_ERROR;
    // delete question set before
    while(query.next()){
        // delete exist question
        int code = this->delete_security_question(query.value("q_id").toString(), u_id);
        if(SQL_EXEC_ERROR == code) return SQL_EXEC_ERROR;
    }
    // insert new question
    QSqlQuery insert(db_connection);
    insert.prepare("INSERT INTO user_question VALUES (:u_id, :q_id, :answer)");
    for (const auto &i_a : answer){
        insert.bindValue(":u_id", u_id);
        insert.bindValue(":q_id", i_a.first);
        insert.bindValue(":answer", i_a.second);
        success = insert.exec();
        if (!success) return SQL_EXEC_ERROR;
    }
    return SUCCESS;
}

/**
* @functionName  delete_security_question
* @Description   delete a security_question user set
* @author        chenhanlin
* @date          2018-07-03
* @parameter     int q_id, int u_id
* @return        int
*/
int UserDAO::delete_security_question(const QString &q_id, const QString &u_id) const
{
    QSqlQuery delete_sql(db_connection);
    delete_sql.prepare("DELETE FROM user_question WHERE q_id=:q_id AND u_id=:u_id");
    delete_sql.bindValue(":q_id", q_id);
    delete_sql.bindValue(":u_id", u_id);
    bool success = delete_sql.exec();
    if (!success) return SQL_EXEC_ERROR;
    else return SUCCESS;
}

/**
* @functionName  transaction
* @Description   start a transaction
* @author        chenhanlin
* @date          2018-07-06
* @parameter     void
* @return        void
*/
void UserDAO::transaction()
{
    this->db_connection.transaction();
}

/**
* @functionName  rollback
* @Description   rollback transaction
* @author        chenhanlin
* @date          2018-07-06
* @parameter     void
* @return        void
*/
void UserDAO::rollback()
{
    this->db_connection.rollback();
}

/**
* @functionName  commit
* @Description   commit a transaction
* @author        chenhanlin
* @date          2018-07-06
* @parameter     void
* @return        void
*/
void UserDAO::commit()
{
    this->db_connection.commit();
}

/**
* @functionName  insert_user
* @Description   use INSERT to add a user record in DB
* @author        chenhanlin
* @date          2018-07-02
* @parameter     User &user
* @return        int
*/
int UserDAO::insert_user(User &user) const
{
    QSqlQuery sql(db_connection);
//    insert.prepare("CALL add_user(:e_id, :passwd, :permission_level, :access_code)");
    bool success = sql.exec("SELECT A.id FROM id_contain AS A JOIN (SELECT CEIL(MAX(CAST(id AS SIGNED))*RAND())\
                 AS id FROM id_contain) AS B ON CAST(A.id AS SIGNED) >= B.id LIMIT 1");
    if (!success) return SQL_EXEC_ERROR;
    sql.next();
    QString u_id(sql.value("id").toString());
    sql.prepare("INSERT INTO user(u_id, passwd, e_id, status, permission_level, access_code) VALUES (:u_id, :passwd, :e_id, :status, :permission_level, :access_code)");
    sql.bindValue(":u_id", u_id);
    sql.bindValue(":passwd", user.get_passwd());
    sql.bindValue(":e_id", user.get_e_id());
    sql.bindValue(":status", int(user.get_status()));
    sql.bindValue(":permission_level", user.get_permission_level());
    sql.bindValue(":access_code", user.get_access_code());
    // prepare sql
    success = sql.exec();
    if(!success){
        return SQL_EXEC_ERROR;
    }
    sql.prepare("DELETE FROM id_contain WHERE id=:id");
    sql.bindValue(":id", u_id);
    success = sql.exec();
    if(!success){
        return SQL_EXEC_ERROR;
    }
    return SUCCESS;
}

/**
* @functionName  update_user
* @Description   use UPDATE to update a user record in DB
* @author        chenhanlin
* @date          2018-07-02
* @parameter     User &user
* @return        int
*/
int UserDAO::update_user(const User &user) const
{
    QSqlQuery update(db_connection);
    // prepare sql
    update.prepare("UPDATE user SET passwd=:passwd, status=:status, permission_level=:permission_level, access_code=:access_code WHERE u_id=:u_id");
    update.bindValue(":u_id", user.get_u_id());
    update.bindValue(":passwd", user.get_passwd());
    update.bindValue(":status", int(user.get_status()));
    update.bindValue(":permission_level", user.get_permission_level());
    update.bindValue(":access_code", user.get_access_code());
    bool is_success = update.exec();
    if(!is_success){
        return SQL_EXEC_ERROR;
    }
    return SUCCESS;
}
