#ifndef SUPPLIERDAO_H
#define SUPPLIERDAO_H

/**
* @projectName   neuerp_server
* @brief         This class interacts with the database to
*                get or save supplier information.
* @author        luxijia
* @date          2018-7-3
* @modify_author
* @modify_date
*/
#include <iostream>
#include <vector>
#include <entity/supplier.h>
#include <entity/provide_product.h>
#include <QString>
#include <QtDebug>
#include <status_code.h>
#include "connection_pool.h"
#include <QVariantList>

class SupplierDao
{
public:
    SupplierDao();
    ~SupplierDao();
    void transaction();
    void commit();
    void rollback();
    int query_supplier(std::vector<Supplier> &suppliers, const QString &keyword, int &all_reslut_num,
                       int offset, int item, int state);
    int query_supplier_by_id(std::vector<Supplier> &suppliers, const QString &bar_code);
    int update_supplier_state_support(const QString &id);
    int update_supplier_state_stop(const QString &id);
    int update_supplier_information(Supplier &supplier);
    int save_suppleir(Supplier &supplier, QString &sp_id);
    int delete_supplier_record(const QString &id);
private:
    QSqlDatabase db;
};

#endif // SUPPLIERDAO_H
