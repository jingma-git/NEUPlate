#ifndef PURCHASEPLANDAO_H
#define PURCHASEPLANDAO_H

#include <vector>
#include <QDateTime>
#include <QSqlQuery>
#include <QSqlDatabase>
#include <QSqlRecord>
#include <set>

#include "entity/purchaseplan.h"
#include "entity/planitem.h"
#include "entity/product_to_buy.h"

#include "connection_pool.h"
#include "status_code.h"


class PurchasePlanDao
{
public:
    PurchasePlanDao();
    ~PurchasePlanDao();
    bool add(PurchasePlan plan);
    PurchasePlan load(QString plan_id);

    int query(std::vector<PurchasePlan> &plans, const QString &keyword,int &all_results_num,
               const QString &start, const QString &end, int state, int offset, int rows);
    int query_productsToBuy(std::vector<ProductToBuy> &products, QString keyword,
                                 int &all_results_num, bool asc_order,int page,int page_size);
    int update_state(QString plan_id, int state);
    int update_plan_items(QString plan_id, std::vector<PlanItem> &planItems);
    int load_plan_items(QString plan_id, std::vector<PlanItem> &plan_items);

private:
    QSqlDatabase db;
    PurchasePlan sql_to_purchase_plan(QSqlQuery query);
};

#endif // PURCHASEPLANDAO_H
