#ifndef EXIT_LISTEN_H
#define EXIT_LISTEN_H

#include <QThread>
#include <QDebug>
#include <iostream>
#include <QCoreApplication>
#include <Entity_DAO/connection_pool.h>

class ExitListen : public QThread
{
    Q_OBJECT
public:
    explicit ExitListen(QObject *parent = 0);
protected:
    void run();
};

#endif // EXIT_LISTEN_H
