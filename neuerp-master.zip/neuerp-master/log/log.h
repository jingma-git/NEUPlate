#ifndef LOG_H
#define LOG_H

/**
* @projectName   Log.h
* @brief         Declare custom log functions
* @author        luxijia
* @date          2015-6-29
* @modify_author
* @modify_date
*/

#include <stdio.h>
#include <stdlib.h>
#include <QDebug>
#include <QMessageLogContext>
#include <QMutex>
#include <QString>
#include <QMutexLocker>
#include <QDateTime>
#include <QFile>
#include <QDir>
#include <QTextStream>
#include <QSettings>
#include <QCoreApplication>

void log_record(QtMsgType type, const QMessageLogContext& context, const QString &msg);
bool create_file(QString file_path, QString file_name);

#endif // LOG_H
