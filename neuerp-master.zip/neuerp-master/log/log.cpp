/**
* @projectName   Log.cpp
* @brief         Implement log functions
* @author        luxijia
* @date          2018-6-29
* @modify_author chenhanlin
* @modify_date	 2018-7-04
* @modify_brief  add QInfo
*/

#include "log.h"
#include <iostream>
#include <string>

/**
* @functionName  create_file
* @Description   create log file in specified directory
* @author        luxijia
* @date          2018-6-30
* @parameter     file_path the specified directory
* @parameter     file_name the log file's name
* @return        if create file success or file exist return true
*                else return false.
*/

bool create_file(QString file_path, QString file_name)
{
    QDir temp_dir;
    QString current_dir = temp_dir.currentPath();
    QFile *temp_file = new QFile();

    if (!temp_dir.exists(file_path))
        if(!temp_dir.mkdir(file_path))
            return false;

    temp_dir.setCurrent(file_path);

    if(temp_file->exists(file_name))
    {
        temp_dir.setCurrent(current_dir);
        return true;
    }

    temp_file->setFileName(file_name);

    if (!temp_file->open(QIODevice::WriteOnly | QIODevice::Text))
    {
        temp_dir.setCurrent(current_dir);
        return false;
    }

    temp_file->close();
    temp_dir.setCurrent(current_dir);
    return true;
}

/**
* @functionName  log_record
* @Description   Custom log functions
* @author        luxijia
* @date          2018-6-30
* @parameter     type Call parameter type
* @parameter     context log message position context
* @parameter     msg log message context
* @return
*/
void log_record(QtMsgType type,const QMessageLogContext &context, const QString &msg)
{
    //lock
    QMutex mutex;
    QMutexLocker locker(&mutex);

    //log header
    QString text;

    //log has four message type
    switch (type) {

    case QtDebugMsg:
        text = QString("[Debug]:");
        break;

    case QtWarningMsg:
        text = QString("[Waring]:");
        break;

    case QtCriticalMsg:
        text = QString("[Critical]:");
        break;

    case QtFatalMsg:
        text = QString("[Fatal]:");
        break;
    }

    //error message generate position
    QString position = QString("File:(%1) Line(%2)").arg(context.file).arg(context.line);

    //log file context define
    QString current_date_time = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss ddd");
    QString current_date = QString("(%1)").arg(current_date_time);
    QString message = QString("%1 %2 %3 %4").arg(current_date).arg(position).arg(text).arg(msg);
    QString file_time = current_date_time.section(" ", 0, 0).trimmed();
    QString file_name = QString("%1%2").arg(file_time).arg("log.txt");

    QSettings setting(":/app.ini", QSettings::IniFormat);
    QString dir = setting.value("log_dir").toString();
    create_file(dir, file_name);

    QFile file(QString("%1/%2").arg(dir).arg(file_name));

    if(file.open(QIODevice::ReadWrite | QIODevice::Append | QIODevice::Text))
    {
        QTextStream out(&file);
        out <<  message << "\n";
        std::cout << std::string(message.toLocal8Bit()) <<std::endl;
    }

    file.flush();
    file.close();
}
