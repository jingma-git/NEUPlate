#include "employeeuser.h"

EmployeeUser::EmployeeUser(const QString &m_e_id, const QString &m_name, const QString &m_department, const QString &m_position, employee_state m_e_state, int u_state)
    :m_e_id(m_e_id), m_name(m_name), m_department(m_department), m_position(m_position), m_e_state(m_e_state), m_u_state(u_state)
{

}

QString EmployeeUser::get_e_id() const
{
    return m_e_id;
}

void EmployeeUser::set_e_id(const QString &e_id)
{
    m_e_id = e_id;
}

QString EmployeeUser::get_name() const
{
    return m_name;
}

void EmployeeUser::set_name(const QString &name)
{
    m_name = name;
}

QString EmployeeUser::get_department() const
{
    return m_department;
}

void EmployeeUser::set_department(const QString &department)
{
    m_department = department;
}

QString EmployeeUser::position() const
{
    return m_position;
}

void EmployeeUser::setPosition(const QString &position)
{
    m_position = position;
}

employee_state EmployeeUser::e_state() const
{
    return m_e_state;
}

void EmployeeUser::setE_state(const employee_state &e_state)
{
    m_e_state = e_state;
}

int EmployeeUser::u_state() const
{
    return m_u_state;
}

void EmployeeUser::setU_state(const int u_state)
{
    m_u_state = u_state;
}

/**
* @functionName  to_json
* @Description   change object's data to json
* @author        chenhanlin
* @date          2018-07-11
* @parameter     void
* @return        void
*/
QJsonObject EmployeeUser::to_json() const
{
    QJsonObject json;
    json.insert("e_id", m_e_id);
    json.insert("name", m_name);
    json.insert("dept", m_department);
    json.insert("position", m_position);
    json.insert("e_state", int(m_e_state));
    json.insert("u_state", int(m_u_state));
    return json;
}
