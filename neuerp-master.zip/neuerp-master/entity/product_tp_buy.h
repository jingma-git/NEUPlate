#ifndef PRODUCT_TP_BUY_H
#define PRODUCT_TP_BUY_H

class ProductToBuy
{
public:
    ProductToBuy();
};

#endif // PRODUCT_TP_BUY_H
