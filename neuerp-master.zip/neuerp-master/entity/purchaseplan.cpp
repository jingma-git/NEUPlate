#include "purchaseplan.h"

PurchasePlan::PurchasePlan()
{
}

