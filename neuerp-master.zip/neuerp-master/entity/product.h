//
// Created by xiaha on 2018/7/3.
//

#ifndef ENTITY_PRODUCT_H
#define ENTITY_PRODUCT_H

#include <QString>
#include <QJsonObject>
class Product {
private:
    QString p_id;
    QString bar_code;
    QString name;
    double price;
    QString description;
    QString img_url;
    int state;
    int stock_amount;
public:
    Product(const QString &p_id, const QString &bar_code, const QString &name, double price, const QString &description,
            const QString &img_url, int state,int stock_amount);
    Product();
    QJsonObject toJSON();

public:
    const int &getStock_amount() const;

    void setStock_amount(const int amount);
    const QString &getP_id() const;

    void setP_id(const QString &p_id);

    const QString &getBar_code() const;

    void setBar_code(const QString &bar_code);

    const QString &getName() const;

    void setName(const QString &name);

    double getPrice() const;

    void setPrice(double price);

    const QString &getDescription() const;

    void setDescription(const QString &description);

    const QString &getImg_url() const;

    void setImg_url(const QString &img_url);

    int getState() const;

    void setState(int state);

    virtual ~Product();


};


#endif //ENTITY_PRODUCT_H
