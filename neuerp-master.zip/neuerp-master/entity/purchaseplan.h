#ifndef PURCHASEPLAN_H
#define PURCHASEPLAN_H

#include <QString>
#include <vector>
#include <QJsonObject>
#include "planitem.h"

using namespace std;

class PurchasePlan
{
public:
    static const int COMPLETED = 0;
    static const int EDITABLE = 1;
    PurchasePlan();
    PurchasePlan(QString plan_id, QString name, QString date, int state=0):
        plan_id(plan_id),name(name),date(date),state(state){}
    PurchasePlan(QString plan_id, QString name, QString date, int state, std::vector<PlanItem> plan_items):
        plan_id(plan_id),name(name),date(date),state(state), plan_items(plan_items){}
    PurchasePlan(QJsonObject json_obj);
    void fromJSON(QJsonObject json_obj);

    void add_plan_item(PlanItem item){
        plan_items.push_back(item);
    }

    QJsonObject toJSON(){
        QJsonObject plan_json;
        plan_json.insert("plan_id",plan_id);
        plan_json.insert("name",name);
        plan_json.insert("date",date);
        plan_json.insert("state",state);
        return plan_json;
    }

    QString to_string(){
        return plan_id + " " + name+ " " + date + " " + QString::number(state);
    }

    QString get_plan_id(){
        return plan_id;
    }

    void set_plan_id(QString plan_id){
        this->plan_id = plan_id;
    }

    QString get_name(){
        return name;
    }

    void set_name(QString name){
        this->name = name;
    }

    QString get_date(){
        return date;
    }

    void set_date(QString date){
        this->date = date;
    }

    int get_state(){
        return state;
    }

    void set_state(int state){
        this->state = state;
    }
    std::vector<PlanItem> get_plan_items(){
        return plan_items;
    }
    void set_plan_items(std::vector<PlanItem> plan_items){
        this->plan_items = plan_items;
    }

private:
    QString plan_id;
    QString name; //只要plan_id不同,计划可以重名
    QString date; //最近一次被编辑的时间
    int state; // 已导出订单-0,可编辑-1
    std::vector<PlanItem> plan_items;
};


#endif // PURCHASEPLAN_H
