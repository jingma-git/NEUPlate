#ifndef EMPLOYEEUSER_H
#define EMPLOYEEUSER_H

#include <QString>
#include <QJsonObject>
#include "user.h"
#include "employee.h"

class EmployeeUser
{
public:
    EmployeeUser(const QString &m_e_id, const QString &m_name, const QString &m_department, const QString &m_position, employee_state m_e_state, int u_state);
    QString get_e_id() const;
    void set_e_id(const QString &get_e_id);

    QString get_name() const;
    void set_name(const QString &get_name);

    QString get_department() const;
    void set_department(const QString &get_department);

    QString position() const;
    void setPosition(const QString &position);

    employee_state e_state() const;
    void setE_state(const employee_state &e_state);

    int u_state() const;
    void setU_state(const int u_state);

    QJsonObject to_json() const;

private:
    QString m_e_id;
    QString m_name;
    QString m_department;
    QString m_position;
    employee_state m_e_state;
    int m_u_state;
};

#endif // EMPLOYEEUSER_H
