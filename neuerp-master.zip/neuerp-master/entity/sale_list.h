#ifndef SALE_H
#define SALE_H

/**
* @projectName   neuerp
* @brief         This class store the sale information
* @author        luxijia
* @date          2018-7-5
* @modify_author
* @modify_date
*/
#include <QString>

class SaleList
{
public:
    const QString &getSale_id() const;
    void setSale_id(const QString &sale_id);
    const QString &getSale_date() const;
    void setSale_date(const QString &sale_date);
    const QString &getClient_name() const;
    void setClient_name(const QString &client_name);
    const QString &getClient_address() const;
    void setClient_address(const QString &client_address);
    const QString &getClient_phone() const;
    void setClient_phone(const QString &client_phone);
    int getSale_state() const;
    void setSale_state(int sale_state);
    const QString &getSalesman() const;
    void setSalesman(const QString &salesman);
    const QString &getHandler_name() const;
    void setHandler_name(const QString &handler_name);
    const QString &getHandler_id() const;
    void setHandler_id(const QString &handler_id);
    const QString &getRemark() const;
    void setRemark(const QString &remark);
private:
    QString sale_id;
    QString sale_date;
    QString client_name;
    QString client_address;
    QString client_phone;
    int sale_state;
    QString salesman;
    QString handler_id;
    QString handler_name;
    QString remark;
};

#endif // SALE_H
