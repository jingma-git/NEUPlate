#ifndef SUPPLIER_H
#define SUPPLIER_H

/**
* @projectName   Supplier.h
* @brief         This class store the supplier information
* @author        luxijia
* @date          2018-7-3
* @modify_author
* @modify_date
*/
#include <QString>

class Supplier
{
public:
    const QString &getSp_id() const;
    const QString &getSp_name() const;
    const QString &getSp_region() const;
    const QString &getSp_phone() const;
    const QString &getContact() const;
    int getSp_state() const;
    void setSp_id(const QString &sp_id);
    void setSp_name(const QString &sp_name);
    void setSp_region(const QString &sp_region);
    void setSp_phone(const QString &sp_phone);
    void setContact(const QString &contact);
    void setSp_state(int sp_state);
private:
    QString sp_id;
    QString sp_name;
    QString sp_region;
    QString sp_phone;
    QString contact;
    int sp_state;
};

#endif // SUPPLIER_H
