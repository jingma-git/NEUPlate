#include "user.h"

/**
* @functionName  User
* @Description   class User's constructor, for the data from database
* @author        chenhanlin
* @date          2018-07-02
* @parameter     int u_id, int e_id, int access_code, QString passwd, int permisson_level, int status
* @return        void
*/
User::User(const QString &u_id, const QString &e_id, int access_code, const QString &passwd, int permisson_level, int status)
    :m_str_u_id(u_id), m_i_access_code(access_code), m_str_e_id(e_id), m_str_passwd(passwd), m_i_permission_level(permisson_level),
      m_b_is_new(false), m_status(status)
{

}

/**
* @functionName  User
* @Description   class User's constructor, for the data to create a new one
* @author        chenhanlin
* @date          2018-07-02
* @parameter     QString e_id, QString passwd
* @return        void
*/
User::User(const QString &e_id, const QString &passwd)
    :m_i_access_code(1), m_str_e_id(e_id), m_str_passwd(passwd), m_i_permission_level(4),
      m_b_is_new(true), m_status(USER_NEW)
{

}

/* set/get function */
int User::get_access_code() const
{
    return m_i_access_code;
}

void User::set_access_code(int i_access_code)
{
    m_i_access_code = i_access_code;
}

int User::get_permission_level() const
{
    return m_i_permission_level;
}

void User::set_permission_level(int i_permission_level)
{
    m_i_permission_level = i_permission_level;
}

bool User::is_new() const
{
    return m_b_is_new;
}

QString User::get_u_id() const
{
    return m_str_u_id;
}

QString User::get_e_id() const
{
    return m_str_e_id;
}

QString User::get_passwd() const
{
    return m_str_passwd;
}

void User::set_passwd(const QString &str_passwd)
{
    m_str_passwd = str_passwd;
}

int User::get_status() const
{
    return m_status;
}

void User::set_status(const int status)
{
    m_status = status;
}
/*end set/get function*/
