#ifndef PLANITEM_H
#define PLANITEM_H
#include <QString>
#include <QJsonObject>
#include <QDebug>
class PlanItem
{
public:
    PlanItem();
    PlanItem(const PlanItem& other);
    PlanItem operator=(const PlanItem& other);
    PlanItem(QJsonObject planItem_json);

    QJsonObject toJSON();
    QString to_string(){
      return plan_id + " "+ product_id+" "+sp_id+" \n"+
              product_name + " "+ product_id + "\n"+
              QString::number(amt)+" price "+QString::number(pp_price,'g',2);
    }

    QString get_plan_id(){
        return plan_id;
    }
    void set_plan_id(QString plan_id){
        this->plan_id = plan_id;
    }

    QString get_product_id(){
        return product_id;
    }
    void set_product_id(QString product_id){
        this->product_id = product_id;
    }
    QString get_product_name(){
        return product_name;
    }
    void set_product_name(QString product_name){
        this->product_name = product_name;
    }
    QString get_supplier_id(){
        return sp_id;
    }
    void set_supplier_id(QString supplier_id){
        sp_id = supplier_id;
    }
    QString get_supplier_name(){
        return sp_name;
    }
    void set_supplier_name(QString supplier_name){
        qDebug()<<" set_supplier_name(QString supplier_name)"<<supplier_name;
        sp_name = supplier_name;
    }
    int get_amt(){
        return amt;
    }
    void set_amt(int amt){
        this->amt = amt;
    }

    int get_pp_price(){
        return pp_price;
    }
    void set_pp_price(double pp_price){
        this->pp_price = pp_price;
    }

private:
    QString plan_id;
    QString product_id;
    QString product_name;
    QString sp_id;
    QString sp_name;
    int amt;
    double pp_price;
};

#endif // PLANITEM_H
