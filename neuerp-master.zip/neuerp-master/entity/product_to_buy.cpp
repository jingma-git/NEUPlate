#include "product_to_buy.h"
#include <QDebug>

const QString &ProductToBuy::getP_id() const {
    return p_id;
}

void ProductToBuy::setP_id(const QString &p_id) {
   this->p_id = p_id;
}

const QString &ProductToBuy::getBar_code() const {
    return bar_code;
}

void ProductToBuy::setBar_code(const QString &bar_code) {
    this->bar_code = bar_code;
}

const QString &ProductToBuy::getName() const {
    return name;
}

void ProductToBuy::setName(const QString &name) {
    this->name = name;
}

const QString &ProductToBuy::getDesc() const {
    return description;
}

void ProductToBuy::setDesc(const QString &description) {
    this->description = description;
}

const QString &ProductToBuy::getImg_url() const {
    return img_url;
}

void ProductToBuy::setImg_url(const QString &img_url) {
    this->img_url = img_url;
}

const int &ProductToBuy::getStock_amount() const
{
    return stock_amount;

}

void ProductToBuy::setStock_amount(const int amount)
{
    this->stock_amount=amount;
}

ProductToBuy::ProductToBuy(const QString &p_id, const QString &bar_code, const QString &name,
                 const QString &description, const QString &img_url,int amount) : p_id(p_id), bar_code(bar_code),
                                                                                  name(name),
                                                                                  description(description),
                                                                                  img_url(img_url),stock_amount(amount) {}


void ProductToBuy::add_supplier(QString sp_id, QString sp_name, double pp_price){
    this->sp_ids.push_back(sp_id);
    this->sp_names.push_back(sp_name);
    this->pp_prices.push_back(pp_price);
}

ProductToBuy::ProductToBuy()
{

}

QJsonObject ProductToBuy::toJSON()
{
    QJsonObject productToBuy_json;
    productToBuy_json.insert("p_id", p_id);
    productToBuy_json.insert("name", name);
    productToBuy_json.insert("bar_code", bar_code);
    productToBuy_json.insert("description", description);
    productToBuy_json.insert("img", PhotoTool::load_photo(img_url));
    productToBuy_json.insert("stock_amount", stock_amount);
    QJsonArray spIdArray;
    QJsonArray spNameArray;
    QJsonArray priceArray;

    foreach(QString sp_id,sp_ids){
        spIdArray.append(sp_id);
    }
    foreach(QString sp_name,sp_names){
        spNameArray.append(sp_name);
    }
    foreach(double pp_price, pp_prices){
        priceArray.append(pp_price);
    }
    productToBuy_json.insert("spIdArray", spIdArray);
    productToBuy_json.insert("spNameArray",spNameArray);
    productToBuy_json.insert("priceArray", priceArray);
    qDebug() << productToBuy_json["img"].toString();
    return productToBuy_json;
}



