#include "sale_list.h"

const QString &SaleList::getSale_id() const
{
    return sale_id;
}

void SaleList::setSale_id(const QString &sale_id)
{
    SaleList::sale_id = sale_id;
}

const QString &SaleList::getSale_date() const
{
    return sale_date;
}

void SaleList::setSale_date(const QString &sale_date)
{
    SaleList::sale_date = sale_date;
}

const QString &SaleList::getClient_name() const
{
    return client_name;
}

void SaleList::setClient_name(const QString &client_name)
{
    SaleList::client_name = client_name;
}

const QString &SaleList::getClient_address() const
{
    return client_address;
}

void SaleList::setClient_address(const QString &client_address)
{
    SaleList::client_address = client_address;
}

const QString &SaleList::getClient_phone() const
{
    return client_phone;
}

void SaleList::setClient_phone(const QString &client_phone)
{
    SaleList::client_phone = client_phone;
}

int SaleList::getSale_state() const
{
    return sale_state;
}

void SaleList::setSale_state(int sale_state)
{
    SaleList::sale_state = sale_state;
}

const QString &SaleList::getSalesman() const
{
    return salesman;
}

void SaleList::setSalesman(const QString &salesman)
{
    SaleList::salesman = salesman;
}

const QString &SaleList::getHandler_id() const
{
    return handler_id;
}

void SaleList::setHandler_id(const QString &handler_id)
{
    SaleList::handler_id = handler_id;
}

const QString &SaleList::getRemark() const
{
    return remark;
}

void SaleList::setRemark(const QString &remark)
{
    SaleList::remark = remark;
}

const QString &SaleList::getHandler_name() const
{
    return handler_name;
}

void SaleList::setHandler_name(const QString &handler_name)
{
    SaleList::handler_name = handler_name;
}
