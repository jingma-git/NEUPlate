#include <Entity/purchase_order.h>
PurchaseOrder::PurchaseOrder(){

}

PurchaseOrder::PurchaseOrder(const PurchaseOrder& other){
    if(this!=&other){
     this->order_id = other.order_id;
     this->sp_id = other.sp_id;
     this->state = other.state;
     this->date = other.date;
     int size = other.orderItems.size();
     this->orderItems.clear();
     for(int i=0; i<size; i++){
         this->orderItems.push_back(other.orderItems[i]);
     }
    }
}

PurchaseOrder PurchaseOrder::operator=(const PurchaseOrder& other){
    if(this!=&other){
        this->order_id = other.order_id;
        this->sp_id = other.sp_id;
        this->state = other.state;
        this->date = other.date;
        int size = other.orderItems.size();
        this->orderItems.clear();
        for(int i=0; i<size; i++){
            this->orderItems.push_back(other.orderItems[i]);
        }
    }
    return *this;
}

PurchaseOrder::PurchaseOrder(QJsonObject order_json){
    order_id = order_json.value("order_id").toString();
    sp_id = order_json.value("sp_id").toString();
    state = order_json.value("state").toInt();
    date = order_json.value("date").toString();
    QJsonArray orderItemArray = order_json.value("order_items").toArray();
    foreach(const QJsonValue& value, orderItemArray){
        OrderItem orderItem(value.toObject());
        orderItems.push_back(orderItem);
    }
}

QJsonObject PurchaseOrder::toJSON(){
    QJsonObject order_json;
    order_json.insert("order_id", order_id);
    order_json.insert("sp_id",sp_id);
    order_json.insert("state",state);
    order_json.insert("date",date);
    QJsonArray orderItemArray;
    for(OrderItem orderItem:orderItems){
        orderItemArray.append(orderItem.toJSON());
    }
    order_json.insert("order_items", orderItemArray);
    return order_json;
}
QString PurchaseOrder::toString(){
    return "order_id "+order_id + "\n" +
            "sp_id "+sp_id + "\n"+
            "state "+state + "\n" +
            "date "+date +"\n**********"+orderItems[0].toString();
}
