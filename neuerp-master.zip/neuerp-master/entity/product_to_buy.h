#ifndef PRODUCT_TO_BUY_H
#define PRODUCT_TO_BUY_H
#include <vector>
#include <QJsonArray>
#include <QJsonObject>

#include "tool/phototool.h"
class ProductToBuy
{  
private:
    QString p_id;
    QString bar_code;
    QString name;
    QString description;
    QString img_url;
    int stock_amount;
    std::vector<double> pp_prices;
    std::vector<QString> sp_ids;
    std::vector<QString> sp_names;
public:
    ProductToBuy(const QString &p_id, const QString &bar_code, const QString &name, const QString &description,
            const QString &img_url, int stock_amount);
    ProductToBuy();
    QJsonObject toJSON();

public:
    const int &getStock_amount() const;

    void setStock_amount(const int amount);
    const QString &getP_id() const;

    void setP_id(const QString &p_id);

    const QString &getBar_code() const;

    void setBar_code(const QString &bar_code);

    const QString &getName() const;

    void setName(const QString &name);


    const QString &getDesc() const;

    void setDesc(const QString &description);

    const QString &getImg_url() const;

    void setImg_url(const QString &img_url);

    void add_supplier(QString sp_id, QString sp_name, double pp_price);

};

#endif // PRODUCT_TO_BUY_H
