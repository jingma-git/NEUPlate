//
// Created by xiaha on 2018/7/3.
//

#include "product.h"
#include "Tool/phototool.h"


const QString &Product::getP_id() const {
    return p_id;
}

void Product::setP_id(const QString &p_id) {
    Product::p_id = p_id;
}

const QString &Product::getBar_code() const {
    return bar_code;
}

void Product::setBar_code(const QString &bar_code) {
    Product::bar_code = bar_code;
}

const QString &Product::getName() const {
    return name;
}

void Product::setName(const QString &name) {
    Product::name = name;
}

double Product::getPrice() const {
    return price;
}

void Product::setPrice(double price) {
    Product::price = price;
}

const QString &Product::getDescription() const {
    return description;
}

void Product::setDescription(const QString &description) {
    Product::description = description;
}

const QString &Product::getImg_url() const {
    return img_url;
}

void Product::setImg_url(const QString &img_url) {
    Product::img_url = img_url;
}

int Product::getState() const {
    return state;
}

void Product::setState(int state) {
    Product::state = state;
}

Product::Product(const QString &p_id, const QString &bar_code, const QString &name, double price,
                 const QString &description, const QString &img_url, int state,int amount) : p_id(p_id), bar_code(bar_code),
                                                                                  name(name), price(price),
                                                                                  description(description),
                                                                                  img_url(img_url), state(state),stock_amount(amount) {}

Product::Product()
{

}

QJsonObject Product::toJSON()
{
    QJsonObject product_json;
    product_json.insert("p_id",getP_id());
    product_json.insert("name",getName());
    product_json.insert("price",getPrice());
    product_json.insert("bar_code",getBar_code());
    product_json.insert("description",getDescription());
    product_json.insert("photo", PhotoTool::load_photo(img_url));
    product_json.insert("state",getState());
    product_json.insert("stock_amount",getStock_amount());
    return product_json;

}

const int &Product::getStock_amount() const
{
    return stock_amount;

}

void Product::setStock_amount(const int amount)
{
    this->stock_amount=amount;
}

Product::~Product() {

}
