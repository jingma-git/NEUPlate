﻿/**
* @projectName   neuerp_server
* @brief         class user, contain the information of employee's account and access to database
* @author        chenhanlin
* @date          2018-07-02
*/
#ifndef USER_H
#define USER_H

#include <QString>
#include <vector>
#include <map>

class User
{
public:
    static const int USER_NORMAL = 1;
    static const int USER_FROZN = 2;
    static const int USER_CLOSED = 4;
    static const int USER_NEW = 8;
public:
    User(const QString &u_id, const QString &e_id, int access_code, const QString &passwd, int permisson_level, int m_i_status);
    User(const QString &e_id, const QString &passwd);

    int get_access_code() const;
    void set_access_code(int i_access_code);

    int get_permission_level() const;
    void set_permission_level(int i_permission_level);

    bool is_new() const;

    QString get_u_id() const;

    QString get_e_id() const;

    QString get_passwd() const;
    void set_passwd(const QString &str_passwd);

    int get_status() const;
    void set_status(const int status);

private:
    QString m_str_u_id;
    int m_i_access_code;
    QString m_str_e_id;
    QString m_str_passwd;
    int m_i_permission_level;
    bool m_b_is_new;
    int m_status;
};

#endif // USER_H
