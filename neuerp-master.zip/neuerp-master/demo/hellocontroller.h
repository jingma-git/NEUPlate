#ifndef HELLOCONTROLLER_H
#define HELLOCONTROLLER_H

#include <Network/Route/controller.h>

// note: for find this class, you should add #include "demo/hellocontroller.h" in controller/all_controller.h
class HelloController : public Controller
{
    DECLEAR_CONTROLLER(HelloController) // declear the controller, shuold pass the class name
private:
    void sayHello();
    void sayGoodBye();
};

#endif // HELLOCONTROLLER_H
