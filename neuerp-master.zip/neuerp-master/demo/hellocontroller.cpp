#include "hellocontroller.h"
#include <string>
#include <iostream>
#include <QDebug>

// implement controller,should pass class name and module name, system will invoke by module name
IMPLEMENT_CONSTROLLER_BEGIN(HelloController, hello)
// bind the function with function name, system will invoke function by the name, you should pass function_name, actual fucntion name, class name
BIND(hello, sayHello, HelloController)
BIND(bye, sayGoodBye, HelloController)
IMPLEMENT_CONTROLLER_END

void HelloController::sayHello()
{
    int name = this->req->get_int("name");
    qDebug() << "Hello," << name;
    resp->put("answer", "Hello");
    qDebug()<<resp->get_string("answer");
}

void HelloController::sayGoodBye()
{
    QString name = this->req->get_string("name");
    qDebug() << "Good Bye," << name;
    resp->put("answer", "bye");
}
