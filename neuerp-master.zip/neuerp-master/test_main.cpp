#include "test/testrunner.h"
#include "test/test_purchase_plan.h"
#include <QDebug>

int main(){
    TestRunner testRunner;
    testRunner.addTest(new TestPurchasePlanDao());
    qDebug()<<"Overall result:"<<(testRunner.runTests()?"Pass":"Fail");
    return 0;
}
