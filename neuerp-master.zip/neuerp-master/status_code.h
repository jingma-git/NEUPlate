#ifndef STATUS_CODE_H
#define STATUS_CODE_H

static const int SUCCESS = 0;

static const int SQL_EXEC_ERROR = 1;
static const int EMPTY_SET = 2;

static const int ADD_ERROR = 4;
static const int REMOVE_ERROR = 6;
static const int MODIFY_ERROR = 8;
static const int QUERY_ERROR = 12;
static const int EMPTY_QUERY = 9;

static const int ERROR_PARAMS = 10;
static const int NO_MODULE = 15;
static const int NO_FUNC = 16;
static const int ILLEGAL_ACCESS = 21;

// user
static const int OLD_PASSWD_ERROR = 11;
static const int WRONG_ANSWER = 14;
static const int ERROR_PASSWD = 17;
static const int FROZEN = 18;
static const int CLOSED = 19;
static const int NEW = 20;
static const int LOGINED = 23;

//sale list and supplier
static const int DELETE_ERROR = 21;
static const int CANCEL_ERROR = 22;
static const int CHANGE_ERROR = 23;


//for product
static const int STOCK_NOT_EMPTY = 711;
static const int BAR_CODE_ERROR = 712;
static const int P_ID_NOT_FIND = 713;

#endif // STATUS_CODE_H
