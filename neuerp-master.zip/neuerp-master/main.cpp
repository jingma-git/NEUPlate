#include <QCoreApplication>
#include <Network/Server/mainserver.h>
#include "Controller/usercontroller.h"
#include "log/log.h"

int main(int argc, char *argv[])
{
    qInstallMessageHandler(log_record);
    QCoreApplication a(argc, argv);

    UserController::init_access_code();
    MainServer server(1234);
    int ret = a.exec();
    return ret;
}
