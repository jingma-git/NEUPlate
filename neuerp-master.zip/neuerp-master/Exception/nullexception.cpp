#include "nullexception.h"

const char* NullException::what() const throw()
{
    return "null value is return";
}
