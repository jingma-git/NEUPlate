#include "exit_listen.h"

ExitListen::ExitListen(QObject *parent):QThread(parent)
{

}

void ExitListen::run()
{
    while (true)
    {
        std::string line;
        std::cin >> line;
        if(line.compare("q") == 0)
        {
            qDebug() << "exit success!";
            ConnectionPool::release();
            QCoreApplication::exit(0);
        }
    }
}
