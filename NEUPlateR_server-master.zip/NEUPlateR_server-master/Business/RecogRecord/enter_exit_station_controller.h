#ifndef ENTER_EXIT_STATION_CONTROLLER_H
#define ENTER_EXIT_STATION_CONTROLLER_H

#include <QString>
#include "recog_record_dao.h"
namespace EnterExitStationController
{
    void recog_plate_no();
    void car_enter();
    void car_exit();
}

#endif // ENTER_STATION_CONTROLLER_H
