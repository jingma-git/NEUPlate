#ifndef CAR_TYPE_DEDUCTION_HEAD_H
#define CAR_TYPE_DEDUCTION_HEAD_H

#include "car_type_deduction.h"
#include "beijing_car_type_deduction.h"
#include "liaoning_car_type_deduction.h"

#endif // CAR_TYPE_DEDUCTION_HEAD_H
