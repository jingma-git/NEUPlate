#include "car_type_deduction.h"

CCarTypeDeduction::~CCarTypeDeduction()
{

}
