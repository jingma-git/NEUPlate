#ifndef DEDUCTION_HEAD_H
#define DEDUCTION_HEAD_H

#include "deduction.h"
#include "liaoning_deduction.h"
#include "beijing_deduction.h"

#endif // DEDUCTION_HEAD_H
