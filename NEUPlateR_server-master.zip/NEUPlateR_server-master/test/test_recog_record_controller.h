#ifndef TEST_RECOG_RECORD_CONTROLLER_H
#define TEST_RECOG_RECORD_CONTROLLER_H

#include "log/log_handler.h"
#include "Business/RecogRecord/recog_record_controller.h"

namespace TestRecogRecord{
void test_query_photo_path();
void test_query_station_id();
}

#endif // TEST_RECOG_RECORD_CONTROLLER_H
