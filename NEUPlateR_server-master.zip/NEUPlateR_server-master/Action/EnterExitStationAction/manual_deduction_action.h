#ifndef MANUAL_DEDUCTION_ACTION_H
#define MANUAL_DEDUCTION_ACTION_H
#include "Route/action.h"

class CManualDeductionAction:public CAction
{
public:
    DECLEAR_ACTION(CManualDeductionAction)

};

#endif // MANUAL_DEDUCTION_ACTION_H
