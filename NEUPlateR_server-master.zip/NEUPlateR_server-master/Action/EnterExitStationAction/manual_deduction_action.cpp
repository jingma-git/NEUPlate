#include "manual_deduction_action.h"

IMPLEMENT_ACTION(manual_deduct,CManualDeductionAction)

