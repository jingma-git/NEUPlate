#include "my_msg_box.h"
#include "ui_my_msg_box.h"
#include "UI/iconhelper.h"

#include <QPixmap>

MyMsgBox::MyMsgBox(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MyMsgBox)
{
    ui->setupUi(this);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
}

MyMsgBox::~MyMsgBox()
{
    delete ui;
}

/**
* @functionName  set_title
* @brief         set window's title
* @author        chenhanlin
* @date          2018-07-30
* @parameter     const QString &title window title
* @return        void
*/
void MyMsgBox::set_title(const QString &title)
{
    this->ui->label_title->setText(title);
}

/**
* @functionName  set_text
* @brief         set window's content text
* @author        chenhanlin
* @date          2018-07-30
* @parameter     const QString &text content text
* @return        void
*/
void MyMsgBox::set_text(const QString &text)
{
    ui->label_text->setText(text);
}

/**
* @functionName  set_icon
* @brief         set window icon
* @author        chenhanlin
* @date          2018-07-30
* @parameter     const QString &icon_path icon photo path
* @return        void
*/
void MyMsgBox::set_icon(const QString &icon_path)
{
    QPixmap icon(icon_path);
    ui->label_icon->setPixmap(icon);
}

void MyMsgBox::hide_confirm_button()
{
    ui->btn_confirm->hide();
}

void MyMsgBox::show_confirm_button()
{
    ui->btn_confirm->show();
}

void MyMsgBox::hide_cancel_button()
{
    ui->btn_cancel->hide();
}

void MyMsgBox::show_cancel_button()
{
    ui->btn_cancel->show();
}

void MyMsgBox::on_btnMenu_Close_clicked()
{
    this->close();
    reject();
}

void MyMsgBox::on_btn_confirm_clicked()
{
    accept();
}

void MyMsgBox::on_btn_cancel_clicked()
{
    reject();
}
