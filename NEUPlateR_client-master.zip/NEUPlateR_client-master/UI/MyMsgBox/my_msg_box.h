#ifndef MY_MSG_BOX_H
#define MY_MSG_BOX_H

#include <QDialog>

namespace Ui {
class MyMsgBox;
}

class MyMsgBox : public QDialog
{
    Q_OBJECT

public:
    explicit MyMsgBox(QWidget *parent = 0);
    ~MyMsgBox();
    void set_title(const QString &title);
    void set_text(const QString &text);
    void set_icon(const QString &icon_path);
    void hide_confirm_button();
    void show_confirm_button();
    void hide_cancel_button();
    void show_cancel_button();

private slots:
    void on_btnMenu_Close_clicked();

    void on_btn_confirm_clicked();

    void on_btn_cancel_clicked();

private:
    Ui::MyMsgBox *ui;
};

#endif // MSGBOX_H
