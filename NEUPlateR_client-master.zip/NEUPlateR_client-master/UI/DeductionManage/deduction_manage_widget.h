#ifndef DEDUCTION_MANAGE_WIDGET_H
#define DEDUCTION_MANAGE_WIDGET_H

#include <QWidget>
#include <QToolButton>


namespace Ui {
class DeductionManageWidget;
}

class DeductionManageWidget : public QWidget
{
    Q_OBJECT
public:
    explicit DeductionManageWidget(QWidget *parent = 0);
    ~DeductionManageWidget();
    void  init_menu();

private slots:
    void  menu_click();

private:
    Ui::DeductionManageWidget *ui;

    QList<int> pixChars;
    QList<QToolButton *> btns;

    void  init_widget();

};

#endif // PERSONAL_CENTER_H
