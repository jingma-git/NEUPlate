#include "deduction_manage_widget.h"
#include "ui_deduction_manage_widget.h"
#include "UI/iconhelper.h"

DeductionManageWidget::DeductionManageWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DeductionManageWidget)
{
    ui->setupUi(this);
    this->init_menu();
    this->init_widget();
}


void DeductionManageWidget::init_menu(){
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf031 << 0xf036 << 0xf249;
    btns<<ui->btnProfile<<ui->btnQuestion<<ui->btnPassword;

    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btnProfile->click();
}


void DeductionManageWidget::init_widget(){
}


void DeductionManageWidget::menu_click(){

    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);

    /*
    if(b==ui->btnProfile){
        ui->stackedWidget->setCurrentIndex(0);
    }else if(b==ui->btnQuestion){
        ui->stackedWidget->setCurrentIndex(1);
    }else if(b==ui->btnPassword){
        ui->stackedWidget->setCurrentIndex(2);
    }
    */

}

DeductionManageWidget::~DeductionManageWidget()
{
    delete ui;
}
