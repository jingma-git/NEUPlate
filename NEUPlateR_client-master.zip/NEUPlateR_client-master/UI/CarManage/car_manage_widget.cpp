#include "car_manage_widget.h"

CarManageWidget::CarManageWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CarManageWidget)
{
    this->car_info_widget=new CarInfoWidget();
    this->car_query_widget=new CarQueryWidget();

    car_info_widget->init_as_add_car();

    ui->setupUi(this);
    this->init_menu();
    this->init_widget();


}


void CarManageWidget::init_menu(){
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf031 << 0xf036 ;
    btns<<ui->btn_query_car<<ui->btn_add_car;


    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btn_query_car->click();
}


void CarManageWidget::init_widget(){
    ui->stackedWidget->insertWidget(0,car_query_widget);
    ui->stackedWidget->insertWidget(1,car_info_widget);
}


void CarManageWidget::menu_click(){

    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);


    if(b==ui->btn_query_car){
        ui->stackedWidget->setCurrentIndex(0);
    }else if(b==ui->btn_add_car){
        ui->stackedWidget->setCurrentIndex(1);

    }

}

CarManageWidget::~CarManageWidget()
{
    delete ui;
    delete this->car_info_widget;
    delete this->car_query_widget;
}
