#ifndef CAR_INFO_H
#define CAR_INFO_H

#include <QWidget>
#include <QDialog>
#include "Entity/car.h"
#include <functional>
#include "neu_head.h"

namespace Ui {
class CarInfoWidget;
}

class CarInfoWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CarInfoWidget(QWidget *parent = 0);
    ~CarInfoWidget();

    void init_as_add_car();
    void init_as_car_info(CCar &car);
    void init_as_car_info_show_only(CCar &car);


signals:
    void refresh_car_query_table();
    void close_dialog();
private slots:
    void save_click();
    void edit_click();
    void cancel_click();


private:
    Ui::CarInfoWidget *ui;
    void switch_to_edit_mode(bool flag);
    void show_car_info();
    void update_car();
    void add_car();
    void get_info_from_ui();
    void recv_result(CResponse &resp);
    void clear_content();



    WaitingSpinnerWidget *wait;
    bool is_add;
    QString this_id;

    CCar car;
};

#endif // CAR_INFO_H
