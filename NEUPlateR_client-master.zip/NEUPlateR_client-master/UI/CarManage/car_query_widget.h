#ifndef CAR_QUERY_H
#define CAR_QUERY_H

#include <QWidget>
#include "Entity/car.h"
#include "ui_car_query_widget.h"
#include "neu_head.h"
#include <functional>
#include <QJsonArray>
#include <QMenu>
#include "edit_car_dialog.h"

namespace Ui {
class CarQueryWidget;
}

class CarQueryWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CarQueryWidget(QWidget *parent = 0);
    ~CarQueryWidget();

private:
    Ui::CarQueryWidget *ui;
    std::vector<CCar> cars;
    int current_page;
    int max_pages;
    int page_size;
    QMenu *right_menu;
    QAction *edit_action;
    QAction *delete_action;

    QString keyword;

    WaitingSpinnerWidget *wait;

    EditCarDialog *edit_car_dialog;
    QString this_id;

private slots:
    void query_clicked();
    void query_cars();
    void recv_cars(CResponse &resp);
    void refresh_table();
    void refresh_page_bar();
    void change_page(int i);
    void next_page();
    void previous_page();
    void init_menu();
    void edit_clicked();
    void delete_clicked();
    void right_menu_action(const QPoint& pos);
    void recv_delete(CResponse &resp);
};

#endif // CAR_QUERY_H
