#include "car_info_widget.h"
#include "ui_car_info_widget.h"

CarInfoWidget::CarInfoWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CarInfoWidget)
{
    wait=new WaitingSpinnerWidget(this);
    ui->setupUi(this);
    ui->label_add_ok->setVisible(false);
    ui->btn_ok->setVisible(false);

    QRegExp regRxp("^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1}");
    ui->ledit_plate->setValidator(new QRegExpValidator(regRxp,this));



    this->this_id=QString::number(int(this));

    connect(ui->btn_edit,SIGNAL(clicked()),this,SLOT(edit_click()));
    connect(ui->btn_save,SIGNAL(clicked()),this,SLOT(save_click()));
    connect(ui->btn_ok,SIGNAL(clicked()),this,SLOT(cancel_click()));
    connect(ui->btn_cancel,SIGNAL(clicked()),this,SLOT(cancel_click()));
    Network::registered("car_info_update_car"+this_id, std::bind(&CarInfoWidget::recv_result, this, std::placeholders::_1));
    Network::registered("car_info_add_car"+this_id, std::bind(&CarInfoWidget::recv_result, this, std::placeholders::_1));


    setTabOrder(ui->ledit_plate, ui->cmb_model);
    setTabOrder(ui->cmb_model, ui->ledit_color);
    setTabOrder(ui->ledit_color, ui->cmb_type);
    setTabOrder(ui->cmb_type, ui->ledit_payer);
}

CarInfoWidget::~CarInfoWidget()
{
    delete ui;
    delete wait;
}

void CarInfoWidget::init_as_add_car()
{
    //框都是空的，且可编辑
    switch_to_edit_mode(true);


    ui->ledit_payer->setVisible(false);
    ui->label_payer->setVisible(false);
    ui->btn_cancel->setText("重置");
    is_add=true;
}

void CarInfoWidget::init_as_car_info(CCar &car)
{
    // 框都不可以编辑。然后要把车辆信息显示出来
    this->car=car;
    show_car_info();

    switch_to_edit_mode(false);

    ui->ledit_payer->setVisible(true);
    ui->label_payer->setVisible(true);

    ui->ledit_payer->setEnabled(false);

    is_add=false;
}

void CarInfoWidget::init_as_car_info_show_only(CCar &car){

    this->car=car;
    show_car_info();
    switch_to_edit_mode(false);
    ui->btn_edit->setVisible(false);

    ui->ledit_payer->setVisible(true);
    ui->label_payer->setVisible(true);

    ui->ledit_payer->setEnabled(false);

    ui->label_add_ok->setVisible(true);
    ui->btn_ok->setVisible(true);
    
}

void CarInfoWidget::switch_to_edit_mode(bool flag)
{
    //把可以编辑的部分设置为可编辑
    ui->ledit_color->setEnabled(flag);
    ui->cmb_model->setEnabled(flag);
    ui->ledit_plate->setEnabled(flag);
    ui->cmb_type->setEnabled(flag);

    ui->btn_cancel->setVisible(flag);
    ui->btn_save->setVisible(flag);
    ui->btn_edit->setVisible(!flag);



}

void CarInfoWidget::show_car_info()
{
    //把车辆的信息加载显示到 对应的空里面
    ui->ledit_color->setText(car.color());
    bool ok;
    int tmp_model=car.model().toInt(&ok);
    if(!ok){
        tmp_model=6;
    }if(tmp_model<1||tmp_model>5){
        tmp_model=6;
    }
    ui->cmb_model->setCurrentIndex(tmp_model-1);
    ui->ledit_payer->setText(car.payer_id());  //todo payer id对应到缴费人的名字或者用户名或者身份证号码
    ui->ledit_plate->setText(car.plate());
    int tmp_type=car.type();
    if(tmp_type<1||tmp_type>4){
        tmp_type=5;
    }
    ui->cmb_type->setCurrentIndex(tmp_type-1);
}

void CarInfoWidget::edit_click()
{
    switch_to_edit_mode(true);
    ui->ledit_plate->setEnabled(false);


}

void CarInfoWidget::cancel_click()
{

    if(!is_add){
        switch_to_edit_mode(false);
    }else{
        clear_content();
    }

}

void CarInfoWidget::update_car()
{
    qDebug()<<"update car";
    CRequest req;
    req.set_action("update_car");
    req.put("car",car.toJSON());
    req.set_started_by("car_info_update_car"+this_id);
    Network::send(req);
    wait->start();

}

void CarInfoWidget::add_car()
{
    qDebug()<<"add car";
    CRequest req;
    req.set_action("add_car");
    req.put("car",car.toJSON());
    req.set_started_by("car_info_add_car"+this_id);
    Network::send(req);
    wait->start();
}

void CarInfoWidget::get_info_from_ui()
{
    car.setColor(ui->ledit_color->text());
    car.setModel(QString::number(ui->cmb_model->currentIndex()+1));
    car.setPayer_id(ui->ledit_payer->text());
    car.setPlate(ui->ledit_plate->text().toUpper());
    car.setType(ui->cmb_type->currentIndex()+1);
}

void CarInfoWidget::recv_result(CResponse &resp)
{
    int status_code=resp.status_code();
    wait->stop();
    if(StatusCode::SUCCESS==status_code){
        qDebug()<<"is_add:"<<is_add;
        if(is_add==true){
            MsgBox::success("车辆管理","添加车辆成功");
            clear_content();

        }else{
            MsgBox::success("车辆管理","修改车辆信息成功");
            emit refresh_car_query_table();  //让查询列表中的结果更新
            emit close_dialog();
        }

    }else if(StatusCode::SQL_EXEC_ERROR){
        if(is_add==true){
            MsgBox::success("车辆管理","添加车辆失败");
        }else{
            MsgBox::success("车辆管理","修改车辆信息失败");
        }

    }

}

void CarInfoWidget::clear_content()
{//添加完一次之后，把之前的信息清空
    ui->ledit_color->clear();
    ui->ledit_payer->clear();
    ui->ledit_plate->clear();
    ui->cmb_type->setCurrentIndex(0);
    ui->cmb_model->setCurrentIndex(0);
    get_info_from_ui();
    car.setCar_id(NULL);
}

void CarInfoWidget::save_click()
{
    get_info_from_ui();
    if(car.color()==""||car.plate()==""){
        MsgBox::information("车辆管理","字段不能为空");
        return;
    }
    if(is_add==true){
        add_car();
    }else{
        update_car();
    }
}
