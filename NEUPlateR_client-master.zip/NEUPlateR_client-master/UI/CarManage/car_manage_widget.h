#ifndef CAR_MANAGE_WIDGET
#define CAR_MANAGE_WIDGET

#include "UI/iconhelper.h"
#include "ui_car_manage_widget.h"
#include <QWidget>
#include <QToolButton>
#include "UI/CarManage/car_info_widget.h"
#include "UI/CarManage/car_query_widget.h"


namespace Ui {
class CarManageWidget;
}

class CarManageWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CarManageWidget(QWidget *parent = 0);
    ~CarManageWidget();
    void  init_menu();

private slots:
    void  menu_click();

private:
    Ui::CarManageWidget *ui;

    QList<int> pixChars;
    QList<QToolButton *> btns;
    CarInfoWidget *car_info_widget;
    CarQueryWidget *car_query_widget;

    void  init_widget();

};

#endif // PERSONAL_CENTER_H
