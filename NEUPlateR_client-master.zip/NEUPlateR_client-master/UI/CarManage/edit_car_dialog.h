#ifndef EDIT_CAR_DIALOG_H
#define EDIT_CAR_DIALOG_H

#include <QDialog>
#include "car_info_widget.h"


namespace Ui {
class EditCarDialog;
}

class EditCarDialog : public QDialog
{
    Q_OBJECT

public:
    explicit EditCarDialog(QWidget *parent = 0);
    ~EditCarDialog();
    void init_as_car_info(CCar &car);
    void init_as_car_info_show_only(CCar &car);

private slots:


    void on_btnMenu_Close_clicked();
    void refresh_car_query_table_slot();
signals:
    void refresh_car_query_table();

private:
    Ui::EditCarDialog *ui;
    CarInfoWidget *car_info_widget;

};

#endif // EDIT_DIALOG_H
