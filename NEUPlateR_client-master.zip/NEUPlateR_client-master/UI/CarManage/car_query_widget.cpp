#include "car_query_widget.h"
#include "login_user.h"

CarQueryWidget::CarQueryWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CarQueryWidget)
{
    ui->setupUi(this);
    ui->tableWidget->setRowCount(10);
    edit_car_dialog=nullptr;
    this->this_id=QString::number(int(this));

    wait=new WaitingSpinnerWidget(this);

    current_page=1;
    max_pages=1;
    page_size=10;

    connect(ui->btn_query,SIGNAL(clicked()),this,SLOT(query_clicked()));
    connect(ui->btn_previous_page,SIGNAL(clicked()),this,SLOT(previous_page()));
    connect(ui->btn_next_page,SIGNAL(clicked()),this,SLOT(next_page()));
    connect(ui->cmb_page,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));
    connect(ui->ledit_keyword,SIGNAL(returnPressed()),this,SLOT(query_clicked()));

    Network::registered("query_cars_query_car"+this_id,std::bind(&CarQueryWidget::recv_cars, this, std::placeholders::_1));
    Network::registered("query_cars_delete_car"+this_id,std::bind(&CarQueryWidget::recv_delete, this, std::placeholders::_1));


    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);

    init_menu();
    query_clicked();
}

CarQueryWidget::~CarQueryWidget()
{
    delete ui;
    delete right_menu;

    delete edit_action;
    delete delete_action;
    delete wait;
}

void CarQueryWidget::query_clicked()
{
    keyword=ui->ledit_keyword->text();
    current_page=1;
    max_pages=1;
    query_cars();
}

void CarQueryWidget::query_cars()
{
    CRequest req;
    req.set_action("query_cars");
    req.put("keyword",keyword);
    req.put("page",current_page);
    req.put("page_size",page_size);
    req.set_started_by("query_cars_query_car"+this_id);
    Network::send(req);
    wait->start();

}

void CarQueryWidget::recv_cars(CResponse &resp)
{
    qDebug()<<"status code:"<<resp.status_code();
    wait->stop();

    QJsonArray cars_json=resp.get_array("cars");
    if(resp.status_code()==StatusCode::SUCCESS){
        this->cars.clear();
        foreach (const QJsonValue &car_json, cars_json) {
            CCar tmp_car=CCar(car_json.toObject());
            this->cars.push_back(tmp_car);
        }
        max_pages=resp.get_int("all_pages");
        refresh_page_bar();
        refresh_table(); //刷新自己的表格

    }else if(resp.status_code()==StatusCode::EMPTY_QUERY){
        this->cars.clear();
        max_pages=1;
        refresh_page_bar();
        refresh_table(); //刷新自己的表格
    }else if(resp.status_code()==StatusCode::SQL_EXEC_ERROR){

    }



}

void CarQueryWidget::refresh_table()
{
    unsigned int cars_len=this->cars.size();
    QTableWidget &table= *(ui->tableWidget);
    while (table.rowCount()!=0) {
        table.removeRow(0);
    }
       ui->tableWidget->insertRow(0);
    for(unsigned int i=0;i<cars_len;i++){
        CCar &c=cars.at(i);
        if(i!=0){
            table.insertRow(i);
        }
        table.setItem(i,0,new QTableWidgetItem(c.plate()));
        table.item(i,0)->setTextAlignment(Qt::AlignCenter);
        table.setItem(i,1,new QTableWidgetItem(c.get_model_string()));
        table.item(i,1)->setTextAlignment(Qt::AlignCenter);
        table.setItem(i,2,new QTableWidgetItem(c.color()));
        table.item(i,2)->setTextAlignment(Qt::AlignCenter);
        table.setItem(i,3,new QTableWidgetItem(c.get_type_string()));

        table.item(i,3)->setTextAlignment(Qt::AlignCenter);
//        table.setItem(i,4,new QTableWidgetItem(c.payer_id()));
//        table.item(i,4)->setTextAlignment(Qt::AlignCenter);
        }

}

void CarQueryWidget::refresh_page_bar()
{

    disconnect(ui->cmb_page,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));
    ui->btn_previous_page->setEnabled(!(current_page==1));
    ui->btn_next_page->setEnabled(!(current_page==max_pages));
    ui->cmb_page->clear();

    for(int i=0;i<max_pages;i++){
        ui->cmb_page->insertItem(i,QString("第%1页").arg(i+1));
    }
    ui->cmb_page->setCurrentIndex(current_page-1);
    connect(ui->cmb_page,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));


}

void CarQueryWidget::change_page(int i)
{
    current_page=i+1;
    query_cars();
}

void CarQueryWidget::next_page()
{
    change_page(current_page-1+1);
}

void CarQueryWidget::previous_page()
{
    change_page(current_page-1-1);
}

void CarQueryWidget::init_menu()
{
    right_menu=new QMenu(ui->tableWidget);

    edit_action=new QAction(this);
    delete_action=new QAction(this);

    edit_action->setText("查看详情");
    delete_action->setText("删除车辆");

    right_menu->addAction(edit_action);

    connect(edit_action,SIGNAL(triggered()),this,SLOT(edit_clicked()));
    if(LoginUser::get_instance().access_level() == 3){
        right_menu->addAction(delete_action);
        connect(delete_action,SIGNAL(triggered()),this,SLOT(delete_clicked()));
    }

    connect(this->ui->tableWidget, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(right_menu_action(const QPoint&)));
}



void CarQueryWidget::right_menu_action(const QPoint &pos)
{
    right_menu->exec(QCursor::pos());
}


void CarQueryWidget::edit_clicked()
{

    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int row=ui->tableWidget->row(items.at(0));

    delete edit_car_dialog;
    edit_car_dialog=nullptr;

    edit_car_dialog=new EditCarDialog;
    edit_car_dialog->init_as_car_info(cars.at(row));
    edit_car_dialog->setModal(true);
    connect(edit_car_dialog,SIGNAL(refresh_car_query_table()),this,SLOT(query_clicked()));
    edit_car_dialog->show();

}

void CarQueryWidget::delete_clicked()
{
    int result= MsgBox::question("车辆管理","删除操作不可逆。确认删除？");
    if(result==MsgBox::YES){
        QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
        int row=ui->tableWidget->row(items.at(0));

        CRequest req;
        req.set_action("delete_car");
        req.put("car_id",cars.at(row).car_id());
        req.set_started_by("query_cars_delete_car"+this_id);
        Network::send(req);
        wait->start();

    }else{

    }

}

void CarQueryWidget::recv_delete(CResponse &resp)
{
    int status_code=resp.status_code();
    if(status_code==StatusCode::SUCCESS){
        MsgBox::success("车辆管理","删除车辆成功");

        query_cars();

    }else{
        MsgBox::error("车辆管理","删除车辆失败");
    }

}



