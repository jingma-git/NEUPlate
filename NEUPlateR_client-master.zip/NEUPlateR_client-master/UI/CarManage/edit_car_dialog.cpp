#include "edit_car_dialog.h"
#include "ui_edit_car_dialog.h"
#include "UI/iconhelper.h"

EditCarDialog::EditCarDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EditCarDialog)
{
    ui->setupUi(this);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));

    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    car_info_widget=new CarInfoWidget;
    ui->verticalLayout->addWidget(car_info_widget);
    connect(car_info_widget,SIGNAL(refresh_car_query_table()),this,SLOT(refresh_car_query_table_slot()));
    connect(car_info_widget,SIGNAL(close_dialog()),this,SLOT(close()));

}

EditCarDialog::~EditCarDialog()
{
    delete ui;
    delete car_info_widget;
}

void EditCarDialog::init_as_car_info(CCar &car)
{
    car_info_widget->init_as_car_info(car);

}

void EditCarDialog::init_as_car_info_show_only(CCar &car)
{
    car_info_widget->init_as_car_info_show_only(car);
}

void EditCarDialog::on_btnMenu_Close_clicked()
{
    close();
}

void EditCarDialog::refresh_car_query_table_slot()
{
    emit refresh_car_query_table();
}
