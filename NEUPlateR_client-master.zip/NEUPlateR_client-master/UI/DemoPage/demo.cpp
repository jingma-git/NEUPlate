#include "demo.h"
#include "ui_demo.h"
#include "UI/iconhelper.h"

ChargeWidget::ChargeWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChargeWidget)
{
    ui->setupUi(this);
    this->init_menu();
    this->init_widget();
}


void ChargeWidget::init_menu(){
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf031 << 0xf036 << 0xf249;
    btns<<ui->btnProfile<<ui->btnQuestion<<ui->btnPassword;

    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btnProfile->click();
}


void ChargeWidget::init_widget(){
}


void ChargeWidget::menu_click(){

    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);

    /*
    if(b==ui->btnProfile){
        ui->stackedWidget->setCurrentIndex(0);
    }else if(b==ui->btnQuestion){
        ui->stackedWidget->setCurrentIndex(1);
    }else if(b==ui->btnPassword){
        ui->stackedWidget->setCurrentIndex(2);
    }
    */

}

ChargeWidget::~ChargeWidget()
{
    delete ui;
}
