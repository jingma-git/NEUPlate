#include "change_passwd_widget.h"
#include "ui_change_passwd_widget.h"

ChangePasswdWidget::ChangePasswdWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChangePasswdWidget)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    Network::registered("modify_passwd_in_change", std::bind(&ChangePasswdWidget::handle_modify_passwd, this, std::placeholders::_1));
}

ChangePasswdWidget::~ChangePasswdWidget()
{
    delete ui;
    delete wait;
}

void ChangePasswdWidget::reset()
{
    ui->ledt_old_passwd->clear();
    ui->ledt_new_passwd1->clear();
    ui->ledt_new_passwd2->clear();
}

/**
* @functionName  message_arrive
* @Description   handler response when server send to this gui
* @author        chenhanlin
* @date          2018-07-07
* @parameter     Response resp
* @return        void
*/
void ChangePasswdWidget::handle_modify_passwd(CResponse &resp)
{
    wait->stop();
    switch (resp.status_code()) {
    case StatusCode::INVAILD_PASSWD:
        MsgBox::information(tr("修改密码"),tr("原密码输入错误"));
        break;
    case StatusCode::SUCCESS:
        MsgBox::information(tr("修改密码"),tr("修改成功"));
        reset();
        break;
    default:
        MsgBox::information(tr("修改密码"),tr("系统错误，请稍后再试"));
        break;
    }
}
void ChangePasswdWidget::on_btn_submit_clicked()
{
    QString origin(ui->ledt_old_passwd->text());
    QString new_passwd(ui->ledt_new_passwd1->text());
    QString new_passwd_confirm(ui->ledt_new_passwd2->text());
    // input shuold not empty
    if (origin.isEmpty() || new_passwd.isEmpty() || new_passwd_confirm.isEmpty()){
        MsgBox::information(tr("修改密码"),tr("输入不能为空。"));
        return;
    }
    // the passwd input twice shuold be the same
    if(new_passwd != new_passwd_confirm){
        MsgBox::information(tr("修改密码"),tr("两次输入的密码不一致。"));
        return;
    }
    CRequest req;
    req.set_action("modify_passwd");
    req.set_started_by("modify_passwd_in_change");
    req.put("new_passwd", new_passwd);
    req.put("old_passwd", origin);
    req.put("username", LoginUser::get_instance().username());
    Network::send(req);
    wait->start();
}
