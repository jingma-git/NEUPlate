#ifndef PERSONAL_PAGE_WIDGET_H
#define PERSONAL_PAGE_WIDGET_H

#include <QWidget>
#include <QToolButton>

#include "personal_information_widget.h"
#include "change_passwd_widget.h"
#include "change_questions_widget.h"

namespace Ui {
class PersonalPageWidget;
}

class PersonalPageWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PersonalPageWidget(QWidget *parent = 0);
    ~PersonalPageWidget();
    void  init_menu();

private slots:
    void  menu_click();

private:
    Ui::PersonalPageWidget *ui;

    QList<int> pixChars;
    QList<QToolButton *> btns;

    PersonalInfoWidget *person;
    ChangePasswdWidget *passwd;
    ChangeQuestionWidget *question;

    void  init_widget();

};

#endif // PERSONAL_CENTER_H
