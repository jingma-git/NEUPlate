#include "change_questions_widget.h"
#include "ui_change_questions_widget.h"
#include <functional>

ChangeQuestionWidget::ChangeQuestionWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChangeQuestionWidget),
    invoke_changed(false)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    this->ui->stackedWidget->setCurrentIndex(0);
    Network::registered("query_employee_question_in_question", std::bind(&ChangeQuestionWidget::handle_query_employee_questions, this, std::placeholders::_1));
    Network::registered("check_question_in_question", std::bind(&ChangeQuestionWidget::handle_check_answer, this, std::placeholders::_1));
    Network::registered("query_questions_in_question", std::bind(&ChangeQuestionWidget::handle_query_questions, this, std::placeholders::_1));
    Network::registered("set_employee_questions_in_question", std::bind(&ChangeQuestionWidget::handler_change_question, this, std::placeholders::_1));
}

ChangeQuestionWidget::~ChangeQuestionWidget()
{
    delete ui;
    delete wait;
}

/**
* @functionName  init
* @Description   query user's question for use
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void ChangeQuestionWidget::init()
{
    invoke_changed = false;
    this->ui->stackedWidget->setCurrentIndex(0);
    ui->cmb_questions->clear();
    ui->cmb_questions1->clear();
    ui->cmb_questions2->clear();
    ui->cmb_questions3->clear();
    ui->cmb_questions->addItem(tr("选择密保问题"));
    ui->cmb_questions1->addItem(tr("选择密保问题1"));
    ui->cmb_questions2->addItem(tr("选择密保问题2"));
    ui->cmb_questions3->addItem(tr("选择密保问题3"));
    ui->ledt_answer->clear();
    ui->ledt_answer1->clear();
    ui->ledt_answer2->clear();
    ui->ledt_answer3->clear();
    invoke_changed = true;
    CRequest req;
    req.put("username", LoginUser::get_instance().username());
    req.set_action("query_employee_question");
    req.set_started_by("query_employee_question_in_question");
    Network::send(req);
    wait->start();
}

/**
* @functionName  handle_query_question
* @Description   handle response from query_question
* @author        chenhanlin
* @date          2018-07-08
* @parameter     Response
* @return        void
*/
void ChangeQuestionWidget::handle_query_employee_questions(CResponse &resp)
{
    wait->stop();
    // check status code
    if (StatusCode::SUCCESS != resp.status_code()){
        MsgBox::information(tr("密保问题"), tr("系统错误，请稍后再试"));
        return;
    }

    QString default_str(this->ui->cmb_questions->itemText(0));
    this->ui->cmb_questions->clear();
    this->ui->cmb_questions->addItem(default_str);
    // get question
    QJsonObject questions = resp.get_json("questions");
    for(const auto &key : questions.keys()){
        QString question(questions[key].toString());
        this->question_table.insert(std::map<QString, QString>::value_type(question, key));
        this->ui->cmb_questions->addItem(question);
    }
    // jump page
    wait->stop();
}

void ChangeQuestionWidget::handle_check_answer(CResponse &resp)
{
    wait->stop();
    switch (resp.status_code()) {
    case StatusCode::SUCCESS:
        get_question();
        this->ui->stackedWidget->setCurrentIndex(1);
        break;
    case StatusCode::WRONG_ANSWER:
        MsgBox::information(tr("密保管理"), tr("密保问题回答错误"));
        this->ui->cmb_questions->setCurrentIndex(0);
        this->ui->ledt_answer->setText("");
        break;
    default:
        MsgBox::warming(tr("密保管理"), tr("系统错误，请稍后再试"));
        break;
    }
}

/**
* @functionName  question_arrive
* @Description   handle the query of security questions
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void ChangeQuestionWidget::handle_query_questions(CResponse &resp)
{
    wait->stop();
    question_table.clear();
    invoke_changed = false;
    ui->cmb_questions1->clear();
    ui->cmb_questions2->clear();
    ui->cmb_questions3->clear();
    ui->cmb_questions1->addItem(tr("选择密保问题1"));
    ui->cmb_questions2->addItem(tr("选择密保问题2"));
    ui->cmb_questions3->addItem(tr("选择密保问题3"));
    ui->ledt_answer1->clear();
    ui->ledt_answer2->clear();
    ui->ledt_answer3->clear();
    invoke_changed = true;
    if(StatusCode::SUCCESS != resp.status_code()){
        MsgBox::information(tr("密保管理"), tr("系统错误，请稍后再试"));
        this->ui->stackedWidget->setCurrentIndex(0);
    }
    QJsonObject questions = resp.get_json("questions");
    for(const auto &key : questions.keys()){
        QString question(questions[key].toString());
        this->question_table.insert(std::map<QString, QString>::value_type(question, key));
        this->ui->cmb_questions1->addItem(question);
        this->ui->cmb_questions2->addItem(question);
        this->ui->cmb_questions3->addItem(question);
    }
}

/**
* @functionName  commit_arrive
* @Description   handler the response after submit
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void ChangeQuestionWidget::handler_change_question(CResponse &resp)
{
    wait->stop();

    if(StatusCode::SUCCESS == resp.status_code()){
        MsgBox::success(tr("密保管理"), tr("修改成功"));
    }else{
        MsgBox::warming(tr("密保管理"), tr("系统错误，请稍后再试"));
    }
    this->ui->stackedWidget->setCurrentIndex(0);
    this->ui->cmb_questions->setCurrentIndex(0);
    this->ui->ledt_answer->setText("");
}

void ChangeQuestionWidget::on_btn_check_clicked()
{
    // get input
    QString answer(this->ui->ledt_answer->text());
    QString question(this->ui->cmb_questions->currentText());
    auto iter = question_table.find(question);
    // check input
    if(question_table.end() == iter){
        MsgBox::information(tr("密保管理"), tr("请选择密保问题"));
        return;
    }
    if (answer.isEmpty()){
        MsgBox::information(tr("密保管理"), tr("请输入回答"));
        return;
    }
    // build request
    CRequest req;
    req.set_action("check_question");
    req.set_started_by("check_question_in_question");
    req.put("username", LoginUser::get_instance().username());
    req.put("q_id", iter->second);
    req.put("answer", answer);
    Network::send(req);
    wait->start();
}

/**
* @functionName  get_question
* @Description   query all securtiy question from server
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void ChangeQuestionWidget::get_question()
{
    CRequest req;
    req.set_action("query_questions");
    req.set_started_by("query_questions_in_question");
    Network::send(req);
    wait->start();
}

void ChangeQuestionWidget::on_cmb_questions1_currentIndexChanged(const QString &arg1)
{
    if(!invoke_changed) return;
    int index = this->ui->cmb_questions1->findText(arg1);
    // get combo box name
    QString object_name(this->ui->cmb_questions1->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->cmb_questions2->addItem(old);
        this->ui->cmb_questions3->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->cmb_questions2->findText(arg1);
        this->ui->cmb_questions2->removeItem(index);
        index = this->ui->cmb_questions3->findText(arg1);
        this->ui->cmb_questions3->removeItem(index);
    }
}

void ChangeQuestionWidget::on_cmb_questions2_currentIndexChanged(const QString &arg1)
{
    if(!invoke_changed) return;
    int index = this->ui->cmb_questions2->findText(arg1);
    // get combo box name
    QString object_name(this->ui->cmb_questions2->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->cmb_questions1->addItem(old);
        this->ui->cmb_questions3->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->cmb_questions1->findText(arg1);
        this->ui->cmb_questions1->removeItem(index);
        index = this->ui->cmb_questions3->findText(arg1);
        this->ui->cmb_questions3->removeItem(index);
    }
}

void ChangeQuestionWidget::on_cmb_questions3_currentIndexChanged(const QString &arg1)
{
    if(!invoke_changed) return;
    int index = this->ui->cmb_questions3->findText(arg1);
    // get combo box name
    QString object_name(this->ui->cmb_questions3->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->cmb_questions2->addItem(old);
        this->ui->cmb_questions1->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->cmb_questions2->findText(arg1);
        this->ui->cmb_questions2->removeItem(index);
        index = this->ui->cmb_questions1->findText(arg1);
        this->ui->cmb_questions1->removeItem(index);
    }
}

void ChangeQuestionWidget::on_btn_cancel_clicked()
{
    this->ui->stackedWidget->setCurrentIndex(0);
    this->ui->cmb_questions->setCurrentIndex(0);
    this->ui->ledt_answer->setText("");
}

void ChangeQuestionWidget::on_btn_submit_clicked()
{
    if(0 == this->ui->cmb_questions1->currentIndex() || 0 == this->ui->cmb_questions2->currentIndex() || 0 == this->ui->cmb_questions3->currentIndex()){
        MsgBox::information(tr("密保管理"), tr("请选择密保问题"));
        return;
    }
    QString question1(this->ui->cmb_questions1->currentText());
    QString question2(this->ui->cmb_questions2->currentText());
    QString question3(this->ui->cmb_questions3->currentText());
    QString answer1(this->ui->ledt_answer1->text());
    QString answer2(this->ui->ledt_answer2->text());
    QString answer3(this->ui->ledt_answer3->text());
    if (answer1.isEmpty() || answer2.isEmpty() || answer3.isEmpty()){
        MsgBox::information(tr("密保管理"), tr("请输入回答"));
        return;
    }
    QJsonObject questions;
    questions.insert(question_table[question1], answer1);
    questions.insert(question_table[question2], answer2);
    questions.insert(question_table[question3], answer3);
    CRequest req;
    req.set_action("set_employee_questions");
    req.set_started_by("set_employee_questions_in_question");
    req.put("username", LoginUser::get_instance().username());
    req.put("questions", questions);
    Network::send(req);
    wait->start();
}
