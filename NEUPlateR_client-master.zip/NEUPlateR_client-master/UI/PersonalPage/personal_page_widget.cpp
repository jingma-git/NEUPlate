#include "personal_page_widget.h"
#include "ui_personal_page_widget.h"
#include "UI/iconhelper.h"

PersonalPageWidget::PersonalPageWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PersonalPageWidget)
{
    person = new PersonalInfoWidget;
    passwd = new ChangePasswdWidget;
    question = new ChangeQuestionWidget;
    ui->setupUi(this);
    this->init_widget();
    this->init_menu();
}


void PersonalPageWidget::init_menu(){
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf031 << 0xf036 << 0xf249;
    btns<<ui->btn_person<<ui->btn_question<<ui->btn_passwd;

    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btn_person->click();
}


void PersonalPageWidget::init_widget(){
    ui->stackedWidget->insertWidget(0, person);
    ui->stackedWidget->insertWidget(1, passwd);
    ui->stackedWidget->insertWidget(2, question);
}


void PersonalPageWidget::menu_click(){

    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);

    if(b==ui->btn_person){
        person->init();
        ui->stackedWidget->setCurrentIndex(0);
    }else if(b==ui->btn_passwd){
        ui->stackedWidget->setCurrentIndex(1);
    }else if(b==ui->btn_question){
        question->init();
        ui->stackedWidget->setCurrentIndex(2);
    }

}

PersonalPageWidget::~PersonalPageWidget()
{
    delete ui;
    delete person;
    delete passwd;
    delete question;
}
