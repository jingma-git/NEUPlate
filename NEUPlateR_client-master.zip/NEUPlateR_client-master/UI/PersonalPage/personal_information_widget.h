#ifndef PROFILE_MANAGE_H
#define PROFILE_MANAGE_H

#include <QWidget>
#include "neu_head.h"
#include "Entity/employee.h"

namespace Ui {
class PersonalInfoWidget;
}

class PersonalInfoWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PersonalInfoWidget(QWidget *parent = 0);
    ~PersonalInfoWidget();
    void init();

    bool Is_init() const;

private slots:
    void on_btn_edit_clicked();
    void handle_query_employee(CResponse&);
    void handle_modify_employee(CResponse&);

    void on_btn_back_clicked();

    void on_btn_submit_clicked();

private:
    Ui::PersonalInfoWidget *ui;
    bool is_init;
    WaitingSpinnerWidget *wait;
    CEmployee employee;

    void init_lineedit();
};

#endif // PROFILE_MANAGE_H
