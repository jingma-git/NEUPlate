#include "personal_information_widget.h"
#include "ui_personal_information_widget.h"
#include "login_user.h"
#include "Exception/null_exception.h"

#include <QDate>
#include <QPixmap>
#include <QByteArray>
#include <QIcon>

PersonalInfoWidget::PersonalInfoWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PersonalInfoWidget),
    is_init(false)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    this->ui->btn_submit->hide();
    this->ui->btn_back->hide();
    init_lineedit();
    Network::registered("query_employee_in_personal", std::bind(&PersonalInfoWidget::handle_query_employee, this, std::placeholders::_1));
    Network::registered("modify_employee_in_personal", std::bind(&PersonalInfoWidget::handle_modify_employee, this, std::placeholders::_1));

    setTabOrder(ui->cmb_sex, ui->dedt_birthday);
    setTabOrder(ui->dedt_birthday, ui->ledt_email);
    setTabOrder(ui->ledt_email, ui->cmb_edu);
    setTabOrder(ui->cmb_edu, ui->cmb_married);
    setTabOrder(ui->cmb_married, ui->ledt_birth_place);
    setTabOrder(ui->ledt_birth_place, ui->ledt_phone);
    setTabOrder(ui->ledt_phone, ui->ledt_political_status);
    setTabOrder(ui->ledt_political_status, ui->ledt_nation);
}

PersonalInfoWidget::~PersonalInfoWidget()
{
    delete ui;
}

/**
* @functionName  init
* @Description   init this gui, query this user's employee information from server
* @author        chenhanlin
* @date          2018-07-09
* @parameter     void
* @return        void
*/
void PersonalInfoWidget::init()
{
    CRequest req;
    req.set_action("query_employee");
    req.set_started_by("query_employee_in_personal");
    req.put("username", LoginUser::get_instance().username());
    Network::send(req);
    wait->start();
}

void PersonalInfoWidget::on_btn_edit_clicked()
{
    this->ui->btn_submit->show();
    this->ui->btn_back->show();
    this->ui->btn_edit->hide();

    ui->cmb_sex->setEnabled(true);
    ui->dedt_birthday->setEnabled(true);
    ui->ledt_email->setEnabled(true);
    ui->cmb_edu->setEnabled(true);
    ui->cmb_married->setEnabled(true);
    ui->ledt_birth_place->setEnabled(true);
    ui->ledt_nation->setEnabled(true);
    ui->ledt_political_status->setEnabled(true);
    ui->ledt_phone->setEnabled(true);
}

/**
* @functionName  init_message
* @Description   handle the response of init(), response contain user's information
* @author        chenhanlin
* @date          2018-07-09
* @parameter     Response resp
* @return        void
*/
void PersonalInfoWidget::handle_query_employee(CResponse &resp)
{
    wait->stop();

    if(StatusCode::SUCCESS != resp.status_code()){
        MsgBox::information(tr("系统错误"),tr("系统错误，请稍后再试"));
        return;
    }

    QJsonObject e_info;

    try{
        e_info = resp.get_json("employee");
    }catch(NullException e){
        MsgBox::information(tr("系统错误"),tr("系统错误，请稍后再试"));
        return;
    }

    // get data
    QString name(e_info["name"].toString());
    QString work_place(e_info["work_place"].toString());
    int gender(e_info["gender"].toInt()-1);
    QDate birthday(QDate::fromString(e_info["birthday"].toString()));
    QString birth_place(e_info["birth_place"].toString());
    QString nation(e_info["nation"].toString());
    bool married(e_info["married"].toBool());
    QString political_status(e_info["political_state"].toString());
    int edu(e_info["edu"].toInt());
    QString id(e_info["id"].toString());
    QString phone(e_info["telephone"].toString());
    QString email(e_info["email"].toString());
    QString photo_base64(e_info["photo"].toString());
    int access_level = e_info["access_level"].toInt();

    QPixmap photo;
    photo.loadFromData(QByteArray::fromBase64(photo_base64.toUtf8()));

    // save in employee

    // show in gui
    ui->label_name->setText(name);
    ui->label_id->setText(id);
    ui->cmb_sex->setCurrentIndex(gender);
    ui->dedt_birthday->setDate(birthday);
    ui->label_work_place->setText(work_place);
    ui->ledt_phone->setText(phone);
    ui->ledt_email->setText(email);
    ui->cmb_edu->setCurrentIndex(edu);
    ui->cmb_married->setCurrentIndex(int(married));
    ui->ledt_birth_place->setText(birth_place);
    ui->ledt_political_status->setText(political_status);
    ui->ledt_nation->setText(nation);
    ui->label_access_level->setText(QString().setNum(access_level));
    if(!photo_base64.isEmpty())
        ui->label_photo->setPixmap(photo);

    employee.set_name(name);
    employee.set_id(id);
    employee.set_gender(gender);
    employee.set_birthday(birthday);
    employee.set_work_place(work_place);
    employee.set_telephone(phone);
    employee.set_email(email);
    employee.set_education(edu);
    employee.set_married(married);
    employee.set_birth_place(birth_place);
    employee.set_political_state(political_status);
    employee.set_nation(nation);
    employee.set_access_level(access_level);

    this->is_init = true;
}

/**
* @functionName  submit_message
* @Description   handler the modify_part method's response
* @author        chenhanlin
* @date          2018-07-09
* @parameter     Response resp
* @return        void
*/
void PersonalInfoWidget::handle_modify_employee(CResponse &resp)
{
    wait->stop();

    if(StatusCode::SUCCESS != resp.status_code()){
        MsgBox::information(tr("系统错误"),tr("系统错误，请稍后再试"));
        return;
    }
    MsgBox::success(tr("系统提示"), tr("修改成功"));

    int sex = ui->cmb_sex->currentIndex();
    QDate birthday(ui->dedt_birthday->date());
    QString birth_place(ui->ledt_birth_place->text());
    QString nation(ui->ledt_nation->text());
    QString email(ui->ledt_email->text());
    int edu = ui->cmb_edu->currentIndex();
    int married = ui->cmb_married->currentIndex();
    QString phone(ui->ledt_phone->text());
    QString political_status(ui->ledt_political_status->text());

    employee.set_gender(sex);
    employee.set_birthday(birthday);
    employee.set_birth_place(birth_place);
    employee.set_nation(nation);
    employee.set_email(email);
    employee.set_education(edu);
    employee.set_married(married);
    employee.set_telephone(phone);
    employee.set_political_state(political_status);
    this->ui->btn_back->click();
}

bool PersonalInfoWidget::Is_init() const
{
    return is_init;
}

void PersonalInfoWidget::on_btn_back_clicked()
{
    this->ui->btn_submit->hide();
    this->ui->btn_back->hide();
    this->ui->btn_edit->show();

    // disable tool
    ui->dedt_birthday->setEnabled(false);
    ui->cmb_sex->setEnabled(false);
    ui->ledt_birth_place->setEnabled(false);
    ui->ledt_nation->setEnabled(false);
    ui->cmb_married->setEnabled(false);
    ui->ledt_political_status->setEnabled(false);
    ui->cmb_edu->setEnabled(false);
    ui->ledt_phone->setEnabled(false);
    ui->ledt_email->setEnabled(false);

    // reset data
    ui->cmb_sex->setCurrentIndex(int(employee.gender()));
    ui->dedt_birthday->setDate(QDate::fromString(employee.birthday()));
    ui->ledt_phone->setText(employee.telephone());
    ui->ledt_email->setText(employee.email());
    ui->cmb_edu->setCurrentIndex(int(employee.education()));
    ui->cmb_married->setCurrentIndex(int(employee.married()));
    ui->ledt_birth_place->setText(employee.birth_place());
    ui->ledt_political_status->setText(employee.political_state());
    ui->ledt_nation->setText(employee.nation());
//    ui->photo->setIcon(QIcon(photo));
}

void PersonalInfoWidget::on_btn_submit_clicked()
{
    int sex = ui->cmb_sex->currentIndex();
    QDate birthday(ui->dedt_birthday->date());
    QString nation(ui->ledt_nation->text());
    QString email(ui->ledt_email->text());
    QString birth_place(ui->ledt_birth_place->text());
    int edu = ui->cmb_edu->currentIndex();
    int married = ui->cmb_married->currentIndex();
    QString phone(ui->ledt_phone->text());
    QString political_status(ui->ledt_political_status->text());

    if(email.isEmpty() || phone.isEmpty()){
        MsgBox::information(tr("编辑信息"), tr("请填写完整信息"));
        return;
    }
    QRegExp email_check("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$");
    QRegExp phone_check("^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$");
    if(!email_check.exactMatch(email)){
        MsgBox::information(tr("编辑信息"), tr("请输入正确的电子邮件"));
        return;
    }
    if(!phone_check.exactMatch(phone)){
        MsgBox::information(tr("编辑信息"), tr("请输入正确的电话号码"));
        return;
    }

    QJsonObject employee;
    CRequest req;
    req.set_action("modify_employee");
    req.set_started_by("modify_employee_in_personal");
    employee.insert("username", LoginUser::get_instance().username());
    employee.insert("birthday", birthday.toString());
    employee.insert("birth_place", birth_place);
    employee.insert("nation", nation);
    employee.insert("gender", sex+1);
    employee.insert("married", bool(married));
    employee.insert("political_status", political_status);
    employee.insert("education", edu);
    employee.insert("telephone", phone);
    employee.insert("email", email);

    req.put("employee", employee);
    Network::send(req);
    wait->start();
}


/**
* @functionName  init_lineedit
* @Description       add contraint at line edit
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         void
* @return               void
*/
void PersonalInfoWidget::init_lineedit()
{
    QRegExp email("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$");
    QRegExpValidator *pemail = new QRegExpValidator(email, this);
    ui->ledt_email->setValidator(pemail);
    QRegExp phone("^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$");
    QRegExpValidator *pphone = new QRegExpValidator(phone, this);
    ui->ledt_phone->setValidator(pphone);
}
