#ifndef PASSWORD_MANAGE_H
#define PASSWORD_MANAGE_H

#include <QWidget>
#include "neu_head.h"

namespace Ui {
class ChangePasswdWidget;
}

class ChangePasswdWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ChangePasswdWidget(QWidget *parent = 0);
    ~ChangePasswdWidget();
    void reset();

private slots:
    void handle_modify_passwd(CResponse&);

    void on_btn_submit_clicked();

private:
    Ui::ChangePasswdWidget *ui;
    WaitingSpinnerWidget *wait;
};

#endif // PASSWORD_MANAGE_H
