#ifndef QUESTION_MANAGE_H
#define QUESTION_MANAGE_H

#include <QWidget>
#include <map>

#include "neu_head.h"

namespace Ui {
class ChangeQuestionWidget;
}

class ChangeQuestionWidget : public QWidget
{
    Q_OBJECT
public:
    explicit ChangeQuestionWidget(QWidget *parent = 0);
    ~ChangeQuestionWidget();
    void init();

private slots:
    void handle_query_employee_questions(CResponse&);
    void handle_check_answer(CResponse&);
    void handle_query_questions(CResponse&);
    void handler_change_question(CResponse&);

    void on_btn_check_clicked();

    void on_cmb_questions1_currentIndexChanged(const QString &arg1);

    void on_cmb_questions2_currentIndexChanged(const QString &arg1);

    void on_cmb_questions3_currentIndexChanged(const QString &arg1);

    void on_btn_cancel_clicked();

    void on_btn_submit_clicked();

private:
    Ui::ChangeQuestionWidget *ui;
    std::map<QString, QString> question_table;
    std::map<QString, QString> selected;
    WaitingSpinnerWidget *wait;
    bool invoke_changed;

    void get_question();
};

#endif // QUESTION_MANAGE_H
