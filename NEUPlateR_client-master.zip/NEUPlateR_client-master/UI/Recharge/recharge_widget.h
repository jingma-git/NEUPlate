#ifndef RECHARGE_WIDGET_H
#define RECHAEGE_WIDGET_H

#include <QWidget>
#include <QToolButton>


namespace Ui {
class RechargeWidget;
}

class RechargeWidget : public QWidget
{
    Q_OBJECT

public:
    explicit RechargeWidget(QWidget *parent = 0);
    ~RechargeWidget();
    void  init_menu();

private slots:
    void  menu_click();

private:
    Ui::RechargeWidget *ui;

    QList<int> pixChars;
    QList<QToolButton *> btns;

    void  init_widget();

};

#endif // PERSONAL_CENTER_H
