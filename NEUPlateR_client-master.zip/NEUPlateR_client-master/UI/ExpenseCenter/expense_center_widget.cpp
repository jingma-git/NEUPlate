#include "expense_center_widget.h"
#include "ui_expense_center_widget.h"
#include "UI/iconhelper.h"

ExpenseCenterWidget::ExpenseCenterWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ExpenseCenterWidget)
{
    m_recharge_widget = new RechargeWidget();
    m_deduction_widget = new DeductionWidget();

    ui->setupUi(this);
    this->init_menu();
    this->init_widget();
}


void ExpenseCenterWidget::init_menu(){
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf031 << 0xf036;
    btns<<ui->btn_recharge<<ui->btn_deduction;

    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btn_recharge->click();
}


void ExpenseCenterWidget::init_widget()
{
    ui->stackedWidget->insertWidget(0, m_recharge_widget);
    ui->stackedWidget->insertWidget(1, m_deduction_widget);
}


void ExpenseCenterWidget::menu_click(){

    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);


    if(b==ui->btn_recharge){
        ui->stackedWidget->setCurrentIndex(0);
    }else if(b==ui->btn_deduction){
        m_deduction_widget->init_deduction_record();
        ui->stackedWidget->setCurrentIndex(1);
    }
}

ExpenseCenterWidget::~ExpenseCenterWidget()
{
    delete ui;

}
