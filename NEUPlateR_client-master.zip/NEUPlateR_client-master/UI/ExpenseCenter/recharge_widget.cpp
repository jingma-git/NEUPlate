#include "recharge_widget.h"
#include "ui_recharge_widget.h"

/**
* @name          RechargeWidget
* @brief         the constructor of class RechargeWidget that initial the ui interface and class resource.
* @author        luxijia
* @date          2018-08-02
* @param         parent parent widget
* @return        RechargeWidget
*/
RechargeWidget::RechargeWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RechargeWidget)
{
    ui->setupUi(this);

    m_waiting = new WaitingSpinnerWidget(this);

    QRegExp id_judge("^\\d{6}(18|19|20)?\\d{2}(0[1-9]|1[012])(0[1-9]|[12]\\d|3[01])\\d{3}(\\d|[xX])$");
    QRegExp amount_judge("^(0|([1-9]\\d{0,5}(\\.\\d{1,2})?))$");
    QRegExpValidator *p_id_validator = new QRegExpValidator(id_judge, this);
    QRegExpValidator *p_amount_judge = new QRegExpValidator(amount_judge, this);
    this->ui->ledit_id_number->setValidator(p_id_validator);
    this->ui->ledit_recharge_amount->setValidator(p_amount_judge);
    Network::registered("charge_payer_balance_in_recharge_widget", std::bind(&RechargeWidget::recv_charge_payer, this, std::placeholders::_1));
}

/**
* @name          ~RechargeWidget
* @brief         the deconstructor of class RechargeWidget that release the class resource.
* @author        luxijia
* @date          2018-08-02
* @return        RechargeWidget
*/
RechargeWidget::~RechargeWidget()
{
    delete ui;
    delete m_waiting;
}

/**
* @name          the constructor of class RechargeWidget that initial the ui interface and resource.
* @brief         a slot function that send recharge request after clicked recharge push button.
* @author        luxijia
* @date          2018-08-02
*/
void RechargeWidget::on_btn_recharge_clicked()
{
    if (this->ui->ledit_id_number->text().isEmpty() ||
            this->ui->ledit_recharge_amount->text().isEmpty())
    {
        MsgBox::warming("警告", "信息未填写完毕!");
        return;
    }

    //Regular judge vailaction
    QRegExp id_judge("^\\d{6}(18|19|20)?\\d{2}(0[1-9]|1[012])(0[1-9]|[12]\\d|3[01])\\d{3}(\\d|[xX])$");
    QRegExp amount_judge("^\\+?(?!0+(\\.00?)?$)\\d+(\\.\\d\\d?)?$");

    if (!id_judge.exactMatch(this->ui->ledit_id_number->text()))
    {
        MsgBox::warming("警告", "身份证输入有误!");
        return;
    }

    if (!amount_judge.exactMatch(this->ui->ledit_recharge_amount->text()))
    {
        MsgBox::warming("警告", "金额输入有误!");
        return;
    }

    QString id_number = this->ui->ledit_id_number->text();
    double amount =this->ui->ledit_recharge_amount->text().toDouble();

    CRequest req;
    req.set_action("recharge_payer");
    req.set_started_by("charge_payer_balance_in_recharge_widget");
    req.put("id_card", id_number);
    req.put("value", amount);

    Network::send(req);
    m_waiting->start();
}

/**
* @name          recv_charge_payer
* @brief         recv server response to charge request.
* @author        luxijia
* @date          2018-08-02
* @param         pesp {@CResponse} object the response body
*/
void RechargeWidget::recv_charge_payer(CResponse &resp)
{
    m_waiting->stop();

    if (StatusCode::BALANCE_OVERFLOW == resp.status_code())
    {
        MsgBox::warming("警告","充值金额超出限制!");
        return;
    }
    else if (StatusCode::PAYER_NOT_FOUND == resp.status_code())
    {
        MsgBox::warming("警告","账户不存在!");
        return;
    }
    else if (StatusCode::UPDATE_ERROR == resp.status_code())
    {
        MsgBox::error("失败", "充值失败!");
        return;
    }
    else if (StatusCode::ERROR_PARAMS == resp.status_code())
    {
        MsgBox::error("失败", "发送参数出错!");
        return;
    }

    MsgBox::success("成功", "充值成功!");
    this->ui->ledit_id_number->clear();
    this->ui->ledit_recharge_amount->clear();
}

/**
* @name          on_btn_cancel_clicked
* @brief         a slot function that cancel charge and clear input data.
* @author        luxijia
* @date          2018-08-02
*/
void RechargeWidget::on_btn_cancel_clicked()
{
    this->ui->ledit_id_number->clear();
    this->ui->ledit_recharge_amount->clear();
}
