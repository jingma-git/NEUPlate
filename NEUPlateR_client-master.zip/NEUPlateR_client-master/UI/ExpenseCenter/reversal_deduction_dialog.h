#ifndef REVERSAL_DEDUCTION_DIALOG_H
#define REVERSAL_DEDUCTION_DIALOG_H

#include <QDialog>
#include <QPixmap>
#include "UI/msgbox.h"
#include "UI/waitingspinnerwidget.h"
#include "tool/phototool.h"
#include "neu_head.h"
#include "UI/iconhelper.h"

namespace Ui {
class ReversalDeductionDialog;
}

class ReversalDeductionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ReversalDeductionDialog(QWidget *parent = 0);
    ~ReversalDeductionDialog();

signals:
    void reversal_deduction_success();

private slots:
    void recv_reversal_deduction_photo(const QString &deduction_id, const QString &start_id, const QString &end_id,
                                 const QByteArray &start_photo, const QByteArray &end_photo);
    void recv_reversal_deduction_record(CResponse&);

    void on_btn_reversal_clicked();
    void on_btn_cancel_clicked();

private:
    Ui::ReversalDeductionDialog *ui;
    WaitingSpinnerWidget *m_waiting;
    QString m_start_id;
    QString m_end_id;
    QString m_dedcution_id;
    QByteArray m_start_photo;
    QByteArray m_end_photo;
    QImage m_in_img;
    QImage m_out_img;
};

#endif // REVERSAL_DEDUCTION_DIALOG_H
