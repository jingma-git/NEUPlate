#ifndef DEDUCTION_WIDGET_H
#define DEDUCTION_WIDGET_H

#include <QWidget>
#include <QMenu>
#include <QJsonArray>
#include "UI/msgbox.h"
#include "UI/waitingspinnerwidget.h"
#include "neu_head.h"
#include "Entity/deduction_record.h"
#include "reversal_deduction_dialog.h"

namespace Ui {
class DeductionWidget;
}

class DeductionWidget : public QWidget
{
    Q_OBJECT

public:
    explicit DeductionWidget(QWidget *parent = 0);
    void init_deduction_record();
    ~DeductionWidget();

signals:
    void send_reversal_drive_record(const QString&, const QString&, const QString&, const QByteArray&, const QByteArray&);

private slots:

    void change_page(int new_index);
    void last_page();
    void next_page();
    void right_menu_action(const QPoint&);

    void recv_search_deduction_record(CResponse&);
    void recv_delete_deduction_record(CResponse&);
    void recv_reversal_deduction_validity(CResponse&);
    void recv_reversal_result();

    void on_dedit_end_userDateChanged(const QDate &date);
    void on_dedit_start_userDateChanged(const QDate &date);

    void on_btn_reversal_deduction_clicked();
    void on_btn_delete_deduction_clicked();
    void on_btn_search_clicked();

private:
    Ui::DeductionWidget *ui;

    std::vector<CDedutionRecord> m_records;
    QMenu *m_right_menu;
    QAction *m_reversal_deduction;
    QAction *m_delete_deduction;
    WaitingSpinnerWidget *m_waiting;
    ReversalDeductionDialog *m_reversal_deduction_dialog;
    int page;
    int item;
    int current_page;
    bool inited;

    void refresh_page();
    void search_deduction_record();
    void show_deduction_record();
    void create_menu();
    QString transform_pay_method(int pay_method);
};

#endif // DEDUCTION_WIDGET_H
