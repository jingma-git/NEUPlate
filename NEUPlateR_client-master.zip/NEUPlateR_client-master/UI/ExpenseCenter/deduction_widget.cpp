#include "deduction_widget.h"
#include "login_user.h"
#include "ui_deduction_widget.h"

DeductionWidget::DeductionWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DeductionWidget)
{
    ui->setupUi(this);
    current_page = 1;
    page = 1;
    item = 10;
    inited = false;
    m_waiting = new WaitingSpinnerWidget(this);
    m_reversal_deduction_dialog = new ReversalDeductionDialog();

    //fixed table rows number
//    ui->tableWidget->setRowCount(item);
    ui->tableWidget->setShowGrid(false);
//    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    ui->tableWidget->insertRow(0);

    //set time
    ui->dedit_end->setDate(QDate::currentDate());
    ui->dedit_start->setDate(QDate::currentDate().addDays(-7));

    //set tool button
//    ui->tbtn_left->setArrowType(Qt::LeftArrow);
//    ui->tbtn_right->setArrowType(Qt::RightArrow);

    //set right mouse button menu
    create_menu();
    refresh_page();

    //connect search line deit return presss signal with search button clicked signal
    connect(ui->ledit_search, SIGNAL(returnPressed()), ui->btn_search, SIGNAL(clicked()));

    //connect left and right tool button whth last page and next page function
    connect(ui->tbtn_left, SIGNAL(clicked()), this, SLOT(last_page()));
    connect(ui->tbtn_right, SIGNAL(clicked()), this, SLOT(next_page()));
    connect(this, SIGNAL(send_reversal_drive_record(QString,QString,QString,QByteArray,QByteArray)),
            m_reversal_deduction_dialog, SLOT(recv_reversal_deduction_photo(QString,QString,QString,QByteArray,QByteArray)));
    connect(m_reversal_deduction_dialog, SIGNAL(reversal_deduction_success()), this, SLOT(recv_reversal_result()));

    Network::registered("search_deduction_record_in_deduction_widget",
                        std::bind(&DeductionWidget::recv_search_deduction_record, this, std::placeholders::_1));
    Network::registered("delete_deduction_record_in_deduction_widget",
                        std::bind(&DeductionWidget::recv_delete_deduction_record, this, std::placeholders::_1));
    Network::registered("valid_reversal_deduction_record_in_deduction_widget",
                        std::bind(&DeductionWidget::recv_reversal_deduction_validity, this, std::placeholders::_1));

    if(LoginUser::get_instance().access_level() < 3){
        ui->btn_delete_deduction->hide();
    }
}

DeductionWidget::~DeductionWidget()
{
    delete ui;
    delete m_right_menu;
    delete m_reversal_deduction;
    delete m_delete_deduction;
    delete m_waiting;
    delete m_reversal_deduction_dialog;
}

/**
* @functionName  create_menu
* @Description   crete table widget right mouse menu
* @author        luxijia
* @date          2018-7-12
*/
void DeductionWidget::create_menu()
{
    m_right_menu = new QMenu(this->ui->tableWidget);

    m_reversal_deduction = new QAction(this);
    m_delete_deduction = new QAction(this);

    m_reversal_deduction->setText(QString("冲正"));

    m_right_menu->addAction(m_reversal_deduction);

    //connect action
    connect(m_reversal_deduction, SIGNAL(triggered()), this, SLOT(on_btn_reversal_deduction_clicked()));

    if(LoginUser::get_instance().access_level() > 2){
        m_delete_deduction->setText(QString("删除"));
        m_right_menu->addAction(m_delete_deduction);
        connect(m_delete_deduction, SIGNAL(triggered()), this, SLOT(on_btn_delete_deduction_clicked()));
    }

    connect(this->ui->tableWidget, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(right_menu_action(const QPoint&)));
}

QString DeductionWidget::transform_pay_method(int pay_method)
{
    switch (pay_method)
    {
    case 1:
        return "普通付费";
    case 2:
        return "快速支付";
    default:
        return "";
    }
}

/**
* @functionName  right_menu_action
* @Description   show right menu item
* @author        luxijia
* @date          2018-7-12
* @parameter     QPoint dialog postion
*/
void DeductionWidget::right_menu_action(const QPoint &pos)
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();
    int rows = count / this->ui->tableWidget->columnCount();

    if (rows > 0)
    {
        m_reversal_deduction->setEnabled(true);
        m_delete_deduction->setEnabled(true);

        if (rows > 1)
            m_reversal_deduction->setDisabled(true);

        if ((rows == 1) &&
                ((QDateTime::currentDateTime() >=
                 QDateTime::fromString(m_records[this->ui->tableWidget->row(items.at(0))].deduction_time(),
                                       "yyyy-MM-dd hh:mm:ss").addDays(2)) ||
                 m_records[this->ui->tableWidget->row(items.at(0))].fee() <= 0) ||
                m_records[this->ui->tableWidget->row(items.at(0))].pay_menthod() != 2)
            m_reversal_deduction->setDisabled(true);


        m_right_menu->exec(QCursor::pos());
    }
}

/**
* @functionName  refresh_page
* @Description   refresh combobox context and set current page.
* @author        luxijia
* @date          2018-7-12
*/
void DeductionWidget::refresh_page()
{
    disconnect(this->ui->comboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(change_page(int)));
    this->ui->tbtn_left->setEnabled(!(1 == current_page || 0 == current_page));
    this->ui->tbtn_right->setEnabled(!(current_page == page));
    this->ui->comboBox->clear();

    for (int i = 0; i < page; i++)
        this->ui->comboBox->insertItem(i, QString("第%1页").arg(i+1));

    this->ui->comboBox->setCurrentIndex(current_page - 1);
    connect(this->ui->comboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(change_page(int)));
}

/**
* @functionName  change_page
* @Description   change current page number and search supplier
* @author        luxijia
* @date          2018-7-10
* @parameter     new_index combobox next state index
*/
void DeductionWidget::change_page(int new_index)
{
    current_page = new_index + 1;
    search_deduction_record();
}

/**
* @functionName  init_deduction_record
* @Description   set all search deduction record condition to default
*                and search;
* @author        luxijia
* @date          2018-8-1
*/
void DeductionWidget::init_deduction_record()
{
    if (inited)
       return;

    inited=true;
    current_page = 1;
    this->ui->ledit_search->clear();
    this->ui->cbox_finish->clicked(false);
    this->ui->cbox_reversal->clicked(false);
    this->ui->dedit_start->setDate(QDate::currentDate().addDays(-7));
    this->ui->dedit_end->setDate(QDate::currentDate());
    search_deduction_record();
}

/**
* @functionName  last_page
* @Description   a slot funtion that return last page.
* @author        luxijia
* @date          2018-7-12
*/
void DeductionWidget::last_page()
{
    //since combobox index begin in 0, and actually page begin in 1,
    //index need sub 1 and then sub 1
    int index = current_page - 2;

    if (index < 0)
        index = 0;

    change_page(index);
}

/**
* @functionName  next_page
* @Description   a slot funtion that return last page.
* @author        luxijia
* @date          2018-7-12
*/
void DeductionWidget::next_page()
{
    //since combobox index begin in 0, and actually page begin in 1,
    //index need and 1 and then sub 1
    int index = current_page;

    if (index > page)
        index = page;

    change_page(current_page);
}

/**
* @functionName  on_btn_search_clicked
* @Description   a slot function that send search sale list request
*                after click search botton.
* @author        luxijia
* @date          2018-7-10
*/
void DeductionWidget::on_btn_search_clicked()
{
    current_page = 1;
    search_deduction_record();
}

/**
* @functionName  search_sale_list
* @Description   send search sale list request to server.
* @author        luxijia
* @date          2018-7-12
*/
void DeductionWidget::search_deduction_record()
{
    CRequest req;
    req.set_action("query_deduction_record");
    req.set_started_by("search_deduction_record_in_deduction_widget");

    int state;

    if (true == this->ui->cbox_reversal->isChecked())
        state = 0;

    if (true == this->ui->cbox_finish->isChecked())
        state = 1;

    if ((this->ui->cbox_reversal->isChecked() == true && this->ui->cbox_finish->isChecked() == true)
            || (this->ui->cbox_reversal->isChecked() == false && this->ui->cbox_finish->isChecked() == false))
        state = -1;

    req.put("state", state);
    req.put("keyword", this->ui->ledit_search->text());
    req.put("page_number", current_page);
    req.put("page_item", item);
    req.put("start_time", this->ui->dedit_start->date().addDays(-1).toString("yyyy-MM-dd"));
    req.put("end_time", this->ui->dedit_end->date().addDays(1).toString("yyyy-MM-dd"));

    Network::send(req);
    m_waiting->start();
}

/**
* @functionName  recv_search_sale_list
* @Description   a slot function that receive search sale list request's respone,
*                show whether search success, and close conncection.
* @author        luxijia
* @date          2018-7-12
* @parameter     resp network response
*/
void DeductionWidget::recv_search_deduction_record(CResponse &resp)
{
    //close connection
    m_waiting->stop();

    if (StatusCode::QUERY_ERROR == resp.status_code())
    {
        MsgBox::error("失败", "查询失败!");
        return;
    }
    else if (StatusCode::ERROR_PARAMS == resp.status_code())
    {
        MsgBox::error("失败", "发送参数出错!");
        return;
    }
    else if(StatusCode::EMPTY_QUERY == resp.status_code())
    {
        int row_count = this->ui->tableWidget->rowCount();

        for (int i = row_count - 1; i > -1; i--)
            this->ui->tableWidget->removeRow(i);

        this->ui->tableWidget->insertRow(0);
        return;
    }

    m_records.clear();
    page = ceil((double)resp.get_int("all_row_number") / item);
    QJsonArray deduction_array = resp.get_array("deduction_record");

    if (!deduction_array.isEmpty())
    {
        int size = deduction_array.size();

        for (int i = 0; i < size; i++)
        {
            QJsonValue value = deduction_array.at(i);

            if (value.isObject())
            {
                QJsonObject deduction_object = value.toObject();
                CDedutionRecord deduction_record;
                deduction_record.setDeduction_id(deduction_object.value("deduction_id").toString());
                deduction_record.setPlate(deduction_object.value("plate").toString());
                deduction_record.setStart_name(deduction_object.value("start_name").toString());
                deduction_record.setEnd_name(deduction_object.value("end_name").toString());
                deduction_record.setDistance(deduction_object.value("distance").toDouble());
                deduction_record.setFee(deduction_object.value("fee").toDouble());
                deduction_record.setPay_menthod(deduction_object.value("pay_method").toInt());
                deduction_record.setDeduction_time(deduction_object.value("deduction_time").toString());
                m_records.push_back(deduction_record);
            }
        }
    }

    refresh_page();
    show_deduction_record();
}

/**
* @functionName  show_deduction_record
* @Description   show deduction record information in table widget.
* @author        luxijia
* @date          2018-8-1
*/
void DeductionWidget::show_deduction_record()
{
    int row_count = this->ui->tableWidget->rowCount();

    for (int j = row_count - 1; j > -1; j--)
        this->ui->tableWidget->removeRow(j);

    this->ui->tableWidget->insertRow(0);

    int size = m_records.size();
    int row = -1;

    for (int i = 0; i < size; i++)
    {
        this->ui->tableWidget->setItem(i, 0, new QTableWidgetItem(m_records[i].plate()));
        this->ui->tableWidget->setItem(i, 1, new QTableWidgetItem(m_records[i].start_name()));
        this->ui->tableWidget->setItem(i, 2, new QTableWidgetItem(m_records[i].end_name()));
        this->ui->tableWidget->setItem(i, 3, new QTableWidgetItem(QString::number(m_records[i].distance())));
        this->ui->tableWidget->setItem(i, 4, new QTableWidgetItem(QString::number(m_records[i].fee())));
        this->ui->tableWidget->setItem(i, 5, new QTableWidgetItem(transform_pay_method(m_records[i].pay_menthod())));
        this->ui->tableWidget->setItem(i, 6, new QTableWidgetItem(m_records[i].deduction_time()));
        this->ui->tableWidget->resizeColumnToContents(6);
        this->ui->tableWidget->item(i, 0)->setTextAlignment(Qt::AlignCenter);
        this->ui->tableWidget->item(i, 1)->setTextAlignment(Qt::AlignCenter);
        this->ui->tableWidget->item(i, 2)->setTextAlignment(Qt::AlignCenter);
        this->ui->tableWidget->item(i, 3)->setTextAlignment(Qt::AlignCenter);
        this->ui->tableWidget->item(i, 4)->setTextAlignment(Qt::AlignCenter);
        this->ui->tableWidget->item(i, 5)->setTextAlignment(Qt::AlignCenter);
        this->ui->tableWidget->item(i, 6)->setTextAlignment(Qt::AlignCenter);
        this->ui->tableWidget->update();

        if (i < size - 1)
        {
            row = this->ui->tableWidget->rowCount();
            this->ui->tableWidget->insertRow(row);
        }

    }
}
/**
* @functionName  on_btn_reversal_deduction_clicked
* @Description   a slot function that repeal selected supplier
*                and send request.
* @author        luxijia
* @date          2018-7-12
*/
void DeductionWidget::on_btn_reversal_deduction_clicked()
{

    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();
    int rows = count / this->ui->tableWidget->columnCount();

    if (0 == rows || rows > 1)
        return;

    int row = this->ui->tableWidget->row(items.at(0));

    if (0 > m_records[row].fee())
    {
        MsgBox::warming("警告", "试图冲正已冲正记录");
        return;
    }

    if (QDateTime::currentDateTime() >=
            QDateTime::fromString(m_records[row].deduction_time(), "yyyy-MM-dd hh:mm:ss").addDays(2))
    {
        MsgBox::warming("警告", "已超出冲正的时间");
        return;
    }

    CRequest req;
    req.set_action("vailed_reversal_deduction_record");
    req.set_started_by("valid_reversal_deduction_record_in_deduction_widget");

    req.put("reversal_deduction", m_records[row].deduction_id());

    Network::send(req);
    m_waiting->start();
}

/**
* @functionName  recv_reversal_deduction_validity
* @Description   a slot function that receive reversal deduction record validity request's respone,
*                show whether repeal success, and close conncection.
* @author        luxijia
* @date          2018-8-2
* @parameter     resp network response
*/
void DeductionWidget::recv_reversal_deduction_validity(CResponse &resp)
{
    m_waiting->stop();

    if (StatusCode::INVAILD_REVERSAL == resp.status_code())
    {
        MsgBox::error("失败", "此缴费记录无法冲正!");
        return;
    }
    else if (StatusCode::TIME_OUT_ERROR == resp.status_code())
    {
        MsgBox::error("失败","缴费记录冲正已超出时限!");
        return;
    }
    else if (StatusCode::ERROR_PARAMS == resp.status_code())
    {
        MsgBox::error("失败", "发送参数出错!");
        return;
    }

    emit send_reversal_drive_record(resp.get_string("deduction_id"), resp.get_string("start_id"), resp.get_string("end_id"),
                                    resp.get_string("start_photo").toUtf8(), resp.get_string("end_photo").toUtf8());
}

/**
* @name          recv_reversal_result
* @brief         recive reversal deduction result
* @author        luxijia
* @date          2018-08-08
*/
void DeductionWidget::recv_reversal_result()
{
    current_page = 1;
    search_deduction_record();
}

/**
* @functionName  on_btn_delete_deduction_clicked
* @Description   a slot function that delete selected deduction record
*                and send request.
* @author        luxijia
* @date          2018-7-9
*/
void DeductionWidget::on_btn_delete_deduction_clicked()
{

    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int count = items.count();

    if (0 == count)
        return;

    int flag = MsgBox::question("注意", "是否确认删除缴费记录,此操作无法撤销!");

    if (flag == MsgBox::NO)
        return;

    CRequest req;
    req.set_action("delete_deduction_record");
    req.set_started_by("delete_deduction_record_in_deduction_widget");

    //get remove supplier id
    QJsonArray delete_deduction;

    int row = -1;

    for (int i = 0; i < count; i++)
    {
        if (row != this->ui->tableWidget->row(items.at(i)))
        {
            row = this->ui->tableWidget->row(items.at(i));
            delete_deduction.append(m_records[row].deduction_id());
        }
    }

    req.put("delete_deduction", delete_deduction);

    Network::send(req);
    m_waiting->start();
}

/**
* @functionName  recv_delete_sale_list
* @Description   a slot function that receive delete sale list request's respone,
*                show whether delete success, and close conncection.
* @author        luxijia
* @date          2018-7-12
* @parameter     resp network response
*/
void DeductionWidget::recv_delete_deduction_record(CResponse &resp)
{
    m_waiting->stop();

    if (StatusCode::DELETE_ERROR == resp.status_code())
    {
        MsgBox::error("失败", "删除缴费记录失败!");
        return;
    }
    else if (StatusCode::ERROR_PARAMS == resp.status_code())
    {
        MsgBox::error("失败", "发送参数出错!");
        return;
    }

    MsgBox::information("成功","删除缴费单成功！");

    search_deduction_record();
}

/**
* @functionName  on_dedit_end_userDateChanged
* @Description   when user change end date deit then end date edit time
*                can't less the start.
* @author        luxijia
* @date          2018-7-13
* @parameter     date end edit change date
*/
void DeductionWidget::on_dedit_end_userDateChanged(const QDate &date)
{
    if (date < this->ui->dedit_start->date())
        this->ui->dedit_end->setDate(this->ui->dedit_start->date());
}

/**
* @functionName  on_dedit_start_userDateChanged
* @Description   when user change start date deit then start date edit time
*                can't more the start.
* @author        luxijia
* @date          2018-7-13
* @parameter     date start edit change date
*/
void DeductionWidget::on_dedit_start_userDateChanged(const QDate &date)
{
    if (date > this->ui->dedit_end->date())
        this->ui->dedit_start->setDate(this->ui->dedit_end->date());
}
