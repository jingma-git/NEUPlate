#ifndef RECHARGE_WIDGET_H
#define RECHARGE_WIDGET_H

#include <QWidget>
#include "UI/msgbox.h"
#include "UI/waitingspinnerwidget.h"
#include "neu_head.h"

namespace Ui {
class RechargeWidget;
}

class RechargeWidget : public QWidget
{
    Q_OBJECT

public:
    explicit RechargeWidget(QWidget *parent = 0);
    ~RechargeWidget();

private slots:
    void recv_charge_payer(CResponse &);

    void on_btn_recharge_clicked();
    void on_btn_cancel_clicked();

private:
    Ui::RechargeWidget *ui;
    WaitingSpinnerWidget *m_waiting;
};

#endif // RECHARGE_WIDGET_H
