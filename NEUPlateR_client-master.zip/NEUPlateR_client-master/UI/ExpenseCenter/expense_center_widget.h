#ifndef EXPENSE_CENTER_WIDGET_H
#define EXPENSE_CENTER_WIDGET_H

#include <QWidget>
#include <QToolButton>
#include "deduction_widget.h"
#include "recharge_widget.h"


namespace Ui {
class ExpenseCenterWidget;
}

class ExpenseCenterWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ExpenseCenterWidget(QWidget *parent = 0);
    ~ExpenseCenterWidget();
    void  init_menu();

private slots:
    void  menu_click();

private:
    Ui::ExpenseCenterWidget *ui;

    QList<int> pixChars;
    QList<QToolButton *> btns;
    DeductionWidget *m_deduction_widget;
    RechargeWidget *m_recharge_widget;

    void  init_widget();

};

#endif // PERSONAL_CENTER_H
