#include "reversal_deduction_dialog.h"
#include "ui_reversal_deduction_dialog.h"

/**
* @name          ReversalDeductionDialog
* @brief         the constructor of class ReversalDeductionDialog that initial the ui interface and class resource.
* @author        luxijia
* @date          2018-08-02
* @param         parent parent widget
* @return        ReversalDeductionDialog
*/
ReversalDeductionDialog::ReversalDeductionDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ReversalDeductionDialog)
{
    ui->setupUi(this);
    setModal(true);
    m_waiting = new WaitingSpinnerWidget(this);

    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    Network::registered("reversal_deduction_record_in_reversal_deduction_dailog", std::bind(&ReversalDeductionDialog::recv_reversal_deduction_record, this, std::placeholders::_1));

    connect(this->ui->btnMenu_Close, SIGNAL(clicked()), this->ui->btn_cancel, SIGNAL(clicked()));
}

/**
* @name          ~ReversalDeductionDialog
* @brief         the deconstructor of class ReversalDeductionDialog that release the class resource.
* @author        luxijia
* @date          2018-08-02
* @return        ReversalDeductionDialog
*/
ReversalDeductionDialog::~ReversalDeductionDialog()
{
    delete ui;
    delete m_waiting;
}

/**
* @name          recv_reversal_deduction
* @brief         receive reversal deduction relative drive record's recognition photo.
* @author        luxijia
* @date          2018-08-03
* @param         start_id the id of start recognition log.
* @param         end_id the id of end recognition log.
* @param         start_photo the start recognition photo.
* @param         end_photo the end_recognition photo.
*/
void ReversalDeductionDialog::recv_reversal_deduction_photo(const QString &deduction_id, const QString &start_id, const QString &end_id,
                                                      const QByteArray &start_photo, const QByteArray &end_photo)
{
    this->m_start_id = start_id;
    this->m_end_id = end_id;
    this->m_start_photo = start_photo;
    this->m_end_photo = end_photo;
    this->m_dedcution_id = deduction_id;
    QByteArray start_byte = QByteArray::fromBase64(start_photo);
    QByteArray end_byte = QByteArray::fromBase64(end_photo);

//    QBuffer start_buffer(&start_byte);
//    QBuffer end_buffer(&end_byte);

//    start_buffer.open(QIODevice::ReadOnly);
//    end_buffer.open(QIODevice::ReadOnly);

//    QImageReader in_img_reader(&start_buffer,"JPG");
//    QImageReader out_img_reader(&end_buffer,"JPG");

//    m_in_img = in_img_reader.read();
//    m_out_img = out_img_reader.read();

    if (start_byte.isEmpty() || end_byte.isEmpty())
    {
        MsgBox::warming("警告","读取图片失败！");
        this->close();
        return;
    }

    QPixmap in;
    QPixmap out;
    in.loadFromData(start_byte);
    out.loadFromData(end_byte);

    this->ui->label_in_image->setPixmap(in);
    this->ui->label_out_image->setPixmap(out);
    this->show();
}

/**
* @name          on_btn_reversal_clicked
* @brief         a slot function that reversal deduction record after clicked reversal button.
* @author        luxijia
* @date          2018-08-03
*/
void ReversalDeductionDialog::on_btn_reversal_clicked()
{
    if (this->ui->ledit_plate->text().isEmpty())
    {
        MsgBox::warming("警告", "没有填写车牌");
        return;
    }

    int flag = MsgBox::question("提示", QString("%1%2").arg("是否确定冲正？人工输入车牌为：").arg(this->ui->ledit_plate->text()));

    if (MsgBox::NO == flag)
        return;

    CRequest req;
    req.set_action("reversal_deduction_record_by_plate");
    req.set_started_by("reversal_deduction_record_in_reversal_deduction_dailog");
    req.put("plate", this->ui->ledit_plate->text());
    req.put("reversal_deduction", m_dedcution_id);
    Network::send(req);
    m_waiting->start();
}

/**
* @name          recv_reversal_deduction_record
* @brief         the slot function that receive reversal deduction record request's response.
* @author        luxijia
* @date          2018-08-03
* @param         resp the request's response.
*/
void ReversalDeductionDialog::recv_reversal_deduction_record(CResponse &resp)
{
    m_waiting->stop();

    if ((StatusCode::INSERT_ERROR == resp.status_code()) || (StatusCode::HAS_REVERSAL == resp.status_code()))
    {
        MsgBox::error("失败", "冲正失败!");
        return;
    }
    else if (StatusCode::INVAILD_REVERSAL == resp.status_code())
    {
        MsgBox::error("失败", "非法冲正!");
        return;
    }
    else if (StatusCode::TIME_OUT_ERROR == resp.status_code())
    {
        MsgBox::error("失败", "冲正超过限定时间!");
        return;
    }
    else if (StatusCode::ERROR_PARAMS == resp.status_code())
    {
        MsgBox::error("失败", "发送参数出错!");
        return;
    }

    MsgBox::information("消息","冲正成功!");

    this->ui->ledit_plate->clear();
    this->ui->label_in_image->clear();
    this->ui->label_out_image->clear();
    emit reversal_deduction_success();
    this->close();
}

/**
* @name          on_btn_reversal_clicked
* @brief         a slot function that reversal deduction record after clicked reversal button.
* @author        luxijia
* @date          2018-08-03
*/
void ReversalDeductionDialog::on_btn_cancel_clicked()
{
    int flag;

    if (!this->ui->ledit_plate->text().isEmpty())
    {
        flag = MsgBox::question("退出","车牌信息未提交，是否退出!");

        if (MsgBox::YES == flag)
        {
            this->ui->ledit_plate->clear();
            this->ui->label_in_image->clear();
            this->ui->label_out_image->clear();
            this->close();
            return;
        }
    }

    this->close();
    return;
}
