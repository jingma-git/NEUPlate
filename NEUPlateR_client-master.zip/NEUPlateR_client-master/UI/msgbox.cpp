#include "msgbox.h"
#include "UI/MyMsgBox/my_msg_box.h"

/**
* @functionName  information
* @Description   show information messagebox
* @author        chenhanlin
* @date          2018-07-07
* @parameter     void
* @return        void
*/
void MsgBox::information(const QString &title, const QString &text)
{
    static MyMsgBox msg;
    static bool init = false;
    if(!init){
        msg.set_icon(":/image/提示_1.png");
        msg.hide_cancel_button();
    }
    msg.set_title(title);
    msg.set_text(text);
    msg.exec();
}
void MsgBox::error(const QString &title, const QString &text)
{
    static MyMsgBox msg;
    static bool init = false;
    if(!init){
        msg.set_icon(":/image/提示.png");
        msg.hide_cancel_button();
    }
    msg.set_title(title);
    msg.set_text(text);
    msg.exec();
}

int MsgBox::question(const QString &title, const QString &text)
{
    static MyMsgBox msg;
    static bool init = false;
    if(!init){
        msg.set_icon(":/image/提示_2.png");
    }
    msg.set_title(title);
    msg.set_text(text);
    if(QDialog::Accepted == msg.exec())
        return MsgBox::YES;
    else
        return MsgBox::NO;
}

void MsgBox::warming(const QString &title, const QString &text)
{
    static MyMsgBox msg;
    static bool init = false;
    if(!init){
        msg.set_icon(":/image/警告.png");
        msg.hide_cancel_button();
    }
    msg.set_title(title);
    msg.set_text(text);
    msg.exec();
}

void MsgBox::success(const QString &title, const QString &text)
{
    static MyMsgBox msg;
    static bool init = false;
    if(!init){
        msg.set_icon(":/image/确认_蓝色.png");
        msg.hide_cancel_button();
    }
    msg.set_title(title);
    msg.set_text(text);
    msg.exec();
}
