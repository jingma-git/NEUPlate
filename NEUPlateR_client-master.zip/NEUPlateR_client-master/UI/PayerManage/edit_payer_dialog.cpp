#include "edit_payer_dialog.h"
#include "ui_edit_payer_dialog.h"




EditPayerDialog::EditPayerDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EditPayerDialog)
{
    ui->setupUi(this);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));

    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    payer_info_widget=new PayerInfoWidget;
    ui->verticalLayout->addWidget(payer_info_widget);
    connect(payer_info_widget,SIGNAL(refresh_payer_query_table()),this,SLOT(refresh_payer_query_table_slot()));
    connect(payer_info_widget,SIGNAL(close_dialog()),this,SLOT(close()));



}

EditPayerDialog::~EditPayerDialog()
{
    delete ui;
    delete payer_info_widget;
}

void EditPayerDialog::init_as_payer_info(CPayer &payer)
{
    payer_info_widget->init_as_payer_info(payer);
}

void EditPayerDialog::refresh_payer_query_table_slot()
{
    emit refresh_payer_query_table();
}

void EditPayerDialog::on_btnMenu_Close_clicked()
{
    close();
}
