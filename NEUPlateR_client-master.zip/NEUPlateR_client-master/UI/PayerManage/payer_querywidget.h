#ifndef PAYER_QUERYWIDGET_H
#define PAYER_QUERYWIDGET_H

#include <QWidget>
#include "Entity/payer.h"
#include "neu_head.h"
#include <QJsonArray>
#include "payer_info_widget.h"
#include <QMenu>
#include "edit_payer_dialog.h"


namespace Ui {
class PayerQueryWidget;
}

class PayerQueryWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PayerQueryWidget(QWidget *parent = 0);
    ~PayerQueryWidget();

private:
    Ui::PayerQueryWidget *ui;
    std::vector<CPayer> payers;

    int current_page;
    int max_pages;
    int page_size;
    QMenu *right_menu;
    QAction *edit_action;
    QAction *delete_action;

    QString keyword;
    QString this_id;

    WaitingSpinnerWidget *wait;

    EditPayerDialog *edit_payer_dialog;



private slots:
    void query_clicked();
    void query_payers();
    void recv_payers(CResponse &resp);
    void refresh_table();
    void refresh_page_bar();
    void change_page(int i);
    void next_page();
    void previous_page();
    void init_menu();
    void edit_clicked();
    void delete_clicked();
    void recv_delete(CResponse &resp);
    void right_menu_action(const QPoint& pos);

};

#endif // PAYER_QUERYWIDGET_H
