#ifndef EDIT_PAYER_DIALOG_H
#define EDIT_PAYER_DIALOG_H
#include "payer_info_widget.h"
#include <QDialog>
#include "UI/iconhelper.h"

namespace Ui {
class EditPayerDialog;
}

class EditPayerDialog : public QDialog
{
    Q_OBJECT

public:
    explicit EditPayerDialog(QWidget *parent = 0);
    ~EditPayerDialog();
    void init_as_payer_info(CPayer &payer );

private slots:
    void on_btnMenu_Close_clicked();
    void refresh_payer_query_table_slot();

signals:
    void refresh_payer_query_table();
private:

    Ui::EditPayerDialog *ui;
    PayerInfoWidget *payer_info_widget;
};

#endif // EDIT_PAYER_DIALOG_H
