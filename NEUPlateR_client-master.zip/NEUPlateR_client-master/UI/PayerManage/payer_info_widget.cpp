#include "payer_info_widget.h"
#include "ui_payer_info_widget.h"

PayerInfoWidget::PayerInfoWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PayerInfoWidget)
{
    ui->setupUi(this);
    this_id=QString::number(int(this));
    wait=new WaitingSpinnerWidget(this);



    ui->ledit_balance->setEnabled(false);
    ui->ledit_id_card->setEnabled(false);
    bundle_car_dialog=nullptr;
    ui->dedit_birthday->setDate(QDate::fromString("1997-07-10","yyyy-MM-dd"));



    connect(ui->btn_save,SIGNAL(clicked()),this,SLOT(save_click()));
    connect(ui->btn_cancel,SIGNAL(clicked()),this,SLOT(cancel_click()));
    connect(ui->btn_add_car,SIGNAL(clicked()),this,SLOT(add_car_click()));
    connect(ui->btn_edit,SIGNAL(clicked()),this,SLOT(edit_click()));

    Network::registered("payer_info_update_payer"+this_id, std::bind(&PayerInfoWidget::recv_result, this, std::placeholders::_1));
    Network::registered("payer_info_add_payer"+this_id, std::bind(&PayerInfoWidget::recv_result, this, std::placeholders::_1));
    Network::registered("payer_info_bundle_car"+this_id, std::bind(&PayerInfoWidget::bundle_recv, this, std::placeholders::_1));
    Network::registered("payer_info_unbundle_car"+this_id, std::bind(&PayerInfoWidget::unbundle_recv, this, std::placeholders::_1));
    Network::registered("payer_info_get_car"+this_id, std::bind(&PayerInfoWidget::recv_cars, this, std::placeholders::_1));

    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);  //只能选择单行

    init_menu();
    refresh_cars_table();

    QRegExp id("(^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$)|(^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}$)");
    QRegExpValidator *pid = new QRegExpValidator(id, this);
    ui->ledit_id_card->setValidator(pid);

    QRegExp phone("^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$");
    QRegExpValidator *pphone = new QRegExpValidator(phone, this);
    ui->ledit_tel->setValidator(pphone);

    setTabOrder(ui->ledit_username, ui->ledit_id_card);
    setTabOrder(ui->ledit_id_card, ui->ledit_name);
    setTabOrder(ui->ledit_name, ui->cmb_gender);
    setTabOrder(ui->cmb_gender, ui->ledit_tel);
    setTabOrder(ui->ledit_tel, ui->dedit_birthday);


    connect(ui->ledit_id_card,SIGNAL(editingFinished()),this,SLOT(parse_id_card()));
}

PayerInfoWidget::~PayerInfoWidget()
{
    delete ui;
    delete wait;

    delete unbundle_action;
}

void PayerInfoWidget::init_as_add_payer()
{
    //设置为空的框可以编辑
    this->setWindowTitle("注册缴费人");
    switch_to_edit_mode(true);

    ui->ledit_id_card->setEnabled(true);
    ui->ledit_username->setEnabled(true);


    ui->btn_cancel->setVisible(true);
    ui->btn_save->setVisible(true);
    ui->btn_edit->setVisible(false);
    ui->frame_cars->setVisible(true);
    ui->btn_cancel->setText("重置");
    is_add=true;

//    ui->frame_cars->setVisible(false);
    ui->frame_cars->hide();
    ui->frame_balance->hide();
//    delete ui->frame_cars;
}

void PayerInfoWidget::init_as_payer_info(const CPayer &payer)
{
    //把传入的payer的信息显示
    this->setWindowTitle("缴费人信息");
    this->payer=payer;
    ui->ledit_id_card->setEnabled(false);
    ui->ledit_username->setEnabled(false);
    switch_to_edit_mode(false);
    show_payer_info();

    ui->frame_cars->setVisible(true);
    is_add=false;
    get_cars();
}

void PayerInfoWidget::show_payer_info()
{
    //将payer中的内容显示到空里
    ui->ledit_name->setText(payer.name());
    ui->ledit_username->setText(payer.username());
    ui->ledit_id_card->setText(payer.id_card());
    ui->ledit_balance->setText(QString::number(payer.balance()));
    ui->ledit_tel->setText(payer.tel());
    ui->dedit_birthday->setDate(QDate::fromString(payer.birthday(),"yyyy-MM-dd"));
    ui->cmb_gender->setCurrentIndex(payer.gender());
}


void PayerInfoWidget::parse_id_card()
{
    QString id_card=ui->ledit_id_card->text();
    QRegExp id_card_reg("(^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$)|(^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}$)");
    if(id_card_reg.exactMatch(id_card)){
        int gender=(id_card.mid(16,1).toInt()+1)%2;
        ui->cmb_gender->setCurrentIndex(gender);
        QString birthday=id_card.mid(6,4)+"-"+id_card.mid(10,2)+"-"+id_card.mid(12,2);
        ui->dedit_birthday->setDate(QDate::fromString(birthday,"yyyy-MM-dd"));
    }

}

void PayerInfoWidget::switch_to_edit_mode(bool flag)
{

    ui->ledit_name->setEnabled(flag);
    ui->ledit_tel->setEnabled(flag);
    ui->cmb_gender->setEnabled(flag);
    ui->dedit_birthday->setEnabled(flag);
    if(is_add==true){
        ui->ledit_id_card->setEnabled(flag);
    }

    ui->btn_cancel->setVisible(flag);
    ui->btn_save->setVisible(flag);
    ui->btn_edit->setVisible(!flag);
    ui->btn_add_car->setVisible(flag);

}

void PayerInfoWidget::get_payer_info_from_ui()
{
    payer.setBalance(ui->ledit_balance->text().toDouble());
    payer.setBirthday(ui->dedit_birthday->date().toString("yyyy-MM-dd"));
    payer.setGender(ui->cmb_gender->currentIndex());
    payer.setId_card(ui->ledit_id_card->text());
    payer.setName(ui->ledit_name->text());
    payer.setTel(ui->ledit_tel->text());
    payer.setUsername(ui->ledit_username->text());
    //    payer.setPhoto();
}

void PayerInfoWidget::add_payer()
{
    qDebug()<<"add payer";
    CRequest req;
    req.set_action("add_payer");
    req.put("payer",payer.toJSON());
    req.set_started_by("payer_info_add_payer"+this_id);
    Network::send(req);
    wait->start();
}

void PayerInfoWidget::update_payer()
{

    qDebug()<<"update payer";
    CRequest req;
    req.set_action("update_payer");
    req.put("payer",payer.toJSON());
    req.set_started_by("payer_info_update_payer"+this_id);
    Network::send(req);
    wait->start();
}

void PayerInfoWidget::recv_result(CResponse &resp)
{
    int status_code=resp.status_code();
    wait->stop();
    if(StatusCode::SUCCESS==status_code){
        qDebug()<<"is_add:"<<is_add;
        if(is_add==true){
            MsgBox::success("缴费人管理","注册缴费人成功");
            cars.clear();
            //清空输入框
            ui->ledit_name->clear();
            ui->ledit_tel->clear();
            ui->ledit_username->clear();
            ui->ledit_id_card->clear();
            ui->cmb_gender->setCurrentIndex(0);
            ui->dedit_birthday->setDate(QDate::fromString("1997-07-10","yyyy-MM-dd"));

        }else{
            MsgBox::success("缴费人管理","修改缴费人信息成功");
            cars.clear();
            emit refresh_payer_query_table(); //刷新query payer的表格
            emit close_dialog();
        }

    }else if(StatusCode::SQL_EXEC_ERROR){
        if(is_add==true){
            MsgBox::success("缴费人管理","注册缴费人失败");
        }else{
            MsgBox::success("缴费人管理","修改缴费人信息失败");
        }

    }
}


void PayerInfoWidget::clear_content()
{
    ui->ledit_balance->clear();
    ui->ledit_id_card->clear();
    ui->ledit_name->clear();
    ui->ledit_tel->clear();
    ui->ledit_username->clear();

    ui->dedit_birthday->setDate(QDate::fromString("1997-07-10","yyyy-MM-dd"));
    ui->cmb_gender->setCurrentIndex(0);



    cars.clear();
    payer=CPayer();
    refresh_cars_table();
}

void PayerInfoWidget::init_menu()
{

    right_menu=new QMenu(ui->tableWidget);
    unbundle_action=new QAction(this);
    unbundle_action->setText("解绑车辆");
    right_menu->addAction(unbundle_action);
    connect(unbundle_action,SIGNAL(triggered()),this,SLOT(unbundle_click()));
    connect(this->ui->tableWidget, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(right_menu_action(const QPoint&)));

}

void PayerInfoWidget::right_menu_action(const QPoint &pos)
{
    right_menu->exec(QCursor::pos());
}



void PayerInfoWidget::save_click()
{
    get_payer_info_from_ui();
    if(payer.name()==""||payer.username()==""){
        MsgBox::error("缴费人管理","字段填写不能为空");
        return;
    }
    QRegExp id_check("(^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$)|(^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}$)");
    QRegExp phone_check("^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$");
    if(!id_check.exactMatch(payer.id_card())){
        MsgBox::information("添加缴费人","请输入正确的身份证号");
        return;
    }
    if(!phone_check.exactMatch(payer.tel())){
        MsgBox::information("添加缴费人","请输入正确的电话号码");
        return;
    }
    if(is_add==true){
        add_payer();
    }else{
        update_payer();
    }
}

void PayerInfoWidget::edit_click()
{
    switch_to_edit_mode(true);

}



void PayerInfoWidget::cancel_click()
{
    if(is_add){
        clear_content();
    }else{
       switch_to_edit_mode(false);
    }
}

void PayerInfoWidget::add_car_click()
{
    //弹出一个框输入车牌
    delete bundle_car_dialog;
    bundle_car_dialog=nullptr;
    bundle_car_dialog=new BundleCarDialog;

    bundle_car_dialog->setModal(true);
    connect(bundle_car_dialog,SIGNAL(bundel_car(CCar)),this,SLOT(bundle_car(CCar)));
    bundle_car_dialog->show();
}


void PayerInfoWidget::get_cars()
{
    CRequest req;
    req.set_action("query_cars_by_payer");
    req.put("payer_id",payer.payer_id());
    req.set_started_by("payer_info_get_car"+this_id);
    Network::send(req);
    wait->start();

}

void PayerInfoWidget::recv_cars(CResponse &resp)
{
    int status_code=resp.status_code();
    wait->stop();
    cars.clear();
    if(StatusCode::SUCCESS==status_code){
        QJsonArray cars_json=resp.get_array("cars");
        foreach (const QJsonValue &car_json, cars_json) {
            CCar tmp_car=CCar(car_json.toObject());
            this->cars.push_back(tmp_car);
        }
        refresh_cars_table();

    }else if(StatusCode::SQL_EXEC_ERROR==status_code){
        MsgBox::error("车辆信息","查询失败");
    }
}

void PayerInfoWidget::refresh_cars_table()
{
    QTableWidget &table= *(ui->tableWidget);
    while (table.rowCount()!=0) {
        table.removeRow(0);
    }


    ui->tableWidget->insertRow(0);
    unsigned int cars_len=this->cars.size();

    table.clearContents();
    for(unsigned int i=0;i<cars_len;i++){
        CCar &c=cars.at(i);
        if(i!=0){
            table.insertRow(i);
        }
        table.setItem(i,0,new QTableWidgetItem(c.plate()));
        table.item(i,0)->setTextAlignment(Qt::AlignCenter);
        table.setItem(i,1,new QTableWidgetItem(c.color()));
        table.item(i,1)->setTextAlignment(Qt::AlignCenter);
        table.setItem(i,2,new QTableWidgetItem(c.get_model_string()));
        table.item(i,2)->setTextAlignment(Qt::AlignCenter);
        table.setItem(i,3,new QTableWidgetItem(c.get_type_string()));
        table.item(i,3)->setTextAlignment(Qt::AlignCenter);
    }
}

void PayerInfoWidget::bundle_car(CCar car)
{
    if(payer.payer_id()==""){
        cars.push_back(car);
        refresh_cars_table();
    }else{
        CRequest req;
        req.set_action("bundle_car");
        req.put("car_id",car.car_id());
        req.put("payer_id",payer.payer_id());
        req.set_started_by("payer_info_bundle_car"+this_id);
        Network::send(req);
        wait->start();
    }
}


void PayerInfoWidget::bundle_recv(CResponse &resp)
{
    int status_code=resp.status_code();
    wait->stop();
    if(StatusCode::SUCCESS==status_code){
        get_cars();

    }else if(StatusCode::SQL_EXEC_ERROR==status_code){
        MsgBox::error("车辆绑定","绑定失败");

    }

}

void PayerInfoWidget::unbundle_click()
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int row=ui->tableWidget->row(items.at(0));
    QString car_id=cars.at(row).car_id();

    if(payer.payer_id()==""){
        std::vector<CCar>::iterator it=cars.begin()+row;
        cars.erase(it);
        refresh_cars_table();

    }else{
        CRequest req;
        req.set_action("unbundle_car");
        req.put("car_id",car_id);
        req.set_started_by("payer_info_unbundle_car"+this_id);
        Network::send(req);
        wait->start();
    }

}

void PayerInfoWidget::unbundle_recv(CResponse &resp)
{
    int status_code=resp.status_code();
    wait->stop();
    if(StatusCode::SUCCESS==status_code){
        get_cars();
    }else if(StatusCode::SQL_EXEC_ERROR==status_code){
        MsgBox::error("车辆绑定","解绑失败");

    }
}





