#ifndef PAYER_INFO_H
#define PAYER_INFO_H

#include <QWidget>
#include "Entity/payer.h"
#include "neu_head.h"
#include "bundle_car_dialog.h"
#include <QMenu>
#include <QJsonArray>

/**
todo:
发送和接收绑定；

**/

namespace Ui {
class PayerInfoWidget;
}

class PayerInfoWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PayerInfoWidget(QWidget *parent = 0);
    ~PayerInfoWidget();

    void init_as_add_payer();

    void init_as_payer_info(const CPayer &payer);

signals:
    void refresh_payer_query_table();
    void close_dialog();

private:
    void show_payer_info();

    void switch_to_edit_mode(bool flag);

    void get_payer_info_from_ui();


    void recv_result(CResponse &resp);

    void add_payer();
    void update_payer();
    void init_menu();
    void unbundle_recv(CResponse &resp);
    void bundle_recv(CResponse &resp);
    void get_cars();
    void recv_cars(CResponse &resp);
    void refresh_cars_table();
    void clear_content();

private slots:
    void unbundle_click();
    void save_click();
    void edit_click();
    void cancel_click();
    void add_car_click();
    void bundle_car(CCar car);
    void right_menu_action(const QPoint& pos);
    void parse_id_card();



private:
    Ui::PayerInfoWidget *ui;
    bool is_add;
    QString this_id;
    WaitingSpinnerWidget *wait;
    BundleCarDialog *bundle_car_dialog;
    std::vector<CCar> cars;  //注意清空里面的内容
    QMenu *right_menu;
    QAction *unbundle_action;

    CPayer payer;
};

#endif // PAYER_INFO_H
