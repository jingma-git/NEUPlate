#ifndef BUNDLE_CAR_DIALOG_H
#define BUNDLE_CAR_DIALOG_H

#include <QDialog>
#include "neu_head.h"
#include "Entity/car.h"
#include <functional>
#include "UI/iconhelper.h"
namespace Ui {
class BundleCarDialog;
}

class BundleCarDialog : public QDialog
{
    Q_OBJECT

public:
    explicit BundleCarDialog(QWidget *parent = 0);
    ~BundleCarDialog();

private:
    Ui::BundleCarDialog *ui;
    CCar car;
    bool is_selete;
    QString this_id;
    WaitingSpinnerWidget *wait;
signals:
    void bundel_car(CCar car);


private slots:
    void query_click();
    void cancel_click();
    void confirm_click();
    void recv_car(CResponse &resp);
    void show_car_info();


    void on_btnMenu_Close_clicked();
};

#endif // BUNDLE_CAR_DIALOG_H
