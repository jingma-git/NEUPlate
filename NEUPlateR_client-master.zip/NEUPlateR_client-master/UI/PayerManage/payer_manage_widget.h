#ifndef PAYER_MANAGE_WIDGET_H
#define PAYER_MANAGE_WIDGET_H

#include <QWidget>
#include <QToolButton>
#include "payer_info_widget.h"
#include "payer_querywidget.h"

namespace Ui {
class PayerManageWidget;
}

class PayerManageWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PayerManageWidget(QWidget *parent = 0);
    ~PayerManageWidget();
    void  init_menu();

private slots:
    void  menu_click();

private:
    Ui::PayerManageWidget *ui;

    QList<int> pixChars;
    QList<QToolButton *> btns;

    PayerInfoWidget *payer_info_widget;
    PayerQueryWidget *payer_query_widget;


    void  init_widget();

};

#endif // PERSONAL_CENTER_H
