#include "payer_manage_widget.h"
#include "ui_payer_manage_widget.h"
#include "UI/iconhelper.h"

PayerManageWidget::PayerManageWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PayerManageWidget)
{

    this->payer_query_widget=new PayerQueryWidget();
    this->payer_info_widget=new PayerInfoWidget();
    this->payer_info_widget->init_as_add_payer();
    ui->setupUi(this);
    this->init_menu();
    this->init_widget();

}


void PayerManageWidget::init_menu(){
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf031 << 0xf036 ;
    btns<<ui->btnQuery<<ui->btnPayerInfo;

    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btnQuery->click();
}


void PayerManageWidget::init_widget(){
    ui->stackedWidget->addWidget(payer_query_widget);
    ui->stackedWidget->addWidget(payer_info_widget);
}


void PayerManageWidget::menu_click(){

    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);


    if(b==ui->btnQuery){
        ui->stackedWidget->setCurrentIndex(0);
    }else if(b==ui->btnPayerInfo){
        ui->stackedWidget->setCurrentIndex(1);
    }
}

PayerManageWidget::~PayerManageWidget()
{
    delete ui;
    delete payer_info_widget;
    delete payer_query_widget;
}
