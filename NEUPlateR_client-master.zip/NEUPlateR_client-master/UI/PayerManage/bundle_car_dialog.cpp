#include "bundle_car_dialog.h"
#include "ui_bundle_car_dialog.h"

BundleCarDialog::BundleCarDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::BundleCarDialog)
{
    ui->setupUi(this);
    this_id=QString::number(int(this));
    wait=new WaitingSpinnerWidget(this);


    ui->label_color_content->clear();
    ui->label_modle_content->clear();
    ui->label_plate_content->clear();
    ui->label_type_content->clear();
    this->setWindowFlags(Qt::FramelessWindowHint);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));

    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);


    QRegExp regRxp("^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1}");
    ui->ledit_plate->setValidator(new QRegExpValidator(regRxp,this));


    connect(ui->btn_cancel,SIGNAL(clicked()),this,SLOT(cancel_click()));
    connect(ui->btn_confirm,SIGNAL(clicked()),this,SLOT(confirm_click()));
    connect(ui->btn_query,SIGNAL(clicked()),this,SLOT(query_click()));
    Network::registered("bundel_car_query_car"+this_id, std::bind(&BundleCarDialog::recv_car, this, std::placeholders::_1));
}

BundleCarDialog::~BundleCarDialog()
{
    delete ui;
    delete wait;
}

void BundleCarDialog::query_click()
{
    if(ui->ledit_plate->text()==""){
        MsgBox::warming("绑定车辆","请输入车牌");
    }
    CRequest req;
    req.set_action("query_car_by_plate");
    req.put("plate",ui->ledit_plate->text().toUpper());
    req.set_started_by("bundel_car_query_car"+this_id);
    Network::send(req);
    wait->start();

}

void BundleCarDialog::cancel_click()
{
    close();
}

void BundleCarDialog::confirm_click()
{
    qDebug()<<"confirm: plate:"<<car.plate();
    if(car.plate()==""){
        MsgBox::information("绑定车辆","请先选择一辆车");
        return;
    }
    int result=MsgBox::question("绑定车辆","确定绑定这车辆"+car.plate()+"?");
    if(result==MsgBox::YES){
        emit bundel_car(car);
        close();
    }else{
        return;
    }

}

void BundleCarDialog::recv_car(CResponse &resp)
{

    wait->stop();
    if(StatusCode::SUCCESS==resp.status_code()){
        QJsonObject car_json=resp.get_json("car");
        if(car_json.value("payer_id")!=""){
            MsgBox::information("绑定车辆","此车辆已被其他用户绑定,请尝试选择其他车辆");
            return;
        }
        car=CCar(car_json);
        show_car_info();
    }else if(StatusCode::EMPTY_QUERY==resp.status_code()){
        MsgBox::information("绑定车辆","未查到此车，请检查车牌号");
        return;
    }else if(StatusCode::SQL_EXEC_ERROR==resp.status_code()){
        MsgBox::information("绑定车辆","查询错误");
        return;
    }

}

void BundleCarDialog::show_car_info()
{
    ui->label_color_content->setText(car.color());
    ui->label_modle_content->setText(car.get_model_string());
    ui->label_plate_content->setText(car.plate());
    ui->label_type_content->setText(car.get_type_string());
}

void BundleCarDialog::on_btnMenu_Close_clicked()
{
    close();
}
