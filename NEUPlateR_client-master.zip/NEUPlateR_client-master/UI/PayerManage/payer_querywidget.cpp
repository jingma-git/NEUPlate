#include "payer_querywidget.h"
#include "ui_payer_querywidget.h"
#include "login_user.h"

PayerQueryWidget::PayerQueryWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PayerQueryWidget)
{
    ui->setupUi(this);
    edit_payer_dialog=nullptr;
    this_id=QString::number(int(this));

    wait=new WaitingSpinnerWidget(this);

    current_page=1;
    max_pages=1;
    page_size=10;
    connect(ui->btn_query,SIGNAL(clicked()),this,SLOT(query_clicked()));
    connect(ui->btn_previous_page,SIGNAL(clicked()),this,SLOT(previous_page()));
    connect(ui->btn_next_page,SIGNAL(clicked()),this,SLOT(next_page()));
    connect(ui->cmb_page,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));


    connect(ui->ledit_keyword,SIGNAL(returnPressed()),this,SLOT(query_clicked()));

    Network::registered("query_payers_query_payers"+this_id,std::bind(&PayerQueryWidget::recv_payers, this, std::placeholders::_1));
    Network::registered("query_payers_delete_payer"+this_id,std::bind(&PayerQueryWidget::recv_delete, this, std::placeholders::_1));


    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setShowGrid(false);
//    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);

    init_menu();
    query_clicked();

}

PayerQueryWidget::~PayerQueryWidget()
{
    delete ui;
    delete right_menu;

    delete edit_action;
    delete delete_action;
    delete wait;

}

void PayerQueryWidget::query_clicked()
{
    keyword=ui->ledit_keyword->text();
    current_page=1;
    max_pages=1;
    query_payers();
}

void PayerQueryWidget::query_payers()
{
    CRequest req;
    req.set_action("query_payers");
    req.put("keyword",keyword);
    req.put("page",current_page);
    req.put("page_size",page_size);
    req.set_started_by("query_payers_query_payers"+this_id);
    Network::send(req);
    wait->start();
}

void PayerQueryWidget::recv_payers(CResponse &resp)
{
    qDebug()<<"status code:"<<resp.status_code();
    wait->stop();

    QJsonArray payers_json=resp.get_array("payers");
    if(resp.status_code()==StatusCode::SUCCESS){
        this->payers.clear();
        foreach (const QJsonValue &payer_json, payers_json) {
            CPayer tmp_payer=CPayer(payer_json.toObject());
            this->payers.push_back(tmp_payer);
        }
        max_pages=resp.get_int("all_pages");
        refresh_page_bar();
        refresh_table();

    }else if(resp.status_code()==StatusCode::EMPTY_QUERY){
        this->payers.clear();
        max_pages=1;
        refresh_page_bar();
        refresh_table();

    }else if(resp.status_code()==StatusCode::SQL_EXEC_ERROR){
        MsgBox::error("查询缴费人","系统错误");
    }


}

void PayerQueryWidget::refresh_table()
{

    QTableWidget &table= *(ui->tableWidget);
    while (table.rowCount()!=0) {
        table.removeRow(0);
    }
       ui->tableWidget->insertRow(0);
    unsigned int payers_len=this->payers.size();
    for(unsigned int i=0;i<payers_len;i++){
        if(i!=0){
            table.insertRow(i);
        }
        CPayer &p=payers.at(i);
        table.setItem(i,0,new QTableWidgetItem(p.name()));
        table.item(i,0)->setTextAlignment(Qt::AlignCenter);
        table.setItem(i,1,new QTableWidgetItem(p.username()));
        table.item(i,1)->setTextAlignment(Qt::AlignCenter);
        table.setItem(i,2,new QTableWidgetItem((p.gender()==0?"男":"女")));
        table.item(i,2)->setTextAlignment(Qt::AlignCenter);
        table.setItem(i,3,new QTableWidgetItem(p.id_card()));
        table.item(i,3)->setTextAlignment(Qt::AlignCenter);
        table.setItem(i,4,new QTableWidgetItem(QString::number(p.balance(),'f',2)));
        table.resizeColumnToContents(3);
        table.item(i,4)->setTextAlignment(Qt::AlignCenter);
        }
}

void PayerQueryWidget::refresh_page_bar()
{
    disconnect(ui->cmb_page,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));
       ui->btn_previous_page->setEnabled(!(current_page==1));
       ui->btn_next_page->setEnabled(!(current_page==max_pages));
       ui->cmb_page->clear();

       for(int i=0;i<max_pages;i++){
           ui->cmb_page->insertItem(i,QString("第%1页").arg(i+1));
       }
       ui->cmb_page->setCurrentIndex(current_page-1);
       connect(ui->cmb_page,SIGNAL(currentIndexChanged(int)),this,SLOT(change_page(int)));

}

void PayerQueryWidget::change_page(int i)
{
    current_page=i+1;
    query_payers();
}

void PayerQueryWidget::next_page()
{
change_page(current_page-1+1);
}

void PayerQueryWidget::previous_page()
{
 change_page(current_page-1-1);
}

void PayerQueryWidget::init_menu()
{
    right_menu=new QMenu(ui->tableWidget);

        edit_action=new QAction(this);
        delete_action=new QAction(this);

        edit_action->setText("查看详情");

        right_menu->addAction(edit_action);

        connect(edit_action,SIGNAL(triggered()),this,SLOT(edit_clicked()));
        if(LoginUser::get_instance().access_level() > 2){
            delete_action->setText("删除缴费人");
            right_menu->addAction(delete_action);
            connect(delete_action,SIGNAL(triggered()),this,SLOT(delete_clicked()));
        }

        connect(this->ui->tableWidget, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(right_menu_action(const QPoint&)));


}

void PayerQueryWidget::edit_clicked()
{
    QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
    int row=ui->tableWidget->row(items.at(0));

    delete edit_payer_dialog;
    edit_payer_dialog=nullptr;

    edit_payer_dialog=new EditPayerDialog;

    edit_payer_dialog->init_as_payer_info(payers.at(row));
    connect(edit_payer_dialog,SIGNAL(refresh_payer_query_table()),this,SLOT(query_clicked()));

    edit_payer_dialog->setModal(true);

    edit_payer_dialog->show();
}

void PayerQueryWidget::delete_clicked()
{
    int result= MsgBox::question("缴费人管理","删除操作不可逆。确认删除？\n删除之后，相关车辆将自动解绑");
    if(result==MsgBox::YES){
        QList<QTableWidgetItem*> items = this->ui->tableWidget->selectedItems();
        int row=ui->tableWidget->row(items.at(0));

        CRequest req;
        req.set_action("delete_payer");
        req.put("payer_id",payers.at(row).payer_id());
        req.set_started_by("query_payers_delete_payer"+this_id);
        Network::send(req);
        wait->start();
    }else{

    }
}

void PayerQueryWidget::recv_delete(CResponse &resp)
{
    int status_code=resp.status_code();
    if(status_code==StatusCode::SUCCESS){
        MsgBox::information("缴费人管理","删除缴费人成功");
        query_payers();

    }else{
        MsgBox::error("缴费人管理","删除缴费人失败");
    }


}

void PayerQueryWidget::right_menu_action(const QPoint &pos)
{
    right_menu->exec(QCursor::pos());
}



