#include "cut_photo_dialog.h"
#include "ui_cutphotodialog.h"
#include <QByteArray>
#include <QBuffer>
#include <QImage>
#include <QDebug>

CutPhotoDialog::CutPhotoDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CutPhotoDialog)
{
    ui->setupUi(this);
    this->InitializeUI();
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
//    picture_cut = new PicturePreviewPanel(ui->widget);
//    ui->verticalLayout_2->addWidget(picture_cut);
    ui->btn_submit->setProperty("btn_color", "green");
}

CutPhotoDialog::~CutPhotoDialog()
{
    delete ui;
}

void CutPhotoDialog::load_photo(const QString &photo_path)
{
    m_PicturePath = photo_path;

    LoadPicture_p();
}

bool CutPhotoDialog::eventFilter(QObject *watched, QEvent *event)
{
    if (watched == ui->photo)
    {
        if (event->type() == QEvent::Resize)
        {
            LoadPicture_p();
            if (m_BgWidget)
            {
                m_BgWidget->resize(picture1.size());
                int x = ui->photo->width() - picture1.width();
                x /= 2;
                int y = ui->photo->height() - picture1.height();
                y /= 2;
                m_BgWidget->move(x, y);
            }
        }
    }
    return QWidget::eventFilter(watched, event);
}

void CutPhotoDialog::on_btn_submit_clicked()
{
    QPixmap pic(picture1.copy(m_BgWidget->PictureSaveFinished()));
    QByteArray data;
    QBuffer buf(&data);
    buf.open(QIODevice::WriteOnly);
    pic.save(&buf, "jpg");

    emit notify_data(data);
    emit notify_pixmap(pic);
    close();
}

void CutPhotoDialog::LoadPicture_p()
{
    QPixmap picture;

    picture.load(m_PicturePath);
    if (!picture.isNull())
    {
        picture = picture.scaled(ui->photo->width(), ui->photo->height(), Qt::KeepAspectRatio, Qt::SmoothTransformation);
//        picture = picture.scaled(m_PictureContainer->width(), m_PictureContainer->height());
        ui->photo->setPixmap(picture);
//        m_PictureContainer->resize(picture.size());
        m_BgWidget->PictureLoadFinished();
    }
    picture1=picture;
}

void CutPhotoDialog::InitializeUI()
{
//    ui->photo->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);

    ui->photo->installEventFilter(this);

    ui->photo->setAlignment(Qt::AlignCenter | Qt::AlignVCenter);

    m_BgWidget = new BackgroundWidget(ui->photo, Round);
    m_BgWidget->show();
}
