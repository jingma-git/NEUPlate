#ifndef CUT_PHOTO_DIALOG_H
#define CUT_PHOTO_DIALOG_H

#include <QDialog>
#include <QPixmap>
#include "picturepreviewpanel.h"

namespace Ui {
class CutPhotoDialog;
}

class CutPhotoDialog : public QDialog
{
    Q_OBJECT

public:
    explicit CutPhotoDialog(QWidget *parent = 0);
    ~CutPhotoDialog();

    void load_photo(const QString &photo_path);

protected:
    bool eventFilter(QObject *, QEvent *);

private slots:
    void on_btn_submit_clicked();

private:
    Ui::CutPhotoDialog *ui;
    QPixmap picture1;
    QString m_PicturePath;
    BackgroundWidget * m_BgWidget = nullptr;
private:
    void LoadPicture_p();
    void InitializeUI();

signals:
    void notify_data(QByteArray);
    void notify_pixmap(QPixmap);
};

#endif // CUT_PHOTO_DIALOG_H
