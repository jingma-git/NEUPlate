#include "forget_passwd_dialog.h"
#include "ui_forget_passwd_dialog.h"
#include "UI/iconhelper.h"
#include <QJsonObject>
#include <QStringList>
#include <functional>

/**
* @functionName  Forget_passwd
* @Description   contructor, it will init some feature and icon
* @author        chenhanlin
* @date          2018-07-08
* @parameter     QWidget *parent
* @return        void
*/
ForgetPasswdDialog::ForgetPasswdDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ForgetPasswdDialog)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->ui->stackedWidget->setCurrentIndex(0);

    Network::registered("query_employee_question_in_find_passwd", std::bind(&ForgetPasswdDialog::handle_query_question, this, std::placeholders::_1));
    Network::registered("find_passwd_in_find_passwd", std::bind(&ForgetPasswdDialog::handle_find_passwd, this, std::placeholders::_1));
}

ForgetPasswdDialog::~ForgetPasswdDialog()
{
    delete ui;
    delete wait;
}

/**
* @functionName  on_btnMenu_Close_clicked
* @Description   close this window
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void ForgetPasswdDialog::on_btnMenu_Close_clicked()
{
    close();
}

/**
* @functionName  handle_query_question
* @Description   proccess response from query employee question request
* @author        chenhanlin
* @date          2018-07-08
* @parameter     CResponse &resp
* @return        void
*/
void ForgetPasswdDialog::handle_query_question(CResponse &resp)
{
    wait->stop();

    // check status code
    if (StatusCode::NEW_EMPLOYEE == resp.status_code()){
        MsgBox::information(tr("找回密码"), tr("请先初始化用户"));
        return;
    }

    if(StatusCode::SYSTEM_ERROR == resp.status_code()){
        MsgBox::information(tr("找回密码"), tr("系统错误，请稍后再试"));
        return;
    }

    // get question
    QJsonObject questions(resp.get_json("questions"));
    for(const auto &key : questions.keys()){
        QString question(questions[key].toString());
        this->question_table.insert(std::map<QString, QString>::value_type(question, key));
        this->ui->cmb_questions->addItem(question);
    }
    // jump page
    ui->stackedWidget->setCurrentIndex(1);
}

/**
* @functionName  handle_find_passwd
* @Description   when find_passwd's response arrive, it will show some message
* @author        chenhanlin
* @date          2018-07-08
* @parameter     Response resp
* @return        void
*/
void ForgetPasswdDialog::handle_find_passwd(CResponse &resp)
{
    wait->stop();
    switch (resp.status_code()) {
    case StatusCode::SUCCESS:
        MsgBox::success(tr("找回密码"), tr("密码修改成功"));
        accept();
        reset();
        break;
    case StatusCode::WRONG_ANSWER:
        MsgBox::information(tr("找回密码"), tr("密保问题回答错误"));
        break;
    default:
        MsgBox::warming(tr("找回密码"), tr("系统错误，请稍后再试"));
        break;
    }
}

void ForgetPasswdDialog::reset()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->ledt_username->clear();
    ui->ledt_answer->clear();
    ui->ledt_new_passwd->clear();
    ui->ledt_passwd_confirm->clear();
    ui->cmb_questions->clear();
    ui->cmb_questions->addItem(tr("选择密保问题"));
}

void ForgetPasswdDialog::on_btn_cancel_find_clicked()
{
    close();
    reset();
}

void ForgetPasswdDialog::on_btn_confirm_username_clicked()
{
    QString username(this->ui->ledt_username->text());
    if(username.isEmpty()){
        MsgBox::information(tr("找回密码"), tr("请输入用户名"));
        return;
    }
    CRequest req;
    req.set_action("query_employee_question");
    req.set_started_by("query_employee_question_in_find_passwd");
    req.put("username", username);
    Network::send(req);
    wait->start();
}

void ForgetPasswdDialog::on_btn_back_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void ForgetPasswdDialog::on_btn_submit_clicked()
{
    // get input
    QString new_passwd(this->ui->ledt_new_passwd->text());
    QString new_passwd_confirm(this->ui->ledt_passwd_confirm->text());
    QString answer(this->ui->ledt_answer->text());
    QString question(this->ui->cmb_questions->currentText());
    QString username(ui->ledt_username->text());
    auto iter = question_table.find(question);
    // check input
    if(question_table.end() == iter){
        MsgBox::information(tr("找回密码"), tr("请选择密保问题"));
        return;
    }
    if (answer.isEmpty()){
        MsgBox::information(tr("找回密码"), tr("请输入回答"));
        return;
    }
    if(new_passwd.isEmpty() || new_passwd_confirm.isEmpty()){
        MsgBox::information(tr("找回密码"), tr("请输入新密码"));
        return;
    }
    if (new_passwd != new_passwd_confirm){
        MsgBox::information(tr("找回密码"), tr("两次输入的密码不一致"));
        return;
    }
    // build request
    CRequest req;
    req.set_action("find_passwd");
    req.set_started_by("find_passwd_in_find_passwd");
    req.put("username", username);
    req.put("q_id", iter->second);
    req.put("answer", answer);
    req.put("passwd", new_passwd);
    // build connect signal and function
    Network::send(req);
    wait->start();
}
