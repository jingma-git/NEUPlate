#include "userinitdialog.h"
#include "ui_userinitdialog.h"
#include "UI/iconhelper.h"
#include <QJsonObject>

UserInitDialog::UserInitDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UserInitDialog)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    Network::registered("query_questions_in_init", std::bind(&UserInitDialog::handle_query_question, this, std::placeholders::_1));
    Network::registered("init_employee_in_init", std::bind(&UserInitDialog::handle_init, this, std::placeholders::_1));
}

UserInitDialog::~UserInitDialog()
{
    delete ui;
    delete wait;
}

void UserInitDialog::on_btnMenu_Close_clicked()
{
    close();
    reset();
}

void UserInitDialog::on_btn_submit_clicked()
{
    if(0 == this->ui->cmb_questions1->currentIndex() || 0 == this->ui->cmb_questions2->currentIndex() || 0 == this->ui->cmb_questions3->currentIndex()){
        MsgBox::information(tr("新用户初始化"), tr("请选择密保问题"));
        return;
    }
    QString question1(this->ui->cmb_questions1->currentText());
    QString question2(this->ui->cmb_questions2->currentText());
    QString question3(this->ui->cmb_questions3->currentText());
    QString answer1(this->ui->ledt_answer1->text());
    QString answer2(this->ui->ledt_answer2->text());
    QString answer3(this->ui->ledt_answer3->text());
    QString passwd1(this->ui->ledt_passwd1->text());
    QString passwd2(this->ui->ledt_passwd2->text());
    if (answer1.isEmpty() || answer2.isEmpty() || answer3.isEmpty()){
        MsgBox::information(tr("新用户初始化"), tr("请输入回答"));
        return;
    }
    if(passwd1.isEmpty() || passwd2.isEmpty()){
        MsgBox::information(tr("新用户初始化"), tr("请输入密码"));
        return;
    }
    if (passwd1 != passwd2){
        MsgBox::information(tr("新用户初始化"), tr("两次输入的密码不一致"));
        return;
    }
    QJsonObject questions;
    questions.insert(question_table[question1], answer1);
    questions.insert(question_table[question2], answer2);
    questions.insert(question_table[question3], answer3);
    CRequest req;
    req.set_started_by("init_employee_in_init");
    req.set_action("init_employee");
    req.put("username", username);
    req.put("passwd", passwd1);
    req.put("questions", questions);
    Network::send(req);
    wait->start();
}

/**
* @functionName  question_arrive
* @Description   when query all security question's response arrive, it will handle response
* @author        chenhanlin
* @date          2018-07-08
* @parameter     Response resp
* @return        void
*/
void UserInitDialog::handle_query_question(CResponse &resp)
{
    wait->stop();

    // get question
    QJsonObject questions(resp.get_json("questions"));
    for(const auto &key : questions.keys()){
        QString question(questions[key].toString());
        this->question_table.insert(std::map<QString, QString>::value_type(question, key));
        this->ui->cmb_questions1->addItem(question);
        this->ui->cmb_questions2->addItem(question);
        this->ui->cmb_questions3->addItem(question);
    }
}

void UserInitDialog::handle_init(CResponse &resp)
{
    wait->stop();
    switch (resp.status_code()) {
    case StatusCode::SUCCESS:
        MsgBox::success(tr("用户初始化"), tr("新用户初始化成功"));
        close();
        break;
    case StatusCode::NO_NEW_EMPLOYEE:
        MsgBox::success(tr("用户初始化"), tr("账户已初始化, 请选择未初始化账户"));
        break;
    default:
        MsgBox::warming(tr("用户初始化"), tr("系统错误，请稍后再试"));
        break;
    }
}

/**
* @functionName  get_questions
* @Description   send request to sever to get all security question
* @author        chenhanlin
* @date          2018-07-08
* @parameter     void
* @return        void
*/
void UserInitDialog::get_questions()
{
    CRequest req;
    req.set_started_by("query_questions_in_init");
    req.set_action("query_questions");
    Network::send(req);
}

void UserInitDialog::reset()
{
    ui->cmb_questions1->clear();
    ui->cmb_questions2->clear();
    ui->cmb_questions3->clear();
    ui->cmb_questions1->addItem(tr("选择密保问题1"));
    ui->cmb_questions2->addItem(tr("选择密保问题2"));
    ui->cmb_questions3->addItem(tr("选择密保问题3"));
    ui->ledt_answer1->clear();
    ui->ledt_answer2->clear();
    ui->ledt_answer3->clear();
    ui->ledt_passwd1->clear();
    ui->ledt_passwd2->clear();
}

/**
* @functionName  on_question1_currentIndexChanged
* @Description   update another combo box's item
* @author        chenhanlin
* @date          2018-07-08
* @parameter     QString arg1
* @return        void
*/
void UserInitDialog::on_cmb_questions1_currentIndexChanged(const QString &arg1)
{
    int index = this->ui->cmb_questions1->findText(arg1);
    // get combo box name
    QString object_name(this->ui->cmb_questions1->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->cmb_questions2->addItem(old);
        this->ui->cmb_questions3->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->cmb_questions2->findText(arg1);
        this->ui->cmb_questions2->removeItem(index);
        index = this->ui->cmb_questions3->findText(arg1);
        this->ui->cmb_questions3->removeItem(index);
    }
}

/**
* @functionName  on_question1_currentIndexChanged
* @Description   update another combo box's item
* @author        chenhanlin
* @date          2018-07-08
* @parameter     QString arg1
* @return        void
*/
void UserInitDialog::on_cmb_questions2_currentIndexChanged(const QString &arg1)
{
    int index = this->ui->cmb_questions2->findText(arg1);
    // get combo box name
    QString object_name(this->ui->cmb_questions2->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->cmb_questions1->addItem(old);
        this->ui->cmb_questions3->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->cmb_questions1->findText(arg1);
        this->ui->cmb_questions1->removeItem(index);
        index = this->ui->cmb_questions3->findText(arg1);
        this->ui->cmb_questions3->removeItem(index);
    }
}

/**
* @functionName  on_question1_currentIndexChanged
* @Description   update another combo box's item
* @author        chenhanlin
* @date          2018-07-08
* @parameter     QString arg1
* @return        void
*/
void UserInitDialog::on_cmb_questions3_currentIndexChanged(const QString &arg1)
{
    int index = this->ui->cmb_questions3->findText(arg1);
    // get combo box name
    QString object_name(this->ui->cmb_questions3->objectName());
    if(selected.end() == selected.find(object_name)){
        // if first, record only
        if (0 != index)
            selected.insert(std::map<QString, QString>::value_type(object_name, arg1));
    }else{
        // get the old, and reduction
        QString old(selected[object_name]);
        this->ui->cmb_questions2->addItem(old);
        this->ui->cmb_questions1->addItem(old);

        if (0 != index)
            selected[object_name] = arg1;
        else
            selected.erase(selected.find(object_name));
    }
    // remove new one
    if (0 != index){
        index = this->ui->cmb_questions2->findText(arg1);
        this->ui->cmb_questions2->removeItem(index);
        index = this->ui->cmb_questions1->findText(arg1);
        this->ui->cmb_questions1->removeItem(index);
    }
}

void UserInitDialog::on_btn_cancel_clicked()
{
    close();
}

void UserInitDialog::set_username(const QString &username)
{
    this->username = username;
    get_questions();
}
