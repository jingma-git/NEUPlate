#include "unforzendialog.h"
#include "ui_unforzendialog.h"
#include "UI/iconhelper.h"
#include <functional>

UnfrozenDialog::UnfrozenDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UnforzenDialog)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->ui->stackedWidget->setCurrentIndex(0);

    Network::registered("query_employee_question_in_unfrozen", std::bind(&UnfrozenDialog::handle_query_question, this, std::placeholders::_1));
    Network::registered("unfrozen_in_unfrozen", std::bind(&UnfrozenDialog::handle_unfrozen, this, std::placeholders::_1));
}

UnfrozenDialog::~UnfrozenDialog()
{
    delete ui;
    delete wait;
}

void UnfrozenDialog::on_btnMenu_Close_clicked()
{
    close();
    reset();
}

void UnfrozenDialog::handle_query_question(CResponse &resp)
{
    wait->stop();

    // check status code
    if (StatusCode::NEW_EMPLOYEE == resp.status_code()){
        MsgBox::information(tr("找回密码"), tr("请先初始化用户"));
        return;
    }

    if(StatusCode::SYSTEM_ERROR == resp.status_code()){
        MsgBox::information(tr("找回密码"), tr("系统错误，请稍后再试"));
        return;
    }

    // get question
    QJsonObject questions(resp.get_json("questions"));
    for(const auto &key : questions.keys()){
        QString question(questions[key].toString());
        this->question_table.insert(std::map<QString, QString>::value_type(question, key));
        this->ui->cmb_questions->addItem(question);
    }
    // jump page
    ui->stackedWidget->setCurrentIndex(1);
}

void UnfrozenDialog::handle_unfrozen(CResponse &resp)
{
    wait->stop();
    switch (resp.status_code()) {
    case StatusCode::SUCCESS:
        MsgBox::success(tr("解冻账户"), tr("账户已解冻"));
        accept();
        reset();
        break;
    case StatusCode::WRONG_ANSWER:
        MsgBox::information(tr("解冻账户"), tr("密保问题回答错误"));
        break;
    default:
        MsgBox::warming(tr("解冻账户"), tr("系统错误，请稍后再试"));
        break;
    }
}

void UnfrozenDialog::reset()
{
    ui->ledt_username->clear();
    ui->ledt_answer->clear();
    ui->cmb_questions->clear();
    ui->cmb_questions->addItem(tr("选择密保问题"));
}

void UnfrozenDialog::on_btn_cancel_clicked()
{
    close();
    reset();
}

void UnfrozenDialog::on_btn_confirm_username_clicked()
{
    QString username(this->ui->ledt_username->text());
    if(username.isEmpty()){
        MsgBox::information(tr("解冻账户"), tr("请输入用户名"));
        return;
    }
    CRequest req;
    req.set_action("query_employee_question");
    req.set_started_by("query_employee_question_in_unfrozen");
    req.put("username", username);
    Network::send(req);
    wait->start();
}

void UnfrozenDialog::on_btn_back_clicked()
{
    this->ui->stackedWidget->setCurrentIndex(0);
}

void UnfrozenDialog::on_btn_submit_clicked()
{
    QString answer(this->ui->ledt_answer->text());
    QString question(this->ui->cmb_questions->currentText());
    QString username(ui->ledt_username->text());
    auto iter = question_table.find(question);
    // check input
    if(question_table.end() == iter){
        MsgBox::information(tr("解冻账户"), tr("请选择密保问题"));
        return;
    }
    if (answer.isEmpty()){
        MsgBox::information(tr("解冻账户"), tr("请输入回答"));
        return;
    }
    // build request
    CRequest req;
    req.set_action("unfrozen");
    req.set_started_by("unfrozen_in_unfrozen");
    req.put("username", username);
    req.put("q_id", iter->second);
    req.put("answer", answer);
    Network::send(req);
    wait->start();
}
