#ifndef USERINITDIALOG_H
#define USERINITDIALOG_H

#include <QDialog>
#include <map>
#include "neu_head.h"

namespace Ui {
class UserInitDialog;
}

class UserInitDialog : public QDialog
{
    Q_OBJECT

public:
    explicit UserInitDialog(QWidget *parent = 0);
    ~UserInitDialog();
    void set_username(const QString &username);

private slots:
    void on_btnMenu_Close_clicked();

    void on_btn_submit_clicked();

    void handle_query_question(CResponse&);
    void handle_init(CResponse&);

    void on_cmb_questions1_currentIndexChanged(const QString &arg1);

    void on_cmb_questions2_currentIndexChanged(const QString &arg1);

    void on_cmb_questions3_currentIndexChanged(const QString &arg1);

    void on_btn_cancel_clicked();
private:
    Ui::UserInitDialog *ui;
    QString username;
    std::map<QString, QString> question_table;
    std::map<QString, QString> selected;
    WaitingSpinnerWidget *wait;

    void get_questions();
    void reset();

};

#endif // USERINITDIALOG_H
