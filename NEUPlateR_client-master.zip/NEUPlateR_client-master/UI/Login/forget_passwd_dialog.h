#ifndef FORGET_PASSWD_H
#define FORGET_PASSWD_H

#include <QDialog>
#include <QString>
#include <map>
#include "neu_head.h"

namespace Ui {
class ForgetPasswdDialog;
}

class ForgetPasswdDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ForgetPasswdDialog(QWidget *parent = 0);
    ~ForgetPasswdDialog();

private slots:
    void on_btnMenu_Close_clicked();

    void handle_query_question(CResponse&);
    void handle_find_passwd(CResponse&);

    void on_btn_cancel_find_clicked();

    void on_btn_confirm_username_clicked();

    void on_btn_back_clicked();

    void on_btn_submit_clicked();

private:
    Ui::ForgetPasswdDialog *ui;
    std::map<QString, QString> question_table;
    WaitingSpinnerWidget *wait;

    void reset();
};

#endif // FORGET_PASSWD_H
