#ifndef UNFORZENDIALOG_H
#define UNFORZENDIALOG_H

#include <QDialog>
#include <map>
#include "neu_head.h"

namespace Ui {
class UnforzenDialog;
}

class UnfrozenDialog : public QDialog
{
    Q_OBJECT

public:
    explicit UnfrozenDialog(QWidget *parent = 0);
    ~UnfrozenDialog();

private slots:
    void on_btnMenu_Close_clicked();

    void handle_query_question(CResponse&);
    void handle_unfrozen(CResponse&);

    void on_btn_cancel_clicked();

    void on_btn_confirm_username_clicked();

    void on_btn_back_clicked();

    void on_btn_submit_clicked();

private:
    Ui::UnforzenDialog *ui;
    std::map<QString, QString> question_table;
    WaitingSpinnerWidget *wait;

    void reset();
};

#endif // UNFORZENDIALOG_H
