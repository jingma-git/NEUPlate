#include <functional>
#include "login.h"
#include "ui_login.h"
#include "UI/iconhelper.h"
#include "login_user.h"

LoginDialog::LoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog),
    wait(nullptr)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    forget = new ForgetPasswdDialog;
    unfrozen = new UnfrozenDialog;
    init = new UserInitDialog;
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    // bind response function
    Network::registered("login_in_loginDialog", std::bind(&LoginDialog::login_resp, this, std::placeholders::_1));
    auto &client = CTcpConnection::get_instance();
    connect(&client, SIGNAL(notify_close()), this, SLOT(close_connection()));
    connect(&client, SIGNAL(notify_error(QString)), this, SLOT(error_arrive(QString)));
}

LoginDialog::~LoginDialog()
{
    delete ui;
    delete forget;
    delete unfrozen;
    delete init;
    delete wait;
}

/**
* @functionName  login_resp
* @Description   process the response from login request
* @author        chenhanlin
* @date          2018-07-08
* @parameter     CResponse &resp
* @return        void
*/
void LoginDialog::login_resp(CResponse &resp)
{
    wait->stop();
    switch (resp.status_code()) {
    case StatusCode::SUCCESS:
        disconnect(&CTcpConnection::get_instance(), SIGNAL(notify_close()), this, SLOT(close_connection()));
        disconnect(&CTcpConnection::get_instance(), SIGNAL(notify_error(QString)), this, SLOT(error_arrive(QString)));
        LoginUser::get_instance().set_username(ui->ledt_username->text());
        LoginUser::get_instance().set_access_level(resp.get_int("access_level"));
        if(LoginUser::get_instance().access_level() < 2){
            MsgBox::warming("登录", "无权限登录此系统");
            reject();
        }else{
            accept();
        }
        break;
    case StatusCode::ERROR_PARAMS:
    case StatusCode::SYSTEM_ERROR:
        MsgBox::error(tr("登录"), tr("系统错误，请稍后再试"));
        return;
    case StatusCode::NO_SUCH_USER:
    case StatusCode::INVAILD_PASSWD:
        MsgBox::warming(tr("登录"), tr("用户名或密码错误"));
        return;
    case StatusCode::NEW_EMPLOYEE:
        MsgBox::information(tr("登录"), tr("请初始化用户"));
        init->set_username(ui->ledt_username->text());
        init->setModal(true);
        init->show();
        return;
    case StatusCode::FROZEN:
        MsgBox::information(tr("登录"), tr("账户已冻结，请解冻"));
        unfrozen->setModal(true);
        unfrozen->show();
        return;
    case StatusCode::RESIGNATION:
        MsgBox::information(tr("登录"), tr("员工已离职，账户禁止登录。"));
        return;
    case StatusCode::LOGINED:
        MsgBox::information("登录", "账户已登录");
        return;
    }
}

void LoginDialog::error_arrive(QString)
{
    MsgBox::error(tr("网络错误"), tr("无法连接至网络，请重试"));
    close();
}

void LoginDialog::close_connection()
{
    MsgBox::error(tr("网络错误"), tr("与服务器断开连接，请稍后再试。"));
    close();
}

void LoginDialog::on_btnMenu_Close_clicked()
{
    close();
}

void LoginDialog::on_btn_login_clicked()
{
    QString username(ui->ledt_username->text());
    QString passwd(ui->ledt_passwd->text());

    if(username.isEmpty() || passwd.isEmpty()){
        MsgBox::warming(tr("登录"), tr("请输入用户名和密码"));
        return;
    }

    CRequest req;
    req.set_action("login");
    req.set_started_by("login_in_loginDialog");
    req.put("username", username);
    req.put("passwd", passwd);
    Network::send(req);
    wait->start();
}

void LoginDialog::on_btn_forget_passwd_clicked()
{
    forget->setModal(true);
    forget->show();
}
