#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include "neu_head.h"
#include "forget_passwd_dialog.h"
#include "unforzendialog.h"
#include "userinitdialog.h"

namespace Ui {
class LoginDialog;
}

class LoginDialog : public QDialog
{
    Q_OBJECT
public:
    explicit LoginDialog(QWidget *parent = 0);
    ~LoginDialog();

private slots:
    void login_resp(CResponse&);
    void error_arrive(QString);
    void close_connection();

    void on_btnMenu_Close_clicked();

    void on_btn_login_clicked();

    void on_btn_forget_passwd_clicked();

private:
    Ui::LoginDialog *ui;
    QString e_id;
    WaitingSpinnerWidget *wait;
    ForgetPasswdDialog *forget;
    UnfrozenDialog *unfrozen;
    UserInitDialog *init;
};

#endif // LOGIN_H
