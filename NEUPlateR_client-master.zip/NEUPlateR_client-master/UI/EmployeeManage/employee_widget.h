#ifndef EMPOLEE_AND_ACCOUNT_MANAGE_H
#define EMPOLEE_AND_ACCOUNT_MANAGE_H

#include <QWidget>
#include <QMenu>
#include <vector>
#include "neu_head.h"
#include "modify_employee_dialog.h"

namespace Ui {
class EmployeeWidget;
}

class EmployeeWidget : public QWidget
{
    Q_OBJECT

public:
    explicit EmployeeWidget(QWidget *parent = 0);
    ~EmployeeWidget();
    void init_page();

private slots:
    void on_tableWidget_customContextMenuRequested(const QPoint &pos);

    void delete_select_employee();
    void frozen_select_employee();
    void unfrozen_select_employee();
    void leave_select_employee();
    void hire_select_employee();
    void search_page();
    void condition_change();

    void handle_delete_employee(CResponse&);
    void handle_modify_state(CResponse&);
    void handle_query_employee(CResponse&);

    void on_tableWidget_cellChanged(int row, int column);

    void modify_employee();

    void on_cmb_page_currentIndexChanged(int index);

    void on_tbn_next_clicked();

    void on_tbn_previous_clicked();

private:
    Ui::EmployeeWidget *ui;
    QMenu *t_menu;
    WaitingSpinnerWidget *wait;
    ModifyEmployeeDialog *modify;
    std::vector<QString> select_e_id;
    static const int page_item;
    bool change_work;

    void init_table();
    void init_button();

    void query_page(int page);
};

#endif // EMPOLEE_AND_ACCOUNT_MANAGE_H
