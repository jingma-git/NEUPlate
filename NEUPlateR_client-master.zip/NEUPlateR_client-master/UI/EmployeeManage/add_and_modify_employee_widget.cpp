#include "add_and_modify_employee_widget.h"
#include "ui_add_and_modify_employee_widget.h"
#include "UI/iconhelper.h"
#include <QFileDialog>
#include <QFile>
#include <QDate>
#include <QByteArray>
#include <QPixmap>
#include <QRegExp>
#include <QRegExpValidator>

AddAndModifyEmloyeeWidget::AddAndModifyEmloyeeWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddAndModifyEmployeeWidget)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    cut = new CutPhotoDialog;
    init_lineedit();

    connect(cut, SIGNAL(notify_data(QByteArray)), this, SLOT(receive_photo_data(QByteArray)));
    connect(cut, SIGNAL(notify_pixmap(QPixmap)), this, SLOT(receive_pixmap(QPixmap)));
    Network::registered(QString("add_employee_in_%1").arg(int(this)), std::bind(&AddAndModifyEmloyeeWidget::handle_add_employee, this, std::placeholders::_1));
    Network::registered(QString("modify_employee_in_%1").arg(int(this)), std::bind(&AddAndModifyEmloyeeWidget::handle_modify_employee, this, std::placeholders::_1));
    Network::registered(QString("query_employee_in_%1").arg(int(this)), std::bind(&AddAndModifyEmloyeeWidget::handle_query_employee, this, std::placeholders::_1));

    setTabOrder(ui->ledt_name, ui->ledt_work_place);
    setTabOrder(ui->ledt_work_place, ui->cmb_sex);
    setTabOrder(ui->cmb_sex, ui->dedt_birthday);
    setTabOrder(ui->dedt_birthday, ui->ledt_email);
    setTabOrder(ui->ledt_email, ui->ledt_id);
    setTabOrder(ui->ledt_id, ui->cmb_edu);
    setTabOrder(ui->cmb_edu, ui->cmb_married);
    setTabOrder(ui->cmb_married, ui->ledt_birth_place);
    setTabOrder(ui->ledt_birth_place, ui->ledt_phone);
    setTabOrder(ui->ledt_phone, ui->ledt_political_status);
    setTabOrder(ui->ledt_political_status, ui->ledt_nation);
    setTabOrder(ui->ledt_nation, ui->spx_access_level);
}

AddAndModifyEmloyeeWidget::~AddAndModifyEmloyeeWidget()
{
    delete ui;
    delete wait;
    delete cut;
}

void AddAndModifyEmloyeeWidget::modify_employee(const QString &username)
{
    this->username = username;
    CRequest req;
    req.set_action("query_employee");
    req.set_started_by(QString("query_employee_in_%1").arg(int(this)));
    req.put("username", username);
    Network::send(req);
    wait->start();
}

void AddAndModifyEmloyeeWidget::on_btn_submit_clicked()
{
    submit_employee();
}

/**
* @functionName  on_btn_upload_clicked
* @Description   upoload button trigger
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void AddAndModifyEmloyeeWidget::on_btn_upload_clicked()
{
    QString filename = QFileDialog::getOpenFileName(this, tr("选择图片"), "./", tr("图片文件(*.png *.jpg)"));
    if(filename.isEmpty())return;
    wait->start();
    cut->load_photo(filename);
    cut->setModal(true);
    cut->show();
    wait->stop();
}

/**
* @functionName  handle_add_employee
* @Description   handle the response from add_employee
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void AddAndModifyEmloyeeWidget::handle_add_employee(CResponse &resp)
{
    wait->stop();

    if(StatusCode::SUCCESS != resp.status_code()){
        MsgBox::warming(tr("添加员工"), tr("系统错误，请稍后再试"));
        return;
    }
    this->reset();
}

/**
* @functionName  handle_modify_employee
* @brief         process the resposne from modify employee
* @author        chenhanlin
* @date          2018-08-02
* @parameter     void
* @return        void
*/
void AddAndModifyEmloyeeWidget::handle_modify_employee(CResponse &resp)
{
    if(StatusCode::SUCCESS != resp.status_code()){
        MsgBox::warming(tr("编辑员工信息"), tr("系统错误，请稍后再试"));
        return;
    }
    this->reset();
    emit modify_done();
}

/**
* @functionName  handle_query_employee
* @Description   process the response from query_employee
* @author        chenhanlin
* @date          2018-07-10
* @parameter     Response resp
* @return        void
*/
void AddAndModifyEmloyeeWidget::handle_query_employee(CResponse &resp)
{
    wait->stop();

    if(StatusCode::NO_SUCH_USER == resp.status_code()){
        MsgBox::warming(tr("编辑员工信息"), tr("无此员工信息"));
    }

    if(StatusCode::SUCCESS != resp.status_code()){
        MsgBox::warming(tr("编辑员工信息"), tr("系统错误，请稍后再试"));
        return;
    }

    QJsonObject employee(resp.get_json("employee"));

    ui->ledt_name->setText(employee["name"].toString());
    ui->ledt_work_place->setText(employee["work_place"].toString());
    ui->cmb_sex->setCurrentIndex(employee["gender"].toInt() - 1);
    ui->dedt_birthday->setDate(QDate::fromString(employee["birthday"].toString()));
    ui->ledt_birth_place->setText(employee["birth_place"].toString());
    ui->ledt_nation->setText(employee["nation"].toString());
    ui->cmb_married->setCurrentIndex(int(employee["married"].toBool()));
    ui->ledt_political_status->setText(employee["political_state"].toString());
    ui->cmb_edu->setCurrentIndex(employee["edu"].toInt());
    ui->ledt_id->setText(employee["id"].toString());
    ui->ledt_phone->setText(employee["telephone"].toString());
    ui->ledt_email->setText(employee["email"].toString());
    ui->spx_access_level->setValue(employee["access_level"].toInt());
    QPixmap photo;
    photo_data = employee["photo"].toString().toUtf8();
    if(!photo_data.isEmpty()){
        photo.loadFromData(QByteArray::fromBase64(photo_data));
        ui->label_photo->setPixmap(photo);
    }
}

/**
* @functionName  recevice_photo_data
* @Description       recevice photo data from cutdialog
* @author              chenhanlin
* @date                  2018-07-13
* @parameter         void
* @return               void
*/
void AddAndModifyEmloyeeWidget::receive_photo_data(QByteArray data)
{
    // to base64
    photo_data = data.toBase64();
}

/**
* @functionName  receive_pixmap
* @Description   receive QPixmap object from cutdialog
* @author        chenhanlin
* @date          2018-07-13
* @parameter     void
* @return        void
*/
void AddAndModifyEmloyeeWidget::receive_pixmap(QPixmap photo)
{
    ui->label_photo->setPixmap(photo);
}

/**
* @functionName  cancel_submit
* @Description   do question before close window and clear some input
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void AddAndModifyEmloyeeWidget::reset()
{
    ui->ledt_name->clear();
    ui->ledt_id->clear();
    ui->cmb_sex->setCurrentIndex(0);
    ui->ledt_work_place->clear();
    ui->ledt_email->clear();
    ui->cmb_edu->setCurrentIndex(0);
    ui->cmb_married->setCurrentIndex(0);
    ui->ledt_birth_place->clear();
    ui->ledt_phone->clear();
    ui->ledt_political_status->clear();
    ui->ledt_nation->clear();
    this->photo_data.clear();
    this->username.clear();
    ui->label_photo->setPixmap(QPixmap(":/image/user.png"));
}

/**
* @functionName  submit_employee
* @Description   get data from gui and send add_employee request to server
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void AddAndModifyEmloyeeWidget::submit_employee()
{
    QString name(ui->ledt_name->text());
    QString id(ui->ledt_id->text());
    int sex = ui->cmb_sex->currentIndex() + 1;
    QDate birthday(ui->dedt_birthday->date());
    QString work_place(ui->ledt_work_place->text());
    QString email(ui->ledt_email->text());
    int edu = ui->cmb_edu->currentIndex();
    int married = bool(ui->cmb_married->currentIndex());
    QString birth_place(ui->ledt_birth_place->text());
    QString phone(ui->ledt_phone->text());
    QString political_status(ui->ledt_political_status->text());
    QString nation(ui->ledt_nation->text());
    int access_level(ui->spx_access_level->value());

    if(photo_data.isEmpty() || name.isEmpty() || id.isEmpty() || work_place.isEmpty() || email.isEmpty() || phone.isEmpty()){
        MsgBox::information(tr("添加员工"), tr("请填写完整信息"));
        return;
    }
    QRegExp id_check("(^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$)|(^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}$)");
    QRegExp email_check("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$");
    QRegExp phone_check("^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$");
    if(!id_check.exactMatch(id)){
        MsgBox::information(tr("添加员工"), tr("请输入正确的身份证号"));
        return;
    }
    if(!email_check.exactMatch(email)){
        MsgBox::information(tr("添加员工"), tr("请输入正确的电子邮件"));
        return;
    }
    if(!phone_check.exactMatch(phone)){
        MsgBox::information(tr("添加员工"), tr("请输入正确的电话号码"));
        return;
    }


    CRequest req;
    QJsonObject employee;
    if(username.isEmpty()){
        req.set_action("add_employee");
        req.set_started_by(QString("add_employee_in_%1").arg(int(this)));
    }else{
        employee.insert("username", this->username);
        req.set_action("modify_employee");
        req.set_started_by(QString("modify_employee_in_%1").arg(int(this)));
    }


    employee.insert("name", name);
    employee.insert("work_place", work_place);
    employee.insert("gender", sex);
    employee.insert("birthday", birthday.toString());
    employee.insert("birth_place", birth_place);
    employee.insert("nation", nation);
    employee.insert("married", married);
    employee.insert("political_status", political_status);
    employee.insert("education", edu);
    employee.insert("id", id);
    employee.insert("telephone", phone);
    employee.insert("email", email);
    employee.insert("photo", QString(photo_data));
    employee.insert("access_level", access_level);

    req.put("employee", employee);

    Network::send(req);
    wait->start();
}

/**
* @functionName  init_lineedit
* @Description       add contraint at line edit
* @author              chenhanlin
* @date                  2018-07-12
* @parameter         void
* @return               void
*/
void AddAndModifyEmloyeeWidget::init_lineedit()
{
    QRegExp id("(^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$)|(^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}$)");
    QRegExpValidator *pid = new QRegExpValidator(id, this);
    ui->ledt_id->setValidator(pid);
    QRegExp email("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$");
    QRegExpValidator *pemail = new QRegExpValidator(email, this);
    ui->ledt_email->setValidator(pemail);
    QRegExp phone("^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$");
    QRegExpValidator *pphone = new QRegExpValidator(phone, this);
    ui->ledt_phone->setValidator(pphone);
}
