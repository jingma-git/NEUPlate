#ifndef PERSONAL_CENTER_H
#define PERSONAL_CENTER_H

#include <QWidget>
#include <QToolButton>

#include "employee_widget.h"
#include "add_and_modify_employee_widget.h"

namespace Ui {
class EmployeeManageWidget;
}

class EmployeeManageWidget : public QWidget
{
    Q_OBJECT

public:
    explicit EmployeeManageWidget(QWidget *parent = 0);
    ~EmployeeManageWidget();
    void  init_menu();

private slots:
    void  menu_click();

private:
    Ui::EmployeeManageWidget *ui;

    QList<int> pixChars;
    QList<QToolButton *> btns;

    EmployeeWidget *employee;
    AddAndModifyEmloyeeWidget *add;

    void  init_widget();

};

#endif // PERSONAL_CENTER_H
