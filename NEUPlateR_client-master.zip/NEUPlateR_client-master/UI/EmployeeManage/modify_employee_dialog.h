#ifndef MODIFY_EMPLOYEE_DIALOG_H
#define MODIFY_EMPLOYEE_DIALOG_H

#include <QDialog>
#include "add_and_modify_employee_widget.h"

namespace Ui {
class ModifyEmployeeDialog;
}

class ModifyEmployeeDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ModifyEmployeeDialog(QWidget *parent = 0);
    ~ModifyEmployeeDialog();
    void modify_employee(const QString &username);

private slots:
    void on_btnMenu_Close_clicked();
    void handle_done();

private:
    Ui::ModifyEmployeeDialog *ui;

    AddAndModifyEmloyeeWidget *modify;
};

#endif // MODIFY_EMPLOYEE_DIALOG_H
