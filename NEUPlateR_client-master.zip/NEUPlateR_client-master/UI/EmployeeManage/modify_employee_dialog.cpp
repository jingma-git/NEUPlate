#include "modify_employee_dialog.h"
#include "ui_modify_employee_dialog.h"
#include "UI/iconhelper.h"

ModifyEmployeeDialog::ModifyEmployeeDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ModifyEmployeeDialog)
{
    modify = new AddAndModifyEmloyeeWidget(this);
    ui->setupUi(this);
    ui->verticalLayout->addWidget(modify);
    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));

    connect(modify, SIGNAL(modify_done()), this, SLOT(handle_done()));
}

ModifyEmployeeDialog::~ModifyEmployeeDialog()
{
    delete ui;
}


/**
* @functionName  modify
* @brief         init employee infomation to modify
* @author        chenhanlin
* @date          2018-08-02
* @parameter     void
* @return        void
*/
void ModifyEmployeeDialog::modify_employee(const QString &username)
{
    modify->modify_employee(username);
}

void ModifyEmployeeDialog::on_btnMenu_Close_clicked()
{
    close();
}

void ModifyEmployeeDialog::handle_done()
{
    this->accept();
}
