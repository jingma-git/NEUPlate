#include "employee_widget.h"
#include "ui_employee_widget.h"
#include "Entity/employee.h"
#include "login_user.h"
#include <functional>
#include <QJsonArray>
#include <QJsonObject>
#include <QPoint>
#include <QAction>
#include <QStandardItem>
#include <QHeaderView>
#include <QContextMenuEvent>
#include <QTableWidgetItem>
#include <cmath>

const int EmployeeWidget::page_item = 10;

EmployeeWidget::EmployeeWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::EmployeeWidget),
    wait(nullptr),
    change_work(false)
{
    ui->setupUi(this);
    wait = new WaitingSpinnerWidget(this);
    modify = new ModifyEmployeeDialog;
    init_button();
    init_table();

    connect(ui->cmb_level, SIGNAL(currentIndexChanged(int)), this, SLOT(condition_change()));
    connect(ui->cmb_sex, SIGNAL(currentIndexChanged(int)), this, SLOT(condition_change()));
    connect(ui->cmb_state, SIGNAL(currentIndexChanged(int)), this, SLOT(condition_change()));

    Network::registered(QString("query_employees_in_%1").arg(int(this)), std::bind(&EmployeeWidget::handle_query_employee, this, std::placeholders::_1));
    Network::registered(QString("delete_employees_in_%1").arg(int(this)), std::bind(&EmployeeWidget::handle_delete_employee, this, std::placeholders::_1));
    Network::registered(QString("modify_state_in_%1").arg(int(this)), std::bind(&EmployeeWidget::handle_modify_state, this, std::placeholders::_1));
}

EmployeeWidget::~EmployeeWidget()
{
    delete ui;
    delete modify;
}

/**
* @functionName  init_page
* @Description   when click the button, this page show, shuld init and show some information;
* @author        chenhanlin
* @date          2018-07-11
* @parameter     void
* @return        void
*/
void EmployeeWidget::init_page()
{
    wait->start();
    ui->ledit_input->clear();
    ui->cmb_state->setCurrentIndex(0);
    ui->cmb_sex->setCurrentIndex(0);
    change_work = false;
    ui->cmb_page->clear();
    ui->cmb_page->addItem(tr("第1页"));
    query_page(0);
    change_work = true;
}

/**
* @functionName  init_table
* @Description   set tablewidget
* @author        chenhanlin
* @date          2018-07-09
* @parameter     void
* @return        void
*/
void EmployeeWidget::init_table()
{
    // basicly set
    ui->tableWidget->setShowGrid(false);
    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tableWidget->horizontalHeader()->setSectionsClickable(false);
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    // constructor menu
    t_menu = new QMenu(ui->tableWidget);
    QAction *delete_e = t_menu->addAction(tr("删除"));
    QAction *leave_e = t_menu->addAction(tr("离职"));
    QAction *enter_e = t_menu->addAction(tr("入职"));
    QAction *frozen_u = t_menu->addAction(tr("冻结"));
    QAction *unfrozen_u = t_menu->addAction(tr("解冻"));
    QAction *modify_e = t_menu->addAction(tr("编辑"));
    modify_e->setObjectName("modify");

    connect(delete_e, SIGNAL(triggered(bool)), this, SLOT(delete_select_employee()));
    connect(leave_e, SIGNAL(triggered(bool)), this, SLOT(leave_select_employee()));
    connect(enter_e, SIGNAL(triggered(bool)), this, SLOT(hire_select_employee()));
    connect(frozen_u, SIGNAL(triggered(bool)), this, SLOT(frozen_select_employee()));
    connect(unfrozen_u, SIGNAL(triggered(bool)), this, SLOT(unfrozen_select_employee()));
    connect(modify_e, SIGNAL(triggered(bool)), this, SLOT(modify_employee()));

    ui->tableWidget->insertRow(0);
    /*
    for(int i=0; i < page_item; i++){
        ui->tableWidget->insertRow(i);
    }
    */
}

/**
* @functionName  init_tool_button
* @Description   init the set state and page change toolbutton
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeWidget::init_button()
{
    // init employee_state button
    QMenu *e_menu = new QMenu(this);
    QAction *enter = e_menu->addAction(tr("入职"));
    QAction *leave = e_menu->addAction(tr("离职"));
    QAction *frozen = e_menu->addAction(tr("冻结"));
    QAction *unfrozen = e_menu->addAction(tr("解冻"));

    ui->tbn_e_state->setPopupMode(QToolButton::InstantPopup);
    ui->tbn_e_state->setMenu(e_menu);
    ui->tbn_next->setArrowType(Qt::RightArrow);
    ui->tbn_previous->setArrowType(Qt::LeftArrow);

    connect(enter, SIGNAL(triggered(bool)), this, SLOT(hire_select_employee()));
    connect(leave, SIGNAL(triggered(bool)), this, SLOT(leave_select_employee()));
    connect(frozen, SIGNAL(triggered(bool)), this, SLOT(frozen_select_employee()));
    connect(unfrozen, SIGNAL(triggered(bool)), this, SLOT(unfrozen_select_employee()));

    connect(ui->btn_delete, SIGNAL(clicked(bool)), this, SLOT(delete_select_employee()));
    connect(ui->btn_search, SIGNAL(clicked(bool)), this, SLOT(search_page()));
}

/**
* @functionName  query_page
* @Description   query the ith page by some condition
* @author        chenhanlin
* @date          2018-07-11
* @parameter     int page
* @return        void
*/
void EmployeeWidget::query_page(int page)
{
    QString keyword(ui->ledit_input->text());
    int e_state = ui->cmb_state->currentIndex();
    e_state = e_state <0 ? 0 : e_state;
    int gender = ui->cmb_sex->currentIndex();
    gender = gender < 0 ? 0 : gender;
    int level = ui->cmb_level->currentIndex();
    switch (e_state) {
    case 1:
        e_state = 1;
        break;
    case 2:
        e_state = 2;
        break;
    case 3:
        e_state = 4;
        break;
    case 4:
        e_state = 8;
        break;
    }
    CRequest req;
    req.set_action("query_employees");
    req.set_started_by(QString("query_employees_in_%1").arg(int(this)));
    req.put("keyword", keyword);
    req.put("page", page);
    req.put("page_num", page_item);
    req.put("gender", gender);
    req.put("access_level", level);
    req.put("state", e_state);
    Network::send(req);
    wait->start();
}

/**
* @functionName  on_tableWidget_customContextMenuRequest
* @Description   trigger the right click menu
* @author        chenhanlin
* @date          2018-07-10
* @parameter     QPoint pos
* @return        void
*/
void EmployeeWidget::on_tableWidget_customContextMenuRequested(const QPoint &pos)
{
    QList<QTableWidgetItem*> items = ui->tableWidget->selectedItems();
    int total = items.count() / 5;
    if(total > 0){
        for(auto &a : t_menu->actions()){
            if(a->objectName() == "modify"){
                if(total == 1)
                    a->setEnabled(true);
                else
                    a->setEnabled(false);
                break;
            }
        }
        t_menu->exec(QCursor::pos());
    }
}

/**
* @functionName  select_delete_employee
* @Description   send remove_employee request to delete employees, the employee is get by select by mutilple line
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeWidget::delete_select_employee()
{
    int flag = MsgBox::question(tr("删除员工"), tr("删除操作不可逆转，请确认是否删除员工？"));
    if(MsgBox::NO == flag) return;
    QList<QTableWidgetItem*> items = ui->tableWidget->selectedItems();
    QJsonArray e_id;
    for(const auto &item : items){
        if(item->column() == 0){
            if(item->text() == LoginUser::get_instance().username()){
                MsgBox::warming("删除员工", "无效的操作");
                return;
            }
            e_id.push_back(item->text());
        }
    }

    CRequest req;
    req.put("usernames", e_id);
    req.set_action("delete_employees");
    req.set_started_by(QString("delete_employees_in_%1").arg(int(this)));
    Network::send(req);
    wait->start();
}

/**
* @functionName  frozen_select_employee
* @Description   freeze selected multi-line user
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeWidget::frozen_select_employee()
{
    int flag = MsgBox::question(tr("员工管理"), tr("是否冻结选中账户？"));
    if(MsgBox::NO == flag) return;
    QJsonArray e_ids;
    auto items = ui->tableWidget->selectedItems();
    for(const auto &item : items){
        if(item->column() == 0){
            e_ids.push_back(item->text());
        }
    }
    CRequest req;
    req.set_action("frozen_employee");
    req.set_started_by(QString("modify_state_in_%1").arg(int(this)));
    req.put("usernames", e_ids);
    Network::send(req);
    wait->start();
}

/**
* @functionName  unfrozen_select_employee
* @Description   unfreeze selected multi-line user
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeWidget::unfrozen_select_employee()
{
    int flag = MsgBox::question(tr("员工管理"), tr("是否解冻选中账户？"));
    if(MsgBox::NO == flag) return;
    QJsonArray e_ids;
    auto items = ui->tableWidget->selectedItems();
    for(const auto &item : items){
        if(item->column() == 0){
            e_ids.push_back(item->text());
        }
    }
    CRequest req;
    req.set_action("unfrozen_employee");
    req.set_started_by(QString("modify_state_in_%1").arg(int(this)));
    req.put("usernames", e_ids);
    Network::send(req);
    wait->start();
}

/**
* @functionName  leave_select_employee
* @Description   set selected multi-line employee's state to leave
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeWidget::leave_select_employee()
{
    int flag = MsgBox::question(tr("员工管理"), tr("是否为选中员工办理离职？"));
    if(MsgBox::NO == flag) return;
    QJsonArray e_ids;
    auto items = ui->tableWidget->selectedItems();
    for(const auto &item : items){
        if(item->column() == 0){
            e_ids.push_back(item->text());
        }
    }
    CRequest req;
    req.set_action("resignation");
    req.set_started_by(QString("modify_state_in_%1").arg(int(this)));
    req.put("usernames", e_ids);
    Network::send(req);
    wait->start();
}

/**
* @functionName  hire_select_employee
* @Description   set selected multi-line employee's state to normal
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeWidget::hire_select_employee()
{
    int flag = MsgBox::question(tr("员工管理"), tr("是否为选中员工办理入职？"));
    if(MsgBox::NO == flag) return;
    QJsonArray e_ids;
    auto items = ui->tableWidget->selectedItems();
    for(const auto &item : items){
        if(item->column() == 0){
            e_ids.push_back(item->text());
        }
    }
    CRequest req;
    req.set_action("hire_employees");
    req.set_started_by(QString("modify_state_in_%1").arg(int(this)));
    req.put("usernames", e_ids);
    Network::send(req);
    wait->start();
}

/**
* @functionName  search_page
* @Description       query employee by condition
* @author              chenhanlin
* @date                  2018-07-11
* @parameter         void
* @return               void
*/
void EmployeeWidget::search_page()
{
    change_work = false;
    ui->cmb_page->clear();
    ui->cmb_page->addItem(tr("第1页"));
    this->query_page(0);
    change_work = true;
}

/**
* @functionName  condition_change
* @brief         do query when you select condition
* @author        chenhanlin
* @date          2018-08-01
* @parameter     void
* @return        void
*/
void EmployeeWidget::condition_change()
{
    this->query_page(ui->cmb_page->currentIndex());
}

/**
* @functionName  handle_delete_employee
* @Description   process the response from delete employee
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeWidget::handle_delete_employee(CResponse &resp)
{
    wait->stop();
    if(StatusCode::SUCCESS != resp.status_code()){
        MsgBox::warming(tr("员工管理"), tr("系统错误，请稍后再试"));
        return;
    }

    change_work = false;
    ui->cmb_page->clear();
    ui->cmb_page->addItem(tr("第1页"));
    query_page(0);
    change_work = true;

}

/**
* @functionName  handle_modify_state
* @Description   process the response from unfrozen, frozen, leave, hire request
* @author        chenhanlin
* @date          2018-07-10
* @parameter     void
* @return        void
*/
void EmployeeWidget::handle_modify_state(CResponse &resp)
{
    wait->stop();
    if(StatusCode::SUCCESS != resp.status_code()){
        MsgBox::warming(tr("员工管理"), tr("系统错误，请稍后再试"));
        return;
    }

    // refresh page
    query_page(ui->cmb_page->currentIndex());
}

/**
* @functionName  handle_query_employee
* @brief         process query employees request
* @author        chenhanlin
* @date          2018-08-01
* @parameter     void
* @return        void
*/
void EmployeeWidget::handle_query_employee(CResponse &resp)
{
    wait->stop();

    if(StatusCode::SYSTEM_ERROR == resp.status_code()){
        MsgBox::warming(tr("员工管理"), tr("系统错误，请稍后再试"));
        return;
    }

    ui->tableWidget->clearContents();
    for(int i=ui->tableWidget->rowCount()-1; i > 0; i--){
        ui->tableWidget->removeRow(i);
    }
    if(StatusCode::NO_SUCH_USER == resp.status_code()){
        return;
    }

    QJsonArray employees(resp.get_array("employees"));

    int total = resp.get_int("total");
    int page_num = std::ceil(double(total)/page_item);

    int count = 0;
    // build data
    for(const auto i : employees){
        int col = 0;
        QJsonObject employee(i.toObject());
        QTableWidgetItem *username = new QTableWidgetItem(employee.value("username").toString());
        ui->tableWidget->setItem(count, col, username);
        username->setTextAlignment(Qt::AlignCenter);
        col++;
        QTableWidgetItem *name = new QTableWidgetItem(employee.value("name").toString());
        ui->tableWidget->setItem(count, col, name);
        name->setTextAlignment(Qt::AlignCenter);
        col++;
        QTableWidgetItem *work_place = new QTableWidgetItem(employee.value("work_place").toString());
        ui->tableWidget->setItem(count, col, work_place);
        work_place->setTextAlignment(Qt::AlignCenter);
        col++;
        QTableWidgetItem *access_level = new QTableWidgetItem(QString("%1级权限").arg(employee.value("access_level").toInt()));
        ui->tableWidget->setItem(count, col, access_level);
        access_level->setTextAlignment(Qt::AlignCenter);
        col++;
        QTableWidgetItem *state = new QTableWidgetItem(EmployeeState::state_str(employee.value("state").toInt()));
        ui->tableWidget->setItem(count, col, state);
        state->setTextAlignment(Qt::AlignCenter);
        col++;
        count++;
        if(count < employees.size())
            ui->tableWidget->insertRow(count);
    }

    // build page
    this->change_work = false;
    if(ui->cmb_page->count() < page_num){
        for(int i=ui->cmb_page->count(); i<page_num; i++){
            ui->cmb_page->addItem(QString("第%1页").arg(i+1));
        }
    }
    ui->tbn_next->setEnabled(true);
    ui->tbn_previous->setEnabled(true);
    if(ui->cmb_page->currentIndex()+1 == ui->cmb_page->count()){
        ui->tbn_next->setEnabled(false);
    }
    if(0 == ui->cmb_page->currentIndex()){
        ui->tbn_previous->setEnabled(false);
    }
    this->change_work = true;
}

void EmployeeWidget::on_tableWidget_cellChanged(int row, int column)
{
    if(0 == column){
        auto item = ui->tableWidget->item(row, column);
        if(item->checkState() == Qt::Checked){
            select_e_id.push_back(item->text());
        }else{
            auto iter = select_e_id.begin();
            for(;iter!=select_e_id.end(); iter++){
                if(*iter == item->text()) break;
            }
            if(iter!=select_e_id.end()) select_e_id.erase(iter);
        }
    }
}

void EmployeeWidget::modify_employee()
{
    QList<QTableWidgetItem*> items = ui->tableWidget->selectedItems();
    for(const auto &item : items){
        if(item->column() == 0){
            modify->modify_employee(item->text());
            break;
        }
    }
    if(QDialog::Accepted == modify->exec()){
        query_page(ui->cmb_page->currentIndex());
    }
}

void EmployeeWidget::on_cmb_page_currentIndexChanged(int index)
{
    if(change_work){
        change_work = false;
        query_page(index);
        change_work = true;
    }
}

void EmployeeWidget::on_tbn_next_clicked()
{
    this->ui->cmb_page->setCurrentIndex(ui->cmb_page->currentIndex() + 1);
    if(ui->cmb_page->currentIndex()+1 == ui->cmb_page->count()){
        ui->tbn_next->setEnabled(false);
    }else{
        ui->tbn_next->setEnabled(true);
    }
    ui->tbn_previous->setEnabled(true);
}

void EmployeeWidget::on_tbn_previous_clicked()
{
    this->ui->cmb_page->setCurrentIndex(ui->cmb_page->currentIndex() - 1);
    if(0 == ui->cmb_page->currentIndex()){
        ui->tbn_previous->setEnabled(false);
    }else{
        ui->tbn_previous->setEnabled(true);
    }
    ui->tbn_next->setEnabled(true);
}
