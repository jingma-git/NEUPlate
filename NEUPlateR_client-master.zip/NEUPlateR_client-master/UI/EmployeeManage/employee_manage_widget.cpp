#include "employee_manage_widget.h"
#include "ui_employee_manage_widget.h".h"
#include "UI/iconhelper.h"

EmployeeManageWidget::EmployeeManageWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::EmployeeManageWidget)
{
    employee = new EmployeeWidget;
    add = new AddAndModifyEmloyeeWidget;
    ui->setupUi(this);
    this->init_menu();
    this->init_widget();
}


void EmployeeManageWidget::init_menu(){
    ui->leftMenu->setProperty("flag", "left");

    pixChars << 0xf031 << 0xf036;
    btns<<ui->btn_manage<<ui->btn_add;

    int count = btns.count();
    for (int i = 0; i < count; i++) {
        btns.at(i)->setCheckable(true);
        btns.at(i)->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        connect(btns.at(i), SIGNAL(clicked(bool)), this, SLOT(menu_click()));
    }
    IconHelper::Instance()->setStyle(ui->leftMenu, btns, pixChars, 10, 20, 15, "left", 5);
    ui->btn_manage->click();
}


void EmployeeManageWidget::init_widget(){
    ui->stackedWidget->insertWidget(0, employee);
    ui->stackedWidget->insertWidget(1, add);
}


void EmployeeManageWidget::menu_click(){

    QToolButton *b = (QToolButton *)sender();

    IconHelper::Instance()->setButton(btns,b);

    if(b==ui->btn_manage){
        employee->init_page();
        ui->stackedWidget->setCurrentIndex(0);
    }else if(b==ui->btn_add){
        ui->stackedWidget->setCurrentIndex(1);
    }

}

EmployeeManageWidget::~EmployeeManageWidget()
{
    delete ui;
    delete employee;
}
