#ifndef ADD_EMPLOYEE_DIALOG_H
#define ADD_EMPLOYEE_DIALOG_H

#include <QWidget>
#include "neu_head.h"
#include "UI/CutDialog/cut_photo_dialog.h"

namespace Ui {
class AddAndModifyEmployeeWidget;
}

class AddAndModifyEmloyeeWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AddAndModifyEmloyeeWidget(QWidget *parent = 0);
    ~AddAndModifyEmloyeeWidget();
    void modify_employee(const QString &username);

private slots:
    void on_btn_submit_clicked();

    void on_btn_upload_clicked();

    void handle_add_employee(CResponse&);
    void handle_modify_employee(CResponse&);
    void handle_query_employee(CResponse&);

    void receive_photo_data(QByteArray data);
    void receive_pixmap(QPixmap photo);

signals:
    void modify_done();

private:
    Ui::AddAndModifyEmployeeWidget *ui;
    QByteArray photo_data;
    QString username;
    WaitingSpinnerWidget *wait;
    CutPhotoDialog *cut;

    void reset();
    void submit_employee();
    void init_lineedit();
};

#endif // ADD_EMPLOYEE_DIALOG_H
