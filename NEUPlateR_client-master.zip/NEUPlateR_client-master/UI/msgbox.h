/**
* @projectName   NEUERP_client
* @brief         beautify QMessageBox
* @author        chenhanlin
* @date          2018-07-07
*/

#ifndef MSGBOX_H
#define MSGBOX_H

#include <QString>
#include <QWidget>

namespace MsgBox
{
    static const int YES = 0;
    static const int NO = 1;
    void information(const QString &title, const QString &text);
    void error(const QString &title, const QString &text);
    int question(const QString &title, const QString &text);
    void warming(const QString &title, const QString &text);
    void success(const QString &title, const QString &text);
}

#endif // MSGBOX_H
