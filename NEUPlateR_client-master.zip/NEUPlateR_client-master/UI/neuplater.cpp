#include "neuplater.h"
#include "ui_neuplater.h"
#include "iconhelper.h"
#include "login_user.h"
#include "FlowLayout/flowlayout.h"
#include <QPalette>
#include <QColor>
#include <QRect>


NEUPlateR::NEUPlateR(QWidget *parent)
    : QWidget(parent),
      ui(new Ui::NEUPlateR)
{
    ui->setupUi(this);
    this->setWindowTitle("智能高速收费系统-管理端");

    this->setMinimumSize(800, 500);
    auto rect = this->geometry();
    rect.setWidth(1100);
    rect.setHeight(630);
    this->setGeometry(rect);
    ui->btn_back->hide();
}

NEUPlateR::~NEUPlateR()
{
    delete ui;
    delete m_car;
    delete m_payer;
    delete m_person;
    delete m_expense;
    delete m_employee;
}

//初始化页面
void NEUPlateR::init_page()
{
    m_car = new CarManageWidget;
    m_payer = new PayerManageWidget;
    m_person = new PersonalPageWidget;
    m_expense = new ExpenseCenterWidget;

    auto &client = CTcpConnection::get_instance();
    connect(&client, SIGNAL(notify_close()), this, SLOT(close_connection()));
    connect(&client, SIGNAL(notify_error(QString)), this, SLOT(error_arrive(QString)));

    if(LoginUser::get_instance().access_level() > 2){
        m_employee = new EmployeeManageWidget;
        ui->btn_employee->show();
        ui->stackedWidget->insertWidget(5, m_employee);
    }else{
        m_employee = nullptr;
        ui->btn_employee->hide();
    }

    ui->btn_back->setProperty("type", "back");
    connect(ui->btn_back, SIGNAL(clicked()), this, SLOT(buttonClick()));
    //set main page layout
    ui->main_page->setLayout(ui->main_page_layout);
    QSize icoSize(40, 40);
    QSize button_size(250, 80);

    // set main page button
    QList<QToolButton *> tbtns = ui->main_page->findChildren<QToolButton *>();
    FlowLayout *layout = new FlowLayout(button_size, 10, 20, 20);
    foreach (QToolButton *btn, tbtns)
    {
        btn->setIconSize(icoSize);
        btn->setMinimumSize(button_size);
        btn->setCheckable(true);
        connect(btn, SIGNAL(clicked()), this, SLOT(buttonClick()));
        layout->addWidget(btn);
        btn->setProperty("btn_color", "white");
    }
    ui->frame->setLayout(layout);


    this->setProperty("canMove", true);
    this->setWindowFlags(Qt::FramelessWindowHint);

    IconHelper::Instance()->setIcon(ui->btnMenu_Min, QChar(0xf068));
    IconHelper::Instance()->setIcon(ui->btnMenu_Max, QChar(0xf067));
    IconHelper::Instance()->setIcon(ui->btnMenu_Close, QChar(0xf00d));

    ui->labTitle->setFont(QFont("Microsoft Yahei", 9));
    // page0 is the main page
    init_stacked_widget();
    ui->stackedWidget->setCurrentIndex(0);
}

void NEUPlateR::init_stacked_widget()
{
    ui->stackedWidget->insertWidget(1, m_car);
    ui->stackedWidget->insertWidget(2, m_payer);
    ui->stackedWidget->insertWidget(3, m_person);
    ui->stackedWidget->insertWidget(4, m_expense);
}

void NEUPlateR::error_arrive(QString)
{

    MsgBox::error(tr("网络错误"), tr("无法连接至网络，请重试"));
    close();
}

void NEUPlateR::close_connection()
{

    MsgBox::error(tr("网络错误"), tr("与服务器断开连接，请稍后再试。"));
    close();
}

//设置stackedWidget切换的点击事件，根据点击的按钮来确定跳转到哪一个widget。并且要设置按钮对应的状态
void NEUPlateR::buttonClick()
{
    auto *b = (QToolButton*)sender();
    //todo 根据不同的页面来设置
    QPalette palette;
//    ui->labTitle->setAutoFillBackground(true);
    ui->title_widget->setAutoFillBackground(true);
    if(b == ui->btn_back){
        palette.setColor(QPalette::Background, QColor(255,255,255));
        ui->btn_back->hide();
        ui->stackedWidget->setCurrentIndex(0);
    }else{
        palette.setColor(QPalette::Background, QColor(227,229,228));
        ui->btn_back->show();
    }
    ui->title_widget->setPalette(palette);

    if (b == ui->btn_person)
    {
        ui->stackedWidget->setCurrentIndex(3);
    }else if(b == ui->btn_expense){
        ui->stackedWidget->setCurrentIndex(4);
    }else if(b == ui->btn_payer){
        ui->stackedWidget->setCurrentIndex(2);
    }else if(b == ui->btn_car){
        ui->stackedWidget->setCurrentIndex(1);
    }else if(b == ui->btn_employee){
        ui->stackedWidget->setCurrentIndex(5);
    }
}

void NEUPlateR::on_btnMenu_Min_clicked()
{
    showMinimized();
}

void NEUPlateR::on_btnMenu_Max_clicked()
{
    static bool max = false;
    static QRect location = this->geometry();

    if (max)
    {
        this->setGeometry(location);
    }
    else
    {
        location = this->geometry();
        this->setGeometry(qApp->desktop()->availableGeometry());
    }

    this->setProperty("canMove", max);
    max = !max;
}

void NEUPlateR::on_btnMenu_Close_clicked()
{
    close();
}
