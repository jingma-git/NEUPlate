#ifndef NEUPLATER_H
#define NEUPLATER_H

#include <QWidget>
#include <QToolButton>
#include "CarManage/car_manage_widget.h"
#include "PayerManage/payer_manage_widget.h"
#include "PersonalPage/personal_page_widget.h"
#include "ExpenseCenter/expense_center_widget.h"
#include "EmployeeManage/employee_manage_widget.h"

namespace Ui {
class NEUPlateR;
}

class NEUPlateR : public QWidget
{
    Q_OBJECT

public:
    explicit NEUPlateR(QWidget *parent = 0);
    ~NEUPlateR();
    void init_page();

private:
    Ui::NEUPlateR *ui;
    CarManageWidget *m_car;
    PayerManageWidget *m_payer;
    PersonalPageWidget *m_person;
    ExpenseCenterWidget *m_expense;
    EmployeeManageWidget *m_employee;


private slots:
    void buttonClick();
    void init_stacked_widget();
    void error_arrive(QString);
    void close_connection();
private slots:
    void on_btnMenu_Min_clicked();
    void on_btnMenu_Max_clicked();
    void on_btnMenu_Close_clicked();
};

#endif // NEUPLATER_H
