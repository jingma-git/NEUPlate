#ifndef PHOTOTOOL_H
#define PHOTOTOOL_H

#include <QString>

class PhotoTool
{
public:
    static QString save_photo(const QString &photo_data);
    static void delete_photo(const QString &photo_path);
    static QString load_photo(const QString &photo_path);
};

#endif // PHOTOTOOL_H
