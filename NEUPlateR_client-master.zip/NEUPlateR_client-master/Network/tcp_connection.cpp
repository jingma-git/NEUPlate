#include "tcp_connection.h"
#include <QDebug>
#include <QJsonObject>
#include <QJsonDocument>
#include <QByteArray>
#include <QHostAddress>
#include <QStringList>

/**
* @functionName  get_instance
* @Description   get the singleton MainClient class
* @author        chenhanlin
* @date          2018-07-03
* @parameter     void
* @return        void
*/
CTcpConnection &CTcpConnection::get_instance()
{
    static CTcpConnection client;
    return client;
}

/**
* @functionName  connect_to_server
* @Description   connect socket with server
* @author        chenhanlin
* @date          2018-07-03
* @parameter     std::string host, int port
* @return        void
*/
void CTcpConnection::connect_to_server(const QString &host, int port)
{
    m_socket.connectToHost(host, port);
}

/**
* @functionName  send
* @Description   send data in request to server
* @author        chenhanlin
* @date          2018-07-03
* @parameter     Request &req
* @return        void
*/
void CTcpConnection::send(const CRequest &req)
{
    if(!m_socket.isWritable()) emit notify_error(tr("socket is not writable"));
    QString send_data(req.to_json() + "\r\n\r\n");
    m_socket.write(send_data.toUtf8());
    qDebug() << "[Request]:" << send_data;
}

void CTcpConnection::registered(const QString &started_by, const std::function<void(CResponse&)> &callback)
{
    callback_map().insert(std::map<QString, std::function<void(CResponse&)>>::value_type(started_by, callback));
}

std::map<QString, std::function<void (CResponse &)> > &CTcpConnection::callback_map()
{
    static std::map<QString, std::function<void(CResponse&)>> callback;
    return callback;
}

CTcpConnection::CTcpConnection(QObject *parent) : QObject(parent)
{
    connect(&m_socket, SIGNAL(readyRead()), this, SLOT(message_arrive()));
    connect(&m_socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(error_occours()));
    connect(&m_socket, SIGNAL(disconnected()), this, SLOT(connection_close()));
}

CTcpConnection::~CTcpConnection()
{

}

CTcpConnection::CTcpConnection(const CTcpConnection &mainclient)
{

}

CTcpConnection &CTcpConnection::operator =(const CTcpConnection &mainclient)
{

}

/**
* @functionName  connection_close
* @Description   excute in socket close connection
* @author        chenhanlin
* @date          2018-07-03
* @parameter     void
* @return        void
*/
void CTcpConnection::connection_close()
{
    qDebug() << "close connection with " << m_socket.peerAddress().toString() << " :" << m_socket.peerPort();
    m_socket.close();
    emit notify_close();
}

/**
* @functionName  message_arrive
* @Description   receive data from sever and put them into response
* @author        chenhanlin
* @date          2018-07-03
* @parameter     void
* @return        void
*/
void CTcpConnection::message_arrive()
{
    m_cache += m_socket.readAll();
    // split request
    QStringList reqs = m_cache.split("\r\n\r\n");
    // if not receive totally, save into cache
    if(!m_cache.endsWith("\r\n\r\n")){
        m_cache = reqs[reqs.size() - 1];
        for (int i=0; i < reqs.size()-1; i++)
            m_req_queue.push(reqs[i]);
    }else{
        m_cache.clear();
        for (int i=0; i < reqs.size(); i++)
            m_req_queue.push(reqs[i]);
    }
    while (!m_req_queue.empty()) {
        QString message(m_req_queue.front());
        m_req_queue.pop();
        if(message.isEmpty()) continue;
        qDebug() << "[Response]:" << message;
        QJsonDocument json_doc(QJsonDocument::fromJson(message.toUtf8()));
        QJsonObject json(json_doc.object());
        CResponse resp(json);
        auto& callbacks = callback_map();
        auto iter = callbacks.find(resp.started_by());
        if(callbacks.end() != iter){
            (iter->second)(resp);
        }
    }
}

/**
* @functionName  error_occurs
* @Description   send error message to gui class
* @author        chenhanlin
* @date          2018-07-03
* @parameter     void
* @return        void
*/
void CTcpConnection::error_occours()
{
    QString error(m_socket.errorString());
    qDebug() << error;
    emit notify_error(error);
}

/**
* @functionName  send
* @brief         send interface
* @author        chenhanlin
* @date          2018-07-27
* @parameter     const CRequest &req send request
* @return        void
*/
void Network::send(const CRequest &req)
{
    CTcpConnection::get_instance().send(req);
}

/**
* @functionName  connect
* @brief         connect interface
* @author        chenhanlin
* @date          2018-07-27
* @parameter     const QString &host
* 				 int port
* @return        void
*/
void Network::connect(const QString &host, int port)
{
    CTcpConnection::get_instance().connect_to_server(host, port);
}

void Network::registered(const QString &started_by, const std::function<void(CResponse &)> &callback)
{
    CTcpConnection::get_instance().registered(started_by, callback);
}
