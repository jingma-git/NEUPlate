/**
* @projectName   network_client
* @brief         network layer in client, send data and receive data
* @author        chenhanlin
* @date          2018-07-03
*/

#ifndef MAINCLIENT_H
#define MAINCLIENT_H

#include <QObject>
#include <QTcpSocket>
#include <queue>
#include <map>
#include <functional>
#include "request.h"
#include "response.h"

namespace Network {
void send(const CRequest &req);
void connect(const QString &host, int port);
void registered(const QString &started_by, const std::function<void(CResponse&)> &callback);
}

class CTcpConnection : public QObject
{
    Q_OBJECT
public:
    static CTcpConnection &get_instance();
    void connect_to_server(const QString &host, int port);
    void send(const CRequest &req);
    void registered(const QString &started_by, const std::function<void(CResponse&)> &callback);

private:
    QTcpSocket m_socket;
    QString m_cache;
    std::queue<QString> m_req_queue;
    std::map<QString, std::function<void (CResponse&)>> &callback_map();

    explicit CTcpConnection(QObject *parent = nullptr);
    ~CTcpConnection();
    CTcpConnection(const CTcpConnection &mainclient);
    CTcpConnection& operator =(const CTcpConnection &mainclient);
signals:
    void notify_error(QString);
    void notify_close();

private slots:
    void connection_close();
    void message_arrive();
    void error_occours();
};

#endif // MAINCLIENT_H
