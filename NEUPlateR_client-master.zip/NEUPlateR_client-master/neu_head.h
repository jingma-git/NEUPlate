#ifndef NEU_HEAD_H
#define NEU_HEAD_H

#include <QDebug>
#include "status_code.h"
#include "UI/waitingspinnerwidget.h"
#include "UI/msgbox.h"
#include "Network/tcp_connection.h"
#include "Network/request.h"
#include "Network/response.h"
#include "login_user.h"

#endif // NEU_HEAD_H
