#include "login_user.h"
#include <QDebug>

LoginUser::LoginUser()
{

}

LoginUser::~LoginUser()
{

}

int LoginUser::access_level() const
{
    return m_access_level;
}

void LoginUser::set_access_level(int access_level)
{
    m_access_level = access_level;
}

LoginUser &LoginUser::get_instance()
{
    static LoginUser user;
    return user;
}

QString LoginUser::username() const
{
    return m_username;
}

void LoginUser::set_username(const QString &username)
{
    m_username = username;
}
