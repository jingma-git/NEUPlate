#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Network/request.h"
#include <functional>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    Network::registered("main_sayHello", std::bind(&MainWindow::recv_resp, this, std::placeholders::_1));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_send_clicked()
{
    CRequest req;
    req.set_action("sayHello");
    req.put("name", "chenhanlin");
    req.set_started_by("main_sayHello");
    Network::send(req);
}

void MainWindow::error_message(QString error)
{
    this->ui->label->setText(error);
}

void MainWindow::recv_resp(CResponse resp)
{
    this->ui->label->setText(resp.get_string("say"));
}

void MainWindow::close_connection()
{
    this->ui->label->setText("close connection");
}
