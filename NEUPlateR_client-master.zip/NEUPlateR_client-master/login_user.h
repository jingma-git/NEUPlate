#ifndef USERCONTROLLER_H
#define USERCONTROLLER_H

#include <QString>
#include <map>

class LoginUser
{
public:
    static LoginUser &get_instance();

    QString username() const;
    void set_username(const QString &username);

    int access_level() const;
    void set_access_level(int access_level);

private:
    LoginUser();
    ~LoginUser();
    LoginUser(const LoginUser &controller) = delete;
    LoginUser &operator =(const LoginUser &controller) = delete;
    QString m_username;
    int m_access_level;
};

#endif // USERCONTROLLER_H
